
function sq_AddFunctionName(appendage)
{
	appendage.sq_AddFunctionName("proc", "proc_appendage_BigWeaponMastery")
	appendage.sq_AddFunctionName("isDrawAppend", "isDrawAppend_appendage_BigWeaponMastery")
}


function sq_AddEffect(appendage)
{

}


function proc_appendage_BigWeaponMastery(appendage)
{

}

function isDrawAppend_appendage_BigWeaponMastery(appendage)
{
	if(!appendage) {
		return false;
	}
	
	local obj = appendage.getParent();	
	
	return true;
}
