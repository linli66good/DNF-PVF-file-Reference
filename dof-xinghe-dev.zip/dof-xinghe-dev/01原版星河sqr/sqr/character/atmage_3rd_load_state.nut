


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_MAGE, "Character/ATMage/New/ATElementalBomber/ConvergenceReact/ConvergenceReact.nut", "ConvergenceReact", STATE_CONVERGENCEREACT, SKILL_CONVERGENCEREACT);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_MAGE, "Character/ATMage/New/ATElementalBomber/MicroUniverse/MicroUniverse.nut", "MicroUniverse", STATE_MICROUNIVERSE, SKILL_MICROUNIVERSE);







IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_MAGE, "Character/ATMage/New/ATGlacialMaster/GlaciesEdge/GlaciesEdge.nut", "GlaciesEdge", STATE_GLACIESEDGE, SKILL_GLACIESEDGE);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_MAGE, "Character/ATMage/New/ATGlacialMaster/Nastrond/Nastrond.nut", "Nastrond", STATE_NASTROND, SKILL_NASTROND);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_MAGE, "Character/ATMage/New/ATGlacialMaster/TurbulentRumble/TurbulentRumble.nut", "TurbulentRumble", STATE_TURBULENTRUMBLE, SKILL_TURBULENTRUMBLE);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_MAGE, "Character/ATMage/New/ATGlacialMaster/Aracan/Aracan.nut", "Aracan", STATE_ARACAN, SKILL_ARACAN);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_MAGE, "Character/ATMage/New/ATGlacialMaster/BloodStinger/BloodStinger.nut", "BloodStinger", STATE_BLOODSTINGER, SKILL_BLOODSTINGER);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_MAGE, "Character/ATMage/New/ATGlacialMaster/ExtremityPerish/ExtremityPerish.nut", "ExtremityPerish", STATE_EXTREMITYPERISH, SKILL_EXTREMITYPERISH);






IRDSQRCharacter.pushPassiveObj("Character/ATMage/New/ATMagePo/po_ATGlacialMaster.nut", 24337);

