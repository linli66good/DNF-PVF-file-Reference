IRDSQRCharacter.pushScriptFiles("character/atfighter_3rd/atfighter_3rd_header.nut");

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter_3rd/heavenandearth/heavenandearth.nut", "HeavenAndEarth", STATE_HEAVEN_AND_EARTH, SKILL_HEAVEN_AND_EARTH);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter_3rd/glowingtiger/glowingtiger.nut", "GlowingTiger", STATE_GLOWING_TIGER, SKILL_GLOWING_TIGER);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter_3rd/roadtohell/roadtohell.nut", "RoadToHell", STATE_ROAD_TO_HELL, SKILL_ROAD_TO_HELL);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter_3rd/badending/badending.nut", "BadEnding", STATE_BAD_ENDING, SKILL_BAD_ENDING);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter_3rd/deathdoordestroy/deathdoordestroy.nut", "DeathDoorDestroy", STATE_DEATH_DOOR_DESTROY, SKILL_DEATH_DOOR_DESTROY);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter_3rd/stoneshower/stoneshower.nut", "StoneShower", STATE_STONE_SHOWER, SKILL_STONE_SHOWER);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter_3rd/mortalfist/mortalfist.nut", "MortalFist", STATE_MORTAL_FIST, SKILL_MORTAL_FIST);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter_3rd/mortalassault/mortalassault.nut", "MortalAssault", STATE_MORTAL_ASSAULT, SKILL_MORTAL_ASSAULT);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/2_striker/flyingchainkick/flyingchainkick.nut", "flyingchainkick", STATE_FLYINGCHAINKICK, SKILL_FLYINGCHAINKICK);


IRDSQRCharacter.pushPassiveObj("character/atfighter_3rd/po_atfighter.nut", 24320);
