

function checkExecutableSkill_Congest(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(76);
	if (isUse) {
		CreateBuffCutin(obj, "etc/ultimateskillani/atsword_darktempler_neo_buff.ani");
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(102, STATE_PRIORITY_IGNORE_FORCE, true);
		local apPath = "character/atswordman/4_darktempler/congest/ap_congest.nut";
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
		appendage.sq_SetValidTime(obj.sq_GetLevelData(76, 1, sq_GetSkillLevel(obj, 76)));
		appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 76, sq_GetSkillLevel(obj, 76));
		appendage.setEnableIsBuff(true);
		CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
		return true;
	}

	return false;
}


function checkCommandEnable_Congest(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Congest(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(472);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Congest(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}

