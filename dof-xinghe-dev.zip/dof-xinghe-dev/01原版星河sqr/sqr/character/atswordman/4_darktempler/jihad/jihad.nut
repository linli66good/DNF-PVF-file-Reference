
function checkExecutableSkill_Jihad(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(82);
	if (isUse) {
		AIMPOINT_ATSWORDMAN = 82;
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(82, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_Jihad(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Jihad(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.getVar("JihadPos").clear_vector();
			obj.getVar("JihadPos").push_vector(obj.getXPos());
			obj.getVar("JihadPos").push_vector(obj.getYPos());
			obj.getVar("JihadPos").push_vector(0);
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(461);
			obj.sq_PlaySound("SW_JIHAD");
			local castTime = sq_GetCastTime(obj, 75, sq_GetSkillLevel(obj, 75));
			sq_StartDrawCastGauge(obj, castTime, true);
			
			break;
		case 1:
			obj.sq_SetCurrentAnimation(462);
			sq_SetFrameDelayTime(sq_GetCurrentAnimation(obj), 0, 900);
			local customData = 100;
			customData = obj.sq_GetDistancePos(obj.getXPos(), obj.sq_GetDirection(), customData);
			local customData1 = 500;
			local customData2 = 250;
			obj.sq_AddAimPointMark(customData, obj.getYPos(), customData1, customData2);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(463);
			local aimXPos = obj.sq_GetAimPosX(obj.getXPos(), obj.getYPos(), false);
			local aimYPos = obj.sq_GetAimPosY(obj.getXPos(), obj.getYPos(), false);
			obj.sq_RemoveAimPointMark();
			obj.sq_StartWrite();
			obj.sq_WriteDword(82);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(82, -1, 0, getATSwordmanBonus(obj, 1.0, 82)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(82, -1, 1, getATSwordmanBonus(obj, 1.0, 82)));
			obj.sq_WriteDword(obj.sq_GetLevelData(82, 2, sq_GetSkillLevel(obj, 82)));
			obj.sq_WriteDword(obj.sq_GetLevelData(82, 3, sq_GetSkillLevel(obj, 82)));
			sq_SendCreatePassiveObjectPacketPos(obj, 24381, 0, aimXPos, aimYPos, 0);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(464);
			break;
	}
}


function onEndState_Jihad(obj, new_state) {
	if (!obj) return;
	if (new_state != 82) obj.sq_RemoveAimPointMark();
}


function onProc_Jihad(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			local JihadPos_int = obj.getVar("JihadPos").get_vector(0);
			local JihadPos_int1 = obj.getVar("JihadPos").get_vector(1);
			local customData = 4;
			local levelData = obj.sq_GetLevelData(82, 2, sq_GetSkillLevel(obj, 82));
			if (IsInterval_DeusExray(obj, 30)) {
				local JihadPos_int2 = obj.getVar("JihadPos").get_vector(2);
				local loadSlot = obj.sq_GetSkillLoad(65);
				if (!loadSlot) return;
				local loadNum = loadSlot.getRemainLoadNumber();
				if (loadNum < 1) return;
				if (JihadPos_int2 < levelData) {
					obj.getVar("JihadPos").set_vector(2, JihadPos_int2 + 1);
					AtSwordmanDecreaseEvolve(obj);
				}
			}
			break;
	}
}


function onEndCurrentAni_Jihad(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(82, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(82, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(82, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}

