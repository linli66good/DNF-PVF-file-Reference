
function checkExecutableSkill_Destroyer(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(71);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(71, STATE_PRIORITY_IGNORE_FORCE, true);
		obj.getVar("DestroyerCount").clear_vector();
		obj.getVar("DestroyerCount").push_vector(0);
		return true;
	}

	return false;
}


function checkCommandEnable_Destroyer(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Destroyer(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();
	obj.sq_ZStop();
	switch (subState) {
		case 0:
			obj.sq_SetCurrentAnimation(481);
			sq_GetCurrentAnimation(obj).setSpeedRate(300.0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(482);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(483);
			break;
	}
}


function getScrollBasisPos_Destroyer(obj) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	if (!obj.isMyControlObject()) return false;
	local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 300);
	obj.sq_SetCameraScrollPosition(dstPos, obj.getYPos(), 0);
	return true;
}


function onTimeEvent_Destroyer(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	switch (timeEventIndex) {
		case 10:
			if (timeEventCount >= sq_GetIntData(obj, 71, 1)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}


function onProcCon_Destroyer(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local customData = 150;
			local movePos = sq_GetAccel(obj.getZPos(), customData, obj.sq_GetStateTimer(), 150, false);
			sq_setCurrentAxisPos(obj, 2, movePos);
			break;
	}
}


function onEndCurrentAni_Destroyer(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(71, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(71, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}



function onKeyFrameFlag_Destroyer(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:
			local DestroyerCount_int = obj.getVar("DestroyerCount").get_vector(0);
			if (DestroyerCount_int >= sq_GetIntData(obj, 71, 1)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			obj.getVar("DestroyerCount").set_vector(0, DestroyerCount_int + 1);
			obj.sq_StartWrite();
			obj.sq_WriteDword(71);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(71, -1, 1, getATSwordmanBonus(obj, 1.0, 71)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 400, -30, -150);
			break;
		case 1:
			local DestroyerCount_int = obj.getVar("DestroyerCount").get_vector(0);
			if (DestroyerCount_int >= sq_GetIntData(obj, 71, 1)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			obj.getVar("DestroyerCount").set_vector(0, DestroyerCount_int + 1);
			obj.sq_StartWrite();
			obj.sq_WriteDword(71);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(71, -1, 1, getATSwordmanBonus(obj, 1.0, 71)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 250, -30, -150);
			break;
		case 2:
			local DestroyerCount_int = obj.getVar("DestroyerCount").get_vector(0);
			if (DestroyerCount_int >= sq_GetIntData(obj, 71, 1)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			obj.getVar("DestroyerCount").set_vector(0, DestroyerCount_int + 1);
			obj.sq_StartWrite();
			obj.sq_WriteDword(71);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(71, -1, 1, getATSwordmanBonus(obj, 1.0, 71)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 100, -30, -150);
			break;
		case 3:
			local DestroyerCount_int = obj.getVar("DestroyerCount").get_vector(0);
			if (DestroyerCount_int >= sq_GetIntData(obj, 71, 1)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			obj.getVar("DestroyerCount").set_vector(0, DestroyerCount_int + 1);
			obj.sq_StartWrite();
			obj.sq_WriteDword(71);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(71, -1, 1, getATSwordmanBonus(obj, 1.0, 71)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 350, 30, -150);
			break;
		case 4:
			local DestroyerCount_int = obj.getVar("DestroyerCount").get_vector(0);
			if (DestroyerCount_int >= sq_GetIntData(obj, 71, 1)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			obj.getVar("DestroyerCount").set_vector(0, DestroyerCount_int + 1);
			obj.sq_StartWrite();
			obj.sq_WriteDword(71);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(71, -1, 1, getATSwordmanBonus(obj, 1.0, 71)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 200, 30, -150);
			break;
		case 5:
			local DestroyerCount_int = obj.getVar("DestroyerCount").get_vector(0);
			if (DestroyerCount_int >= sq_GetIntData(obj, 71, 1)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			obj.getVar("DestroyerCount").set_vector(0, DestroyerCount_int + 1);
			obj.sq_StartWrite();
			obj.sq_WriteDword(71);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(71, -1, 1, getATSwordmanBonus(obj, 1.0, 71)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 100, 30, -150);
			break;
	}
	return true;
}












