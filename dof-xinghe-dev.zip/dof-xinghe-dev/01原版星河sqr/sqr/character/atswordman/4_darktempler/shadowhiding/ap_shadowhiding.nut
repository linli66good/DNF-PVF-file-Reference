
function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("proc", "proc_appendage_shadowhiding"); }



function proc_appendage_shadowhiding(appendage) {
	if (!appendage || !appendage.isValid()) return;
	local parentObj = appendage.getParent();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	if (!parentObj || sqrChr.getState() == STATE_DIE || sqrChr.isDead()) {
		appendage.setValid(false);
		return;
	}
	sqrChr.setSkillCommandEnable(60, true);
	local useskill = sqrChr.sq_IsEnterSkill(60);
	if (useskill != -1) {
		sqrChr.sq_IntVectClear();
		sqrChr.sq_IntVectPush(2);
		sqrChr.sq_AddSetStatePacket(60, STATE_PRIORITY_IGNORE_FORCE, true);
		appendage.setValid(false);
	}
	return;
}

