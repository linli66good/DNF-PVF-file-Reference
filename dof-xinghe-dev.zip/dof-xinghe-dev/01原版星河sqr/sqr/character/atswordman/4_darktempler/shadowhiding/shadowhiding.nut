
function checkExecutableSkill_ShadowHiding(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(60);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(60, STATE_PRIORITY_IGNORE_FORCE, true);
		obj.getVar("ShadowHiding").clear_vector();
		obj.getVar("ShadowHiding").push_vector(obj.getXPos());
		obj.getVar("ShadowHiding").push_vector(obj.getYPos());
		obj.getVar("ShadowHiding").push_vector(obj.getXPos());
		obj.getVar("ShadowHiding").push_vector(obj.getYPos());
		local apPath = "character/atswordman/4_darktempler/shadowhiding/ap_shadowhiding.nut";
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, true);
		local apInfo = appendage.getAppendageInfo();
		apInfo.setValidTime(obj.sq_GetLevelData(60, 0, sq_GetSkillLevel(obj, 60)));
		return true;
	}

	return false;
}


function checkCommandEnable_ShadowHiding(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_ShadowHiding(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(503);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(504);
			obj.sq_SetStaticMoveInfo(0, 400, 450, true);
			obj.sq_SetStaticMoveInfo(1, 400, 450, true);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			break;
		case 2:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(505);
			break;
	}
}


function onEndCurrentAni_ShadowHiding(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(60, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onProc_ShadowHiding(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 1:
			local ShadowHiding_int = obj.getVar("ShadowHiding").get_vector(2);
			local ShadowHiding_int1 = obj.getVar("ShadowHiding").get_vector(3);
			local ShadowHiding_int2 = obj.getVar("ShadowHiding").get_vector(0);
			local ShadowHiding_int3 = obj.getVar("ShadowHiding").get_vector(1);
			local distance = sq_GetDistance(ShadowHiding_int, ShadowHiding_int1, obj.getXPos(), obj.getYPos(), true);
			local levelData = obj.sq_GetLevelData(60, 0, sq_GetSkillLevel(obj, 60));
			local levelData1 = obj.sq_GetLevelData(60, 1, sq_GetSkillLevel(obj, 60));
			local stateTimer = obj.sq_GetStateTimer();
			local customData = 3;
			if (stateTimer > levelData || distance > levelData1) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(60, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}











