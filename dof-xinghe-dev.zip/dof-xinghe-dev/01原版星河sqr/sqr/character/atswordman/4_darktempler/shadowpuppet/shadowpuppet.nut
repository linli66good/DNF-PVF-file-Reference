
function checkExecutableSkill_ShadowPuppet(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(68);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(68, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_ShadowPuppet(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_ShadowPuppet(obj, state, datas, isResetTimer) {
	if (!obj) return;
	obj.sq_StopMove();
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_SetCurrentAnimation(493);
			obj.sq_PlaySound("SW_SHADOW_PUPPET");
			sq_GetCurrentAnimation(obj).setSpeedRate(200.0);
			if (sq_GetSkillLevel(obj, 77) > 0) break;
			obj.sq_StartWrite();
			obj.sq_WriteDword(68);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(68, -1, 0, getATSwordmanBonus(obj, 1.0, 68)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 400, -3, 0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(494);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(495);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(496);
			local attackRate = obj.sq_GetBonusRateWithPassive(68, -1, 0, getATSwordmanBonus(obj, 1.0, 68));
			local attackRate1 = obj.sq_GetBonusRateWithPassive(68, -1, 2, getATSwordmanBonus(obj, 1.0, 68));
			local customData = attackRate1;
			if (sq_GetSkillLevel(obj, 77) > 0) customData = attackRate + attackRate1;
			obj.sq_StartWrite();
			obj.sq_WriteDword(68);
			obj.sq_WriteDword(1);
			obj.sq_WriteDword(obj.sq_GetLevelData(68, 1, sq_GetSkillLevel(obj, 68)));
			obj.sq_WriteDword(customData);
			obj.sq_WriteDword(sq_GetIntData(obj, 68, 0));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, 0, 68);
			break;
	}
}


function onEndCurrentAni_ShadowPuppet(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(68, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(68, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(68, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}



