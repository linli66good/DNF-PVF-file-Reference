
function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("proc", "proc_appendage_LoyalSlaveDebuff");
	appendage.sq_AddFunctionName("drawAppend", "drawAppend_appendage_LoyalSlaveDebuff");
}


function proc_appendage_LoyalSlaveDebuff(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 40);
	local levelData = sq_GetLevelData(sqrChr, 40, 2, skillLevel);
	local loadSlot = sqrChr.sq_GetSkillLoad(65);
	if (!loadSlot) return;
	local loadNum = loadSlot.getRemainLoadNumber();
	local levelData1 = sq_GetLevelData(sqrChr, 65, 0, sq_GetSkillLevel(sqrChr, 65));
	if (IsInterval_DeadlyCape(parentObj, levelData)) {
		if (loadNum + 1 <= levelData1) loadSlot.increaseLoadCount(1);
	}
}


function drawAppend_appendage_LoyalSlaveDebuff(appendage, isOver, x, y, isFlip) {
	if (!appendage || !appendage.isValid()) return;
	local parentObj = appendage.getParent();
	local width = sq_GetWidthObject(parentObj);
	local height = sq_GetHeightObject(parentObj);
	local screenX = sq_GetScreenXPos(parentObj);
	local customData = 1.3;
	if (height < 120) customData = 1.5;
	local screenY = sq_GetScreenYPos(parentObj) - (height * customData).tointeger();
	local aniPath = "passiveobject/changqing_atswordman/animation/atloyalslave/loyalservant_repeat_body.ani";
	local sq_var = parentObj.getVar();
	local ani = sq_var.GetAnimationMap("LoyalSlaveDebuff", aniPath);
	sq_AnimationProc(ani);
	sq_drawCurrentFrame(ani, screenX, screenY, false);
	return;
}

