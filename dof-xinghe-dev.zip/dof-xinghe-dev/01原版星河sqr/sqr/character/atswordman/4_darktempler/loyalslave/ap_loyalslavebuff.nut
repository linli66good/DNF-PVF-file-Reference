function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_LoyalSlaveBuff");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_LoyalSlaveBuff");
	appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_LoyalSlaveBuff");
}


function onEnd_appendage_LoyalSlaveBuff(appendage) {
	if (!appendage) return;
	local attacker = appendage.sq_GetSourceChrTarget();
}


function onStart_appendage_LoyalSlaveBuff(appendage) {
	if (!appendage) return;
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 40);
	if (skillLevel < 1) return;
	local levelData = sq_GetLevelData(sqrChr, 40, 4, skillLevel) / 10;
	local levelData1 = sq_GetLevelData(sqrChr, 40, 3, skillLevel) / 10;
	local change_appendage = appendage.sq_getChangeStatus("LoyalSlaveBuff");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("LoyalSlaveBuff", sqrChr, sqrChr, 0, 16, false, levelData);
		change_appendage = appendage.sq_AddChangeStatus("LoyalSlaveBuff", sqrChr, sqrChr, 0, 51, false, levelData1);
	} else {
		change_appendage.clearParameter();
		change_appendage.addParameter(16, false, levelData.tofloat());
		change_appendage.addParameter(51, false, levelData1.tofloat());
	}
}


function onAttackParent_appendage_LoyalSlaveBuff(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage) return;
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 40);
	local levelData = sq_GetLevelData(sqrChr, 40, 0, skillLevel);
	local levelData1 = sq_GetLevelData(sqrChr, 40, 1, skillLevel);
	local levelData2 = sq_GetLevelData(sqrChr, 40, 2, skillLevel);
	local staticData = sq_GetIntData(sqrChr, 40, 0) + levelData1;
	local skillLevel1 = sq_GetSkillLevel(sqrChr, 198);
	if (skillLevel1 > 0) {
		local apPath = "character/atswordman/4_darktempler/usir/ap_usir.nut";
		local appendage1 = CNSquirrelAppendage.sq_GetAppendage(damager, apPath);
		if (!appendage1 || !appendage1.isValid()) local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, sqrChr, -1, false, apPath, true);
	}

	if (skillLevel < 1) return;
	local randNum = sq_getRandom(0, 99);
	if (randNum > levelData) return;
	local apPath1 = "character/atswordman/4_darktempler/loyalslave/ap_loyalslavedebuff.nut";
	local apPath2 = "character/atswordman/4_darktempler/loyalslave/ap_loyalslavecool.nut";
	local appendage2 = CNSquirrelAppendage.sq_GetAppendage(damager, apPath1);
	if (!appendage2 || !appendage2.isValid()) {
		local appendage3 = CNSquirrelAppendage.sq_GetAppendage(damager, apPath2);
		if (!appendage3 || !appendage3.isValid()) {
			local appendage4 = CNSquirrelAppendage.sq_AppendAppendage(damager, sqrChr, -1, false, apPath1, true);
			appendage4.getAppendageInfo().setValidTime(levelData1);
			local appendage5 = CNSquirrelAppendage.sq_AppendAppendage(damager, sqrChr, -1, false, apPath2, true);
			appendage5.getAppendageInfo().setValidTime(staticData);
		}
	}
	return;
}


