function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("drawAppend", "drawAppend_appendage_shadowbinding");
	appendage.sq_AddFunctionName("isDrawAppend", "isDrawAppend_appendage_shadowbinding");
}


function isDrawAppend_appendage_shadowbinding(appendage) {
	if (!appendage) return false;
	local parentObj = appendage.getParent();
	if (parentObj.isMyControlObject()) return false;
	return true;
}


function drawAppend_appendage_shadowbinding(appendage, isOver, x, y, isFlip) {
	if (!appendage || !appendage.isValid()) return;
	local parentObj = appendage.getParent()
					  /* 	local width = sq_GetWidthObject(parentObj)
					  local height = sq_GetHeightObject(parentObj);
					  local screenX = sq_GetScreenXPos(parentObj);
					  local customData = 1.3;
					  if(height<120)
							  customData = 1.5;
					  local screenY = sq_GetScreenYPos(parentObj) - (height*customData).tointeger(); */
					  /*
					  local aniPath = "character/swordman/effect/animation/atshadowbinding/monster_shadowbinding_monster_front.ani";
				  local sq_var = parentObj.getVar();
				  local ani = sq_var.GetAnimationMap("Sshadowbinding", aniPath);
				  sq_AnimationProc(ani);
				  sq_drawCurrentFrame(ani, x, y, false); */
					  return;
}
