
function checkExecutableSkill_ShadowBinding(obj) {
	if (!obj) return false;
	local customData = onGetMyPassiveObject_ATSwordman(obj, 24381, 61, 11);
	if (customData) {
		customData.addSetStatePacket(12, null, STATE_PRIORITY_AUTO, false, "");
		return false;
	}

	local isUse = obj.sq_IsUseSkill(61);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(61, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_ShadowBinding(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_ShadowBinding(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			local apPath = "character/atswordman/4_darktempler/shadowbinding/ap_shadowbinding.nut";
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, true);
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_SHADOW_BINDING");
			obj.sq_SetCurrentAnimation(502);
			obj.sq_StartWrite();
			obj.sq_WriteDword(61);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(61, -1, 0, getATSwordmanBonus(obj, 1.0, 61)));
			obj.sq_WriteDword(obj.sq_GetLevelData(61, 2, sq_GetSkillLevel(obj, 61)));
			obj.sq_WriteDword(obj.sq_GetIntData(61, 3));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(61, -1, 1, getATSwordmanBonus(obj, 1.0, 61)));
			obj.sq_WriteDword(obj.getXPos());
			obj.sq_WriteDword(obj.getYPos());
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, -2, 0);
			break;
	}
	
}


function onEndCurrentAni_ShadowBinding(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onProcCon_ShadowBinding(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}



