
function checkExecutableSkill_DeusExray(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(199);
	if (isUse) {
		obj.sq_IsEnterSkillLastKeyUnits(199);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(199, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_DeusExray(obj) {
	if (!obj) return false;
	return true;
}


function onProcCon_DeusExray(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (subState == 1) {
		local levelData = obj.sq_GetLevelData(199, 1, sq_GetSkillLevel(obj, 199));
		local levelData1 = obj.sq_GetLevelData(199, 2, sq_GetSkillLevel(obj, 199));
		local currentAni = sq_GetCurrentAnimation(obj);
		local stateTimer = obj.sq_GetStateTimer();
		local DeusExrayInfo_int = obj.getVar("DeusExrayInfo").get_vector(0);
		local delay = sq_GetDelaySum(currentAni);
		if (IsInterval_DeusExray(obj, sq_GetIntData(obj, 199, 0))) {
			local DeusExrayInfo_int1 = obj.getVar("DeusExrayInfo").get_vector(1);
			local loadSlot = obj.sq_GetSkillLoad(65);
			if (!loadSlot) return;
			local loadNum = loadSlot.getRemainLoadNumber();
			if (loadNum < 1) return;
			if (DeusExrayInfo_int1 < sq_GetIntData(obj, 199, 1)) {
				obj.getVar("DeusExrayInfo").set_vector(1, DeusExrayInfo_int1 + 1);
				AtSwordmanDecreaseEvolve(obj);
			}
		}

		if (!obj.isDownSkillLastKey()) {
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(199, STATE_PRIORITY_IGNORE_FORCE, true);
		} else {
			if (stateTimer > levelData1) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(199, STATE_PRIORITY_IGNORE_FORCE, true);
			}
		}
	}
}


function onSetState_DeusExray(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.getVar("DeusExrayInfo").clear_vector();
			obj.getVar("DeusExrayInfo").push_vector(0);
			obj.getVar("DeusExrayInfo").push_vector(0);
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 3, 200);
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(458);
			obj.sq_PlaySound("SW_EXRAY_01");
			obj.sq_StartWrite();
			obj.sq_WriteDword(199);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(199, -1, 0, getATSwordmanBonus(obj, 1.0, 199)));
			obj.sq_WriteDword(obj.sq_GetLevelData(199, 1, sq_GetSkillLevel(obj, 199)));
			obj.sq_WriteDword(sq_GetIntData(obj, 199, 1));
			obj.sq_WriteDword(sq_GetIntData(obj, 199, 0));
			obj.sq_WriteDword(obj.sq_GetLevelData(199, 3, sq_GetSkillLevel(obj, 199)) / 10);
			obj.sq_WriteDword(obj.sq_GetLevelData(199, 2, sq_GetSkillLevel(obj, 199)) / 10);
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 220, 0, 80);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(459);
			local currentAni = obj.getCurrentAnimation();
			currentAni.setLoop(true);
			local levelData = obj.sq_GetLevelData(199, 1, sq_GetSkillLevel(obj, 199));
			sq_SetFrameDelayTime(currentAni, 0, levelData);
			break;
		case 2:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 8, 400);
			obj.sq_SetCurrentAnimation(460);
			break;
	}
	
}


function onEndCurrentAni_DeusExray(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(199, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function IsInterval_DeusExray(obj, timeGap) {
	if (!obj) return false;
	local TimerDeusExray_clock = obj.getVar("TimerDeusExray").get_ct_vector(0);
	if (!TimerDeusExray_clock) {
		obj.getVar("TimerDeusExray").clear_ct_vector();
		obj.getVar("TimerDeusExray").push_ct_vector();
		TimerDeusExray_clock = obj.getVar("TimerDeusExray").get_ct_vector(0);
		TimerDeusExray_clock.Reset();
		TimerDeusExray_clock.Start(10000, 0);
		return true;
	}

	local customData = TimerDeusExray_clock.Get();
	if (customData > timeGap) {
		TimerDeusExray_clock.Reset();
		TimerDeusExray_clock.Start(10000, 0);
		return true;
	}
	return false;
}

