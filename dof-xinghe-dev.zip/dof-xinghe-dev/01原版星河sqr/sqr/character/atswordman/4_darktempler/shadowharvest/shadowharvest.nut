
function checkExecutableSkill_ShadowHarvest(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(251);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(251, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_ShadowHarvest(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_ShadowHarvest(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(498);
			break;
		case 1:

			break;
	}
}


function onEndCurrentAni_ShadowHarvest(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (obj.getZPos() > 3) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			} else
				obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_USER, true);
			break;
	}
}


function onKeyFrameFlag_ShadowHarvest(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 5, 200);
			obj.sq_StartWrite();
			obj.sq_WriteDword(64);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(sq_GetIntData(obj, 251, 4));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 100, 0, 0 - obj.getZPos());
			obj.sq_StartWrite();
			obj.sq_WriteDword(64);
			obj.sq_WriteDword(1);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(251, -1, 6, getATSwordmanBonus(obj, 1.0, 251)));
			obj.sq_WriteDword(sq_GetIntData(obj, 251, 3));
			obj.sq_WriteDword(sq_GetIntData(obj, 251, 4));
			obj.sq_WriteDword(sq_GetIntData(obj, 251, 5));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(251, -1, 0, getATSwordmanBonus(obj, 1.0, 251)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 100, 0, 0 - obj.getZPos());
			break;
	}
	return true;
}
