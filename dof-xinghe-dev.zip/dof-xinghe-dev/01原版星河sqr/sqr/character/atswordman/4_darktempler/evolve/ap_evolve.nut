function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_evolve"); }



function onAttackParent_appendage_evolve(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local colObj = sq_GetCNRDObjectToCollisionObject(realAttacker);
	local colObjId = colObj.getCollisionObjectIndex();
	local skill_int = colObj.getVar("skill").get_vector(0);
	if (colObjId == 24381 && (skill_int == 75 || skill_int == 59)) return;
	AtSwordmanAddEvolve(sqrChr);
}

