
function checkExecutableSkill_SoulDrain(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(59);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(59, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_SoulDrain(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_SoulDrain(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(507);
			obj.sq_StartWrite();
			obj.sq_WriteDword(59);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetLevelData(59, 0, sq_GetSkillLevel(obj, 59)));
			obj.sq_WriteDword(obj.sq_GetLevelData(59, 1, sq_GetSkillLevel(obj, 59)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(59, -1, 3, getATSwordmanBonus(obj, 1.0, 59)));
			obj.sq_WriteDword(obj.sq_GetLevelData(59, 4, sq_GetSkillLevel(obj, 59)));
			obj.sq_WriteDword(obj.sq_GetLevelData(59, 2, sq_GetSkillLevel(obj, 59)));
			obj.sq_WriteDword(sq_GetIntData(obj, 59, 0));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, -1, 0);
			break;
		case 1:

			break;
	}
	
}


function onEndCurrentAni_SoulDrain(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}



