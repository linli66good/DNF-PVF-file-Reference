
function checkExecutableSkill_StarFall(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(73);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(73, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_StarFall(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_StarFall(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(471);
			break;
	}
	
}


function onEndCurrentAni_StarFall(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onKeyFrameFlag_StarFall(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 1:
			local staticData = sq_GetIntData(obj, 73, 0);
			ObjFindTarget(obj, staticData);
			local levelData = GetObjFindTargets(obj, obj.sq_GetLevelData(73, 0, sq_GetSkillLevel(obj, 73)));
			obj.sq_StartWrite();
			obj.sq_WriteDword(73);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(staticData);
			obj.sq_WriteDword(obj.sq_GetLevelData(73, 0, sq_GetSkillLevel(obj, 73)) - 1);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(73, -1, 1, getATSwordmanBonus(obj, 1.0, 73)));
			obj.sq_WriteDword(obj.getXPos());
			if (levelData) {
				obj.sq_WriteDword(sq_GetObjectId(levelData));
				sq_SendCreatePassiveObjectPacketPos(obj, 24381, 0, levelData.getXPos(), levelData.getYPos(), 0);
			} else {
				obj.sq_WriteDword(-1);
				obj.sq_SendCreatePassiveObjectPacket(24381, 0, 200, -2, 0);
			}

			break;
	}
	return true;
}

