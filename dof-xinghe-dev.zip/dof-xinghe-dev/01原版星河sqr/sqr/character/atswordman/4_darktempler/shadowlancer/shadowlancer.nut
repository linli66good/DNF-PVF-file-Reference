
function checkExecutableSkill_ShadowLancer(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(250);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(250, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_ShadowLancer(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_ShadowLancer(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(500);
			obj.sq_PlaySound("SW_SHADOW_LANCER");
			break;
		case 1:
			obj.sq_SetCurrentAnimation(501);
			obj.sq_StartWrite();
			obj.sq_WriteDword(63);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(250, -1, 0, getATSwordmanBonus(obj, 1.0, 250)));
			obj.sq_WriteDword(sq_GetIntData(obj, 250, 4));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, 0, 60);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 150);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(dstPos);
			break;
	}
}


function onEndCurrentAni_ShadowLancer(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(250, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(200);
			obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onProc_ShadowLancer(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 1:
			local sq_var_int = obj.getVar().get_vector(0);
			local movePos = sq_GetAccel(obj.getXPos(), sq_var_int, obj.sq_GetStateTimer(), 300, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
	}
}

