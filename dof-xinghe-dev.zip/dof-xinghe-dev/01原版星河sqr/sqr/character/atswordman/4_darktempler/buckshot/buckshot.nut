
function checkExecutableSkill_BuckShot(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(75);
	if (isUse) {
		obj.getVar("BuckShot_Boss").clear_vector();
		obj.getVar("BuckShot_Named").clear_vector();
		obj.getVar("BuckShot_Mons").clear_vector();
		BuckShot_FindEnermy(obj, sq_GetIntData(obj, 75, 1));
		obj.sq_StartWrite();
		obj.sq_WriteDword(75);
		obj.sq_WriteDword(0);
		obj.sq_WriteDword(sq_GetIntData(obj, 75, 3));
		obj.sq_WriteDword(obj.sq_GetLevelData(75, 0, sq_GetSkillLevel(obj, 75)));
		obj.sq_WriteDword(obj.sq_GetLevelData(75, 1, sq_GetSkillLevel(obj, 75)));
		obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(75, -1, 2, getATSwordmanBonus(obj, 1.0, 75)));
		obj.sq_WriteDword(sq_GetIntData(obj, 75, 13));
		obj.sq_SendCreatePassiveObjectPacket(24381, 0, -80, 0, 75);
	}

	return false;
}


function checkCommandEnable_BuckShot(obj) {
	if (!obj) return false;
	local loadSlot = obj.sq_GetSkillLoad(65);
	if (!loadSlot) return false;
	local loadNum = loadSlot.getRemainLoadNumber();
	if (loadNum < 1) return false;
	return true;
}


function BuckShot_FindEnermy(obj, range) {
	local objectManager = obj.getObjectManager();
	for (local objectNumber = 0; objectNumber < objectManager.getCollisionObjectNumber(); ++objectNumber) {
		local object = objectManager.getCollisionObject(objectNumber);
		local distFromObj = sq_GetDistanceObject(obj, object, false);
		if (object && obj.isEnemy(object) && distFromObj <= range && object.isObjectType(OBJECTTYPE_ACTIVE) && object.isInDamagableState(obj) && IsFrontOf(obj, object)) {
			local zPos = object.getZPos() + object.getObjectHeight() / 2;
			local aniPath = "passiveobject/changqing_atswordman/Animation/ATBuckShot/BuckshotTarget_Eff_B.ani";
			DarktemplerCreateAniPooledObj(object, aniPath, true, true, object.getXPos(), object.getYPos(), zPos, 1.0);
			local pObjId = sq_GetObjectId(object);
			object = sq_GetCNRDObjectToMonster(object);
			if (sq_IsBoss(object))
				obj.getVar("BuckShot_Boss").push_vector(pObjId);
			else {
				if (sq_IsNamed(object))
					obj.getVar("BuckShot_Named").push_vector(pObjId);
				else
					obj.getVar("BuckShot_Mons").push_vector(pObjId);
			}
		}
	}
	return;
}









