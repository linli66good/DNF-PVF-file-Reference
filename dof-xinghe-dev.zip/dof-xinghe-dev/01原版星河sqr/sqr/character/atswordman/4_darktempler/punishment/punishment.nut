
function checkExecutableSkill_Punishment(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(81);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(81, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_Punishment(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Punishment(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(466);
			obj.sq_PlaySound("SW_PUNISHMENT");
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 250);
			local dstPos1 = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 500);
			obj.getVar("PunishmentInfo").clear_vector();
			obj.getVar("PunishmentInfo").push_vector(dstPos);
			obj.getVar("PunishmentInfo").push_vector(obj.getXPos());
			obj.getVar("PunishmentInfo").push_vector(dstPos1);
			local dstPos2 = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 250);
			obj.getVar("PunishmentInfo2").clear_vector();
			obj.getVar("PunishmentInfo2").push_vector(dstPos2);
			local customData = 0;
			for (local levelData = 0; levelData < obj.sq_GetLevelData(81, 2, sq_GetSkillLevel(obj, 81)); levelData++) {
				local loadSlot = obj.sq_GetSkillLoad(65);
				if (!loadSlot) return true;
				local loadNum = loadSlot.getRemainLoadNumber();
				if (loadNum < 1) break;
				AtSwordmanDecreaseEvolve(obj);
				customData++;
			}
			obj.getVar("PunishmentInfo").push_vector(customData);
			obj.sq_StartWrite();
			obj.sq_WriteDword(81);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(sq_GetIntData(obj, 81, 0));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(81, -1, 0, getATSwordmanBonus(obj, 1.0, 81)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(81, -1, 1, getATSwordmanBonus(obj, 1.0, 81)));
			obj.sq_WriteDword(obj.sq_GetLevelData(81, 2, sq_GetSkillLevel(obj, 81)));
			obj.sq_WriteDword(obj.sq_GetLevelData(81, 3, sq_GetSkillLevel(obj, 81)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 250, -5, 0);
			sq_flashScreen(obj, 15, 1400, 15, 150, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.setTimeEvent(0, 4000, 1, false);
			break;
		case 1:
			obj.sq_PlaySound("SW_PUNISHMENT_FIN");
			obj.sq_SetCurrentAnimation(467);
			sq_flashScreen(obj, 15, 1400, 15, 255, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.setTimeEvent(0, 1200, 1, false);
			obj.sq_StartWrite();
			obj.sq_WriteDword(81);
			obj.sq_WriteDword(2);
			obj.sq_WriteDword(sq_GetIntData(obj, 81, 0));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(81, -1, 0, getATSwordmanBonus(obj, 1.0, 81)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(81, -1, 1, getATSwordmanBonus(obj, 1.0, 81)));
			obj.sq_WriteDword(obj.sq_GetLevelData(81, 2, sq_GetSkillLevel(obj, 81)));
			obj.sq_WriteDword(obj.sq_GetLevelData(81, 3, sq_GetSkillLevel(obj, 81)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 250, -3, 80);
			break;
	}
}


function onTimeEvent_Punishment(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	switch (timeEventIndex) {
		case 0:
			sq_flashScreen(obj, 200, 100, 100, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_SPACE_DISTORT, ENUM_DRAWLAYER_CONTACT);
			break;
		case 1:

			break;
	}
}


function onProc_Punishment(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local currentAni = sq_GetCurrentAnimation(obj);
	local stateTimer = obj.sq_GetStateTimer();
	local delay = sq_GetDelaySum(currentAni);
	switch (subState) {
		case 0:
			if (stateTimer > 1160) {
				local PunishmentInfo_int = obj.getVar("PunishmentInfo").get_vector(0);
				local movePos = sq_GetAccel(obj.getXPos(), PunishmentInfo_int, stateTimer, 100, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			}
			if (stateTimer > 3140) {
				local PunishmentInfo_int = obj.getVar("PunishmentInfo").get_vector(2);
				local movePos = sq_GetAccel(obj.getXPos(), PunishmentInfo_int, stateTimer, 100, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			}
			if (stateTimer > 3940) {
				local PunishmentInfo_int = obj.getVar("PunishmentInfo").get_vector(1);
				local movePos = sq_GetAccel(obj.getXPos(), PunishmentInfo_int, stateTimer, 100, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			}
			if (stateTimer > 4140) {
				local PunishmentInfo_int = obj.getVar("PunishmentInfo").get_vector(2);
				local movePos = sq_GetAccel(obj.getXPos(), PunishmentInfo_int, stateTimer, 100, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			}
			if (stateTimer > 4540) {
				local PunishmentInfo_int = obj.getVar("PunishmentInfo").get_vector(1);
				local movePos = sq_GetAccel(obj.getXPos(), PunishmentInfo_int, stateTimer, 200, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			}
			break;
		case 1:

			break;
	}
}


function onEndCurrentAni_Punishment(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(81, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}



function getScrollBasisPos_Punishment(obj) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	if (!obj.isMyControlObject()) return false;
	switch (subState) {
		case 0:
			local PunishmentInfo2_int = obj.getVar("PunishmentInfo2").get_vector(0);
			obj.sq_SetCameraScrollPosition(PunishmentInfo2_int, obj.getYPos(), 0);
			break;
		case 1:

			break;
	}
	return true;
}



function onKeyFrameFlag_Punishment(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 20:
			sq_flashScreen(obj, 15, 4040, 15, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_StartWrite();
			obj.sq_WriteDword(81);
			obj.sq_WriteDword(1);
			obj.sq_WriteDword(sq_GetIntData(obj, 81, 0));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(81, -1, 0, getATSwordmanBonus(obj, 1.0, 81)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(81, -1, 1, getATSwordmanBonus(obj, 1.0, 81)));
			obj.sq_WriteDword(obj.sq_GetLevelData(81, 2, sq_GetSkillLevel(obj, 81)));
			obj.sq_WriteDword(obj.sq_GetLevelData(81, 3, sq_GetSkillLevel(obj, 81)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, -3, 80);
			break;
	}
	return true;
}


function onTimeEvent_Punishment(obj, timeEventIndex, timeEventCount) {
	if (!obj) return false;
	if (!obj.isMyControlObject()) return false;
	switch (timeEventIndex) {
		case 0:

			break;
		case 1:

			break;
		case 2:

			break;
	}
}















