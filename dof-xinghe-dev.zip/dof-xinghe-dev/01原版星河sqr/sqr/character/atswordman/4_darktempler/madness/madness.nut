
function checkExecutableSkill_Madness(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(72);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(72, STATE_PRIORITY_IGNORE_FORCE, true);
		obj.getVar("Madness_Uid").clear_vector();
		return true;
	}

	return false;
}


function checkCommandEnable_Madness(obj) {
	if (!obj) return false;
	local loadSlot = obj.sq_GetSkillLoad(65);
	if (!loadSlot) return false;
	local loadNum = loadSlot.getRemainLoadNumber();
	local levelData = obj.sq_GetLevelData(72, 0, sq_GetSkillLevel(obj, 72));
	local levelData1 = obj.sq_GetLevelData(77, 1, sq_GetSkillLevel(obj, 77));
	if (sq_GetSkillLevel(obj, 77) > 0) levelData = (levelData * (1.0 + (levelData1 / 100.0))).tointeger();
	if (loadNum < levelData) return false;
	return true;
}


function onSetState_Madness(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(506);
			obj.sq_PlaySound("SW_MADNESS");
			break;
	}
	
}


function onEndCurrentAni_Madness(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onKeyFrameFlag_Madness(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:
			obj.sq_StartWrite();
			obj.sq_WriteDword(72);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(sq_GetIntData(obj, 72, 0));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(72, -1, 1, getATSwordmanBonus(obj, 1.0, 72)));
			obj.sq_WriteDword(sq_GetIntData(obj, 72, 7));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, sq_GetIntData(obj, 72, 0), 0, 0);
			break;
		case 1:
			local direction = obj.getDirection();
			local customData = 190;
			if (direction == 0) customData = -customData;
			local levelData = obj.sq_GetLevelData(72, 0, sq_GetSkillLevel(obj, 72));
			local Madness_Uid_size = obj.getVar("Madness_Uid").size_vector();
			if (Madness_Uid_size > 0)
				for (local customData1 = 0; customData1 < levelData; customData1++) AtSwordmanDecreaseEvolve(obj);
			local customData = 0;
			for (local customData1 = 0; customData1 < Madness_Uid_size; customData1++) {
				customData++;
				obj.sq_StartWrite();
				obj.sq_WriteDword(72);
				obj.sq_WriteDword(1);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(72, -1, 1, getATSwordmanBonus(obj, 1.0, 72)));
				obj.sq_WriteDword(obj.getVar("Madness_Uid").get_vector(customData1));
				obj.sq_WriteDword(customData);
				obj.sq_SendCreatePassiveObjectPacket(24381, 0, -50, 0, 60);
			}

			break;
	}
	return true;
}


function DarktemplerCreateAniPooledObjEX(obj, aniPath, moveWithParent, doneDestroy, xPos, yPos, zPos, aniSize) {
	local ani = sq_CreateAnimation("", aniPath);
	ani.setImageRateFromOriginal(aniSize, aniSize);
	local pooledObj = sq_CreatePooledObject(ani, doneDestroy);
	obj.getVar("aniobj").push_obj_vector(pooledObj);
	pooledObj.setCurrentPos(xPos, yPos, zPos);
	if (moveWithParent) sq_moveWithParent(obj, pooledObj);
	sq_SetCurrentDirection(pooledObj, obj.getDirection());
	sq_AddObject(obj, pooledObj, OBJECTTYPE_DRAWONLY, false);
}


function getScrollBasisPos_Madness(obj) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	if (!obj.isMyControlObject()) return false;
	local staticData = sq_GetIntData(obj, 72, 0);
	if (obj.getDirection() == 0) staticData = -staticData;
	obj.sq_SetCameraScrollPosition(obj.getXPos() + staticData, obj.getYPos(), 0);
	return true;
}











