function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_madness");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_madness");
	appendage.sq_AddFunctionName("onVaildTimeEnd", "onVaildTimeEnd_appendage_madness");
}


function onEnd_appendage_madness(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	destroyObjectByVar(parentObj, "aniobj");
}


function onVaildTimeEnd_appendage_madness(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	destroyObjectByVar(parentObj, "aniobj");
}
