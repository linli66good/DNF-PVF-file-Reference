
function checkExecutableSkill_Scaffold(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(252);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(252, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_Scaffold(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Scaffold(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(497);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Scaffold(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_StartWrite();
			obj.sq_WriteDword(67);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(252, -1, 1, getATSwordmanBonus(obj, 1.0, 252)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(252, -1, 2, getATSwordmanBonus(obj, 1.0, 252)));
			obj.sq_WriteDword(obj.sq_GetLevelData(252, 0, sq_GetSkillLevel(obj, 252)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 30, 0, 67);
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


