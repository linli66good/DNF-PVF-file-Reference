
function checkExecutableSkill_Immolation(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(168);
	if (isUse) {
		obj.sq_IsEnterSkillLastKeyUnits(168);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(168, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}


function checkCommandEnable_Immolation(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Immolation(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.getVar("ImmolationInfo").clear_vector();
			obj.getVar("ImmolationInfo").push_vector(0);
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(468);
			obj.sq_SetCurrentAttackInfo(232);
			local currentAni = obj.getCurrentAnimation();
			sq_ClearAttackBox(currentAni);
			obj.sq_SetCurrentAttackBonusRate(obj.sq_GetBonusRateWithPassive(168, -1, 0, getATSwordmanBonus(obj, 1.0, 168)));
			local skillLevel = sq_GetSkillLevel(obj, 77);
			local customData = 0.0;
			if (skillLevel > 0) customData = obj.sq_GetLevelData(77, 3, skillLevel) / 100.0;
			local staticData = (sq_GetIntData(obj, 168, 3) * (1.0 + customData)).tointeger();
			obj.setTimeEvent(10, staticData, 999, true);
			obj.sq_StartWrite();
			obj.sq_WriteDword(168);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(sq_GetIntData(obj, 168, 1));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(168, -1, 0, getATSwordmanBonus(obj, 1.0, 168)));
			obj.sq_WriteDword(sq_GetIntData(obj, 168, 6));
			obj.sq_WriteDword(sq_GetIntData(obj, 168, 2));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(168, -1, 2, getATSwordmanBonus(obj, 1.0, 168)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(168, -1, 3, getATSwordmanBonus(obj, 1.0, 168)));
			obj.sq_WriteDword(staticData);
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, 0, 0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(469);
			obj.sq_SetCurrentAttackInfo(232);
			local currentAni = obj.getCurrentAnimation();
			sq_ClearAttackBox(currentAni);
			obj.sq_SetCurrentAttackBonusRate(obj.sq_GetBonusRateWithPassive(168, -1, 0, getATSwordmanBonus(obj, 1.0, 168)));
			break;
		case 2:
			sq_SetMyShake(obj, 3, 200);
			obj.stopTimeEvent(10);
			obj.sq_SetCurrentAnimation(470);
			break;
	}
	
}


function onProcCon_Immolation(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (subState == 1) {
		local currentAni = sq_GetCurrentAnimation(obj);
		local stateTimer = obj.sq_GetStateTimer();
		local skillLevel = sq_GetSkillLevel(obj, 168);
		local staticData = sq_GetIntData(obj, 168, 6);
		local staticData1 = sq_GetIntData(obj, 168, 2);
		obj.getVar("ImmolationInfo").set_vector(0, stateTimer);
		if (stateTimer > staticData) {
			if (!obj.isDownSkillLastKey()) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(168, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				if (stateTimer > staticData1) {
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(2);
					obj.sq_AddSetStatePacket(168, STATE_PRIORITY_IGNORE_FORCE, true);
				}
			}
		}
	}
}


function onAttack_Immolation(obj, damager, boundingBox, isStuck) {
	if (!obj) return;
	local levelData = obj.sq_GetLevelData(168, 1, sq_GetSkillLevel(obj, 168));
	sq_sendSetActiveStatusPacket(damager, obj, ACTIVESTATUS_SLOW, 100.0, levelData, false, sq_GetIntData(obj, 168, 1));
	local apPath = "character/atswordman/4_darktempler/immolation/ap_immolation.nut";
	local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
	if (sq_IsHoldable(obj, damager) && !sq_IsFixture(damager))
		if (appendage) {
			sq_MoveToAppendageForce(damager, obj, obj, 0, 0, damager.getZPos(), 3000, true, appendage, true);
			local apInfo = appendage.getAppendageInfo();
			apInfo.setValidTime(600);
		}
}


function onTimeEvent_Immolation(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	switch (timeEventIndex) {
		case 10:
			obj.resetHitObjectList();
			break;
	}
}


function onEndCurrentAni_Immolation(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(168, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(168, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}

