function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("getImmuneTypeDamageRate", "getImmuneTypeDamageRate_appendage_Usir"); }


function getImmuneTypeDamageRate_appendage_Usir(appendage, damageRate, attacker) {
	if (!appendage) return damageRate;
	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 198);
	local levelData = sq_GetLevelData(sqrChr, 198, 2, skillLevel) / 10;
	return damageRate + levelData;
}
