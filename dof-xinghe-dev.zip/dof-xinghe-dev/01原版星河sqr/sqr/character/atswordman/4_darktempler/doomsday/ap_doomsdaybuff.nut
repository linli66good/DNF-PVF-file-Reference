function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onStart", "onStart_appendage_Doomsday"); }

function onStart_appendage_Doomsday(appendage) {
	if (!appendage) return;
	local attacker = appendage.sq_GetSourceChrTarget();
}


