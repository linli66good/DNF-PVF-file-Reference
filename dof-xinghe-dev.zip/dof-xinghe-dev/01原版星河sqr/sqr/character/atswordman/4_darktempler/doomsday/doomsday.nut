
function checkExecutableSkill_Doomsday(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(74);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(74, STATE_PRIORITY_IGNORE_FORCE, true);
		obj.getVar("DoomsdayEnermy").clear_vector();
		if (sq_GetSkillLevel(obj, 74) > 2) {
			local levelData = obj.sq_GetLevelData(74, 5, sq_GetSkillLevel(obj, 74));
			local levelData1 = obj.sq_GetLevelData(74, 4, sq_GetSkillLevel(obj, 74)) / 10;
			local appendage = sq_CreateChangeStatus(16, false, levelData1.tofloat(), levelData);
			appendage.sq_Append(obj, obj);
		}

		return true;
	}

	return false;
}


function checkCommandEnable_Doomsday(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Doomsday(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	local customData = 0;
	if (sq_GetSkillLevel(obj, 74) > 5) customData = obj.sq_GetLevelData(74, 10, sq_GetSkillLevel(obj, 74)) / 100.0;
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(473);
			obj.sq_PlaySound("SW_DOOMSDAY");
			obj.setTimeEvent(10, 500, 1, false);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 100);
			local dstPos1 = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -26);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(dstPos);
			obj.getVar().push_vector(dstPos1);
			obj.sq_SetCurrentAttackInfo(119);
			obj.sq_SetCurrentAttackBonusRate(obj.sq_GetBonusRateWithPassive(74, -1, 0, getATSwordmanBonus(obj, 1.0, 74) + customData));
			break;
		case 1:
			obj.sq_SetCurrentAnimation(474);
			obj.sq_SetCurrentAttackInfo(120);
			obj.sq_SetCurrentAttackBonusRate(obj.sq_GetBonusRateWithPassive(74, -1, 1, getATSwordmanBonus(obj, 1.0, 74) + customData));
			break;
		case 2:
			obj.sq_SetCurrentAnimation(475);
			obj.sq_SetCurrentAttackInfo(120);
			obj.sq_SetCurrentAttackBonusRate(obj.sq_GetBonusRateWithPassive(74, -1, 1, getATSwordmanBonus(obj, 1.0, 74) + customData));
			break;
		case 3:
			obj.sq_SetCurrentAnimation(476);
			obj.sq_SetCurrentAttackInfo(120);
			obj.sq_SetCurrentAttackBonusRate(obj.sq_GetBonusRateWithPassive(74, -1, 1, getATSwordmanBonus(obj, 1.0, 74) + customData));
			break;
		case 4:
			obj.sq_SetCurrentAnimation(477);
			obj.sq_SetCurrentAttackInfo(120);
			obj.sq_SetCurrentAttackBonusRate(obj.sq_GetBonusRateWithPassive(74, -1, 1, getATSwordmanBonus(obj, 1.0, 74) + customData));
			break;
		case 5:
			obj.sq_SetCurrentAnimation(478);
			break;
		case 6:
			obj.sq_SetCurrentAnimation(479);
			break;
		case 7:
			obj.sq_SetCurrentAnimation(480);
			obj.sq_SetCurrentAttackInfo(120);
			local attackRate = obj.sq_GetBonusRateWithPassive(74, -1, 9, getATSwordmanBonus(obj, 1.0, 74) + customData);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 400);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(dstPos);
			obj.getVar().push_vector(obj.getXPos());
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local staticData = obj.sq_GetIntData(74, 20) + 1;
			obj.sq_SetCurrentAttackBonusRate(attackRate * staticData);
			break;
	}
	
}



function getScrollBasisPos_Doomsday(obj) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	if (!obj.isMyControlObject()) return false;
	switch (subState) {
		case 0:
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 220);
			obj.sq_SetCameraScrollPosition(dstPos, obj.getYPos(), 0);
			break;
		case 4:

			break;
		case 5:

			break;
		case 6:

			break;
		case 7:

			break;
	}

	return true;
}


function onEndCurrentAni_Doomsday(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(74, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			sq_SetMyShake(obj, 8, 200);
			sq_flashScreen(obj, 10, 50, 10, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(74, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			sq_SetMyShake(obj, 4, 200);
			sq_flashScreen(obj, 10, 50, 10, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(74, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			sq_SetMyShake(obj, 4, 200);
			sq_flashScreen(obj, 10, 50, 10, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(74, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			sq_SetMyShake(obj, 4, 200);
			sq_flashScreen(obj, 10, 50, 10, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(74, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(74, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 6:
			sq_SetMyShake(obj, 11, 300);
			sq_flashScreen(obj, 10, 100, 10, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(7);
			obj.sq_AddSetStatePacket(74, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 7:
			if (sq_GetSkillLevel(obj, 74) > 8) {
				local levelData = obj.sq_GetLevelData(74, 8, sq_GetSkillLevel(obj, 74));
				local apPath = "character/atswordman/4_darktempler/doomsday/ap_doomsdaybuff.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
				appendage.sq_SetValidTime(levelData);
				appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 74, sq_GetSkillLevel(obj, 74));
				appendage.setEnableIsBuff(true);
				CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
			}
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onTimeEvent_Doomsday(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	switch (timeEventIndex) {
		case 10:
			local customData = 0;
			if (sq_GetSkillLevel(obj, 74) > 5) customData = obj.sq_GetLevelData(74, 10, sq_GetSkillLevel(obj, 74)) / 100.0;
			sq_SetMyShake(obj, 6, 500);
			sq_flashScreen(obj, 10, 50, 10, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_StartWrite();
			obj.sq_WriteDword(74);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(74, -1, 0, getATSwordmanBonus(obj, 1.0, 74) + customData));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(74, -1, 9, getATSwordmanBonus(obj, 1.0, 74) + customData));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 200, 0, 74);
			break;
		case 11:
			local customData = 0;
			if (sq_GetSkillLevel(obj, 74) > 5) customData = obj.sq_GetLevelData(74, 10, sq_GetSkillLevel(obj, 74)) / 100.0;
			obj.sq_SetCurrentAttackBonusRate(obj.sq_GetBonusRateWithPassive(74, -1, 3, getATSwordmanBonus(obj, 1.0, 74) + customData));
			for (local customData1 = 0; customData1 < obj.getVar("DoomsdayEnermy").size_vector(); customData1++) {
				local object = sq_GetObjectByObjectId(obj, obj.getVar("DoomsdayEnermy").get_vector(customData1));
				local zPos = object.getZPos() + object.getObjectHeight() / 2;
				local aniPath = "character/swordman/effect/animation/atsouldrain/loopboom_01.ani";
				DarktemplerCreateAniPooledObj(object, aniPath, true, true, object.getXPos(), object.getYPos(), zPos, 1.0);
				sq_SendHitObjectPacket(obj, object, 0, 0, zPos);
			}
			break;
	}
}


function onProc_Doomsday(obj) {
	if (!obj) return;
	local customData = 1;
	if (obj.getDirection() == 0) customData = -customData;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local sq_var_int = obj.getVar().get_vector(0);
			local sq_var_int1 = obj.getVar().get_vector(1);
			if (obj.sq_GetStateTimer() > 200) {
				local movePos = sq_GetAccel(obj.getXPos(), sq_var_int, obj.sq_GetStateTimer(), 280, false);
				sq_setCurrentAxisPos(obj, 0, movePos);
				sq_SimpleMoveToNearMovablePos(obj, 1000);
			}

			if (obj.sq_GetStateTimer() >= 1300) {
				local movePos = sq_GetAccel(obj.getXPos(), sq_var_int1, obj.sq_GetStateTimer(), 280, false);
				sq_setCurrentAxisPos(obj, 0, movePos);
				sq_SimpleMoveToNearMovablePos(obj, 1000);
			}
			break;
		case 7:
			local sq_var_int = obj.getVar().get_vector(0);
			local movePos = sq_GetAccel(obj.getXPos(), sq_var_int, obj.sq_GetStateTimer(), 300, false);
			sq_setCurrentAxisPos(obj, 0, movePos);
			sq_SimpleMoveToNearMovablePos(obj, 1000);
			break;
	}
}


function onAttack_Doomsday(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	if (!obj.isMyControlObject()) return false;
	switch (subState) {
		case 7:
			local pObjId = sq_GetObjectId(damager);
			obj.getVar("DoomsdayEnermy").push_vector(pObjId);
			break;
	}
}


