function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("getImmuneTypeDamageRate", "getImmuneTypeDamageRate_appendage_BlackMirror");
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_BlackMirror");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_BlackMirror");
	appendage.sq_AddFunctionName("onVaildTimeEnd", "onVaildTimeEnd_appendage_BlackMirror");
	appendage.sq_AddFunctionName("onDamageParent", "onDamageParent_appendage_BlackMirror");
}


function getImmuneTypeDamageRate_appendage_BlackMirror(appendage, damageRate, attacker) {
	if (!appendage) return damageRate;
	local parentObj = appendage.getParent();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local skillLevel = sqrChr.sq_GetSkillLevel(69);
	local staticData = sq_GetIntData(sqrChr, 69, 0);
	return damageRate - staticData;
}


function onStart_appendage_BlackMirror(appendage) {
	if (!appendage) return;
	local attacker = appendage.sq_GetSourceChrTarget();
	appendage.sq_AddEffectFront("character/swordman/effect/animation/atblackmirror/shelter.ani");
	appendage.getVar("temp").clear_vector();
	appendage.getVar("temp").push_vector(0);
}


function onEnd_appendage_BlackMirror(appendage) {
	if (!appendage) return;
	local attacker = appendage.sq_GetSourceChrTarget();
	appendage.sq_DeleteEffectFront();
}


function onVaildTimeEnd_appendage_BlackMirror(appendage) {
	if (!appendage) return;
	local attacker = appendage.sq_GetSourceChrTarget();
	appendage.sq_DeleteEffectFront();
}


function onDamageParent_appendage_BlackMirror(appendage, attacker, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	local temp_int = appendage.getVar("temp").get_vector(0);
	temp_int = temp_int + 1;
	if (temp_int >= parentObj.getVar("count69").get_vector(0)) {
		appendage.sq_DeleteEffectFront();
		appendage.setValid(false);
	}

	appendage.getVar("temp").set_vector(0, temp_int);
}
