
function checkExecutableSkill_BlackMirror(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(69);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(69, STATE_PRIORITY_IGNORE_FORCE, true);
		obj.getVar("BlackMirrorPos").clear_vector();
		obj.getVar("BlackMirrorPos").push_vector(obj.getXPos());
		obj.getVar("BlackMirrorPos").push_vector(obj.getYPos());
		AIMPOINT_ATSWORDMAN = 69;
		return true;
	}

	return false;
}


function checkCommandEnable_BlackMirror(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_BlackMirror(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(492);
			obj.sq_PlaySound("SW_BLACK_MIRROR");
			local delay = sq_GetDelaySum(obj.getCurrentAnimation()) * 0.8;
			sq_StartDrawCastGauge(obj, delay.tointeger(), true);
			local customData = 100;
			customData = obj.sq_GetDistancePos(obj.getXPos(), obj.sq_GetDirection(), customData);
			local customData1 = 500;
			local customData2 = 250;
			obj.sq_AddAimPointMark(customData, obj.getYPos(), customData1, customData2);
			break;
	}
	
}


function onEndCurrentAni_BlackMirror(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEnterFrame_BlackMirror(obj, frameIndex) {
	if (!obj) return;
	if (frameIndex == 8) {
		local aimXPos = obj.sq_GetAimPosX(obj.getXPos(), obj.getYPos(), false);
		local aimYPos = obj.sq_GetAimPosY(obj.getXPos(), obj.getYPos(), false);
		obj.sq_RemoveAimPointMark();
		obj.sq_StartWrite();
		obj.sq_WriteDword(69);
		obj.sq_WriteDword(0);
		obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(69, -1, 0, getATSwordmanBonus(obj, 1.0, 69)));
		obj.sq_WriteDword(obj.sq_GetLevelData(69, 2, sq_GetSkillLevel(obj, 69)));
		obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(69, -1, 3, getATSwordmanBonus(obj, 1.0, 69)));
		obj.sq_WriteDword(obj.sq_GetLevelData(69, 4, sq_GetSkillLevel(obj, 69)));
		obj.sq_WriteDword(obj.sq_GetLevelData(69, 5, sq_GetSkillLevel(obj, 69)));
		obj.sq_WriteDword(sq_GetIntData(obj, 69, 0));
		obj.sq_WriteDword(sq_GetIntData(obj, 69, 79));
		sq_SendCreatePassiveObjectPacketPos(obj, 24381, 0, aimXPos, aimYPos, 0);
	}
}


function onEndState_BlackMirror(obj, new_state) {
	if (!obj) return;
	sq_EndDrawCastGauge(obj);
	obj.sq_RemoveAimPointMark();
}


function onProc_BlackMirror(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local stateTimer = obj.sq_GetStateTimer();
			if (stateTimer > sq_GetCastTime(obj, 69, sq_GetSkillLevel(obj, 69))) return;
			local BlackMirrorPos_int = obj.getVar("BlackMirrorPos").get_vector(0);
			local BlackMirrorPos_int1 = obj.getVar("BlackMirrorPos").get_vector(1);
			local customData = 4;
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL))
				obj.getVar("BlackMirrorPos").set_vector(1, BlackMirrorPos_int1 - 1 * customData);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL))
				obj.getVar("BlackMirrorPos").set_vector(1, BlackMirrorPos_int1 + 1 * customData);
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL))
				obj.getVar("BlackMirrorPos").set_vector(0, BlackMirrorPos_int - 1 * customData);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL))
				obj.getVar("BlackMirrorPos").set_vector(0, BlackMirrorPos_int + 1 * customData);
			break;
	}
}


function onProcCon_BlackMirror(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local xPos = obj.getXPos();
			local yPos = obj.getYPos();
			local zPos = obj.getZPos();
			local dstPos = sq_GetDistancePos(xPos, sq_GetDirection(obj), 50);
			local aimXPos = obj.sq_GetAimPosX(xPos, yPos, false);
			local aimYPos = obj.sq_GetAimPosY(xPos, yPos, false);
			break;
	}
}



