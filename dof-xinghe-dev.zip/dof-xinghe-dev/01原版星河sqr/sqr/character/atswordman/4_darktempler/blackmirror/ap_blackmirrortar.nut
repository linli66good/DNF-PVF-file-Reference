function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("proc", "proc_appendage_BlackMirror"); }


function proc_appendage_BlackMirror(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	if (!parentObj || !sourceObj || sqrChr.getState() != 224) {
		appendage.setValid(false);
		return;
	}

	local Setpos_int = parentObj.getVar("Setpos").get_vector(0);
	local Setpos_int1 = parentObj.getVar("Setpos").get_vector(1);
	sq_setCurrentAxisPos(parentObj, 0, Setpos_int);
	sq_setCurrentAxisPos(parentObj, 1, Setpos_int1);
}

