
function checkExecutableSkill_DeadlyCape(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(70);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_DeadlyCape(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_DeadlyCape(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(484);
			obj.sq_PlaySound("SW_DEDLY_CAPE");
			obj.sq_SetCurrentAttackInfo(125);
			local attackRate = obj.sq_GetBonusRateWithPassive(70, -1, 0, getATSwordmanBonus(obj, 1.0, 70));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.setTimeEvent(10, 300, 1, false);
			obj.getVar("DeadlyCapeCount").clear_vector();
			obj.getVar("DeadlyCapeCount").push_vector(0);
			break;
		case 1:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 3, 30);
			obj.sq_SetCurrentAnimation(485);
			obj.sq_SetCurrentAttackInfo(126);
			local attackRate = obj.sq_GetBonusRateWithPassive(70, -1, 0, getATSwordmanBonus(obj, 1.0, 70));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.getVar("DeadlyCapeCount").set_vector(0, obj.getVar("DeadlyCapeCount").get_vector(0) + 1);
			break;
		case 2:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 3, 30);
			obj.sq_SetCurrentAnimation(486);
			obj.sq_SetCurrentAttackInfo(126);
			local attackRate = obj.sq_GetBonusRateWithPassive(70, -1, 0, getATSwordmanBonus(obj, 1.0, 70));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 3:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 3, 30);
			obj.sq_SetCurrentAnimation(487);
			obj.sq_SetCurrentAttackInfo(126);
			local attackRate = obj.sq_GetBonusRateWithPassive(70, -1, 0, getATSwordmanBonus(obj, 1.0, 70));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 4:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 3, 30);
			obj.sq_SetCurrentAnimation(488);
			obj.sq_SetCurrentAttackInfo(126);
			local attackRate = obj.sq_GetBonusRateWithPassive(70, -1, 0, getATSwordmanBonus(obj, 1.0, 70));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 5:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 3, 30);
			obj.sq_SetCurrentAnimation(489);
			obj.sq_SetCurrentAttackInfo(126);
			local attackRate = obj.sq_GetBonusRateWithPassive(70, -1, 0, getATSwordmanBonus(obj, 1.0, 70));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 6:
			obj.sq_SetCurrentAnimation(490);
			break;
		case 7:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 8, 500);
			obj.sq_SetCurrentAnimation(491);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_DeadlyCape(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			if (obj.getVar("DeadlyCapeCount").get_vector(0) < sq_GetIntData(obj, 70, 0)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(6);
				obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
		case 6:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(7);
			obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 7:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onTimeEvent_DeadlyCape(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	switch (timeEventIndex) {
		case 10:
			obj.sq_StartWrite();
			obj.sq_WriteDword(70);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(70, -1, 1, getATSwordmanBonus(obj, 1.0, 70)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 130, -2, 60);
			break;
		case 11:

			break;
	}
}


function onProcCon_DeadlyCape(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (0 < subState && subState < 6) {
		if (sq_IsKeyDown(OPTION_HOTKEY_JUMP, ENUM_SUBKEY_TYPE_ALL)) {
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(70, STATE_PRIORITY_IGNORE_FORCE, true);
		}
	}
}



function getScrollBasisPos_DeadlyCape(obj) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	if (!obj.isMyControlObject()) return false;
	local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 150);
	obj.sq_SetCameraScrollPosition(dstPos, obj.getYPos(), 0);
	return true;
}



function IsInterval_DeadlyCape(obj, timeGap) {
	if (!obj) return false;
	local TimerDeadlyCape_clock = obj.getVar("TimerDeadlyCape").get_ct_vector(0);
	if (!TimerDeadlyCape_clock) {
		obj.getVar("TimerDeadlyCape").clear_ct_vector();
		obj.getVar("TimerDeadlyCape").push_ct_vector();
		TimerDeadlyCape_clock = obj.getVar("TimerDeadlyCape").get_ct_vector(0);
		TimerDeadlyCape_clock.Reset();
		TimerDeadlyCape_clock.Start(10000, 0);
		return true;
	}

	local customData = TimerDeadlyCape_clock.Get();
	if (customData > timeGap) {
		TimerDeadlyCape_clock.Reset();
		TimerDeadlyCape_clock.Start(10000, 0);
		return true;
	}
	return false;
}
