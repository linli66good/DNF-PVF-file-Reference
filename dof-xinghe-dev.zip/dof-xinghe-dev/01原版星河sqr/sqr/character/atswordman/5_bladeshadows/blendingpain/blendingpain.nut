
function checkExecutableSkill_BlendingPain(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL2);

	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE2, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_BlendingPain(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_BlendingPain(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill3(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_BlendingPain(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE2, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.getVar("LicensePower").set_vector(0, 0);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE2, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.getVar("LicensePower").set_vector(1, 0);
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_BlendingPain(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onAttack_BlendingPain(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	obj.getVar("DeepduskLicense").setBool(0, true);

	switch (subState) {
		case 1:
			obj.getVar("LicensePower").set_vector(0, 0);
			break;
		case 2:
			obj.getVar("LicensePower").set_vector(1, 0);
			break;
	}
}


function onEnterFrame_BlendingPain(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (frameIndex == 1 && obj.isMyControlObject()) sq_SetMyShake(obj, 2, 100);
			break;
		case 2:
			if (frameIndex == 1 && obj.isMyControlObject()) {
			}
			break;
	}
}


function onEndState_BlendingPain(obj, new_state) {
	if (!obj) return;
	if (new_state != CHANGQING_BLADE_STATE2 && new_state != CHANGQING_BLADE_SKILL6 && new_state != CHANGQING_BLADE_SKILL10 && new_state != CHANGQING_BLADE_SKILL18)
		obj.getVar("LicensePower").clear_vector();
}


function onCreateObject_BlendingPain(obj, createObject) {
	if (createObject.isObjectType(OBJECTTYPE_PASSIVE)) obj.getVar("LicensePower").set_vector(2, 0);
}


function onProc_BlendingPain(obj) {
	if (!obj) return;
	OnProc_License(obj);
}


function onKeyFrameFlag_BlendingPain(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_BlendingPain(obj) {
	if (!obj) return;
	onProc_DeepduskLicense(obj);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
