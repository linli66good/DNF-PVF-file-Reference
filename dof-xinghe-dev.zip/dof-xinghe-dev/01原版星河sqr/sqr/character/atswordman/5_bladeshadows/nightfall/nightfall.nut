
function checkExecutableSkill_NightFall(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL11);

	if (isUse) {
		obj.sq_IntVectClear();
		if (obj.getState() == 6)
			obj.sq_IntVectPush(2);
		else
			obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE11, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_NightFall(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_NightFall(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill21(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_NightFall(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE11, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE11, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE11, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_NightFall(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onAttack_NightFall(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	obj.getVar("DeepduskLicense").setBool(0, true);
	local subState = obj.getSkillSubState();

	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_NightFall(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (frameIndex == 2) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(0);
				sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL11);
			} else if (frameIndex == 8) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(1);
				sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL11);
			}
			break;
		case 4:

			break;
	}
}


function onEndState_NightFall(obj, new_state) {
	if (!obj) return;
	if (new_state != CHANGQING_BLADE_STATE11) obj.setShowEquipmentLayer(10, true);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}

	
	
	
function onChangeSkillEffect_NightFall(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL11) return;
	local readData = reciveData.readDword();
	switch (readData) {
		case 0:
			obj.sq_SetStaticMoveInfo(0, -500, -500, true, -300, true);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			break;
		case 1:
			obj.sq_SetStaticMoveInfo(0, 0, 0, true, 0, true);
			break;
	}
}



function onProc_NightFall(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onKeyFrameFlag_NightFall(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_NightFall(obj) {
	if (!obj) return;
	onProc_DeepduskLicense(obj);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
