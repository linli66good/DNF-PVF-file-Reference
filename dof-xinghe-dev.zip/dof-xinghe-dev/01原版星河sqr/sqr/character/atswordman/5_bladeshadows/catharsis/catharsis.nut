
function checkExecutableSkill_Catharsis(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL4);

	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE4, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Catharsis(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_Catharsis(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill5(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_Catharsis(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.getVar("LicensePower").set_vector(0, 0);
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, false);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE4, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE4, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE4, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE4, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.getVar("LicensePower").set_vector(1, 0);
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_Catharsis(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onCreateObject_Catharsis(obj, createObject) {
	if (createObject.isObjectType(OBJECTTYPE_PASSIVE) && createObject.getState() == 10) obj.getVar("LicensePower").set_vector(2, 0);
}


function onAttack_Catharsis(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();

	switch (subState) {
		case 0:
			obj.getVar("LicensePower").set_vector(0, 0);
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 5, 100);
			obj.getVar("Catharsis").push_obj_vector(damager);
			local apPath = "character/atswordman/5_bladeshadows/catharsis/ap_catharsis.nut";
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, true, true, 0, 0, ENUM_DIRECTION_NEUTRAL, appendage);
					sq_MoveToAppendageForce(damager, obj, obj, 0, 0, damager.getZPos(), 50, true, appendage, true);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(2500);
				}
			}
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE4, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.getVar("LicensePower").set_vector(1, 0);
			break;
	}
}


function onEnterFrame_Catharsis(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (frameIndex == 2) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(0);
				sq_BinaryWriteDword(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 50));
				sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL4);
			}
			break;
		case 5:
			if (frameIndex == 1) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(232);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetPowerWithPassive(CHANGQING_BLADE_SKILL4, -1, 3, -1, getATSwordmanBonus(obj, 1.0, CHANGQING_BLADE_SKILL4)));
				obj.sq_WriteDword(sq_GetIntData(obj, CHANGQING_BLADE_SKILL4, 22));
				obj.sq_SendCreatePassiveObjectPacket(24387, 0, 0, 0, 0);
			}
			break;
	}
}


function onEndState_Catharsis(obj, new_state) {
	if (!obj) return;
	if (new_state != CHANGQING_BLADE_STATE4 && new_state != CHANGQING_BLADE_STATE6 && new_state != CHANGQING_BLADE_STATE10 && new_state != CHANGQING_BLADE_STATE18) {
		obj.setShowEquipmentLayer(10, true);
		obj.getVar("LicensePower").clear_vector();
	}
}


function onChangeSkillEffect_Catharsis(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL4) return;
	local readData = reciveData.readDword();
	switch (readData) {
		case 0:
			local readData1 = reciveData.readDword();
			sq_SetCurrentPos(obj, readData1, obj.getYPos(), obj.getZPos() + 80);
			break;
	}
}


function onProc_Catharsis(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local Catharsis_int = obj.getVar("Catharsis").get_vector(0);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), Catharsis_int, stateTimer, delay, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 2:
			local Catharsis_int = obj.getVar("Catharsis").get_vector(0);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), Catharsis_int, stateTimer, delay, false);
			local movePos1 = sq_GetAccel(obj.getZPos(), 220, stateTimer, delay, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) {
				sq_setCurrentAxisPos(obj, 0, movePos);
				sq_setCurrentAxisPos(obj, 2, movePos1);
			}
			break;
		case 3:
			local Catharsis_int = obj.getVar("Catharsis").get_vector(1);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), Catharsis_int, stateTimer, delay, true);
			local movePos1 = sq_GetAccel(obj.getZPos(), 0, stateTimer, delay, true);
			if (obj.isMovablePos(movePos, obj.getYPos())) {
				sq_setCurrentAxisPos(obj, 0, movePos);
				sq_setCurrentAxisPos(obj, 2, movePos1);
			}
			break;
		case 5:
			OnProc_License(obj);
			break;
	}
}


function onKeyFrameFlag_Catharsis(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Catharsis(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
