
function checkExecutableSkill_LastOrder(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL10);

	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE10, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_LastOrder(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_LastOrder(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill22(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_LastOrder(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE10, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_LastOrder(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onAttack_LastOrder(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	obj.getVar("DeepduskLicense").setBool(0, true);
	local subState = obj.getSkillSubState();

	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_LastOrder(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 1:
			if (frameIndex == 2 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 15, 240);
				sq_flashScreen(obj, 0, 150, 150, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, 2);
			}
			break;
	}
}


function onEndState_LastOrder(obj, new_state) {
	if (!obj) return;
	if (new_state != CHANGQING_BLADE_STATE10) {
		obj.setShowEquipmentLayer(10, true);
		sq_SendMessage(obj, 0, 0, 0);
	}
}


	
	
	
function onChangeSkillEffect_LastOrder(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL10) return;
}



function onProc_LastOrder(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onKeyFrameFlag_LastOrder(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_LastOrder(obj) {
	if (!obj) return;
	onProc_DeepduskLicense(obj);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
