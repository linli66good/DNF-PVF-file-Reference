
function checkExecutableSkill_HangOver(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL9);

	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		if (obj.getState() == 4 || (obj.getState() == 3 && obj.getZPos() > 5))
			obj.sq_IntVectPush(0);
		else
			obj.sq_IntVectPush(2);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE9, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_HangOver(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_HangOver(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill13(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_HangOver(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE9, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE9, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE9, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE9, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_HangOver(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onCreateObject_HangOver(obj, createObject) {
	if (createObject.isObjectType(OBJECTTYPE_PASSIVE) && createObject.getState() != 10) obj.getVar("LicensePower").clear_vector();
}


function onAttack_HangOver(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();

	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_HangOver(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_HangOver(obj, new_state) {
	if (!obj) return;
	if (new_state != CHANGQING_BLADE_STATE9 && new_state != CHANGQING_BLADE_STATE6 && new_state != CHANGQING_BLADE_STATE10 && new_state != CHANGQING_BLADE_STATE18) {
		sq_SendMessage(obj, 0, 0, 0);
		obj.getVar("LicensePower").clear_vector();
	}
}


function onChangeSkillEffect_HangOver(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL9) return;
}


function onProc_HangOver(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			OnProc_License(obj);
			break;
		case 1:
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetUniformVelocity(obj.getZPos(), 180, stateTimer, delay);
			sq_setCurrentAxisPos(obj, 2, movePos);

			local direction = obj.sq_GetInputDirection(0);
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) {
				obj.getVar("HangOver").set_vector(0, obj.getXPos());
			} else if (obj.getDirection() == direction) {
				local staticData = obj.sq_GetIntData(CHANGQING_BLADE_SKILL9, 1);
				obj.getVar("HangOver").set_vector(0, sq_GetDistancePos(obj.getXPos(), obj.getDirection(), staticData));
			}
			break;
		case 2:
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local HangOver_int = obj.getVar("HangOver").get_vector(0);

			local movePos1 = sq_GetUniformVelocity(obj.getXPos(), HangOver_int, stateTimer, delay);
			local movePos = sq_GetUniformVelocity(obj.getZPos(), 0, stateTimer, delay);
			if (obj.isMovablePos(movePos1, obj.getYPos())) {
				sq_setCurrentAxisPos(obj, 0, movePos1);
				sq_setCurrentAxisPos(obj, 2, movePos);
			}
			break;
	}
}


function onProcCon_HangOver(obj) {
	if (!obj) return;
	onProc_DeepduskLicense(obj);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
