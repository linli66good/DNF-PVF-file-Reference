
function checkExecutableSkill_DayBreak(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL6);

	if (isUse) {
		ChangqingQQ751675335Skill8(obj);
		return true;
	}
	return false;
}


function checkCommandEnable_DayBreak(obj) {
	if (!obj) return false;
	local staticData = sq_GetIntData(obj, CHANGQING_BLADE_SKILL6, 0);
	local customData = getFormaidableTarget(obj, staticData);
	local customData1 = -1;
	if (customData) customData1 = sq_GetObjectId(customData);

	if (customData1 == -1) return false;
	return true;
}


function onSetState_DayBreak(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill15(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_DayBreak(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE6, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE6, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE6, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_DayBreak(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onAttack_DayBreak(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();

	switch (subState) {
		case 2:
			local apPath = "character/atswordman/5_bladeshadows/daybreak/ap_daybreak.nut";
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, true, true, 0, 0, ENUM_DIRECTION_NEUTRAL, appendage);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(2800);
					if (!obj.getVar("DayBreakHold").is_obj_vector(damager)) obj.getVar("DayBreakHold").push_obj_vector(damager);
				}
			}
			break;
		case 3:
			local zPos = damager.getZPos() + damager.getObjectHeight() / 2;
			local apPath = "character/swordman/effect/animation/atdaybreak/hiteffecta_00.ani";
			CreatePooledObjectAni(damager, apPath, 1, damager.getXPos(), damager.getYPos(), zPos, damager.getDirection(), false, true, false, false);
			break;
	}
}


function onEnterFrame_DayBreak(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (frameIndex == 1) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(0);
				sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL6);
			}
			break;
		case 2:
			if (frameIndex == 1) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(1);
				sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL6);
			} else if (frameIndex == 10)
				sq_SetMyShake(obj, 10, 120);
			else if (frameIndex == 21)
				sq_SetMyShake(obj, 25, 200);
			break;
		case 3:
			if (frameIndex == 1) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(2);
				sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL6);
			} else if (frameIndex == 16) {
				sq_SetMyShake(obj, 10, 500);
				local staticData = sq_GetIntData(obj, CHANGQING_BLADE_SKILL6, 3) - 1;
				local customData = 360 / staticData;
				obj.setTimeEvent(0, customData, staticData, true);
			}
			break;
	}
}


function onEndState_DayBreak(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 2:

			break;
	}

	if (new_state != CHANGQING_BLADE_STATE6) {
		sq_SendMessage(obj, 0, 0, 0);
		obj.setShowEquipmentLayer(10, true);
		local apPath = "character/atswordman/5_bladeshadows/daybreak/ap_daybreak.nut";
		local DayBreakHold_size = obj.getVar("DayBreakHold").get_obj_vector_size();
		for (local customData = 0; customData < DayBreakHold_size; ++customData) {
			local DayBreakHold_obj = obj.getVar("DayBreakHold").get_obj_vector(customData);
			if (DayBreakHold_obj) {
				DayBreakHold_obj = sq_GetCNRDObjectToActiveObject(DayBreakHold_obj);
				if (CNSquirrelAppendage.sq_IsAppendAppendage(DayBreakHold_obj, apPath)) CNSquirrelAppendage.sq_RemoveAppendage(DayBreakHold_obj, apPath);
			}
		}
	}
}


function onChangeSkillEffect_DayBreak(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL6) return;
	local readData = reciveData.readDword();
	switch (readData) {
		case 0:
			local aniPath = "character/swordman/effect/animation/atdaybreak/daybreakstartfront_02.ani";
			CreatePooledObjectAni(obj, aniPath, 1, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, false);

			local aniPath = "character/swordman/effect/animation/atdaybreak/daybreakstartbottom_00.ani";
			CreatePooledObjectAni(obj, aniPath, 2, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, 60.0);
			break;
		case 1:
			local aniPath = "character/swordman/effect/animation/atdaybreak/daybreakattackcover_01.ani";
			sq_setFullScreenEffect(obj, aniPath);

			local aniPath = "character/swordman/effect/animation/atdaybreak/daybreakattackbottom_00.ani";
			CreatePooledObjectAni(obj, aniPath, 2, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, false);
			break;
		case 2:
			local aniPath = "character/swordman/effect/animation/atdaybreak/daybreakendcover_07.ani";
			CreatePooledObjectAni(obj, aniPath, 1, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, false);

			local aniPath = "character/swordman/effect/animation/atdaybreak/daybreakendbottom_00.ani";
			CreatePooledObjectAni(obj, aniPath, 2, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, 60.0);
			break;
	}
}


function onTimeEvent_DayBreak(obj, timeEventIndex, timeEventCount) {
	if (!obj) return false;
	switch (timeEventIndex) {
		case 0:
			obj.resetHitObjectList();
			break;
	}
}


function onProc_DayBreak(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:

			break;
	}
}


function onKeyFrameFlag_DayBreak(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


function onProcCon_DayBreak(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
