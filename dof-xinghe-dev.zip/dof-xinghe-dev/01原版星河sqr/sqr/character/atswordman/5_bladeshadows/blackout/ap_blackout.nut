function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_BlackOut");
	appendage.sq_AddFunctionName("proc", "proc_appendage_BlackOut");
	appendage.sq_AddFunctionName("drawAppend", "drawAppend_appendage_BlackOut");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_BlackOut");
}


function onEnd_appendage_BlackOut(appendage) {
	if (!appendage) {
		return;
	}

	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();

	sourceObj = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	if (!sourceObj || !parentObj) {
		appendage.setValid(false);
		return;
	}
	/*
	if(appendage.getTimer().Get() < 100)
		return;

	ScreenPrintOut = [parentObj.getState()];
	if(sourceObj.isMyControlObject())
	{
		local level		  = sq_GetSkillLevel(sourceObj, 229);
		local attackDamage = sourceObj.sq_GetPowerWithPassive(229, -1, 1, -1, getATSwordmanBonus(sourceObj,1.0,229));
		local staticData = sq_GetIntData(sourceObj, 229, 0);

		sq_BinaryStartWrite();
		sq_BinaryWriteBool(0);
		sq_BinaryWriteFloat(attackDamage.tofloat());
		sq_BinaryWriteWord(staticData);
		sq_BinaryWriteWord(200);
		local customData = true;
		sq_BinaryWriteBool(customData);
		if(!customData)
			sq_BinaryWriteDword(sq_GetObjectId(parentObj));
		local xPos = sourceObj.getXPos() > parentObj.getXPos() ?  sourceObj.getXPos() - parentObj.getXPos() : parentObj.getXPos() - sourceObj.getXPos();
		local yPos = parentObj.getYPos() - sourceObj.getYPos();
		if(sourceObj.getDirection() == parentObj.getDirection())
			xPos = -xPos;
		sq_SendCreatePassiveObjectPacket(sourceObj, 21035, 0, xPos, yPos, 0, ENUM_DIRECTION_NEUTRAL);
	}
 */
}


function proc_appendage_BlackOut(appendage) {
	if (!appendage) return;

	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();

	sourceObj = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	if (!sourceObj || !parentObj) {
		appendage.setValid(false);
		return;
	}
}


function onStart_appendage_BlackOut(appendage) {
	if (!appendage) {
		return;
	}
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
}


function drawAppend_appendage_BlackOut(appendage, isOver, x, y, isFlip) {
	if (!appendage) return;

	local parentObj = appendage.getParent();

	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local currentAni = sq_GetCurrentAnimation(parentObj);

	if (!currentAni) {
		appendage.setValid(false);
		return;
	}

	local aniPath = "character/swordman/effect/animation/atblackout/monsterhold_00.ani";
	local sq_var = parentObj.getVar();
	local ani = sq_var.GetAnimationMap("BlackOutHold", aniPath);
	ani.setImageRate(0.5, 0.5);
	sq_AnimationProc(ani);
	sq_drawCurrentFrame(ani, x, y - sq_GetHeightObject(parentObj) / 2, false);
}

