
function checkExecutableSkill_BlackOut(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL1);

	if (isUse) {
		ChangqingQQ751675335Skill1(obj);
		return true;
	}
	return false;
}


function checkCommandEnable_BlackOut(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_BlackOut(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill2(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_BlackOut(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local BlackOut_int = obj.getVar("BlackOut").get_vector(0);
			if (BlackOut_int == -1) {
				if (obj.getZPos() > 5) {
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(1);
					obj.sq_IntVectPush(0);
					obj.sq_IntVectPush(0);
					obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
				} else
					obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, false);
			} else {
				local object = sq_GetObjectByObjectId(obj, BlackOut_int);
				if (object) {
					object = sq_GetCNRDObjectToActiveObject(object);
					if (sq_IsHoldable(obj, object) && sq_IsGrabable(obj, object) && !sq_IsFixture(object)) {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(2);
						obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE1, STATE_PRIORITY_IGNORE_FORCE, true);
					} else {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(4);
						obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE1, STATE_PRIORITY_IGNORE_FORCE, true);
					}
				}
			}
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE1, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE1, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_BlackOut(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onAttack_BlackOut(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();

	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_BlackOut(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:
			local BlackOut_int = obj.getVar("BlackOut").get_vector(0);
			switch (frameIndex) {
				case 0:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_BinaryWriteDword(BlackOut_int);
					sq_BinaryWriteDword(-10);
					sq_BinaryWriteDword(1);
					sq_BinaryWriteDword(112);
					sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL1);
					break;
				case 1:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_BinaryWriteDword(BlackOut_int);
					sq_BinaryWriteDword(2);
					sq_BinaryWriteDword(1);
					sq_BinaryWriteDword(103);
					sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL1);
					break;
				case 2:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_BinaryWriteDword(BlackOut_int);
					sq_BinaryWriteDword(61);
					sq_BinaryWriteDword(1);
					sq_BinaryWriteDword(69);
					sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL1);
					break;
				case 3:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(1);
					sq_BinaryWriteDword(BlackOut_int);
					sq_BinaryWriteDword(obj.getVar("BlackOut").get_vector(1));
					sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL1);

					obj.sq_StartWrite();
					obj.sq_WriteDword(229);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetPowerWithPassive(CHANGQING_BLADE_SKILL1, -1, 1, -1, getATSwordmanBonus(obj, 1.0, CHANGQING_BLADE_SKILL1)));
					obj.sq_WriteDword(obj.getVar("BlackOut").get_vector(0));
					obj.sq_WriteDword(sq_GetIntData(obj, CHANGQING_BLADE_SKILL1, 18));
					obj.sq_SendCreatePassiveObjectPacket(24387, 0, 0, 1, 0);
					break;
			}
			break;
		case 5:
			if (frameIndex == 2) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(229);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetPowerWithPassive(CHANGQING_BLADE_SKILL1, -1, 3, -1, getATSwordmanBonus(obj, 1.0, CHANGQING_BLADE_SKILL1)));
				obj.sq_WriteDword(obj.getVar("BlackOut").get_vector(0));
				obj.sq_WriteDword(sq_GetIntData(obj, CHANGQING_BLADE_SKILL1, 18));
				obj.sq_SendCreatePassiveObjectPacket(24387, 0, 0, 1, 0);
			}
			break;
	}
}


function onEndState_BlackOut(obj, new_state) {
	if (!obj) return;
	if (new_state != CHANGQING_BLADE_STATE1) obj.setShowEquipmentLayer(10, true);
}


function onChangeSkillEffect_BlackOut(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL1) return;
	local readData = reciveData.readDword();
	local readData1 = reciveData.readDword();
	local object = sq_GetObjectByObjectId(obj, readData1);

	if (readData == 0 && object) {
		local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), reciveData.readDword());
		local yPos = obj.getYPos() + reciveData.readDword();
		local readData2 = reciveData.readDword();
		sq_SetCurrentPos(object, dstPos, yPos, readData2);
	} else if (readData == 1 && object) {
		local dstPos = reciveData.readDword();
		object = sq_GetCNRDObjectToActiveObject(object);

		local apPath = "character/atswordman/5_bladeshadows/blackout/ap_blackout.nut";
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(object, obj, -1, false, apPath, true);
		if (appendage && sq_IsHoldable(obj, object) && sq_IsGrabable(obj, object) && !sq_IsFixture(object)) {
			sq_HoldAndDelayDie(object, obj, true, true, true, 0, 120, ENUM_DIRECTION_NEUTRAL, appendage);
			sq_MoveToAppendageForce(object, obj, obj, dstPos, 0, 0, 100, true, appendage, true);
			local apInfo = appendage.getAppendageInfo();
			apInfo.setValidTime(100);
		}
	}
}


function onProc_BlackOut(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local currentAni = sq_GetCurrentAnimation(obj);
	local delay = sq_GetDelaySum(currentAni);
	local stateTimer = obj.sq_GetStateTimer();

	switch (subState) {
		case 0:
			local BlackOut_int = obj.getVar("BlackOut").get_vector(0);
			local object = sq_GetObjectByObjectId(obj, BlackOut_int);
			if (object) {
				object = sq_GetCNRDObjectToActiveObject(object);
				local movePos = sq_GetUniformVelocity(obj.getXPos(), object.getXPos(), stateTimer, delay / 2);
				local movePos1 = sq_GetUniformVelocity(obj.getYPos(), object.getYPos(), stateTimer, delay / 2);
				local movePos2 = sq_GetUniformVelocity(obj.getZPos(), object.getZPos() + object.getObjectHeight() / 3 * 2, stateTimer, delay / 2);
				if (obj.isMovablePos(movePos, movePos1)) {
					sq_setCurrentAxisPos(obj, 0, movePos);
					sq_setCurrentAxisPos(obj, 1, movePos1);
					sq_setCurrentAxisPos(obj, 2, movePos2);
				}
			}
			break;
		case 2:
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) obj.getVar("BlackOut").set_vector(1, sq_GetIntData(obj, CHANGQING_BLADE_SKILL1, 8));
			break;
		case 3:
			local movePos2 = sq_GetUniformVelocity(obj.getZPos(), 0, stateTimer, delay / 3);
			sq_setCurrentAxisPos(obj, 2, movePos2);
			break;
		case 5:
			local movePos2 = sq_GetUniformVelocity(obj.getZPos(), 0, stateTimer, delay / 3);
			sq_setCurrentAxisPos(obj, 2, movePos2);
			break;
	}
}


function onKeyFrameFlag_BlackOut(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}

