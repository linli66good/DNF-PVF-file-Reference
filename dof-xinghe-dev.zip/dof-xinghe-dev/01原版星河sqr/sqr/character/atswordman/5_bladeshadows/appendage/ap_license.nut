function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_License");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_License");
	appendage.sq_AddFunctionName("proc", "proc_appendage_License");
}


function onStart_appendage_License(appendage) {
	if (!appendage) return;

	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function onEnd_appendage_License(appendage) {
	if (!appendage) return;

	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}


function proc_appendage_License(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);

	local skillLevel = sq_GetSkillLevel(sqrChr, 123);
	local levelData = sq_GetLevelData(sqrChr, 123, 1, skillLevel) / 10;

	local change_appendage = appendage.sq_getChangeStatus("License");
	if (!change_appendage)
		change_appendage = appendage.sq_AddChangeStatus("License", sqrChr, sqrChr, 0, 10, false, levelData);
	else {
		if (sqrChr.getWeaponSubType() == 1) {
			change_appendage.clearParameter();
			change_appendage.addParameter(10, false, levelData.tofloat());
		} else
			change_appendage.clearParameter();
	}
}


