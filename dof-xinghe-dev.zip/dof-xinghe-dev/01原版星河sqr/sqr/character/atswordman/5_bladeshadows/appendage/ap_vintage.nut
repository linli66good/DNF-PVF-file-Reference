function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Vintage");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Vintage");
	appendage.sq_AddFunctionName("proc", "proc_appendage_Vintage");
}


function onStart_appendage_Vintage(appendage) {
	if (!appendage) return;

	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function onEnd_appendage_Vintage(appendage) {
	if (!appendage) return;

	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}


function proc_appendage_Vintage(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);

	local skillLevel = sq_GetSkillLevel(sqrChr, 121);
	local levelData = sq_GetLevelData(sqrChr, 121, 1, skillLevel) / 10;
	local levelData1 = sq_GetLevelData(sqrChr, 121, 0, skillLevel) / 10;

	local change_appendage = appendage.sq_getChangeStatus("Vintage");
	if (!change_appendage)
		change_appendage = appendage.sq_AddChangeStatus("Vintage", sqrChr, sqrChr, 0, 15, false, levelData);
	else {
		change_appendage.clearParameter();
		change_appendage.addParameter(50, false, levelData1.tofloat());
		if (sqrChr.getWeaponSubType() == 1) change_appendage.addParameter(15, false, levelData.tofloat());
	}
}

