function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_OldFashioned");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_OldFashioned");
	appendage.sq_AddFunctionName("proc", "proc_appendage_OldFashioned");
}


function onStart_appendage_OldFashioned(appendage) {
	if (!appendage) return;

	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function onEnd_appendage_OldFashioned(appendage) {
	if (!appendage) return;

	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}


function proc_appendage_OldFashioned(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);

	local skillLevel = sq_GetSkillLevel(sqrChr, 122);
	local levelData = sq_GetLevelData(sqrChr, 122, 0, skillLevel) / 10;
	local levelData1 = sq_GetLevelData(sqrChr, 122, 1, skillLevel) * 10;

	local change_appendage = appendage.sq_getChangeStatus("OldFashioned");
	if (!change_appendage)
		change_appendage = appendage.sq_AddChangeStatus("OldFashioned", sqrChr, sqrChr, 0, 53, true, levelData);
	else {
		if (sqrChr.getWeaponSubType() == 1) {
			change_appendage.clearParameter();
			change_appendage.addParameter(53, true, levelData.tofloat());
			change_appendage.addParameter(33, true, -levelData1.tofloat());
		} else
			change_appendage.clearParameter();
	}
}

