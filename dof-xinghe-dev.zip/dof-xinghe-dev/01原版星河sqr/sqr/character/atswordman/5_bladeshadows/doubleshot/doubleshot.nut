
function checkExecutableSkill_DoubleShot(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL8);

	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE8, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_DoubleShot(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_DoubleShot(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill16(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_DoubleShot(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_DoubleShot(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onAttack_DoubleShot(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	obj.getVar("DeepduskLicense").setBool(0, true);
	local subState = obj.getSkillSubState();

	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_DoubleShot(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (frameIndex == 2) obj.resetHitObjectList();
			break;
		case 4:

			break;
	}
}


function onEndState_DoubleShot(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onChangeSkillEffect_DoubleShot(obj, skillIndex, reciveData) {
	if (!obj) return;
	local readData = reciveData.readDword();
}


function onProc_DoubleShot(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onKeyFrameFlag_DoubleShot(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_DoubleShot(obj) {
	if (!obj) return;
	onProc_DeepduskLicense(obj);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
