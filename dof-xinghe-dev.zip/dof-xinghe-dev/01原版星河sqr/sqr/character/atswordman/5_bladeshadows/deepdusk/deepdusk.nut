
function checkExecutableSkill_DeepDusk(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL7);

	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE7, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_DeepDusk(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_DeepDusk(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill11(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_DeepDusk(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_DeepDusk(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onAttack_DeepDusk(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();

	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_DeepDusk(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_DeepDusk(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onChangeSkillEffect_DeepDusk(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL7) return;
}


function onProc_DeepduskLicense(obj) {
	if (obj.getVar("DeepduskLicense").getBool(0)) ForceUse_ATSwordman(obj, CHANGQING_BLADE_SKILL7, [0], CHANGQING_BLADE_STATE7);
}


function onProc_DeepDusk(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onKeyFrameFlag_DeepDusk(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_DeepDusk(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
