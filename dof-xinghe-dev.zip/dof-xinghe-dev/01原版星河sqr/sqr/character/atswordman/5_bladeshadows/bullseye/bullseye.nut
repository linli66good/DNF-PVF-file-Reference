
function checkExecutableSkill_BullsEye(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL3);

	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE3, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_BullsEye(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_BullsEye(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill4(obj, state, datas, isResetTimer);
}


function onEndCurrentAni_BullsEye(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.getVar("LicensePower").set_vector(0, 0);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE3, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.getVar("LicensePower").set_vector(1, 0);
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function startSkillCoolTime_BullsEye(obj, skillIndex, skillLevel, currentCoolTime) {
	local customData = SwordLicense_ATSwoedman(obj, skillIndex, skillLevel, currentCoolTime);

	return customData;
}


function onAttack_BullsEye(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	obj.getVar("DeepduskLicense").setBool(0, true);

	switch (subState) {
		case 0:
			obj.getVar("BullsEye").setInt(0, damager.getXPos());
			obj.getVar("BullsEye").push_vector(1);
			obj.getVar("LicensePower").set_vector(0, 0);
			break;
		case 1:
			obj.getVar("LicensePower").set_vector(1, 0);
			break;
	}
}


function onEnterFrame_BullsEye(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (frameIndex == 4 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 5, 100);
			} else if (frameIndex == 9 && obj.isMyControlObject()) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(0);
				sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL3);
			} else if (frameIndex == 10 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 6, 150);
			}
			break;
		case 1:
			if (frameIndex == 8 && obj.isMyControlObject()) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(1);
				sq_SendChangeSkillEffectPacket(obj, CHANGQING_BLADE_SKILL3);

			} else if (frameIndex == 9 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 10, 150);
				sq_flashScreen(obj, 0, 100, 50, 178, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, 2);
			}
			break;
	}
}


function getScrollBasisPos_BullsEye(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();

	if (obj.isMyControlObject()) {
		local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), obj.sq_GetIntData(CHANGQING_BLADE_SKILL3, 8));
		local xPos = obj.getXPos();
		if (subState == 0 && obj.sq_GetCurrentFrameIndex(sq_GetCurrentAnimation(obj)) > 5) {
			local stateTimer = obj.sq_GetStateTimer();
			xPos = sq_GetUniformVelocity(xPos, dstPos, stateTimer, obj.sq_GetIntData(CHANGQING_BLADE_SKILL3, 8));
			obj.sq_SetCameraScrollPosition(xPos, obj.getYPos(), 0);
			return true;
		}
	}
	return false;
}


function onEndState_BullsEye(obj, new_state) {
	if (!obj) return;
	if (new_state != CHANGQING_BLADE_STATE3 && new_state != CHANGQING_BLADE_STATE6 && new_state != CHANGQING_BLADE_STATE10 && new_state != CHANGQING_BLADE_STATE18) {
		obj.setShowEquipmentLayer(10, true);
		obj.getVar("LicensePower").clear_vector();
	}
}


function onChangeSkillEffect_BullsEye(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL3) return;
	local readData = reciveData.readDword();
	switch (readData) {
		case 0:
			local customArr = ["character/swordman/effect/animation/atbullseye/attack1/attack1front_00.ani"];
			foreach (path in customArr) CreatePooledObjectAni(obj, path, 1, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, false);

			local customArr1 = [ "character/swordman/effect/animation/atbullseye/attack1/attack1back_00.ani", "character/swordman/effect/animation/atbullseye/attack1/attack1bottom_00.ani" ];
			foreach (path in customArr1) CreatePooledObjectAni(obj, path, 2, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, false);
			break;
		case 1:
			local customArr = ["character/swordman/effect/animation/atbullseye/attack2/attack2front_00.ani"];
			foreach (path in customArr) CreatePooledObjectAni(obj, path, 1, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, false);

			local customArr1 = [ "character/swordman/effect/animation/atbullseye/attack2/attack2back_00.ani", "character/swordman/effect/animation/atbullseye/attack2/attack2bottom_00.ani" ];
			foreach (path in customArr1) CreatePooledObjectAni(obj, path, 2, obj.getXPos(), obj.getYPos(), obj.getZPos(), obj.getDirection(), false, true, false, false);
			break;
	}
}



function onProc_BullsEye(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local currentAni = sq_GetCurrentAnimation(obj);
			local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
			if (frameIndex < 6) OnProc_License(obj);
			break;
		case 1:
			local currentAni = sq_GetCurrentAnimation(obj);
			local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
			if (frameIndex > 12) OnProc_License(obj);
			break;
	}
}


function onKeyFrameFlag_BullsEye(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_BullsEye(obj) {
	if (!obj) return;
	onProc_DeepduskLicense(obj);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
