
function checkExecutableSkill_DangerouShook(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(CHANGQING_BLADE_SKILL5);

	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE5, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_DangerouShook(obj) {
	if (!obj) return false;

	return true;
}


function onSetState_DangerouShook(obj, state, datas, isResetTimer) {
	if (!obj) return;
	ChangqingQQ751675335Skill9(obj, state, datas, isResetTimer);
	obj.sq_SetStaticSpeedInfo(2, 2, 1000, 1000, 1.0, 1.0);
}


function onEndCurrentAni_DangerouShook(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.getVar("LicensePower").set_vector(0, 0);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(CHANGQING_BLADE_STATE5, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_DangerouShook(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	obj.getVar("DeepduskLicense").setBool(0, true);

	switch (subState) {
		case 0:
			obj.getVar("LicensePower").set_vector(0, 0);
			break;
	}
}


function onCreateObject_DangerouShook(obj, createObject) {
	if (createObject.isObjectType(OBJECTTYPE_PASSIVE)) obj.getVar("LicensePower").set_vector(1, 0);
}


function onEnterFrame_DangerouShook(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_DangerouShook(obj, new_state) {
	if (!obj) return;
	if (new_state != CHANGQING_BLADE_STATE5 && new_state != CHANGQING_BLADE_STATE6 && new_state != CHANGQING_BLADE_STATE10 && new_state != CHANGQING_BLADE_STATE18) {
		obj.setShowEquipmentLayer(10, true);
		obj.getVar("LicensePower").clear_vector();
	}
}


function onChangeSkillEffect_DangerouShook(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != CHANGQING_BLADE_SKILL5) return;
}


function onProc_DangerouShook(obj) {
	if (!obj) return;
	OnProc_License(obj);
}


function onProcCon_DangerouShook(obj) {
	if (!obj) return;
	onProc_DeepduskLicense(obj);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
