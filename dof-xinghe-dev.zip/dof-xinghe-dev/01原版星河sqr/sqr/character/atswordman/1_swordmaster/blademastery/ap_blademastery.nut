function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Blademastery");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Blademastery");
	appendage.sq_AddFunctionName("proc", "proc_appendage_Blademastery");
}


function onStart_appendage_Blademastery(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function onEnd_appendage_Blademastery(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}



function proc_appendage_Blademastery(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 11);
	local levelData = sq_GetLevelData(sqrChr, 11, 7, skillLevel) / 10;
	local change_appendage = appendage.sq_getChangeStatus("Blademastery");
	if (!change_appendage)
		change_appendage = appendage.sq_AddChangeStatus("Blademastery", sqrChr, sqrChr, 0, 4, true, levelData);
	else {
		if (sqrChr.getWeaponSubType() == 1) {
			change_appendage.clearParameter();
			change_appendage.addParameter(4, true, levelData.tofloat());
		} else
			change_appendage.clearParameter();
	}
}

