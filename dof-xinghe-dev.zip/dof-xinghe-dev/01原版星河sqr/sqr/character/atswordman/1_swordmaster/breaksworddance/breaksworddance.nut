
function checkExecutableSkill_Breaksworddance(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(140);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 140, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Breaksworddance(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 140, {[0] = true, [108] = true, [14] = true});
}


function onSetState_Breaksworddance(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	local xPos = obj.getXPos();
	local yPos = obj.getYPos();
	obj.getVar("BreaksworddanceSub").setInt(0, subState);
	local BreaksworddanceSpeed_float = obj.getVar("BreaksworddanceSpeed").getFloat(0);
	if (BreaksworddanceSpeed_float < 0.5) BreaksworddanceSpeed_float = 1.0;
	switch (subState) {
		case 0:
			obj.getVar("BreaksworddanceSpeed").setFloat(0, 1.0);
			obj.sq_StopMove();
			BodyMagicSword(obj, "BreakSwordDance_Cast");
			obj.getVar("BreaksworddanceF").setBool(0, false);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(256);
			else
				obj.sq_SetCurrentAnimation(135);
			if (obj.isMyControlObject()) {
				local sq_var = obj.getVar();
				local flashScreenObj = sq_flashScreen(obj, 150, 10500, 300, 250, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
				sq_var.setObject(0, flashScreenObj);
			}

			local dstPos = sq_GetDistancePos(xPos, obj.getDirection(), 300);
			obj.getVar("Breaksworddance").clear_vector();
			obj.getVar("Breaksworddance").push_vector(xPos);
			obj.getVar("Breaksworddance").push_vector(yPos);
			obj.getVar("Breaksworddance").push_vector(dstPos);
			obj.getVar("Breaksworddance").push_vector(yPos);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(0);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 300, 0, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(1);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 300, 0, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(2);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 497, 0, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(3);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 402, -50, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(4);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 402, 57, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(5);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 198, -48, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(6);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 297, 42, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(7);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 100, -31, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(140);
			obj.sq_WriteDword(8);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 100, 21, 0);
			break;
		case 1:
			BodyMagicSword(obj, "BreakSwordDance_Attack1");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(249);
			else
				obj.sq_SetCurrentAnimation(136);
			break;
		case 2:
			BodyMagicSword(obj, "BreakSwordDance_Attack2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(250);
			else
				obj.sq_SetCurrentAnimation(137);
			break;
		case 3:
			BodyMagicSword(obj, "BreakSwordDance_Attack3");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(251);
			else
				obj.sq_SetCurrentAnimation(138);
			break;
		case 4:
			BodyMagicSword(obj, "BreakSwordDance_Attack4");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(252);
			else
				obj.sq_SetCurrentAnimation(139);
			break;
		case 5:
			BodyMagicSword(obj, "BreakSwordDance_Attack5");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(253);
			else
				obj.sq_SetCurrentAnimation(140);
			break;
		case 6:
			BodyMagicSword(obj, "BreakSwordDance_Attack6");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(254);
			else
				obj.sq_SetCurrentAnimation(141);
			break;
		case 7:
			BodyMagicSword(obj, "BreakSwordDance_Attack7");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(255);
			else
				obj.sq_SetCurrentAnimation(142);
			break;
		case 8:
			BodyMagicSword(obj, "BreakSwordDance_FinishAttack");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(257);
			else
				obj.sq_SetCurrentAnimation(143);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, BreaksworddanceSpeed_float);
}


function onEndCurrentAni_Breaksworddance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 6:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(7);
			obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 7:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(8);
			obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 8:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Breaksworddance(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Breaksworddance(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local Breaksworddance_int = obj.getVar("Breaksworddance").get_vector(2);
	local Breaksworddance_int1 = obj.getVar("Breaksworddance").get_vector(3);
	switch (subState) {
		case 1:
			if (frameIndex == 4 && obj.isMyControlObject()) {
				if (obj.isMyControlObject()) {
					sq_SetMyShake(obj, 5, 300);
					sq_flashScreen(obj, 0, 60, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
				}

				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 0, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			}
			break;
		case 2:
			if (frameIndex == 3 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 5, 300);
				sq_flashScreen(obj, 0, 60, 0, 102, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 0, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			}
			break;
		case 3:
			if (frameIndex == 3 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 16, 120);
				sq_flashScreen(obj, 0, 60, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 0, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			}
			break;
		case 4:
			if (frameIndex == 2 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 5, 300);
				sq_flashScreen(obj, 0, 60, 0, 102, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 0, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			}
			break;
		case 5:
			if (frameIndex == 2 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 5, 300);
				sq_flashScreen(obj, 0, 60, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 0, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			}
			break;
		case 6:
			if (frameIndex == 3 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 5, 300);
				sq_flashScreen(obj, 0, 60, 0, 102, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 0, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			}
			break;
		case 7:
			if (frameIndex == 3 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 5, 300);
				sq_flashScreen(obj, 0, 60, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 0, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			}
			break;
		case 8:
			if (frameIndex == 4 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 5, 300);
				sq_flashScreen(obj, 0, 60, 0, 178, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 1, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(5);
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			} else if (frameIndex == 1 && obj.isMyControlObject()) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(140);
				obj.sq_WriteDword(9);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(140, -1, 0, getATSwordmanBonus(obj, 1.0, 140)));
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Breaksworddance_int, Breaksworddance_int1, 0);
			}
			break;
	}
}


function onEndState_Breaksworddance(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (new_state != 140) {
		if (subState != 8) obj.getVar("BreaksworddanceF").setBool(0, true);
		local sq_var_obj = obj.getVar().getObject(0);
		if (sq_var_obj) {
			local pflashScreen = sq_GetCNRDObjectToFlashScreen(sq_var_obj);
			if (pflashScreen) pflashScreen.fadeOut();
		}
	}
}


function onProc_Breaksworddance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local Breaksworddance_int = obj.getVar("Breaksworddance").get_vector(0);
	local Breaksworddance_int1 = obj.getVar("Breaksworddance").get_vector(1);
	switch (subState) {
		case 1:
			local dstPos = sq_GetDistancePos(Breaksworddance_int, obj.getDirection(), 300);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 50, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 2:
			local dstPos = sq_GetDistancePos(Breaksworddance_int, obj.getDirection(), 497);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 50, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 3:
			local dstPos = sq_GetDistancePos(Breaksworddance_int, obj.getDirection(), 402);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 50, false);
			local movePos1 = sq_GetAccel(obj.getYPos(), Breaksworddance_int1 - 50, stateTimer, 50, false);
			if (obj.isMovablePos(movePos, movePos1)) {
				sq_setCurrentAxisPos(obj, 1, movePos1);
				sq_setCurrentAxisPos(obj, 0, movePos);
			}

			break;
		case 4:
			local dstPos = sq_GetDistancePos(Breaksworddance_int, obj.getDirection(), 402);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 50, false);
			local movePos1 = sq_GetAccel(obj.getYPos(), Breaksworddance_int1 + 57, stateTimer, 50, false);
			if (obj.isMovablePos(movePos, movePos1)) {
				sq_setCurrentAxisPos(obj, 1, movePos1);
				sq_setCurrentAxisPos(obj, 0, movePos);
			}

			break;
		case 5:
			local dstPos = sq_GetDistancePos(Breaksworddance_int, obj.getDirection(), 198);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 50, false);
			local movePos1 = sq_GetAccel(obj.getYPos(), Breaksworddance_int1 - 48, stateTimer, 50, false);
			if (obj.isMovablePos(movePos, movePos1)) {
				sq_setCurrentAxisPos(obj, 1, movePos1);
				sq_setCurrentAxisPos(obj, 0, movePos);
			}
			break;
		case 6:
			local dstPos = sq_GetDistancePos(Breaksworddance_int, obj.getDirection(), 297);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 50, false);
			local movePos1 = sq_GetAccel(obj.getYPos(), Breaksworddance_int1 + 42, stateTimer, 50, false);
			if (obj.isMovablePos(movePos, movePos1)) {
				sq_setCurrentAxisPos(obj, 1, movePos1);
				sq_setCurrentAxisPos(obj, 0, movePos);
			}
			break;
		case 7:
			local dstPos = sq_GetDistancePos(Breaksworddance_int, obj.getDirection(), 100);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 50, false);
			local movePos1 = sq_GetAccel(obj.getYPos(), Breaksworddance_int1 - 31, stateTimer, 50, false);
			if (obj.isMovablePos(movePos, movePos1)) {
				sq_setCurrentAxisPos(obj, 1, movePos1);
				sq_setCurrentAxisPos(obj, 0, movePos);
			}
			break;
		case 8:
			local currentAni = sq_GetCurrentAnimation(obj);
			local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
			local dstPos = sq_GetDistancePos(Breaksworddance_int, obj.getDirection(), 100);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 50, false);
			local movePos1 = sq_GetAccel(obj.getYPos(), Breaksworddance_int1 + 21, stateTimer, 50, false);
			if (obj.isMovablePos(movePos, movePos1)) {
				sq_setCurrentAxisPos(obj, 1, movePos1);
				sq_setCurrentAxisPos(obj, 0, movePos);
			}

			if (frameIndex < 3) {
				local movePos2 = sq_GetAccel(obj.getZPos(), 120, stateTimer, 50, false);
				sq_setCurrentAxisPos(obj, 2, movePos2);
			} else {
				local movePos2 = sq_GetAccel(obj.getZPos(), 0, stateTimer, 100, false);
				sq_setCurrentAxisPos(obj, 2, movePos2);
			}
			break;
	}
}


function onKeyFrameFlag_Breaksworddance(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


function onProcCon_Breaksworddance(obj) {
	if (!obj) return;
	local currentAni = sq_GetCurrentAnimation(obj);
	local aniFrameIndex = sq_GetAnimationFrameIndex(currentAni);
	if (aniFrameIndex < 2) return;
	if (sq_IsKeyDown(OPTION_HOTKEY_ATTACK, ENUM_SUBKEY_TYPE_ALL)) {
		if (IsInterval(obj, 100)) {
			local BreaksworddanceSpeed_float = obj.getVar("BreaksworddanceSpeed").getFloat(0);
			obj.getVar("BreaksworddanceSpeed").setFloat(0, BreaksworddanceSpeed_float + 0.05);
		}
	}
}
