function checkExecutableSkill_Breaksworddance(obj)
{
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(140);
	if (isUse)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}

function checkCommandEnable_Breaksworddance(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();
	if(state == STATE_STAND)
		return true;
	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(140);
	}
	return true;
}

function onSetState_Breaksworddance(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();

	if(substate == 0)
	{
			obj.sq_PlaySound("FUSIONBLADE_CAST");
			obj.sq_SetCurrentAnimation(710);
			obj.sq_SetCurrentAttackInfo(227);
			local attackbonus = obj.sq_GetBonusRateWithPassive(140 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackbonus);
			obj.sq_StartWrite();
			obj.sq_WriteDword(54);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, -90, -30, 140);
			obj.sq_StartWrite();
			obj.sq_WriteDword(57);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, -90, -10, 110);
			obj.sq_StartWrite();
			obj.sq_WriteDword(60);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, -110, 10, 70);
			obj.sq_StartWrite();
			obj.sq_WriteDword(63);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, -100, 30, 20);
			local appendage = sq_AttractToMe(obj, 550, 200, 1500);
			obj.getVar("breaksworddanceap").setAppendage(0,appendage);
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(delay);
	}
	if(substate == 1)
	{
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(711);
			local appendage = obj.getVar("breaksworddanceap").getAppendage(0);
			if(appendage)
			appendage.setValid(false);
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
		SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
	local len = 20;
	local leftPress = sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL);
	local rightPress = sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL);
	if(sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT && rightPress) len = 50;
	if(sq_GetDirection(obj) == ENUM_DIRECTION_LEFT && leftPress) len = 50;
	if(sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT && leftPress) len = 0;
	if(sq_GetDirection(obj) == ENUM_DIRECTION_LEFT && rightPress) len = 0;
	local pAni = obj.sq_GetCurrentAni();
	local delay = pAni.getDelaySum(false);
	obj.getVar("breaksworddance").clear_vector();
	obj.getVar("breaksworddance").push_vector(obj.getXPos());
	obj.getVar("breaksworddance").push_vector(sq_GetDistancePos(sq_GetXPos(obj), obj.getDirection(), len));
	obj.getVar("breaksworddance").push_vector(delay);
}

function onEndCurrentAni_Breaksworddance(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_AddSetStatePacket(140, STATE_PRIORITY_IGNORE_FORCE, true);
	}
	if(substate == 1)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}

function onAttack_Breaksworddance(obj, damager, boundingBox, isStuck)
{
	if (!obj) return;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck)
	if (subState == 0)
	{

	}
}

function onProc_Breaksworddance(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();
	local pAni = obj.getCurrentAnimation();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local currentT = sq_GetCurrentTime(pAni);
	local starX = obj.getVar("breaksworddance").get_vector(0);
	local maxX = obj.getVar("breaksworddance").get_vector(1);
	local delay = obj.getVar("breaksworddance").get_vector(2);
	local xAccel = sq_GetAccel(starX, maxX, currentT, delay, true);
	if(subState == 0)
		sq_MoveToNearMovablePos(obj, xAccel, sq_GetYPos(obj), sq_GetZPos(obj), sq_GetXPos(obj), sq_GetYPos(obj), sq_GetZPos(obj), 20, -1, 3);
}

function onKeyFrameFlag_Breaksworddance(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	local ani = obj.getCurrentAnimation();
	local objVar = obj.getVar();
	local delay = objVar.get_vector(0);
	local ndelay = ani.getDelaySum(false);
	local speed = delay.tofloat() / ndelay.tofloat();
	if(substate == 0)
	{
		if (flagIndex == 4)
		{
		Common_Image_Als(obj,"character/swordman/effect/animation/3rd/atfusionblade/atfusionbladestartaurafront_00.ani", 150, 0, 80, 0, 100, 0, speed);
		}
		if (flagIndex == 18)
		{
		sq_SetMyShake(obj, 5, 300);
		Common_Image_Als(obj,"character/swordman/effect/animation/3rd/atfusionblade/atfusionbladestartaurafront_00.ani", 200, 0, 80, 0, 100, 0, speed);
		}
	}
	else if(substate == 1)
	{
		if (flagIndex == 0)
		{
		sq_SetMyShake(obj, 6, 400);
		obj.sq_StartWrite();
		obj.sq_WriteDword(53);
		obj.sq_SendCreatePassiveObjectPacket(24238, 0, 200, 0, 0);
		}
	}
	return true;
}

function onEndState_Breaksworddance(obj, new_state)
{
	if(!obj) return;
	if(new_state != 140)
	{
		local appendage = obj.getVar("breaksworddanceap").getAppendage(0);
		if(appendage)
			appendage.setValid(false);
	}
}
