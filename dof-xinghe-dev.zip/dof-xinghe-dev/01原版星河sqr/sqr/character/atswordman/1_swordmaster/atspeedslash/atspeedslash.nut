
function checkExecutableSkill_Atspeedslash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(145);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 145, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(145, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Atspeedslash(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 143, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Atspeedslash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "SpeedSlash");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(317);
			else
				obj.sq_SetCurrentAnimation(73);
			obj.sq_SetCurrentAttackInfo(59);
			local attackRate = obj.sq_GetBonusRateWithPassive(145, -1, 0, getATSwordmanBonus(obj, 1.0, 145));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), sq_GetLevelData(obj, 145, 1, sq_GetSkillLevel(obj, 145)));
			obj.getVar("Atspeedslash").clear_vector();
			obj.getVar("Atspeedslash").push_vector(dstPos);
			obj.getVar("Atspeedslash").setBool(0, false);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Atspeedslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Atspeedslash(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			MagicswordupOccur(obj, damager, boundingBox, isStuck);
			local apPath = "character/atswordman/1_swordmaster/atspeedslash/ap_atspeedslash.nut";
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager))
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, false, true, 200, 150, ENUM_DIRECTION_NEUTRAL, appendage);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(500);
				}
			break;
	}
}



function onEnterFrame_Atspeedslash(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Atspeedslash(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onChangeSkillEffect_Atspeedslash(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != 145) return;
	if (obj.getVar("Atspeedslash").getBool(0)) return;
	obj.getVar("Atspeedslash").setBool(0, true);
	local currentAni = obj.getCurrentAnimation();
	sq_SetAnimationCurrentTimeByFrame(currentAni, 5, true);
}


function onProcCon_Atspeedslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (obj.getVar("Atspeedslash").getBool(0)) return;
			local currentAni = obj.getCurrentAnimation();
			local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
			obj.setSkillCommandEnable(145, true);
			if (obj.sq_IsEnterSkill(145) != -1 && frameIndex < 4) {
				sq_BinaryStartWrite();
				sq_SendChangeSkillEffectPacket(obj, 145);
			}

			break;
	}
}


function onProc_Atspeedslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (obj.getVar("Atspeedslash").getBool(0)) break;
			local Atspeedslash_int = obj.getVar("Atspeedslash").get_vector(0);
			local currentAni = obj.getCurrentAnimation();
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getXPos(), Atspeedslash_int, stateTimer, delay, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
	}
}

