function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Drawsword");
	appendage.sq_AddFunctionName("proc", "proc_appendage_Drawsword");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Drawsword");
	appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_Drawsword");
}


function onAttackParent_appendage_Drawsword(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	local parentObj = sq_GetCNRDObjectToSQRCharacter(parentObj);
	Attack_BlademasteryDrawsword(parentObj, damager, boundingBox, isStuck);
}


function onStart_appendage_Drawsword(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function proc_appendage_Drawsword(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local customData = 0;
	if (CNSquirrelAppendage.sq_IsAppendAppendage(sqrChr, "character/atswordman/1_swordmaster/timeslash/ap_devilslash.nut"))
		customData = sq_GetLevelData(sqrChr, 142, 4, sq_GetSkillLevel(sqrChr, 142));
	else
		customData = 0;
	local levelData = sq_GetLevelData(sqrChr, 17, 0, sq_GetSkillLevel(sqrChr, 17) + customData);
	local customData1 = 0;
	if (sq_GetSkillLevel(sqrChr, 11) > 0) customData1 = sq_GetLevelData(sqrChr, 11, 6, sq_GetSkillLevel(sqrChr, 11));
	levelData = levelData + customData1;
	local levelData1 = sq_GetLevelData(sqrChr, 17, 1, sq_GetSkillLevel(sqrChr, 17) + customData);
	local staticData = sq_GetIntData(sqrChr, 11, 2);
	levelData1 = levelData1 - staticData;
	local loadSlot = sqrChr.sq_GetSkillLoad(17);
	if (!loadSlot) {
		sqrChr.sq_AddSkillLoad(17, 50, levelData, levelData1);
		loadSlot = sqrChr.sq_GetSkillLoad(17);
	} else {
		local loadNum = loadSlot.getRemainLoadNumber();
		if (!loadSlot.isCooling()) {
			if (loadNum < levelData) {
				loadSlot.increaseLoadCount(1);
				if (loadSlot.getRemainLoadNumber() < levelData) loadSlot.setStartCool();
			}
		}
	}
}


function onEnd_appendage_Drawsword(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local loadSlot = sqrChr.sq_GetSkillLoad(17);
	if (loadSlot) sqrChr.sq_RemoveSkillLoad(17);
}


