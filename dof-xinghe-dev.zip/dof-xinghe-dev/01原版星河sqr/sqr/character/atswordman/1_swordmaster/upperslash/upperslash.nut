
function checkExecutableSkill_Upperslash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(128);
	if (isUse) {
		obj.sq_StopMove();
		CheckUseAddloadDrawsword(obj, 128, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(128, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Upperslash(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 128, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Upperslash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:

			BodyMagicSword(obj, "UpperSlash1");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(329);
			else
				obj.sq_SetCurrentAnimation(77);
			obj.sq_SetCurrentAttackInfo(60);
			local attackRate = obj.sq_GetBonusRateWithPassive(128, -1, 0, getATSwordmanBonus(obj, 1.0, 128));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetStaticMoveInfo(0, 400, -1000, false);
			local staticData = sq_GetIntData(obj, 128, 3) + 1;
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			obj.setTimeEvent(0, delay / staticData, staticData, true);
			break;
		case 1:
			obj.sq_StopMove();
			BodyMagicSword(obj, "UpperSlash2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(330);
			else
				obj.sq_SetCurrentAnimation(78);
			obj.sq_SetCurrentAttackInfo(61);
			local attackRate = obj.sq_GetBonusRateWithPassive(128, -1, 1, getATSwordmanBonus(obj, 1.0, 128));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 2:
			obj.sq_StopMove();
			BodyMagicSword(obj, "UpperSlash2Lv95Passive_Body");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(331);
			else
				obj.sq_SetCurrentAnimation(80);
			obj.sq_SetCurrentAttackInfo(62);
			local attackRate = obj.sq_GetBonusRateWithPassive(128, -1, 1, getATSwordmanBonus(obj, 1.0, 128));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Upperslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(128, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onTimeEvent_Upperslash(obj, timeEventIndex, timeEventCount) {
	if (!obj) return false;
	switch (timeEventIndex) {
		case 0:
			obj.resetHitObjectList();
			break;
	}
}


function onAttack_Upperslash(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Upperslash(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Upperslash(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onKeyFrameFlag_Upperslash(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Upperslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Upperslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}

