
function checkExecutableSkill_Magicswordshoot(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(138);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 138, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(138, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Magicswordshoot(obj) {
	if (!obj) return false;
	if (GetMagicSwordAppIndex(obj) == 0 || obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 138, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Magicswordshoot(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	local customData = 0.0;
	local staticData = sq_GetIntData(obj, 138, 1) / 100.0;
	local loadSlot = obj.sq_GetSkillLoad(138);
	if (loadSlot) {
		local loadNum = loadSlot.getRemainLoadNumber();
		if (loadNum > 0 && !loadSlot.isCooling()) {
			loadSlot.decreaseLoadCount(loadNum);
			customData = staticData * loadNum;
		}
	}

	local customData1 = GetMagicSwordAppIndex(obj);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_IsEnterSkillLastKeyUnits(138);
			obj.sq_PlaySound("SW_SWORDSHOOT_01");
			obj.getVar("MagicswordshootIs").setBool(0, false);
			local customData2 = {[0] = [ "MagicSwordShot_Fire_Start", 306, 115 ],
				[1] = [ "MagicSwordShot_Fire_Start", 306, 115 ],
				[2] = [ "MagicSwordShot_Ice_Start", 309, 118 ],
				[3] = [ "MagicSwordShot_Dark_Start", 303, 124 ],
				[4] = [ "MagicSwordShot_Light_Start", 312, 121 ]} BodyMagicSword(obj, customData2[customData1][0]);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(customData2[customData1][1]);
			else
				obj.sq_SetCurrentAnimation(customData2[customData1][2]);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(138, -1, 0, getATSwordmanBonus(obj, 1.0, 138));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			local customData2 = {[0] = [ "MagicSwordShot_Fire_Loop", 304, 116 ],
				[1] = [ "MagicSwordShot_Fire_Loop", 304, 116 ],
				[2] = [ "MagicSwordShot_Ice_Loop", 307, 119 ],
				[3] = [ "MagicSwordShot_Dark_Loop", 301, 125 ],
				[4] = [ "MagicSwordShot_Light_Loop", 310, 122 ]} BodyMagicSword(obj, customData2[customData1][0]);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(customData2[customData1][1]);
			else
				obj.sq_SetCurrentAnimation(customData2[customData1][2]);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(138, -1, 0, getATSwordmanBonus(obj, 1.0 + customData, 138));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_StartWrite();
			obj.sq_WriteDword(138);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(138, -1, 2, getATSwordmanBonus(obj, 1.0, 138)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(138, -1, 4, getATSwordmanBonus(obj, 1.0 + customData, 138)));
			obj.sq_WriteDword(customData1);
			obj.sq_WriteDword(sq_GetIntData(obj, 138, 4));
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			break;
		case 2:
			obj.sq_PlaySound("SW_SWORDSHOOT_02");
			local customData2 = {[0] = [ "MagicSwordShot_Fire_Shoot", 305, 117 ],
				[1] = [ "MagicSwordShot_Fire_Shoot", 305, 117 ],
				[2] = [ "MagicSwordShot_Ice_Shoot", 305, 117 ],
				[3] = [ "MagicSwordShot_Dark_Shoot", 302, 126 ],
				[4] = [ "MagicSwordShot_Light_Shoot", 311, 123 ]} BodyMagicSword(obj, customData2[customData1][0]);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(customData2[customData1][1]);
			else
				obj.sq_SetCurrentAnimation(customData2[customData1][2]);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(138, -1, 0, getATSwordmanBonus(obj, 1.0 + customData, 138));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	
}


function onEndCurrentAni_Magicswordshoot(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(138, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(138, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Magicswordshoot(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Magicswordshoot(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local customData = GetMagicSwordAppIndex(obj);
	switch (subState) {
		case 0:
			if (frameIndex != 1) break;
			switch (customData) {
				case 0:
					sq_SetMyShake(obj, 2, 360);
					sq_flashScreen(obj, 1, 1, 50, 76, sq_RGB(255, 69, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 1:
					sq_SetMyShake(obj, 2, 360);
					sq_flashScreen(obj, 1, 1, 50, 76, sq_RGB(255, 69, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 2:
					sq_SetMyShake(obj, 2, 360);
					sq_flashScreen(obj, 1, 1, 50, 76, sq_RGB(65, 105, 225), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 3:
					sq_SetMyShake(obj, 2, 360);
					sq_flashScreen(obj, 1, 1, 50, 76, sq_RGB(192, 192, 192), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 4:
					sq_SetMyShake(obj, 2, 360);
					sq_flashScreen(obj, 1, 1, 50, 76, sq_RGB(255, 255, 224), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
		case 1:
			if (frameIndex > 6) break;
			sq_SetMyShake(obj, 2, 240);
			break;
		case 2:
			if (frameIndex != 3) break;
			sq_SetMyShake(obj, 4, 200);
			break;
	}
}


function onEndState_Magicswordshoot(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onKeyFrameFlag_Magicswordshoot(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


function onProcCon_Magicswordshoot(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			local currentAni = sq_GetCurrentAnimation(obj);
			local aniFrameIndex = sq_GetAnimationFrameIndex(currentAni);
			if (aniFrameIndex < 2) return;
			local isDownSkill = obj.isDownSkillLastKey();
			local stateTimer = obj.sq_GetStateTimer();
			local staticData = sq_GetIntData(obj, 138, 9);
			if (!isDownSkill || stateTimer >= staticData) {
				obj.getVar("MagicswordshootIs").setBool(0, true);
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(138, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}


function onProc_Magicswordshoot(obj) {
	if (!obj) return;
}

