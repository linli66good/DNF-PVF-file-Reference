function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_Bladesoul"); }


function onAttackParent_appendage_Bladesoul(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	if (isStuck) return;
	local levelData = sq_GetLevelData(sqrChr, 15, 3, sq_GetSkillLevel(sqrChr, 15));
	local levelData1 = sq_GetLevelData(sqrChr, 15, 1, sq_GetSkillLevel(sqrChr, 15));
	local BladesoulBuffCount_int = sqrChr.getVar("BladesoulBuffCount").getInt(0);
	if (BladesoulBuffCount_int < levelData) sqrChr.getVar("BladesoulBuffCount").setInt(0, BladesoulBuffCount_int + 1);
	local apPath = "character/atswordman/1_swordmaster/bladesoul/ap_bladesoulbuff.nut";
	if (CNSquirrelAppendage.sq_IsAppendAppendage(sqrChr, apPath)) return;
	local appendage = CNSquirrelAppendage.sq_AppendAppendage(sqrChr, sqrChr, -1, false, apPath, false);
	appendage.sq_SetValidTime(levelData1);
	appendage.setEnableIsBuff(true);
	appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(sqrChr), 15, sq_GetSkillLevel(sqrChr, 15));
	CNSquirrelAppendage.sq_Append(appendage, sqrChr, sqrChr, true);
}


