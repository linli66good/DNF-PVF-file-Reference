function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onVaildTimeEnd", "onVaildTimeEnd_appendage_BladesoulBuff");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_BladesoulBuff");
}


function onEnd_appendage_BladesoulBuff(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}


function onVaildTimeEnd_appendage_BladesoulBuff(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local BladesoulBuffCount_int = sqrChr.getVar("BladesoulBuffCount").getInt(0);
	if (BladesoulBuffCount_int > 0) sqrChr.getVar("BladesoulBuffCount").setInt(0, 0);
}
