function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_BladesoulTar");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_BladesoulTar");
	appendage.sq_AddFunctionName("proc", "proc_appendage_BladesoulTar");
	appendage.sq_AddFunctionName("drawAppend", "drawAppend_appendage_BladesoulTar");
}


function onStart_appendage_BladesoulTar(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function onEnd_appendage_BladesoulTar(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}




function drawAppend_appendage_BladesoulTar(appendage, isOver, x, y, isFlip) {
	if (!appendage || !appendage.isValid()) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local customData = 10;
	local customData1 = 10;
	if (parentObj.getCurrentAnimation()) {
		customData = sq_GetWidthObject(parentObj);
		customData1 = sq_GetHeightObject(parentObj);
	}
	local screenX = sq_GetScreenXPos(parentObj);
	local customData2 = 1.3;
	if (customData1 < 120) customData2 = 1.5;
	local screenY = sq_GetScreenYPos(parentObj) - (customData1 / 2.0 * customData2).tointeger();
	local sq_var = parentObj.getVar();
	local aniPath = "character/swordman/effect/animation/atbladesoul/loop_bs_smoke.ani";
	local ani = sq_var.GetAnimationMap("BladesoulTar", aniPath);
	if (sq_IsEnd(ani)) sq_Rewind(ani);
	sq_AnimationProc(ani);
	sq_drawCurrentFrame(ani, screenX, screenY, false);
	return;
}



function proc_appendage_BladesoulTar(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
}

