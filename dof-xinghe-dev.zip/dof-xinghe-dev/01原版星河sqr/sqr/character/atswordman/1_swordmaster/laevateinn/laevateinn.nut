
function checkExecutableSkill_Laevateinn(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(141);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 141, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(141, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Laevateinn(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 141, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Laevateinn(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_LAEVATEINN");
			BodyMagicSword(obj, "ATLaevateinn");
			local sq_var = obj.getVar();
			local flashScreenObj = sq_flashScreen(obj, 150, 10500, 300, 250, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			sq_var.setObject(0, flashScreenObj);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(229);
			else
				obj.sq_SetCurrentAnimation(144);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(141, -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local objectManager = obj.getObjectManager();
			obj.getVar("Laevateinn").clear_obj_vector();
			for (local objectNumber = 0; objectNumber < objectManager.getCollisionObjectNumber(); objectNumber += 1) {
				local apPath = "character/atswordman/1_swordmaster/laevateinn/ap_laevateinn.nut";
				local object = objectManager.getCollisionObject(objectNumber);
				if (object && object.isObjectType(OBJECTTYPE_ACTIVE) && obj.isEnemy(object) && sq_IsHoldable(obj, object)) {
					local appendage = CNSquirrelAppendage.sq_AppendAppendage(object, obj, -1, false, apPath, true);
					sq_HoldAndDelayDie(object, obj, true, true, true, 100, 100, ENUM_DIRECTION_NEUTRAL, appendage);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(5800);
					obj.getVar("Laevateinn").push_obj_vector(object);
				}
			}
			if (obj.isMyControlObject()) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(141);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(141, -1, 0, 1.0));
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, -1, 0);
			}
			break;
	}
	
}



function onEndCurrentAni_Laevateinn(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Laevateinn(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEndState_Laevateinn(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (new_state != 141) {
		local sq_var_obj = obj.getVar().getObject(0);
		if (sq_var_obj) {
			local pflashScreen = sq_GetCNRDObjectToFlashScreen(sq_var_obj);
			if (pflashScreen) pflashScreen.fadeOut();
		}
		local apPath = "character/atswordman/1_swordmaster/laevateinn/ap_laevateinn.nut";
		for (local customData = 0; customData < obj.getVar("Laevateinn").get_obj_vector_size(); ++customData) {
			local Laevateinn_obj = obj.getVar("Laevateinn").get_obj_vector(customData);
			if (CNSquirrelAppendage.sq_IsAppendAppendage(Laevateinn_obj, apPath)) CNSquirrelAppendage.sq_RemoveAppendage(Laevateinn_obj, apPath);
		}
	}
}


function onEnterFrame_Laevateinn(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (frameIndex) {
		case 0:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 2, 150);
			break;
		case 1:

			break;
		case 5:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 2, 1500);
			break;
		case 10:
			sq_flashScreen(obj, 0, 80, 0, 127, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			break;
		case 18:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 10, 100);
			break;
		case 26:
			obj.sq_PlaySound("R_SW_LAEVATEINN_FIN");
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 10, 350);
			sq_flashScreen(obj, 0, 100, 0, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			break;
	}
}



function onKeyFrameFlag_Laevateinn(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Laevateinn(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Laevateinn(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}

