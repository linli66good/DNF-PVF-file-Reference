
function checkExecutableSkill_Thunderslash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(132);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 132, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(169, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Thunderslash(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 132, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Thunderslash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	local currentAni = sq_GetCurrentAnimation(obj);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_THUNDERSLASH");
			BodyMagicSword(obj, "Thunderslash1");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(318);
			else
				obj.sq_SetCurrentAnimation(84);
			obj.sq_SetCurrentAttackInfo(59);
			local attackRate = obj.sq_GetBonusRateWithPassive(132, -1, 0, getATSwordmanBonus(obj, 1.0, 132));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.getVar("ThunderslashSub").setInt(0, 1);
			obj.getVar("ThunderslashSub").clear_obj_vector();
			local staticData = sq_GetIntData(obj, 132, 0);
			obj.getVar("ThunderslashSub").setInt(1, staticData);
			sq_SendMessage(obj, 0, 1, 0);
			break;
		case 1:
			BodyMagicSword(obj, "ThunderslashDash2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(320);
			else
				obj.sq_SetCurrentAnimation(85);
			obj.setTimeEvent(0, 200, 1, false);
			break;
		case 2:
			BodyMagicSword(obj, "ThunderslashJump2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(322);
			else
				obj.sq_SetCurrentAnimation(86);
			obj.setTimeEvent(1, 200, 1, false);
			break;
		case 3:
			obj.getVar("ThunderslashSub").setInt(1, obj.getVar("ThunderslashSub").getInt(1) - 1);
			BodyMagicSword(obj, "ThunderslashGround3");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(321);
			else
				obj.sq_SetCurrentAnimation(87);
			obj.sq_SetCurrentAttackInfo(59);
			local attackRate = obj.sq_GetBonusRateWithPassive(132, -1, 1, getATSwordmanBonus(obj, 1.0, 132));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.setTimeEvent(3, 150, 4, true);
			break;
		case 4:
			obj.getVar("ThunderslashSub").setInt(1, obj.getVar("ThunderslashSub").getInt(1) - 1);
			obj.sq_ZStop();
			BodyMagicSword(obj, "ThunderslashAir3");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(319);
			else
				obj.sq_SetCurrentAnimation(88);
			obj.sq_SetCurrentAttackInfo(59);
			local attackRate = obj.sq_GetBonusRateWithPassive(132, -1, 1, getATSwordmanBonus(obj, 1.0, 132));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.setTimeEvent(4, 160, 4, true);
			break;
		case 5:
			BodyMagicSword(obj, "Thunderslash_Air_Finish_body");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(323);
			else
				obj.sq_SetCurrentAnimation(89);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(132, -1, 0, getATSwordmanBonus(obj, 1.0, 132));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
}


function onEndCurrentAni_Thunderslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local ThunderslashSub_size = obj.getVar("ThunderslashSub").get_obj_vector_size();
			if (ThunderslashSub_size == 0) {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(obj.getVar("ThunderslashSub").getInt(0));
				obj.sq_AddSetStatePacket(169, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
		case 3:
			if (obj.getVar("ThunderslashSub").getInt(1) == 0) {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(3);
				obj.sq_AddSetStatePacket(169, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
		case 4:
			if (obj.getVar("ThunderslashSub").getInt(1) == 0) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(5);
				obj.sq_AddSetStatePacket(169, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(4);
				obj.sq_AddSetStatePacket(169, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(0);
			obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Thunderslash(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:
			local ThunderslashSub_size = obj.getVar("ThunderslashSub").get_obj_vector_size();
			if (ThunderslashSub_size > 0)
				return;
			else
				obj.getVar("ThunderslashSub").push_obj_vector(damager);
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager) && damager.getState() != STATE_HOLD) {
				obj.getVar("ThunderslashSub").setInt(0, 2);
				local apPath = "character/atswordman/1_swordmaster/thunderslash/ap_thunderslash.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, true, false, 100, 100, ENUM_DIRECTION_NEUTRAL, appendage);
					sq_MoveToAppendageForce(damager, obj, obj, 100, 0, 150, 150, true, appendage, true);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(sq_GetIntData(obj, 132, 0) * 600 + 500);
					return;
				}
			} else {
				obj.getVar("ThunderslashSub").setInt(0, 1);
				local xPos = damager.getXPos() + 150;
				if (obj.getDirection() == 1) xPos = damager.getXPos() - 150;
				obj.getVar("Thunderslash").clear_vector();
				obj.getVar("Thunderslash").push_vector(xPos);
			}
			break;
		case 4:

			break;
	}
}


function onTimeEvent_Thunderslash(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (timeEventIndex) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(169, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(169, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			local ThunderslashSub_obj = obj.getVar("ThunderslashSub").get_obj_vector(0);
			sq_SendHitObjectPacket(obj, ThunderslashSub_obj, 0, 0, ThunderslashSub_obj.getObjectHeight() / 2);
			break;
		case 4:
			local ThunderslashSub_obj = obj.getVar("ThunderslashSub").get_obj_vector(0);
			sq_SendHitObjectPacket(obj, ThunderslashSub_obj, 0, 0, ThunderslashSub_obj.getObjectHeight() / 2);
			break;
	}
}


function onEnterFrame_Thunderslash(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:
			switch (frameIndex) {
				case 11:
					if (obj.getVar("ThunderslashSub").getInt(1) != 0) return;
					local apPath = "character/atswordman/1_swordmaster/thunderslash/ap_thunderslash.nut";
					local ThunderslashSub_obj = obj.getVar("ThunderslashSub").get_obj_vector(0);
					if (!ThunderslashSub_obj) return;
					local appendage = CNSquirrelAppendage.sq_AppendAppendage(ThunderslashSub_obj, obj, -1, false, apPath, true);
					if (appendage) {
						sq_HoldAndDelayDie(ThunderslashSub_obj, obj, true, true, false, 100, 100, ENUM_DIRECTION_NEUTRAL, appendage);
						sq_MoveToAppendageForce(ThunderslashSub_obj, obj, obj, 150, 0, -150, 100, true, appendage, true);
						local apInfo = appendage.getAppendageInfo();
						apInfo.setValidTime(100);
						local levelData = sq_GetLevelData(obj, 13, 1, sq_GetSkillLevel(obj, 13)) + 100;
						local levelData1 = sq_GetLevelData(obj, 13, 4, sq_GetSkillLevel(obj, 13)) / 100.0;
						obj.sq_StartWrite();
						obj.sq_WriteDword(132);
						obj.sq_WriteDword(0);
						obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(132, -1, 2, getATSwordmanBonus(obj, 1.0 + levelData1, 132)));
						obj.sq_WriteDword(levelData);
						sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, ThunderslashSub_obj.getXPos(), ThunderslashSub_obj.getYPos(), ThunderslashSub_obj.getZPos());
					}
					break;
			}
			break;
	}
}


function onEndState_Thunderslash(obj, new_state) {
	if (!obj) return;
	if (new_state != 169) sq_SendMessage(obj, 0, 0, 0);
}



function onProcCon_Thunderslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Thunderslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local currentAni = sq_GetCurrentAnimation(obj);
	local customData = 150;
	local stateTimer = obj.sq_GetStateTimer();
	switch (subState) {
		case 1:
			local Thunderslash_int = obj.getVar("Thunderslash").get_vector(0);
			local movePos = sq_GetAccel(obj.getXPos(), Thunderslash_int, stateTimer, customData, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 2:
			local customData1 = 160;
			local movePos1 = sq_GetAccel(obj.getZPos(), customData1, stateTimer, customData, false);
			sq_setCurrentAxisPos(obj, 2, movePos1);
			sq_SimpleMoveToNearMovablePos(obj, 900);
			break;
		case 4:
			if (obj.getVar("ThunderslashSub").getInt(1) == 0) {
			}
			break;
	}
}


function onKeyFrameFlag_Thunderslash(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}











