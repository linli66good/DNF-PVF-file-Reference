
function checkExecutableSkill_Jackcatch(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(139);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 139, {[0] = true, [108] = true, [14] = true}, 0);
		obj.getVar("JackcatchSub").setInt(0, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(139, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Jackcatch(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 139, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Jackcatch(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.getVar("JackcatchSub").setInt(0, subState);
	local JackcatchTarget_size = obj.getVar("JackcatchTarget").get_obj_vector_size();
	if (subState != 0 && subState != 5) {
		for (local customData = 0; customData < JackcatchTarget_size; customData++) {
			local JackcatchTarget_obj = obj.getVar("JackcatchTarget").get_obj_vector(customData);
			if (JackcatchTarget_obj) sq_SendHitObjectPacket(obj, JackcatchTarget_obj, 0, 0, JackcatchTarget_obj.getObjectHeight() / 2);
		}
	}
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "JackCatchCast");
			obj.getVar("JackcatchTar").setBool(0, false);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(293);
			else
				obj.sq_SetCurrentAnimation(133);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 150, 150, 300, 180, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_StartWrite();
			obj.sq_WriteDword(139);
			obj.sq_WriteDword(0);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 350, -30, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(101);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 350, -30, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(111);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 408, 45, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(121);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 296, -86, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(131);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 350, -30, 0);
			break;
		case 1:
			obj.sq_ZStop();
			BodyMagicSword(obj, "JackCatch_Light");
			obj.sq_SetShake(obj, 3, 85);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(300);
			else
				obj.sq_SetCurrentAnimation(128);
			obj.sq_SetCurrentAttackInfo(75);
			local attackRate = obj.sq_GetBonusRateWithPassive(139, -1, 0, getATSwordmanBonus(obj, 1.0, 139));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local aniPath = "character/swordman/effect/animation/atjackcatch/moveattack_light_move_light1.ani";
			DarktemplerCreateAniPooledObj(obj, aniPath, true, true, obj.getXPos(), obj.getYPos(), obj.getZPos(), 1.0);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 584);
			obj.getVar("JackcatchPos").clear_vector();
			obj.getVar("JackcatchPos").push_vector(dstPos);
			obj.getVar("JackcatchPos").push_vector(obj.getYPos() - 40);
			obj.getVar("JackcatchPos").push_vector(150);
			break;
		case 2:
			BodyMagicSword(obj, "JackCatch_Fire");
			obj.sq_SetShake(obj, 3, 85);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(298);
			else
				obj.sq_SetCurrentAnimation(129);
			obj.sq_SetCurrentAttackInfo(75);
			local attackRate = obj.sq_GetBonusRateWithPassive(139, -1, 0, getATSwordmanBonus(obj, 1.0, 139));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local aniPath = "character/swordman/effect/animation/atjackcatch/moveattack_fire_move_fire1.ani";
			DarktemplerCreateAniPooledObj(obj, aniPath, true, true, obj.getXPos(), obj.getYPos(), obj.getZPos(), 1.0);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -451);
			obj.getVar("JackcatchPos").clear_vector();
			obj.getVar("JackcatchPos").push_vector(dstPos);
			obj.getVar("JackcatchPos").push_vector(obj.getYPos() + 30);
			obj.getVar("JackcatchPos").push_vector(obj.getZPos());
			break;
		case 3:
			BodyMagicSword(obj, "JackCatch_Ice");
			obj.sq_SetShake(obj, 3, 85);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(299);
			else
				obj.sq_SetCurrentAnimation(130);
			obj.sq_SetCurrentAttackInfo(75);
			local attackRate = obj.sq_GetBonusRateWithPassive(139, -1, 0, getATSwordmanBonus(obj, 1.0, 139));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local aniPath = "character/swordman/effect/animation/atjackcatch/moveattack_ice_move_ice1.ani";
			DarktemplerCreateAniPooledObj(obj, aniPath, true, true, obj.getXPos(), obj.getYPos(), obj.getZPos(), 1.0);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 274);
			obj.getVar("JackcatchPos").clear_vector();
			obj.getVar("JackcatchPos").push_vector(dstPos);
			obj.getVar("JackcatchPos").push_vector(obj.getYPos() + 40);
			obj.getVar("JackcatchPos").push_vector(obj.getZPos());
			break;
		case 4:
			BodyMagicSword(obj, "JackCatch_Dark");
			obj.sq_SetShake(obj, 3, 85);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(295);
			else
				obj.sq_SetCurrentAnimation(131);
			obj.sq_SetCurrentAttackInfo(75);
			local attackRate = obj.sq_GetBonusRateWithPassive(139, -1, 0, getATSwordmanBonus(obj, 1.0, 139));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local aniPath = "character/swordman/effect/animation/atjackcatch/moveattack_dark_move_dark1.ani";
			DarktemplerCreateAniPooledObj(obj, aniPath, true, true, obj.getXPos(), obj.getYPos(), obj.getZPos(), 1.0);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -120);
			obj.getVar("JackcatchPos").clear_vector();
			obj.getVar("JackcatchPos").push_vector(dstPos);
			obj.getVar("JackcatchPos").push_vector(obj.getYPos() - 120);
			obj.getVar("JackcatchPos").push_vector(obj.getZPos());
			break;
		case 5:
			BodyMagicSword(obj, "JackCatch_Finish");
			if (obj.isMyControlObject()) sq_flashScreen(obj, 15, 25, 15, 180, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(297);
			else
				obj.sq_SetCurrentAnimation(132);
			obj.sq_SetCurrentAttackInfo(76);
			local attackRate = obj.sq_GetBonusRateWithPassive(139, -1, 1, getATSwordmanBonus(obj, 1.0, 139));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 50);
			obj.getVar("JackcatchPos").clear_vector();
			obj.getVar("JackcatchPos").push_vector(dstPos);
			obj.getVar("JackcatchPos").push_vector(obj.getYPos() + 63);
			obj.getVar("JackcatchPos").push_vector(obj.getZPos());
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Jackcatch(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(139, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(139, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(139, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(139, STATE_PRIORITY_IGNORE_FORCE, true);
			sq_SimpleMoveToNearMovablePos(obj, 1100);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			sq_SimpleMoveToNearMovablePos(obj, 1100);
			break;
	}
}


function onAttack_Jackcatch(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	if (subState == 4) {
		local customData = 200;
		local apPath = "character/atswordman/1_swordmaster/jackcatch/ap_jackcatch.nut";
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
		if (sq_IsHoldable(obj, damager) && !sq_IsFixture(damager))
			if (appendage) {
				sq_HoldAndDelayDie(damager, obj, true, true, true, 100, 100, ENUM_DIRECTION_NEUTRAL, appendage);
				local apInfo = appendage.getAppendageInfo();
				apInfo.setValidTime(customData);
			}
	}
}


function onEnterFrame_Jackcatch(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 5:

			if (frameIndex != 2) break;
			local attackRate = obj.sq_GetBonusRateWithPassive(139, -1, 1, getATSwordmanBonus(obj, 1.0, 139));
			obj.sq_StartWrite();
			obj.sq_WriteDword(139);
			obj.sq_WriteDword(5);
			obj.sq_WriteDword(attackRate);
			sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, obj.getXPos(), obj.getYPos(), 0);
			break;
	}
}


function onProc_Jackcatch(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local currentAni = sq_GetCurrentAnimation(obj);
	local delay = sq_GetDelaySum(currentAni) / 10;
	local stateTimer = obj.sq_GetStateTimer();
	local JackcatchPos_int = obj.getVar("JackcatchPos").get_vector(0);
	local JackcatchPos_int1 = obj.getVar("JackcatchPos").get_vector(1);
	local JackcatchPos_int2 = obj.getVar("JackcatchPos").get_vector(2);
	if (subState != 0 && subState != 5) {
		local movePos = sq_GetAccel(obj.getXPos(), JackcatchPos_int, stateTimer, 20, false);
		local movePos1 = sq_GetAccel(obj.getYPos(), JackcatchPos_int1, stateTimer, 20, false);
		local movePos2 = sq_GetAccel(obj.getZPos(), JackcatchPos_int2, stateTimer, 20, false);
		if (obj.isMovablePos(movePos, movePos1)) {
			sq_setCurrentAxisPos(obj, 0, movePos);
			sq_setCurrentAxisPos(obj, 1, movePos1);
			sq_setCurrentAxisPos(obj, 2, movePos2);
		}

	} else if (subState == 5) {
		if (stateTimer < 50) {
			local movePos = sq_GetAccel(obj.getXPos(), JackcatchPos_int, stateTimer, 12, false);
			local movePos1 = sq_GetAccel(obj.getYPos(), JackcatchPos_int1, stateTimer, 12, false);
			if (obj.isMovablePos(movePos, movePos1)) {
				sq_setCurrentAxisPos(obj, 0, movePos);
				sq_setCurrentAxisPos(obj, 1, movePos1);
			}
		} else {
			local movePos2 = sq_GetAccel(obj.getZPos(), 0, stateTimer, 100, false);
			sq_setCurrentAxisPos(obj, 2, movePos2);
		}
	}
}


function onEndState_Jackcatch(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (new_state == 139 && subState == 5)
		obj.getVar("JackcatchTar").setBool(0, true);
	else if (new_state != 139) {
		obj.getVar("JackcatchTar").setBool(0, true);
		obj.sq_SetfindNearMovablePos(obj.getXPos(), obj.getYPos(), 1800, 1000, 50);
	}
}


function onKeyFrameFlag_Jackcatch(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Jackcatch(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}

