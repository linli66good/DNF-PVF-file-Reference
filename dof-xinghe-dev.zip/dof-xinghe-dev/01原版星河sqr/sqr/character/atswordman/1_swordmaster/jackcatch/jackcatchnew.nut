function checkExecutableSkill_Jackcatch(obj)
{
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(139);
	if (isUse)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(139, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}

function checkCommandEnable_Jackcatch(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();
	if(state == STATE_STAND)
		return true;
	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(139);
	}
	return true;
}

function onSetState_Jackcatch(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();

	if(substate == 0)
	{
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(293);
			else
				obj.sq_SetCurrentAnimation(133);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 150, 150, 300, 180, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_StartWrite();
			obj.sq_WriteDword(139);
			obj.sq_WriteDword(0);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 350, -30, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(101);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 350, -30, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(111);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 408, 45, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(121);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 296, -86, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(131);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 350, -30, 0);

	}

}

function onEndCurrentAni_Jackcatch(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


