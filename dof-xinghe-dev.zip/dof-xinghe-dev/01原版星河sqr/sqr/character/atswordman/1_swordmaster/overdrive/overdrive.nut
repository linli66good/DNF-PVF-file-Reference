
function checkExecutableSkill_Overdrive(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(146);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 146, {[0] = true, [108] = true, [14] = true}, 0);
		CreateBuffCutin(obj, "etc/ultimateskillani/atsword_swordmaster_neo_buff.ani");
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(146, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Overdrive(obj) {
	if (!obj) return false;
	return CheckForceDrawsword(obj, 146, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Overdrive(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "OverDrive_ON_Body");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(313);
			else
				obj.sq_SetCurrentAnimation(81);
			local castTime = sq_GetCastTime(obj, 146, sq_GetSkillLevel(obj, 146));
			local currentAni = sq_GetCurrentAnimation(obj);
			local frameStartT = sq_GetFrameStartTime(currentAni, 4);
			local floatData = frameStartT.tofloat() / castTime.tofloat();
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, floatData, floatData);
			sq_StartDrawCastGauge(obj, frameStartT, true);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Overdrive(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEnterFrame_Overdrive(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (frameIndex) {
		case 4:
			local levelData = sq_GetLevelData(obj, 146, 0, sq_GetSkillLevel(obj, 146));
			local apPath = "character/atswordman/1_swordmaster/overdrive/ap_overdrive.nut";
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
			appendage.sq_SetValidTime(levelData);
			appendage.setEnableIsBuff(true);
			appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 146, sq_GetSkillLevel(obj, 146));
			CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
			break;
	}
}


function onEndState_Overdrive(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}



function onProcCon_Overdrive(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Overdrive(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}

function CreateBuffCutin(obj, aniPath) {
	local ani = sq_CreateAnimation("", aniPath);
	local pooledObj = sq_CreatePooledObject(ani, true);
	local objectManager = obj.getObjectManager();
	local xPos = obj.getXPos();
	local yPos = objectManager.getFieldYPos(0, 0, 7);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(xPos + 480, yPos, 0);
	sq_AddObject(obj, pooledObj, 2, false);
}
