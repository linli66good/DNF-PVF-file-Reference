function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Overdrive");
	appendage.sq_AddFunctionName("onVaildTimeEnd", "onVaildTimeEnd_appendage_Overdrive");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Overdrive");
}


function onStart_appendage_Overdrive(appendage) {
	if (!appendage) {
		return;
	}
	local parentObj = appendage.getParent();
	local parentObj = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local skillLevel = sq_GetSkillLevel(parentObj, 146);
	local levelData = parentObj.sq_GetLevelData(146, 2, skillLevel);
	local levelData1 = parentObj.sq_GetLevelData(146, 1, skillLevel);
	local change_appendage = appendage.sq_getChangeStatus("Overdrive");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Overdrive", parentObj, parentObj, 0, 15, false, levelData);
		change_appendage = appendage.sq_AddChangeStatus("Overdrive", parentObj, parentObj, 0, 50, false, levelData1);
	}
	if (change_appendage) {
		levelData1 = levelData1 * 0.1;
		change_appendage.clearParameter();
		change_appendage.addParameter(15, false, levelData.tofloat());
		change_appendage.addParameter(50, false, levelData1.tofloat());
	}
	appendage.sq_AddEffectFront("character/swordman/effect/animation/atoverdrive/overdrive_bufftop.ani");
	appendage.sq_AddEffectBack("character/swordman/effect/animation/atoverdrive/overdrive_buffbot.ani");
}


function onVaildTimeEnd_appendage_Overdrive(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	appendage.sq_DeleteEffectFront();
	appendage.sq_DeleteEffectBack();
}


function onEnd_appendage_Overdrive(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
	appendage.sq_DeleteEffectFront();
	appendage.sq_DeleteEffectBack();
}
