function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Bluntmastery");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Bluntmastery");
	appendage.sq_AddFunctionName("proc", "proc_appendage_Bluntmastery");
}


function onStart_appendage_Bluntmastery(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function onEnd_appendage_Bluntmastery(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}


function proc_appendage_Bluntmastery(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 13);
	local levelData = sq_GetLevelData(sqrChr, 13, 8, skillLevel) / 10;
	local change_appendage = appendage.sq_getChangeStatus("Bluntmastery");
	if (!change_appendage)
		change_appendage = appendage.sq_AddChangeStatus("Bluntmastery", sqrChr, sqrChr, 0, 4, true, levelData);
	else {
		if (sqrChr.getWeaponSubType() == 2) {
			change_appendage.clearParameter();
			change_appendage.addParameter(4, true, levelData.tofloat());
		} else
			change_appendage.clearParameter();
	}
}

