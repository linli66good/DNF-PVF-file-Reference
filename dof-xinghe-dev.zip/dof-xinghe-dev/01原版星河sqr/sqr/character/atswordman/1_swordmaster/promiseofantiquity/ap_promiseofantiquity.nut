function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("proc", "proc_appendage_Promiseofantiquity"); }


function proc_appendage_Promiseofantiquity(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}

	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 16);
	local WeaponType = sqrChr.getWeaponSubType();
	local Promiseofantiquity_int = sqrChr.getVar("Promiseofantiquity").getInt(0);
	local customArr = [ 0, 2, 4, 6, 0 ];
	local levelData = sq_GetLevelData(sqrChr, 16, customArr[WeaponType], skillLevel) / 10;
	local change_appendage = appendage.sq_getChangeStatus("Promiseofantiquity");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Promiseofantiquity", sqrChr, sqrChr, 0, 4, true, levelData);
		sqrChr.getVar("Promiseofantiquity").setInt(0, WeaponType);
	} else {
		if (Promiseofantiquity_int != WeaponType) {
			change_appendage.clearParameter();
			change_appendage.addParameter(4, true, levelData.tofloat());
		}
	}
}

