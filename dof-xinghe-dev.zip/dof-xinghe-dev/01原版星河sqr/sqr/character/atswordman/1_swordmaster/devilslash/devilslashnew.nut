function checkExecutableSkill_Devilslash(obj)
{
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(136);
	if (isUse)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}

function checkCommandEnable_Devilslash(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();
	if(state == STATE_STAND)
		return true;
	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(136);
	}
	return true;
}

function onSetState_Devilslash(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();

	if(substate == 0)
	{
			obj.getVar("WeaponcomboWeapon3").setBool(0, true);
			HeavyswordmasteryAddAppend(obj);
			obj.sq_SetCurrentAnimation(709);
			obj.sq_SetCurrentAttackInfo(219);
			local rate = 0
			if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) rate = sq_GetLevelData(obj, 12, 3, sq_GetSkillLevel(obj, 12));
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(136, -1, 0, getATSwordmanBonus(obj, 1.0 + rate / 100, 136));
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ndelay = ani.getDelaySum(false);
			local speed = delay.tofloat() / ndelay.tofloat();
			locakonhit(obj, "character/swordman/effect/animation/atdevilslash/110lvequipment/attackbodyeffect_00.ani", 0, 0, 0, 0, 100, 0, 1, speed, 0)
			local size = 0
			if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) size = sq_GetLevelData(obj, 12, 13, sq_GetSkillLevel(obj, 12));
			local sizeRate = size.tofloat() / 100.0;
			sq_SetAttackBoundingBoxSizeRate(ani, 1 + sizeRate, 1 + sizeRate, 1 + sizeRate);
	}
}

function onEndCurrentAni_Devilslash(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}

function onAttack_Devilslash(obj, damager, boundingBox, isStuck)
{
	if (!obj) return;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	if (subState == 0)
	{
		local x = sq_GetCenterXPos(boundingBox) - sq_GetXPos(damager);
		local z = sq_GetCenterZPos(boundingBox) - sq_GetZPos(damager);
		local size = 0
		if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) size = 150;
		Common_Image_Als(damager,"character/swordman/effect/animation/atdevilslash/110lvequipment/line_00.ani", x, -0, z, -0, size, 1, 1.0);
	}
}


function onKeyFrameFlag_Devilslash(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		if (flagIndex == 10001)
		{
		sq_SetMyShake(obj, 8, 400);
		local size = 0
		if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) size = sq_GetLevelData(obj, 12, 13, sq_GetSkillLevel(obj, 12));
		Common_Image_Als(obj,"character/swordman/effect/animation/atdevilslash/110lvequipment/attackeffect_00.ani", 200, -30, -0, -0, 100 + size, 0, 1.0);
		}
	}
	return true;
}
