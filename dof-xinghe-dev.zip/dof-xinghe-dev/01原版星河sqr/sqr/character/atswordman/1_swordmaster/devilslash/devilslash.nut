
function checkExecutableSkill_Devilslash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(136);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 136, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IsEnterSkillLastKeyUnits(136);
		obj.getVar("DevilslashT").setInt(0, 0);
		obj.getVar("DevilslashC").setInt(0, 0);
		local customData = 0;
		if (obj.sq_GetState() != 0 && obj.sq_GetState() != 14 && obj.sq_GetState() != 108 && sq_GetSkillLevel(obj, 11) > 0 && obj.getWeaponSubType() == 1) {
			obj.getVar("DevilslashMax").setBool(0, true);
			customData = 2;
		} else {
			obj.getVar("DevilslashMax").setBool(0, false);
		}
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(customData);
		obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Devilslash(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 136, {[0] = true, [108] = true, [14] = true});
}


function onSetState_Devilslash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.getVar("DevilslashXXX").setInt(0, subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_DEVILSLASH");
			BodyMagicSword(obj, "DevilSlashCharge1");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(267);
			else
				obj.sq_SetCurrentAnimation(99);
			local customArr = [
				"effect/animation/atdevilslash/nothing/charge_body_1.ani", "effect/animation/atdevilslash/fire/charge_body_1.ani", "effect/animation/atdevilslash/ice/charge_body_1.ani",
				"effect/animation/atdevilslash/dark/charge_body_1.ani", "effect/animation/atdevilslash/light/charge_body_1.ani"
			];
			obj.sq_AddStateLayerAnimation(-1, obj.sq_CreateCNRDAnimation(customArr[GetMagicSwordAppIndex(obj)]), 0, 0);
			break;
		case 1:
			obj.getVar("DevilslashT").setInt(0, 0);
			obj.getVar("DevilslashT").setInt(1, sq_GetIntData(obj, 136, 4));
			obj.getVar("DevilslashT").setInt(2, sq_GetIntData(obj, 136, 4));
			obj.getVar("DevilslashT").setInt(3, sq_GetIntData(obj, 136, 4));
			BodyMagicSword(obj, "DevilSlashCharge2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(268);
			else
				obj.sq_SetCurrentAnimation(100);
			local customArr = [
				"effect/animation/atdevilslash/nothing/charge_body_2.ani", "effect/animation/atdevilslash/fire/charge_body_2.ani", "effect/animation/atdevilslash/ice/charge_body_2.ani",
				"effect/animation/atdevilslash/dark/charge_body_2.ani", "effect/animation/atdevilslash/light/charge_body_2.ani"
			];
			obj.sq_AddStateLayerAnimation(-1, obj.sq_CreateCNRDAnimation(customArr[GetMagicSwordAppIndex(obj)]), 0, 0);
			break;
		case 2:
			HeavyswordmasteryAddAppend(obj);
			BodyMagicSword(obj, "DevilSlashDash");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(270);
			else
				obj.sq_SetCurrentAnimation(102);
			obj.sq_SetStaticMoveInfo(0, 600, 450, false);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			local customArr = [
				"effect/animation/atdevilslash/nothing/dash_body.ani", "effect/animation/atdevilslash/fire/dash_body.ani", "effect/animation/atdevilslash/ice/dash_body.ani",
				"effect/animation/atdevilslash/dark/dash_body.ani", "effect/animation/atdevilslash/light/dash_body.ani"
			];
			obj.sq_AddStateLayerAnimation(-1, obj.sq_CreateCNRDAnimation(customArr[GetMagicSwordAppIndex(obj)]), 0, 0);
			break;
		case 3:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_DEVILSLASH_FIN");
			BodyMagicSword(obj, "DevilSlashMultiAttack");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(271);
			else
				obj.sq_SetCurrentAnimation(103);
			local customData = 1.0;
			local levelData = sq_GetLevelData(obj, 12, 13, sq_GetSkillLevel(obj, 12)) / 100.0;
			if (obj.getVar("WeaponcomboWeapon3").getBool(0)) {
				if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) {
				} else {
				}
			} else {
				obj.sq_SetStaticMoveInfo(0, 450, 450, false);
			}

			local customArr1 = [ 0, 0, 1, 2 ];
			local customData1 = 0.0;
			local DevilslashT_int = obj.getVar("DevilslashT").getInt(0);
			if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) customData1 = sq_GetLevelData(obj, 12, 2, sq_GetSkillLevel(obj, 12)) / 100.0;
			local attackRate = obj.sq_GetBonusRateWithPassive(136, -1, customArr1[DevilslashT_int], getATSwordmanBonus(obj, 1.0 + customData1, 136));
			if (sq_GetSkillLevel(obj, 11) > 0 && obj.getWeaponSubType() == 1) attackRate = obj.sq_GetBonusRateWithPassive(136, -1, customArr1[DevilslashT_int], getATSwordmanBonus(obj, 1.0, 136));
			local customData2 = 0;
			if (obj.getVar("WeaponcomboWeapon3").getBool(0)) customData2 = sq_GetLevelData(obj, 12, 13, sq_GetSkillLevel(obj, 12));
			obj.sq_StartWrite();
			obj.sq_WriteDword(136);
			obj.sq_WriteDword(1);
			obj.sq_WriteDword(attackRate);
			obj.sq_WriteDword(sq_GetIntData(obj, 136, 10) + customData2);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			break;
		case 4:
			BodyMagicSword(obj, "DevilSlash3Degree");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(266);
			else
				obj.sq_SetCurrentAnimation(105);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 300, 550, 150, 180, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			local customArr = [
				"effect/animation/atdevilslash/nothing/napdo_body_mu.ani", "effect/animation/atdevilslash/fire/napdo_body_mu.ani", "effect/animation/atdevilslash/ice/napdo_body_mu.ani",
				"effect/animation/atdevilslash/dark/napdo_body_mu.ani", "effect/animation/atdevilslash/light/napdo_body_mu.ani"
			];
			obj.sq_AddStateLayerAnimation(-1, obj.sq_CreateCNRDAnimation(customArr[GetMagicSwordAppIndex(obj)]), 0, 0);
			break;
	}
}


function onEndCurrentAni_Devilslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onChangeSkillEffect_Devilslash(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != 136) return;
	local readData = reciveData.readDword();
	local readData1 = reciveData.readDword();
	local readData2 = reciveData.readDword();
	local readData3 = reciveData.readDword() / 100.0;
	if (readData != sq_GetObjectId(obj)) return;
	local customArr = [ "nothing", "fire", "ice", "dark", "light" ];
	local customArr1 = [ "mu", "fire", "ice", "dark", "light" ];
	local aniPath = "character/swordman/effect/animation/atdevilslash/" + customArr[readData1] + "/slash_" + customArr1[readData1] + "_" + readData2.tostring() + ".ani";
	if (readData1 == 3) {
		local aniPath1 = "character/swordman/effect/animation/atdevilslash/" + customArr[readData1] + "/slash_" + customArr[readData1] + "_n_" + readData2.tostring() + ".ani";
		DarktemplerCreateAniPooledObj(obj, aniPath1, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0 + readData3);
	} else
		DarktemplerCreateAniPooledObj(obj, aniPath, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0 + readData3);
}


function onEnterFrame_Devilslash(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 3:
			if (frameIndex % 2 == 0 && obj.isMyControlObject()) {
				local customArr = [ 0, 0, 1, 2 ];
				local customData = 0.0;
				if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3 && obj.getVar("DevilslashT").getInt(0) > 0)
					customData = sq_GetLevelData(obj, 12, 2, sq_GetSkillLevel(obj, 12)) / 100.0;
				obj.sq_PlaySound("R_DSWD");
				local DevilslashC_int = obj.getVar("DevilslashC").getInt(0);
				obj.getVar("DevilslashC").setInt(0, DevilslashC_int + 1);
				local DevilslashT_int = obj.getVar("DevilslashT").getInt(3);
				if (DevilslashC_int - 1 == DevilslashT_int) {
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(4);
					obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
				}
				local customData1 = GetMagicSwordAppIndex(obj);
				local customData2 = frameIndex / 2;
				local customData3 = 0;
				if (obj.getVar("WeaponcomboWeapon3").getBool(0) && sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) customData3 = sq_GetLevelData(obj, 12, 13, sq_GetSkillLevel(obj, 12));
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(sq_GetObjectId(obj));
				sq_BinaryWriteDword(customData1);
				sq_BinaryWriteDword(customData2);
				sq_BinaryWriteDword(customData3);
				sq_SendChangeSkillEffectPacket(obj, 136);
			}
			break;
		case 4:
			if (frameIndex == 10) {
				local DevilslashT_int1 = obj.getVar("DevilslashT").getInt(0);
				local customArr = [ 3, 3, 4, 5 ];
				local customData = 0.0;
				if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3 && obj.getVar("DevilslashT").getInt(0) > 0)
					customData = sq_GetLevelData(obj, 12, 2, sq_GetSkillLevel(obj, 12)) / 100.0;
				local customData3 = 0;
				if (obj.getVar("WeaponcomboWeapon3").getBool(0)) customData3 = sq_GetLevelData(obj, 12, 13, sq_GetSkillLevel(obj, 12));
				if (obj.isMyControlObject()) {
					obj.sq_SetShake(obj, 4, 300);
					sq_flashScreen(obj, 50, 100, 50, 180, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
				}

				local customData4 = customArr[DevilslashT_int1];
				if (obj.getVar("DevilslashMax").getBool(0)) customData4 = customArr[3];
				obj.sq_StartWrite();
				obj.sq_WriteDword(136);
				obj.sq_WriteDword(0);
				if (sq_GetSkillLevel(obj, 11) > 0 && obj.getWeaponSubType() == 1)
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(136, -1, customData4, getATSwordmanBonus(obj, 1.0, 136)));
				else
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(136, -1, customArr[obj.getVar("DevilslashT").getInt(0)], getATSwordmanBonus(obj, 1.0 + customData, 136)));
				obj.sq_PlaySound("DEVILSLASH_EXP");
				obj.sq_WriteDword(sq_GetIntData(obj, 136, 10) + customData3);
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 120, 0, 0);
			}
			break;
	}
}


function onAttack_Devilslash(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEndState_Devilslash(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}



function onProcCon_Devilslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (subState == 0 || subState == 1) {
		local stateTimer = obj.sq_GetStateTimer();
		local staticData = sq_GetIntData(obj, 136, 0);
		local staticData1 = sq_GetIntData(obj, 136, 1);
		local staticData2 = sq_GetIntData(obj, 136, 2);
		local staticData3 = sq_GetIntData(obj, 136, 4);
		local staticData4 = sq_GetIntData(obj, 136, 5);
		local staticData5 = sq_GetIntData(obj, 136, 6);
		local staticData6 = sq_GetIntData(obj, 136, 7);
		local staticData7 = sq_GetIntData(obj, 136, 8);
		local staticData8 = sq_GetIntData(obj, 136, 9);
		if (obj.isDownSkillLastKey()) {
			if (staticData <= stateTimer && staticData1 > stateTimer) {
				if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3)
					obj.getVar("WeaponcomboWeapon3").setBool(0, true);
				else
					obj.getVar("WeaponcomboWeapon3").setBool(0, false);
				obj.getVar("DevilslashT").setInt(0, 1);
				obj.getVar("DevilslashT").setInt(1, staticData3);
				obj.getVar("DevilslashT").setInt(2, staticData4);
				obj.getVar("DevilslashT").setInt(3, staticData3);
			} else if (staticData1 <= stateTimer && staticData2 > stateTimer) {
				obj.getVar("DevilslashT").setInt(0, 2);
				obj.getVar("DevilslashT").setInt(1, staticData5);
				obj.getVar("DevilslashT").setInt(2, staticData6);
				obj.getVar("DevilslashT").setInt(3, staticData5);
			} else if (staticData2 <= stateTimer) {
				obj.getVar("DevilslashT").setInt(0, 3);
				obj.getVar("DevilslashT").setInt(1, staticData7);
				obj.getVar("DevilslashT").setInt(2, staticData8);
				obj.getVar("DevilslashT").setInt(3, staticData7);
				if (obj.getWeaponSubType() == 3 && stateTimer + 300 > staticData2) {
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(2);
					obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
				} else {
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(2);
					obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
				}
			} else {
				obj.getVar("WeaponcomboWeapon3").setBool(0, false);
				obj.getVar("DevilslashT").setInt(0, 0);
				obj.getVar("DevilslashT").setInt(1, staticData3);
				obj.getVar("DevilslashT").setInt(2, staticData4);
				obj.getVar("DevilslashT").setInt(3, staticData3);
			}

		} else {
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
		}

	} else if (subState == 2) {
		if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1) {
			obj.sq_SetStaticMoveInfo(0, 0, 0, false);
		} else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0) {
			obj.sq_SetStaticMoveInfo(0, 0, 0, false);
		}
	} else if (subState == 3) {
		if (sq_IsKeyDown(OPTION_HOTKEY_ATTACK, ENUM_SUBKEY_TYPE_ALL)) {
			local customArr = [ sq_GetIntData(obj, 136, 5), sq_GetIntData(obj, 136, 5), sq_GetIntData(obj, 136, 7), sq_GetIntData(obj, 136, 9) ];
			if (obj.getVar("DevilslashT").getInt(3) < customArr[obj.getVar("DevilslashT").getInt(0)]) obj.getVar("DevilslashT").setInt(3, obj.getVar("DevilslashT").getInt(3) + 1);
		}
	}
}


function onProc_Devilslash(obj) {
	if (!obj) return;
}


function onTimeEvent_Devilslash(obj, timeEventIndex, timeEventCount) {
	if (!obj) return false;
	switch (timeEventIndex) {
		case 10:
			obj.resetHitObjectList();
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(136, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
	return true;
}

