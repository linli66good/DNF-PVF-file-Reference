
function checkExecutableSkill_Illusionblade(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(131);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 131, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(131, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Illusionblade(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 131, {[0] = true, [108] = true, [14] = true});
}


function onSetState_Illusionblade(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	local attackRate = obj.sq_GetBonusRateWithPassive(131, -1, 0, getATSwordmanBonus(obj, 1.0, 131));
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "IllusionBlade");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(285);
			else
				obj.sq_SetCurrentAnimation(82);
			local levelData = sq_GetLevelData(obj, 13, 2, sq_GetSkillLevel(obj, 13));
			local levelData1 = sq_GetLevelData(obj, 13, 5, sq_GetSkillLevel(obj, 13)) / 100.0;
			obj.sq_StartWrite();
			obj.sq_WriteDword(131);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.getWeaponSubType());
			obj.sq_WriteDword(attackRate);
			obj.sq_WriteDword(sq_GetLevelData(obj, 131, 1, sq_GetSkillLevel(obj, 131)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(131, -1, 2, getATSwordmanBonus(obj, 1.0 + levelData1, 131)));
			obj.sq_WriteDword(sq_GetIntData(obj, 131, 1) + levelData);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			break;
		case 1:
			BodyMagicSword(obj, "IllusionBlade2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(286);
			else
				obj.sq_SetCurrentAnimation(83);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}

function onEndCurrentAni_Illusionblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onProc_Illusionblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}

