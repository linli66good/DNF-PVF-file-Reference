
function checkExecutableSkill_Excalibur(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(135);
	if (isUse) {
		obj.sq_PlaySound("SW_EXCALIBUR");
		CheckUseAddloadDrawsword(obj, 135, {[0] = true, [108] = true, [14] = true}, 0);
		local customData = 0;
		if (sq_GetSkillLevel(obj, 13) > 0 && obj.getWeaponSubType() == 2) {
			obj.getVar("Excalibur").setBool(0, true);
			customData = 2;
		} else
			obj.getVar("Excalibur").setBool(0, false);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(customData);
		obj.sq_AddSetStatePacket(135, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Excalibur(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 135, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Excalibur(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_SetStaticMoveInfo(0, 150, 200, false, -500, true);
	obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "Excalibur1");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(276);
			else
				obj.sq_SetCurrentAnimation(96);
			obj.sq_SetCurrentAttackInfo(66);
			local attackRate = obj.sq_GetBonusRateWithPassive(135, -1, 0, getATSwordmanBonus(obj, 1.0, 135));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			BodyExcalibur2(obj, GetMagicSwordAppIndex(obj), "Excalibur1");
			break;
		case 1:
			BodyMagicSword(obj, "Excalibur2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(277);
			else
				obj.sq_SetCurrentAnimation(97);
			obj.sq_SetCurrentAttackInfo(67);
			local attackRate = obj.sq_GetBonusRateWithPassive(135, -1, 0, getATSwordmanBonus(obj, 1.0, 135));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			BodyExcalibur2(obj, GetMagicSwordAppIndex(obj), "Excalibur2");
			break;
		case 2:
			obj.sq_StopMove();
			BodyMagicSword(obj, "Excalibur3");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(278);
			else
				obj.sq_SetCurrentAnimation(98);
			obj.sq_SetCurrentAttackInfo(68);
			local attackRate = obj.sq_GetBonusRateWithPassive(135, -1, 0, getATSwordmanBonus(obj, 1.0, 135));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			BodyExcalibur2(obj, GetMagicSwordAppIndex(obj), "Excalibur3");
			local customData = GetMagicSwordAppIndex(obj);
			if (obj.getVar("Excalibur").getBool(0)) attackRate = (attackRate * (sq_GetLevelData(obj, 13, 6, sq_GetSkillLevel(obj, 13)) / 100.0) + 1.0).tointeger();
			obj.sq_StartWrite();
			obj.sq_WriteDword(135);
			obj.sq_WriteDword(10);
			obj.sq_WriteDword(attackRate);
			obj.sq_WriteDword(customData);
			obj.sq_WriteDword(sq_GetIntData(obj, 135, 4));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(135, -1, 1, getATSwordmanBonus(obj, 1.0, 135)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(135, -1, 2, getATSwordmanBonus(obj, 1.0, 135)));
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 250, 0, 0);
			if (obj.getVar("Excalibur").getBool(0)) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(135);
				obj.sq_WriteDword(1);
				obj.sq_WriteDword(attackRate);
				obj.sq_WriteDword(customData);
				obj.sq_WriteDword(sq_GetIntData(obj, 135, 4));
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(135, -1, 1, getATSwordmanBonus(obj, 1.0, 135)));
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(135, -1, 2, getATSwordmanBonus(obj, 1.0, 135)));
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			}
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Excalibur(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(135, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(135, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Excalibur(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Excalibur(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Excalibur(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProcCon_Excalibur(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
		obj.sq_SetStaticMoveInfo(0, 0, 0, false);
	else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
		obj.sq_SetStaticMoveInfo(0, 0, 0, false);
}


function onProc_Excalibur(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Excalibur(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


function BodyExcalibur2(obj, aniIndex, aniDir) {
	local customArr = [ "_mu_slash_mu.ani", "_fire_slash_fire.ani", "_ice_slash_ice.ani", "_dark_slash_dark.ani", "_light_slash_light.ani" ];
	local filePath = "effect/animation/atexcalibur/" + aniDir + customArr[aniIndex];
	obj.sq_AddStateLayerAnimation(4, obj.sq_CreateCNRDAnimation(filePath), 0, 0);
}
