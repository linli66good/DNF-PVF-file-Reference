
function checkExecutableSkill_Weaponcombo(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(147);
	if (isUse) {
		obj.sq_StopMove();
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Weaponcombo(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return true;
}


function onSetState_Weaponcombo(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
	obj.sq_SetStaticMoveInfo(0, 80, -400, false);
	local WeaponType = obj.getWeaponSubType();
	obj.sq_IsEnterSkillLastKeyUnits(147);
	obj.endSkillCoolTime(147);
	local attackRate = obj.sq_GetBonusRateWithPassive(174, -1, 0, getATSwordmanBonus(obj, 1.0, 147)) / 10;
	local customArr = [ "R_SW_1ATK", "R_SW_2ATK", "R_SW_3ATK" ];
	if ((WeaponType == 3 || WeaponType == 1) && subState < 3)
		obj.sq_PlaySound(customArr[subState]);
	else if (WeaponType == 2 && subState < 2)
		obj.sq_PlaySound(customArr[subState]);
	switch (subState) {
		case 0:
			local customArr1 = [ 33, 39, 42, 37 ];
			local customArr2 = [ 30, 27, 24, 22 ];
			local customArr3 = [ 341, 338, 332, 335 ];
			local customArr4 = [ "WeaponComboShortSword1", "WeaponComboKatana1_body", "WeaponComboClub1_body", "WeaponComboHeavy1_body" ];
			obj.getVar("WeaponcomboWeapon3").setBool(0, false);
			BodyMagicSword(obj, customArr4[WeaponType]);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(customArr3[WeaponType]);
			else
				obj.sq_SetCurrentAnimation(customArr1[WeaponType]);
			obj.sq_SetCurrentAttackInfo(customArr2[WeaponType]);
			obj.applyBasicAttackUp(sq_GetCurrentAttackInfo(obj), obj.getState());
			sq_SetCurrentAttackInfo(obj, sq_GetCurrentAttackInfo(obj));
			if (WeaponType == 0) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(147);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				obj.sq_WriteDword(attackRate);
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			}
			break;
		case 1:
			obj.getVar("Weaponcombo").setBool(0, true);
			local customArr1 = [ 34, 40, 43, 38 ];
			local customArr2 = [ 31, 28, 25, 23 ];
			local customArr3 = [ 342, 339, 333, 337 ];
			local customArr4 = [ "WeaponComboShortSword2", "WeaponComboKatana2_body", "WeaponComboClub2_body", "WeaponComboHeavy2_body" ];
			BodyMagicSword(obj, customArr4[WeaponType]);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(customArr3[WeaponType]);
			else
				obj.sq_SetCurrentAnimation(customArr1[WeaponType]);
			obj.sq_SetCurrentAttackInfo(customArr2[WeaponType]);
			obj.applyBasicAttackUp(sq_GetCurrentAttackInfo(obj), obj.getState());
			sq_SetCurrentAttackInfo(obj, sq_GetCurrentAttackInfo(obj));
			if (WeaponType == 0) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(147);
				obj.sq_WriteDword(1);
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				obj.sq_WriteDword(attackRate);
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			}

			HeavyswordmasteryAddAppend(obj);
			break;
		case 2:
			local customArr1 = [ 35, 41, 44, 45 ];
			local customArr2 = [ 32, 29, 26, 24 ];
			local customArr3 = [ 343, 340, 334, 336 ];
			local customArr4 = [ "WeaponComboShortSword3", "WeaponComboKatana3_body", "WeaponComboClub3_body", "WeaponComboHeavy1_body" ];
			BodyMagicSword(obj, customArr4[WeaponType]);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(customArr3[WeaponType]);
			else
				obj.sq_SetCurrentAnimation(customArr1[WeaponType]);
			obj.sq_SetCurrentAttackInfo(customArr2[WeaponType]);
			local customData = 140;
			obj.applyBasicAttackUp(sq_GetCurrentAttackInfo(obj), obj.getState());
			sq_SetCurrentAttackInfo(obj, sq_GetCurrentAttackInfo(obj));
			if (WeaponType == 0) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(147);
				obj.sq_WriteDword(2);
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				obj.sq_WriteDword(attackRate);
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			}
			break;
		case 3:
			local customArr1 = [ 36, 39, 42, 37 ];
			local customArr3 = [ 344, 338, 332, 335 ];
			local customArr4 = [ "WeaponComboShortSword4", "WeaponComboKatana1_body", "WeaponComboClub1_body", "WeaponComboHeavy1_body" ];
			BodyMagicSword(obj, customArr4[WeaponType]);
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(customArr3[WeaponType]);
			else
				obj.sq_SetCurrentAnimation(customArr1[WeaponType]);
			obj.sq_SetCurrentAttackInfo(33);
			local customData = 140;
			obj.applyBasicAttackUp(sq_GetCurrentAttackInfo(obj), obj.getState());
			sq_SetCurrentAttackInfo(obj, sq_GetCurrentAttackInfo(obj));
			if (WeaponType == 0) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(147);
				obj.sq_WriteDword(3);
				obj.sq_WriteDword(GetMagicSwordAppIndex(obj));
				obj.sq_WriteDword(attackRate);
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			}
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Weaponcombo(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (obj.getVar("WeaponcomboWeapon3").getBool(0)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Weaponcombo(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	if (obj.getWeaponSubType() != 0) {
		MagicSword_BasiconAttack(obj, damager, boundingBox, isStuck);
		MagicswordupOccur(obj, damager, boundingBox, isStuck);
	}
}


function onEnterFrame_Weaponcombo(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local WeaponType = obj.getWeaponSubType();
	switch (subState) {
		case 2:
			if (WeaponType == 2 && frameIndex == 2) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(147);
				obj.sq_WriteDword(20);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(174, -1, 0, getATSwordmanBonus(obj, 1.0, 147)) / 10);
				obj.sq_WriteDword(sq_GetIntData(obj, 147, 5) + 20);
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 110, 0, 0);
			}
			break;
		case 1:
			if (obj.getWeaponSubType() == 3 && frameIndex == 2) {
				sq_SetMyShake(obj, 1, 150);
				local customData = 150;
				local skillLevel = sq_GetSkillLevel(obj, 12);
				if (obj.getVar("WeaponcomboWeapon3").getBool(0) && skillLevel > 0 && obj.getWeaponSubType() == 3) customData = 100 + sq_GetLevelData(obj, 12, 13, skillLevel);
				obj.sq_StartWrite();
				obj.sq_WriteDword(147);
				obj.sq_WriteDword(10);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(174, -1, 0, getATSwordmanBonus(obj, 1.0, 147)) / 10 + 200);
				obj.sq_WriteDword(customData);
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 90, 0, 0);
				obj.getVar("Weaponcombo").setBool(0, false);
			}
			break;
	}
}


function onProc_Weaponcombo(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local currentAni = obj.getCurrentAnimation();
	local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
	local WeaponType = obj.getWeaponSubType();
	procSetIsMove(obj);
	obj.setSkillCommandEnable(147, true);
	ForcePush_ATSwordman(obj, 169, [ 1, 1, 200 ], 6);
	switch (subState) {
		case 0:
			switch (WeaponType) {
				case 0:
					if (frameIndex > 3 && obj.isDownSkillLastKey()) {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(1);
						obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
					}
					break;
				case 1:
					if (frameIndex > 4 && obj.isDownSkillLastKey()) {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(1);
						obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
					}
					break;
				case 2:
					if (frameIndex > 2 && obj.isDownSkillLastKey()) {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(1);
						obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
					}
					break;
				case 3:
					if (frameIndex <= 5) {
						if (obj.isDownSkillLastKey())
							obj.getVar("WeaponcomboWeapon3").setBool(0, true);
						else
							obj.getVar("WeaponcomboWeapon3").setBool(0, false);
					} else {
						if (!obj.getVar("WeaponcomboWeapon3").getBool(0) && obj.isDownSkillLastKey()) {
							obj.sq_IntVectClear();
							obj.sq_IntVectPush(1);
							obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
						}
					}
					break;
			}
			break;
		case 1:
			switch (WeaponType) {
				case 0:
					if (frameIndex > 4 && obj.isDownSkillLastKey()) {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(2);
						obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
					}
					break;
				case 1:
					if (frameIndex > 4 && obj.isDownSkillLastKey()) {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(2);
						obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
					}
					break;
				case 2:
					if (frameIndex > 3 && obj.isDownSkillLastKey()) {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(2);
						obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
					}
					break;
				case 3:
					if (frameIndex > 1) obj.sq_SetStaticMoveInfo(0, 0, 0, false);
					break;
			}
			break;
		case 2:
			switch (WeaponType) {
				case 0:
					if (frameIndex > 3 && obj.isDownSkillLastKey()) {
						obj.sq_IntVectClear();
						obj.sq_IntVectPush(3);
						obj.sq_AddSetStatePacket(147, STATE_PRIORITY_IGNORE_FORCE, true);
					}
					break;
			}
			break;
	}
}

