function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Heavyswordmastery");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Heavyswordmastery");
	appendage.sq_AddFunctionName("proc", "proc_appendage_Heavyswordmastery");
}


function onStart_appendage_Heavyswordmastery(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function onEnd_appendage_Heavyswordmastery(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}



function proc_appendage_Heavyswordmastery(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 12);
	local levelData = sq_GetLevelData(sqrChr, 12, 9, skillLevel) / 10;
	local change_appendage = appendage.sq_getChangeStatus("Heavyswordmastery");
	if (!change_appendage)
		change_appendage = appendage.sq_AddChangeStatus("Heavyswordmastery", sqrChr, sqrChr, 0, 4, true, levelData);
	else {
		if (sqrChr.getWeaponSubType() == 3) {
			change_appendage.clearParameter();
			change_appendage.addParameter(4, true, levelData.tofloat());
		} else
			change_appendage.clearParameter();
	}
}

