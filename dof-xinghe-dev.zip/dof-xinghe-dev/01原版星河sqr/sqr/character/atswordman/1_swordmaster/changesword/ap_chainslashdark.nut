function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_ChangeswordDark");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_ChangeswordDark");
	appendage.sq_AddFunctionName("drawAppend", "drawAppend_appendage_ChangeswordDark");
}


function onStart_appendage_ChangeswordDark(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
}


function onEnd_appendage_ChangeswordDark(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}



function drawAppend_appendage_ChangeswordDark(appendage, isOver, x, y, isFlip) {
	if (!appendage || !appendage.isValid()) return;
	local parentObj = appendage.getParent();
	drawChangeswordCommon(parentObj);
	return;
}

