
function checkExecutableSkill_Changesword(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(96);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_IntVectPush(0);
		obj.sq_IntVectPush(96);
		obj.sq_IntVectPush(sq_GetCastTime(obj, 96, sq_GetSkillLevel(obj, 96)));
		obj.sq_IntVectPush(500);
		obj.sq_IntVectPush(0);
		obj.sq_IntVectPush(4);
		obj.sq_IntVectPush(4);
		obj.sq_IntVectPush(1000);
		obj.sq_IntVectPush(1000);
		obj.sq_IntVectPush(-1);
		obj.sq_AddSetStatePacket(STATE_THROW, STATE_PRIORITY_USER, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Changesword(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Changesword(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(67);
			else
				obj.sq_SetCurrentAnimation(66);
			BodyMagicSword(obj, "ChangeSword");
			break;
		case 1:
			obj.sq_PlaySound("R_SW_CHANGESWORD");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(261);
			else
				obj.sq_SetCurrentAnimation(68);
			Changesword_ChangeAppebd(obj, subState);
			BodyMagicSword(obj, "ChangeSwordFire");
			break;
		case 2:
			obj.sq_PlaySound("R_SW_CHANGESWORD");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(262);
			else
				obj.sq_SetCurrentAnimation(69);
			Changesword_ChangeAppebd(obj, subState);
			BodyMagicSword(obj, "ChangeSwordIce");
			break;
		case 3:
			obj.sq_PlaySound("R_SW_CHANGESWORD");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(260);
			else
				obj.sq_SetCurrentAnimation(70);
			Changesword_ChangeAppebd(obj, subState);
			BodyMagicSword(obj, "ChangeSwordDark");
			break;
		case 4:
			obj.sq_PlaySound("R_SW_CHANGESWORD");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(263);
			else
				obj.sq_SetCurrentAnimation(71);
			Changesword_ChangeAppebd(obj, subState);
			BodyMagicSword(obj, "ChangeSwordlight");
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Changesword(obj) {
	if (!obj) return;
	obj.sq_IntVectClear();
	obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
	local pObjCount = obj.getMyPassiveObjectCount(2438300);
	if (pObjCount == 0) obj.sq_SendCreatePassiveObjectPacket(2438300, 0, 0, 0, 0);
}


function onProcCon_Changesword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local currentAni = sq_GetCurrentAnimation(obj);
			local aniFrameIndex = sq_GetAnimationFrameIndex(currentAni);
			if (obj.sq_GetStateTimer() < 200) return;
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(96, STATE_PRIORITY_IGNORE_FORCE, true);
			} else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(4);
				obj.sq_AddSetStatePacket(96, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				if (obj.getDirection() == 0)
					obj.sq_IntVectPush(1);
				else
					obj.sq_IntVectPush(3);
				obj.sq_AddSetStatePacket(96, STATE_PRIORITY_IGNORE_FORCE, true);
			} else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				if (obj.getDirection() == 0)
					obj.sq_IntVectPush(3);
				else
					obj.sq_IntVectPush(1);
				obj.sq_AddSetStatePacket(96, STATE_PRIORITY_IGNORE_FORCE, true);
			} else if (sq_IsKeyDown(OPTION_HOTKEY_SKILL2, ENUM_SUBKEY_TYPE_ALL)) {
				Changesword_RemoveAppebd(obj);
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}


function onProc_Changesword(obj) {
	if (!obj) return;
}




function onEnterFrame_Changesword(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onEndState_Changesword(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onKeyFrameFlag_Changesword(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


