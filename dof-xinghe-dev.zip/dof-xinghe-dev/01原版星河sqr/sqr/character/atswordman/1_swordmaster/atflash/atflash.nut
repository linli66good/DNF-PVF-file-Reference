
function checkExecutableSkill_Atflash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(134);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 134, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(174, STATE_PRIORITY_IGNORE_FORCE, true);
		if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) sq_SendMessage(obj, OBJECT_MESSAGE_SUPERARMOR, 1, 0);
		obj.startSkillCoolTime(134, sq_GetSkillLevel(obj, 134), -1);
		return true;
	}
	return false;
}


function checkCommandEnable_Atflash(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 134, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Atflash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "Flash1");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(279);
			else
				obj.sq_SetCurrentAnimation(93);
			break;
		case 1:
			BodyMagicSword(obj, "Flash2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(280);
			else
				obj.sq_SetCurrentAnimation(94);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(134, -1, 1, getATSwordmanBonus(obj, 1.0, 134));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 2:
			BodyMagicSword(obj, "flash3_flash2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(281);
			else
				obj.sq_SetCurrentAnimation(95);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(134, -1, 1, getATSwordmanBonus(obj, 1.0, 134));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Atflash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(174, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Atflash(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Atflash(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			local customData = GetMagicSwordAppIndex(obj);
			local attackRate = obj.sq_GetBonusRateWithPassive(134, -1, 1, getATSwordmanBonus(obj, 1.0, 134));
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), sq_GetIntData(obj, 134, 1));
			switch (frameIndex) {
				case 0:
					obj.sq_StartWrite();
					obj.sq_WriteDword(134);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(attackRate);
					obj.sq_WriteDword(dstPos);
					obj.sq_WriteDword(customData);
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 10);
					break;
				case 1:
					obj.sq_StartWrite();
					obj.sq_WriteDword(134);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(1);
					obj.sq_WriteDword(attackRate);
					obj.sq_WriteDword(dstPos);
					obj.sq_WriteDword(customData);
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 10);
					break;
				case 2:
					obj.sq_StartWrite();
					obj.sq_WriteDword(134);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(2);
					obj.sq_WriteDword(attackRate);
					obj.sq_WriteDword(dstPos);
					obj.sq_WriteDword(customData);
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
					break;
				case 6:
					if (sq_GetSkillLevel(obj, 11) > 0 && obj.getWeaponSubType() == 1) {
						obj.sq_StartWrite();
						obj.sq_WriteDword(134);
						obj.sq_WriteDword(0);
						obj.sq_WriteDword(2);
						obj.sq_WriteDword(attackRate);
						obj.sq_WriteDword(dstPos);
						obj.sq_WriteDword(customData);
						obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 10);
					}
					break;
			}
			break;
	}
}


function onEndState_Atflash(obj, new_state) {
	if (!obj) return;
	if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3 && new_state != 174) sq_SendMessage(obj, OBJECT_MESSAGE_SUPERARMOR, 0, 0);
}



function onKeyFrameFlag_Atflash(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Atflash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Atflash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}

