
function checkExecutableSkill_Halfmoon(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(133);
	if (isUse) {
		obj.sq_IsEnterSkillLastKeyUnits(133);
		CheckUseAddloadDrawsword(obj, 133, {[0] = true, [108] = true, [14] = true}, 0);
		if (obj.sq_GetState() != 0 && obj.sq_GetState() != 14 && obj.sq_GetState() != 108 && sq_GetSkillLevel(obj, 11) > 0 && obj.getWeaponSubType() == 1)
			obj.getVar("WeaponcomboWeapon3").setBool(0, true);
		else
			obj.getVar("WeaponcomboWeapon3").setBool(0, false);
		local customData = 0;
		if (obj.getVar("WeaponcomboWeapon3").getBool(0)) customData = 1;
		obj.sq_StopMove();
		obj.sq_PlaySound("SW_HALFMOON");
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(customData);
		obj.sq_AddSetStatePacket(133, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Halfmoon(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 133, {[0] = true, [108] = true, [14] = true});
}


function onSetState_Halfmoon(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			BodyMagicSword(obj, "HalfMoon1");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(282);
			else
				obj.sq_SetCurrentAnimation(90);
			if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) sq_SendMessage(obj, OBJECT_MESSAGE_SUPERARMOR, 1, 0);
			break;
		case 1:
			HeavyswordmasteryAddAppend(obj);
			local customData = 0.0;
			local customData1 = 100;
			local levelData = sq_GetLevelData(obj, 12, 13, sq_GetSkillLevel(obj, 12));
			if (obj.getVar("WeaponcomboWeapon3").getBool(0)) {
				obj.sq_SetStaticMoveInfo(0, 600, 450, false);
				customData = sq_GetIntData(obj, 133, 5) / 100.0;
				if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3) {
					customData = sq_GetLevelData(obj, 12, 1, sq_GetSkillLevel(obj, 12)) / 100.0 + customData;
					customData1 = levelData + customData1;
				}
			} else
				obj.sq_SetStaticMoveInfo(0, 450, 450, false);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			BodyMagicSword(obj, "HalfMoon2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(283);
			else
				obj.sq_SetCurrentAnimation(91);
			local attackRate = obj.sq_GetBonusRateWithPassive(133, -1, 0, getATSwordmanBonus(obj, 1.0 + customData, 133));
			obj.sq_StartWrite();
			obj.sq_WriteDword(133);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(attackRate);
			obj.sq_WriteDword(customData1);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			break;
		case 2:
			local aniPath = "character/swordman/effect/animation/athalfmoon/fullcharge.ani";
			DarktemplerCreateAniPooledObj(obj, aniPath, true, true, obj.getXPos(), obj.getYPos(), obj.getZPos(), 1.0);
			BodyMagicSword(obj, "HalfMoon3");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(284);
			else
				obj.sq_SetCurrentAnimation(92);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Halfmoon(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(133, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Halfmoon(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
}


function onEnterFrame_Halfmoon(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (frameIndex == 3) 
			{
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(133, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
		case 4:

			break;
	}
}


function onEndState_Halfmoon(obj, new_state) {
	if (!obj) return;
	if (sq_GetSkillLevel(obj, 12) > 0 && obj.getWeaponSubType() == 3 && new_state != 133) sq_SendMessage(obj, OBJECT_MESSAGE_SUPERARMOR, 0, 0);
	local subState = obj.getSkillSubState();
}


function onProcCon_Halfmoon(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Halfmoon(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 2:
			local levelData = sq_GetLevelData(obj, 133, 1, sq_GetSkillLevel(obj, 133));
			local staticData = sq_GetIntData(obj, 133, 4);
			local stateTimer = obj.sq_GetStateTimer();
			if (!obj.isDownSkillLastKey()) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_AddSetStatePacket(133, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				if (stateTimer > levelData) {
					obj.getVar("WeaponcomboWeapon3").setBool(0, true);
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(1);
					obj.sq_AddSetStatePacket(133, STATE_PRIORITY_IGNORE_FORCE, true);
				}
			}
			break;
		case 1:
			local aniFrameIndex = sq_GetAnimationFrameIndex(obj.getCurrentAnimation());
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL) && aniFrameIndex < 7) {
				obj.sq_SetStaticMoveInfo(1, 200, 200, false, -500, true);
				obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_UP);
			}
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL) && aniFrameIndex < 7) {
				obj.sq_SetStaticMoveInfo(1, -200, 200, false, -500, true);
				obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_DOWN);
			}
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.sq_SetStaticMoveInfo(0, 0, 0, false);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.sq_SetStaticMoveInfo(0, 0, 0, false);
			break;
	}
}


function onKeyFrameFlag_Halfmoon(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 1)
	{
		if (flagIndex == 10001)
		{
				if (sq_GetSkillLevel(obj, 134) > 0) 
				{
					local customData = GetMagicSwordAppIndex(obj);
					local attackRate = obj.sq_GetBonusRateWithPassive(134, -1, 1, getATSwordmanBonus(obj, 1.0, 134));
					local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), sq_GetIntData(obj, 134, 1));
					obj.sq_StartWrite();
					obj.sq_WriteDword(134);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(attackRate);
					obj.sq_WriteDword(dstPos);
					obj.sq_WriteDword(customData);
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, 30, 0, 10);
				}
		}
	}
	return true;
}


