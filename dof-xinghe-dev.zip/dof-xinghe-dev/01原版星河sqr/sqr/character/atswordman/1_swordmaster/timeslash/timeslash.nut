
function checkExecutableSkill_Timeslash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(142);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 142, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(142, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Timeslash(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 142, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Timeslash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "TimeslashStart");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(328);
			else
				obj.sq_SetCurrentAnimation(106);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(142, -1, 0, getATSwordmanBonus(obj, 1.0, 142));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			if (sq_GetSkillLevel(obj, 142) > 2) sq_SendMessage(obj, OBJECT_MESSAGE_INVINCIBLE, 1, 0);
			break;
		case 1:
			BodyMagicSword(obj, "TimeslashCharge");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(324);
			else
				obj.sq_SetCurrentAnimation(108);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(142, -1, 0, getATSwordmanBonus(obj, 1.0, 142));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 2:
			BodyMagicSword(obj, "TimeslashSlash");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(327);
			else
				obj.sq_SetCurrentAnimation(109);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(142, -1, 0, getATSwordmanBonus(obj, 1.0, 142));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			if (sq_GetSkillLevel(obj, 142) < 2) break;
			local apPath = "character/atswordman/1_swordmaster/timeslash/ap_devilslash.nut";
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
			local levelData = sq_GetLevelData(obj, 142, 3, sq_GetSkillLevel(obj, 142));
			local levelData1 = sq_GetLevelData(obj, 142, 6, sq_GetSkillLevel(obj, 142));
			if (appendage != null) {
				appendage.sq_SetValidTime(levelData);
				appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 142, sq_GetSkillLevel(obj, 142));
				appendage.setEnableIsBuff(true);
				CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
				if (sq_GetSkillLevel(obj, 142) < 8) break;
				local change_appendage = appendage.sq_getChangeStatus("Timeslash");
				if (!change_appendage) {
					change_appendage = appendage.sq_AddChangeStatus("Timeslash", obj, obj, 0, 49, false, levelData1);
				}
				if (change_appendage) {
					levelData1 = levelData1 * -0.01;
					change_appendage.clearParameter();
					change_appendage.addParameter(49, false, levelData1.tofloat());
				}
			}
			break;
		case 3:
			BodyMagicSword(obj, "TimeslashExp");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(326);
			else
				obj.sq_SetCurrentAnimation(110);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(142, -1, 0, getATSwordmanBonus(obj, 1.0, 142));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			if (obj.isMyControlObject()) {
				obj.sq_SetShake(obj, 8, 250);
				sq_setFullScreenEffect(obj, "character/swordman/effect/animation/attimeslash/finish_timeslash_crack.ani");
				locakonhit(obj, "character/swordman/effect/animation/attimeslash/finish_timeslash_space.ani", 0, -1, 0, 0, 100, 1, 1, 1, 0);
			}
			break;
	}

}


function onEndCurrentAni_Timeslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(142, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(142, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(142, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Timeslash(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Timeslash(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (frameIndex == 4) {
			}
			break;
		case 2:
			if (frameIndex == 1 || frameIndex == 6 || frameIndex == 11) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(142);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(142, -1, 0, getATSwordmanBonus(obj, 1.0, 142)));
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			} else if (frameIndex == 19 || frameIndex == 21 || frameIndex == 24) {
			}
			break;
		case 3:
			if (frameIndex == 0 && obj.isMyControlObject()) {
				local sq_var = obj.getVar();
				local flashScreenObj = sq_flashScreen(obj, 0, 1060, 103, 255, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_NORMAL);
				sq_var.setObject(0, flashScreenObj);
				obj.sq_StartWrite();
				obj.sq_WriteDword(142);
				obj.sq_WriteDword(1);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(142, -1, 1, getATSwordmanBonus(obj, 1.0, 142)));
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 0);
			}
			break;
	}
}


function onEndState_Timeslash(obj, new_state) {
	if (!obj) return;
	if (new_state != 142) {
		if (sq_GetSkillLevel(obj, 142) > 2) sq_SendMessage(obj, OBJECT_MESSAGE_INVINCIBLE, 0, 0);
		local sq_var_obj = obj.getVar().getObject(0);
		if (sq_var_obj) {
			local pflashScreen = sq_GetCNRDObjectToFlashScreen(sq_var_obj);
			if (pflashScreen) pflashScreen.fadeOut();
		}
	}
}



function onKeyFrameFlag_Timeslash(obj, flagIndex) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	switch (flagIndex) {
		case 1:
			if (subState != 3) {
				obj.sq_SetShake(obj, 4, 150);
				sq_flashScreen(obj, 0, 60, 0, 102, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
			}
			break;
	}
	return true;
}



function onProcCon_Timeslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Timeslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}

