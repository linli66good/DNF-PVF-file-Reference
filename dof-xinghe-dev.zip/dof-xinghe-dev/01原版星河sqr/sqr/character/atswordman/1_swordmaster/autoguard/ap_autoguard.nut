function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onDamageParent", "onDamageParent_appendage_Autoguard"); }

function onDamageParent_appendage_Autoguard(appendage, attacker, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local chr = sq_GetCNRDObjectToCharacter(parentObj);
	local levelData = sq_GetLevelData(chr, 126, 0, sq_GetSkillLevel(chr, 126));
	local randNum = sq_getRandom(0, 99);
	if (randNum > levelData) return;
	chr.getVar("Autoguard").setBool(0, true);
	if (IsFrontOf(chr, attacker))
		chr.getVar("ATSwordman_Autoguard").setInt(0, attacker.getDirection());
	else
		chr.getVar("ATSwordman_Autoguard").setInt(0, sq_GetOppositeDirection(attacker.getDirection()));
}
