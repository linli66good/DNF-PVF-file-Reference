

function checkExecutableSkill_Autoguard(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(126);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 126, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(126, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Autoguard(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 126, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Autoguard(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "AutoGuardCast1");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(231);
			else
				obj.sq_SetCurrentAnimation(74);
			local castTime = sq_GetCastTime(obj, 126, sq_GetSkillLevel(obj, 126));
			local currentAni = sq_GetCurrentAnimation(obj);
			local frameStartT = sq_GetFrameStartTime(currentAni, 4);
			local floatData = frameStartT.tofloat() / castTime.tofloat();
			sq_StartDrawCastGauge(obj, frameStartT, true);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, floatData, floatData);
			break;
		case 1:
			BodyMagicSword(obj, "AutoGuardCast2");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(232);
			else
				obj.sq_SetCurrentAnimation(75);
			local levelData = sq_GetLevelData(obj, 126, 1, sq_GetSkillLevel(obj, 126));
			local apPath = "character/atswordman/1_swordmaster/autoguard/ap_autoguard.nut";
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
			appendage.sq_SetValidTime(levelData);
			appendage.setEnableIsBuff(true);
			appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 126, sq_GetSkillLevel(obj, 126));
			CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
			appendage.setBuffIconImage(57);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_StopMove();
			obj.sq_SetDirection(obj.getVar("ATSwordman_Autoguard").getInt(0));
			BodyMagicSword(obj, "AutoGuard");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(230);
			else
				obj.sq_SetCurrentAnimation(76);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			sq_SendMessage(obj, OBJECT_MESSAGE_SUPERARMOR, 1, 0);
			local apPath1 = "character/atswordman/guard/ap_guard.nut";
			if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath1)) break;
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath1, false);
			if (appendage != null) {
				appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 85, sq_GetSkillLevel(obj, 85));
				CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
			}
			break;
	}
}


function onEndCurrentAni_Autoguard(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(126, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEnterFrame_Autoguard(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Autoguard(obj, new_state) {
	if (!obj) return;
	sq_SendMessage(obj, OBJECT_MESSAGE_SUPERARMOR, 0, 0);
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			sq_EndDrawCastGauge(obj);
			break;
		case 2:
			local apPath = "character/atswordman/guard/ap_guard.nut";
			if (new_state != 85 && CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath)) CNSquirrelAppendage.sq_RemoveAppendage(obj, apPath);
			break;
	}
}



function onProcCon_Autoguard(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Autoguard(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Autoguard(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


function proSkill_ATSwordman_Autoguard(obj) {
	if (obj.getVar("Autoguard").getBool(0)) {
		obj.getVar("Autoguard").setBool(0, false);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(2);
		obj.sq_AddSetStatePacket(126, STATE_PRIORITY_IGNORE_FORCE, true);
	}

	return;
}














