
function checkExecutableSkill_Dragonupex(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(137);
	if (isUse) {
		CheckUseAddloadDrawsword(obj, 137, {[0] = true, [108] = true, [14] = true}, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(137, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Dragonupex(obj) {
	if (!obj) return false;
	if (obj.getZPos() > 10) return false;
	return CheckForceDrawsword(obj, 137, {[0] = true, [108] = true, [14] = true});
}



function onSetState_Dragonupex(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_SPOUT");
			BodyMagicSword(obj, "DragonUpExCasting");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(272);
			else
				obj.sq_SetCurrentAnimation(111);
			break;
		case 1:
			BodyMagicSword(obj, "DragonUpExDash");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(274);
			else
				obj.sq_SetCurrentAnimation(112);
			obj.sq_SetCurrentAttackInfo(69);
			local attackRate = obj.sq_GetBonusRateWithPassive(137, -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetStaticMoveInfo(0, 800, -1000, false);
			break;
		case 2:
			obj.sq_StopMove();
			BodyMagicSword(obj, "DragonUpExCutting");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(273);
			else
				obj.sq_SetCurrentAnimation(113);
			obj.sq_SetCurrentAttackInfo(70);
			local attackRate = obj.sq_GetBonusRateWithPassive(137, -1, 1, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 3:
			BodyMagicSword(obj, "dragonupexfrontdash");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(275);
			else
				obj.sq_SetCurrentAnimation(114);
			obj.sq_SetCurrentAttackInfo(69);
			local attackRate = obj.sq_GetBonusRateWithPassive(137, -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Dragonupex(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(137, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(137, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Dragonupex(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Dragonupex(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 2:
			if (frameIndex != 3) break;
			obj.sq_StartWrite();
			obj.sq_WriteDword(137);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(137, -1, 1, 1.0));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(137, -1, 2, 1.0));
			obj.sq_WriteDword(sq_GetIntData(obj, 137, 0));
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 105, 1, 0);
			break;
		case 4:

			break;
	}
}


function onEndState_Dragonupex(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onKeyFrameFlag_Dragonupex(obj, flagIndex) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	switch (flagIndex) {
		case 1:
			if (subState != 2) break;
			break;
	}
	return true;
}



function onProcCon_Dragonupex(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.sq_SetStaticMoveInfo(0, 0, 0, false);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.sq_SetStaticMoveInfo(0, 0, 0, false);
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.sq_SetStaticMoveInfo(0, 3800, -1000, false);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.sq_SetStaticMoveInfo(0, 3800, -1000, false);
			break;
	}
}


function onProc_Dragonupex(obj) {
	if (!obj) return;
}

