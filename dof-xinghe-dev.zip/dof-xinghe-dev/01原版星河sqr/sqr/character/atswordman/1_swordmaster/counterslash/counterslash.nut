
function checkExecutableSkill_Counterslash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(144);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(144, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Counterslash(obj) {
	if (!obj) return false;
	local apPath = "character/atswordman/1_swordmaster/counterslash/ap_counterslash.nut";
	if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath)) return true;
	return false;
}



function onSetState_Counterslash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyMagicSword(obj, "CounterSlash");
			if (MagicSword_IsAppebd(obj))
				obj.sq_SetCurrentAnimation(264);
			else
				obj.sq_SetCurrentAnimation(72);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(144, -1, 0, getATSwordmanBonus(obj, 1.0, 144));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Counterslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}

function onAttack_Counterslash(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	MagicSword_BasiconAttack(obj, damager, boundingBox, isStuck);
}

function onProc_Counterslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


