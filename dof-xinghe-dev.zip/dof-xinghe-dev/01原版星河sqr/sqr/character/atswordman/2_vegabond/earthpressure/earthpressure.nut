
function checkExecutableSkill_Earthpressure(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(214);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(214, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Earthpressure(obj) {
	if (!obj) return false;
	return true;
}




function onSetState_Earthpressure(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_EARTH_PRESSURE");
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ndelay = ani.getDelaySum(false);
			local speed = delay.tofloat() / ndelay.tofloat();
			local size = sq_GetIntData(obj, 214, 0);
			locakonhit(obj, "character/swordman/effect/animation/atearthpressure/earthpressureeffect_effect.ani", 0, 0, 0, 0, size, 0, 1, speed, 0);
			obj.sq_SetCurrentAnimation(553);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(214, -1, 0, getATSwordmanBonus(obj, 1.0, 214));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_StartWrite();
			obj.sq_WriteDword(214);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(214, -1, 0, getATSwordmanBonus(obj, 1.0, 214)));
			obj.sq_WriteDword(sq_GetIntData(obj, 214, 0));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, -1, 0);
			break;
	}
}



function onEndCurrentAni_Earthpressure(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Earthpressure(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Earthpressure(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (frameIndex) {
		case 6:
			sq_SetMyShake(obj, 2, 250);
			sq_flashScreen(obj, 0, 100, 0, 102, sq_RGB(192, 192, 192), GRAPHICEFFECT_LINEARDODGE, ENUM_DRAWLAYER_BOTTOM);
			break;
		case 4:

			break;
	}
}


function onEndState_Earthpressure(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Earthpressure(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Earthpressure(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Earthpressure(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
