
function checkExecutableSkill_Rapidstep(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(210);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(210, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Rapidstep(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Rapidstep(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_1ATK_02");
			obj.sq_SetCurrentAnimation(542);
			local currentAni = sq_GetCurrentAnimation(obj);
			local customData = 0;
			obj.getVar("Rapidstep").clear_vector();
			obj.getVar("Rapidstep").push_vector(obj.getXPos());
			obj.getVar("Rapidstep").push_vector(customData);
			break;
	}
}


function onEndCurrentAni_Rapidstep(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEnterFrame_Rapidstep(obj, frameIndex) {
	if (!obj) return;
	if (frameIndex < 9) {
		obj.sq_StartWrite();
		obj.sq_WriteDword(210);
		obj.sq_WriteDword(0);
		obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(210, -1, 0, getATSwordmanBonus(obj, 1.0, 210)));
		obj.sq_WriteDword(frameIndex);
		obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, 0, 65);
	}
}


function onEndState_Rapidstep(obj, new_state) {
	if (!obj) return;
	if (new_state != 210) sq_SimpleMoveToNearMovablePos(obj, 900);
}


function onProc_Rapidstep(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local staticData = sq_GetIntData(obj, 210, 0);
			local Rapidstep_int = obj.getVar("Rapidstep").get_vector(0);
			local dstPos = sq_GetDistancePos(Rapidstep_int, obj.getDirection(), staticData);
			local dstPos1 = sq_GetDistancePos(Rapidstep_int, obj.getDirection(), staticData);
			local currentAni = sq_GetCurrentAnimation(obj);
			local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			if (frameIndex < 7) {
				local movePos = sq_GetAccel(obj.getXPos(), dstPos, stateTimer, 550, false);
				local movePos1 = sq_GetAccel(obj.getZPos(), 100, stateTimer, 550, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) {
					sq_setCurrentAxisPos(obj, 0, movePos);
					sq_setCurrentAxisPos(obj, 2, movePos1);
				}
			} else if (frameIndex >= 7 && frameIndex < 10) {
				local movePos = sq_GetAccel(obj.getXPos(), dstPos1, stateTimer, 100, false);
				local movePos1 = sq_GetAccel(obj.getZPos(), 0, stateTimer, 100, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) {
					sq_setCurrentAxisPos(obj, 0, movePos);
					sq_setCurrentAxisPos(obj, 2, movePos1);
				}
			} else
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onKeyFrameFlag_Rapidstep(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Rapidstep(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
