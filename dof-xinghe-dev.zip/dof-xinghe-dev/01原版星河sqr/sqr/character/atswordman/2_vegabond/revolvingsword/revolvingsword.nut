
function checkExecutableSkill_Revolvingsword(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(227);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(227, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Revolvingsword(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Revolvingsword(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);

	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_REVOLVING_SWORD");
			obj.sq_SetCurrentAnimation(530);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(531);
			obj.sq_SetCurrentAttackInfo(150);
			local attackRate = obj.sq_GetBonusRateWithPassive(103, -1, 0, getATSwordmanBonus(obj, 1.0, 227));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local staticData = sq_GetIntData(obj, 227, 0);
			local staticData1 = sq_GetIntData(obj, 227, 5);
			obj.setTimeEvent(1, staticData1, staticData, true);
			break;
		case 2:
			obj.stopTimeEvent(1);
			obj.sq_SetCurrentAnimation(529);
			obj.sq_SetCurrentAttackInfo(149);
			local attackRate = obj.sq_GetBonusRateWithPassive(103, -1, 1, getATSwordmanBonus(obj, 1.0, 227));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Revolvingsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(227, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:

			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onTimeEvent_Revolvingsword(obj, timeEventIndex, timeEventCount) {
	if (!obj) return false;
	switch (timeEventIndex) {
		case 1:
			obj.resetHitObjectList();
			if (timeEventCount >= sq_GetIntData(obj, 227, 0)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(227, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}


function onEnterFrame_Revolvingsword(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Revolvingsword(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Revolvingsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Revolvingsword(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Revolvingsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (sq_IsKeyDown(OPTION_HOTKEY_JUMP, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(227, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}
