
function checkExecutableSkill_Hermittriplestep(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(225);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(225, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Hermittriplestep(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Hermittriplestep(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.getVar("Hermittriplestep").clear_vector();
			obj.getVar("Hermittriplestep").push_vector(obj.getXPos());
			obj.getVar("Hermittriplestep").push_vector(obj.getXPos());
			obj.getVar("Hermittriplestep").clear_obj_vector();
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(612);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 60, 420, 0, 102, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			local customArr = [
				"character/swordman/effect/animation/athermittriplestep/cast_ilusion.ani", "character/swordman/effect/animation/athermittriplestep/cast_dust.ani",
				"character/swordman/effect/animation/athermittriplestep/cast_effect.ani"
			];
			foreach (path in customArr) ATswordmanCreateAniPooledObj(obj, path, false, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(609);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 0, 120, 0, 102, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			local customArr = [
				"character/swordman/effect/animation/athermittriplestep/attacka_back_leef02.ani", "character/swordman/effect/animation/athermittriplestep/attacka_front_leef03.ani",
				"character/swordman/effect/animation/athermittriplestep/attacka_back_ilusion.ani"
			];
			foreach (path in customArr) ATswordmanCreateAniPooledObj(obj, path, false, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 150);
			obj.getVar("Hermittriplestep").set_vector(1, dstPos);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(610);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 0, 120, 0, 102, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			local customArr = [
				"character/swordman/effect/animation/athermittriplestep/attackb_back_leef02.ani", "character/swordman/effect/animation/athermittriplestep/attackb_back_ilusion.ani",
				"character/swordman/effect/animation/athermittriplestep/attackb_front_leef03.ani"
			];
			foreach (path in customArr) ATswordmanCreateAniPooledObj(obj, path, false, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 150);
			obj.getVar("Hermittriplestep").set_vector(1, dstPos);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(611);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 0, 120, 360, 102, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			local customArr = [
				"character/swordman/effect/animation/athermittriplestep/attackc_back_leef02.ani", "character/swordman/effect/animation/athermittriplestep/attackc_back_ilusion.ani",
				"character/swordman/effect/animation/athermittriplestep/attackc_front_leef01.ani"
			];
			foreach (path in customArr) ATswordmanCreateAniPooledObj(obj, path, false, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 150);
			obj.getVar("Hermittriplestep").set_vector(1, dstPos);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(613);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 720, 120, 0, 255, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 5:
			obj.sq_SetCurrentAnimation(614);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 720, 120, 0, 255, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 6:
			obj.sq_SetCurrentAnimation(615);
			obj.sq_SetCurrentAttackInfo(177);
			local attackRate = obj.sq_GetBonusRateWithPassive(225, -1, 0, getATSwordmanBonus(obj, 1.0, 225));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			if (obj.isMyControlObject()) sq_flashScreen(obj, 0, 0, 600, 153, sq_RGB(255, 255, 255), GRAPHICEFFECT_LINEARDODGE, ENUM_DRAWLAYER_BOTTOM);
			local customArr = [ "character/swordman/effect/animation/athermittriplestep/lastb_effect02.ani", "character/swordman/effect/animation/athermittriplestep/lasta_leef.ani" ];
			foreach (path in customArr) ATswordmanCreateAniPooledObj(obj, path, false, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onEndCurrentAni_Hermittriplestep(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(225, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(225, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(225, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			local Hermittriplestep_int = obj.getVar("Hermittriplestep").get_vector(0);
			local Hermittriplestep_int1 = obj.getVar("Hermittriplestep").get_vector(1);
			if (Hermittriplestep_int == Hermittriplestep_int1) obj.setDirection(sq_GetOppositeDirection(obj.getDirection()));
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(225, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(225, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 6:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEnterFrame_Hermittriplestep(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 6:
			if (frameIndex == 1) {
				sq_SetMyShake(obj, 6, 250);
				local Hermittriplestep_size = obj.getVar("Hermittriplestep").get_obj_vector_size();
				for (local customData = 0; customData < Hermittriplestep_size; ++customData) {
					local Hermittriplestep_obj = obj.getVar("Hermittriplestep").get_obj_vector(customData);
					if (Hermittriplestep_obj) sq_SendHitObjectPacketWithNoStuck(obj, Hermittriplestep_obj, 0, 0, Hermittriplestep_obj.getZPos() + Hermittriplestep_obj.getObjectHeight() / 2);
				}
			}
			break;
	}
}


function onChangeSkillEffect_Hermittriplestep(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != 225) return;
	local readData = reciveData.readDword();
	if (readData == 0) {
	} else if (readData == 1) {
		local Hermittriplestep_int = obj.getVar("Hermittriplestep").get_vector(1);
		obj.getVar("Hermittriplestep").set_vector(0, Hermittriplestep_int);
	}
}


function onAttack_Hermittriplestep(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	local aniPath = "character/swordman/effect/animation/athermittriplestep/hit_effect02.ani";
	DarktemplerCreateAniPooledObj(obj, aniPath, false, true, damager.getXPos(), damager.getYPos() + 1, damager.getZPos() + damager.getObjectHeight() / 2, 1.0);
}


function onEndState_Hermittriplestep(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function HermittriplestepSearchTarget(obj) {
	if (IsInterval(obj, 5)) {
		local objectManager = obj.getObjectManager();
		for (local objectNumber = 0; objectNumber < objectManager.getCollisionObjectNumber(); ++objectNumber) {
			local object = objectManager.getCollisionObject(objectNumber);
			local distFromObj = sq_GetDistanceObject(object, obj, false);
			if (object && obj.isEnemy(object) && distFromObj <= 600 && object.isObjectType(OBJECTTYPE_ACTIVE)) obj.getVar("Hermittriplestep").push_obj_vector(object);
		}
	}
}


function HermittriplestepSetPos(obj, frameIndex) {
	if (frameIndex > 0) {
		local direction = obj.sq_GetInputDirection(0);
		if (obj.getDirection() == direction) {
			sq_BinaryStartWrite();
			sq_BinaryWriteDword(1);
			sq_SendChangeSkillEffectPacket(obj, 225);
		}
	}
}


function onProc_Hermittriplestep(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local currentAni = sq_GetCurrentAnimation(obj);
	local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
	local delay = sq_GetDelaySum(currentAni);
	local stateTimer = obj.sq_GetStateTimer();
	switch (subState) {
		case 1:
			HermittriplestepSearchTarget(obj);
			HermittriplestepSetPos(obj, frameIndex);
			local Hermittriplestep_int = obj.getVar("Hermittriplestep").get_vector(1);
			local movePos = sq_GetAccel(obj.getXPos(), Hermittriplestep_int, stateTimer, delay / 2, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 2:
			HermittriplestepSearchTarget(obj);
			HermittriplestepSetPos(obj, frameIndex);
			local Hermittriplestep_int = obj.getVar("Hermittriplestep").get_vector(1);
			local movePos = sq_GetAccel(obj.getXPos(), Hermittriplestep_int, stateTimer, delay / 2, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 3:
			HermittriplestepSearchTarget(obj);
			HermittriplestepSetPos(obj, frameIndex);
			local Hermittriplestep_int = obj.getVar("Hermittriplestep").get_vector(1);
			local movePos = sq_GetAccel(obj.getXPos(), Hermittriplestep_int, stateTimer, delay / 2, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 4:
			local Hermittriplestep_int = obj.getVar("Hermittriplestep").get_vector(0);
			local movePos = sq_GetAccel(obj.getXPos(), Hermittriplestep_int, stateTimer, 30, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 6:

			break;
	}
}


function onProcCon_Hermittriplestep(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
