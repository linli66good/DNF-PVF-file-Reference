
function checkExecutableSkill_Cometblade(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(220);
	if (isUse) {
		obj.sq_StopMove();
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(2);
		obj.sq_AddSetStatePacket(220, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Cometblade(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Cometblade(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			local customArr = [ 585, 583, 582, 584, 581, 581 ];
			local customData = checkAppend_Dualweapon(obj);
			obj.sq_SetCurrentAnimation(customArr[customData]);
			obj.sq_SetCurrentAttackInfo(170);
			local attackRate = obj.sq_GetBonusRateWithPassive(220, -1, 2, getATSwordmanBonus(obj, 1.0, 220));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			obj.sq_PlaySound("SW_COMET_BLADE");
			obj.sq_SetCurrentAnimation(575);
			obj.sq_SetCurrentAttackInfo(169);
			local attackRate = obj.sq_GetBonusRateWithPassive(220, -1, 2, getATSwordmanBonus(obj, 1.0, 220));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_PlaySound("SW_COMET_BLADE");
			obj.getVar("Cometblade").clear_vector();
			obj.getVar("Cometblade").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 400));
			obj.sq_SetCurrentAnimation(576);
			obj.sq_SetCurrentAttackInfo(165);
			local attackRate = obj.sq_GetBonusRateWithPassive(220, -1, 1, getATSwordmanBonus(obj, 1.0, 220));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ndelay = ani.getDelaySum(false);
			local speed = delay.tofloat() / ndelay.tofloat();
			locakonhit(obj, "character/swordman/effect/animation/atcometblade/cutsmoke.ani", 0, 0, 0, 0, 100, 0, 1, speed, 0);
			locakonhit(obj, "character/swordman/effect/animation/3rd/atgonewiththepetal/rangecheck_01.ani", 0, 0, 0, 0, 100, 0, 1, speed/2, 0);
			break;
		case 3:
			obj.getVar("Cometblade").clear_vector();
			obj.getVar("Cometblade").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 300));
			obj.sq_SetCurrentAnimation(578);
			obj.sq_SetCurrentAttackInfo(167);
			local attackRate = obj.sq_GetBonusRateWithPassive(220, -1, 2, getATSwordmanBonus(obj, 1.0, 220));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 4:
			obj.sq_ZStop();
			obj.getVar("Cometblade").clear_vector();
			obj.getVar("Cometblade").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -300));
			obj.sq_SetCurrentAnimation(577);
			obj.sq_SetCurrentAttackInfo(166);
			local attackRate = obj.sq_GetBonusRateWithPassive(220, -1, 2, getATSwordmanBonus(obj, 1.0, 220));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 5:
			obj.sq_ZStop();
			obj.getVar("Cometblade").clear_vector();
			obj.getVar("Cometblade").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -300));
			obj.sq_SetCurrentAnimation(579);
			obj.sq_SetCurrentAttackInfo(168);
			local attackRate = obj.sq_GetBonusRateWithPassive(220, -1, 2, getATSwordmanBonus(obj, 1.0, 220));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 6:
			obj.sq_SetCurrentAnimation(580);
			obj.sq_SetCurrentAttackInfo(168);
			local attackRate = obj.sq_GetBonusRateWithPassive(220, -1, 3, getATSwordmanBonus(obj, 1.0, 220));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
	SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEnterFrame_Cometblade(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			switch (frameIndex) {
				case 4:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 220);
					break;
				case 7:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 220);
					break;
				case 9:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 220);
					break;
				case 13:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 220);
					break;
				case 20:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 220);
					break;
				case 21:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 220);
					break;
				case 22:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 220);
					sq_SetMyShake(obj, 5, 100);
					sq_flashScreen(obj, 50, 100, 300, 204, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
		case 2:
			switch (frameIndex) {
				case 0:
					sq_SetMyShake(obj, 10, 200);
					sq_flashScreen(obj, 50, 200, 400, 204, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
		case 4:
			switch (frameIndex) {
				case 1:
					sq_SetMyShake(obj, 10, 200);
					sq_flashScreen(obj, 30, 150, 200, 153, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 5:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(1);
					sq_SendChangeSkillEffectPacket(obj, 220);
					break;
			}
			break;
		case 6:
			switch (frameIndex) {
				case 1:
					sq_SetMyShake(obj, 20, 200);
					sq_flashScreen(obj, 30, 150, 250, 204, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
	}
}


function onChangeSkillEffect_Cometblade(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != 220) return;
	local readData = reciveData.readDword();
	if (readData == 0)
		obj.resetHitObjectList();
	else if (readData == 1) {
		local customArr = [ "character/swordman/effect/animation/atcometblade/finishfixsword.ani", "character/swordman/effect/animation/atcometblade/finishfloor_00.ani" ];
		foreach (path in customArr) DarktemplerCreateAniPooledObj(obj, path, false, true, obj.getXPos(), obj.getYPos() - 1, 0, 1.0);
	}
}


function onEndCurrentAni_Cometblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(220, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(220, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.setDirection(sq_GetOppositeDirection(obj.getDirection()));
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(220, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(220, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(220, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 6:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Cometblade(obj, damager, boundingBox, isStuck)
{
	if (!obj) return;
	local substate = obj.getSkillSubState();
	if (substate == 2)
	{
		local masterAppendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, 220, false, "character/atswordman/2_vegabond/cometblade/ap_cometbladehold.nut", true);
		if(masterAppendage)
		{
			sq_HoldAndDelayDie(damager, obj, true, false, false, 0, 0, ENUM_DIRECTION_NEUTRAL, masterAppendage);
			masterAppendage.sq_SetValidTime(2000);
		}
		obj.sq_StartWrite();
		obj.sq_WriteDword(404);
		sq_SendCreatePassiveObjectPacketPos(obj, 24238, 0, damager.getXPos(), damager.getYPos(), damager.getZPos()+70);
	}
}


function onProc_Cometblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local Cometblade_int = obj.getVar("Cometblade").get_vector(0);
	local currentAni = sq_GetCurrentAnimation(obj);
	local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
	local delay = sq_GetDelaySum(currentAni);
	local stateTimer = obj.sq_GetStateTimer();
	switch (subState) {
		case 2:
			if (frameIndex < 8) {
				local movePos = sq_GetAccel(obj.getXPos(), Cometblade_int, stateTimer, 150, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			}	
			break;
		case 3:
			local movePos = sq_GetAccel(obj.getXPos(), Cometblade_int, stateTimer, 100, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 4:
			local movePos = sq_GetAccel(obj.getXPos(), Cometblade_int, stateTimer, 70, false);
			local movePos1 = sq_GetAccel(obj.getZPos(), 220, stateTimer, 70, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) {
				sq_setCurrentAxisPos(obj, 0, movePos);
				sq_setCurrentAxisPos(obj, 2, movePos1);
			}
			break;
		case 5:
			if (frameIndex < 6) {
				local movePos1 = sq_GetAccel(obj.getZPos(), 0, stateTimer, 70, false);
				sq_setCurrentAxisPos(obj, 2, movePos1);
			} else if (frameIndex > 6) {
				local movePos = sq_GetAccel(obj.getXPos(), Cometblade_int, stateTimer, 80, false);
				local movePos1 = sq_GetAccel(obj.getZPos(), 220, stateTimer, 80, false);
				if (obj.isMovablePos(movePos, obj.getYPos())) {
					sq_setCurrentAxisPos(obj, 0, movePos);
					sq_setCurrentAxisPos(obj, 2, movePos1);
				}
			}
			break;
		case 6:
			local movePos1 = sq_GetAccel(obj.getZPos(), 0, stateTimer, 150, false);
			sq_setCurrentAxisPos(obj, 2, movePos1);
			break;
	}
}


function onKeyFrameFlag_Cometblade(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



