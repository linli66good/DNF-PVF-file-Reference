
function checkExecutableSkill_Fistofexplosion(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(219);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(219, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Fistofexplosion(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Fistofexplosion(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(573);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(572);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(574);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			sq_SetMyShake(obj, 7, 180);
			sq_flashScreen(obj, 0, 0, 150, 153, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			obj.sq_StartWrite();
			obj.sq_WriteDword(219);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(219, -1, 2, getATSwordmanBonus(obj, 1.0, 219)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(219, -1, 1, getATSwordmanBonus(obj, 1.0, 219)));
			obj.sq_WriteDword(sq_GetIntData(obj, 219, 2));
			obj.sq_WriteDword(sq_GetLevelData(obj, 219, 0, sq_GetSkillLevel(obj, 219)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 20, 0, 85);
			break;
	}
}


function onEndCurrentAni_Fistofexplosion(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(219, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(219, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


