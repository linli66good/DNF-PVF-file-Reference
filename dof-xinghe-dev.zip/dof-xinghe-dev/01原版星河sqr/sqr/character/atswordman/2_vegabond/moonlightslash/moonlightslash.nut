
function checkExecutableSkill_Moonlightslash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(226);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(226, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Moonlightslash(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Moonlightslash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(620);
			obj.sq_SetCurrentAttackInfo(179);
			local attackRate = obj.sq_GetBonusRateWithPassive(226, -1, 0, getATSwordmanBonus(obj, 1.0, 226));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(616);
			obj.sq_SetCurrentAttackInfo(180);
			local attackRate = obj.sq_GetBonusRateWithPassive(226, -1, 0, getATSwordmanBonus(obj, 1.0, 226));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			obj.setTimeEvent(0, delay / 18, 18, true);
			break;
		case 2:
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 350);
			obj.getVar("Moonlightslash").setInt(0, obj.getXPos());
			obj.getVar("Moonlightslash").setInt(1, dstPos);
			obj.getVar("Moonlightslash").setInt(2, obj.getDirection());
			obj.sq_SetCurrentAnimation(617);
			obj.sq_SetCurrentAttackInfo(181);
			local attackRate = obj.sq_GetBonusRateWithPassive(226, -1, 2, getATSwordmanBonus(obj, 1.0, 226));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 3:
			obj.sq_ZStop();
			obj.sq_SetCurrentAnimation(623);
			obj.sq_SetCurrentAttackInfo(182);
			local attackRate = obj.sq_GetBonusRateWithPassive(226, -1, 3, getATSwordmanBonus(obj, 1.0, 226));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(621);
			obj.sq_SetCurrentAttackInfo(183);
			local attackRate = obj.sq_GetBonusRateWithPassive(226, -1, 5, getATSwordmanBonus(obj, 1.0, 226));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 5:
			obj.sq_SetCurrentAnimation(622);
			obj.sq_SetCurrentAttackInfo(184);
			local attackRate = obj.sq_GetBonusRateWithPassive(226, -1, 6, getATSwordmanBonus(obj, 1.0, 226));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 6:
			obj.sq_SetCurrentAnimation(618);
			obj.getVar("MoonlightslashDraw").setBool(0, true);
			obj.getVar("MoonlightslashDraw").setBool(1, true);
			break;
		case 7:
			obj.sq_SetCurrentAnimation(619);
			obj.sq_SetCurrentAttackInfo(185);
			local attackRate = obj.sq_GetBonusRateWithPassive(226, -1, 7, getATSwordmanBonus(obj, 1.0, 226));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onTimeEvent_Moonlightslash(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	switch (timeEventIndex) {
		case 0:
			obj.resetHitObjectList();
			break;
	}
}


function onEndCurrentAni_Moonlightslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(226, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(226, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(226, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(226, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(226, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.setDirection(obj.getVar("Moonlightslash").getInt(2));
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(226, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 6:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(7);
			obj.sq_AddSetStatePacket(226, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 7:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Moonlightslash(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Moonlightslash(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			switch (frameIndex) {
				case 5:
					sq_SetMyShake(obj, 5, 50);
					sq_flashScreen(obj, 100, 4600, 0, 204, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 11:
					sq_SetMyShake(obj, 4, 100);
					break;
				case 12:
					sq_SetMyShake(obj, 9, 200);
					sq_flashScreen(obj, 0, 50, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 226);
					break;
			}
			break;
		case 1:
			switch (frameIndex) {
				case 0:
					sq_flashScreen(obj, 0, 20, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 3:
					sq_flashScreen(obj, 0, 20, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 6:
					sq_flashScreen(obj, 0, 20, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 9:
					sq_flashScreen(obj, 0, 20, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 12:
					sq_flashScreen(obj, 0, 20, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 15:
					sq_flashScreen(obj, 0, 20, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 18:
					sq_flashScreen(obj, 0, 20, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
		case 2:
			switch (frameIndex) {
				case 0:
					sq_SetMyShake(obj, 5, 240);
					sq_flashScreen(obj, 0, 100, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
		case 3:
			switch (frameIndex) {
				case 0:
					sq_SetMyShake(obj, 3, 10);
					break;
			}
			break;
		case 4:
			switch (frameIndex) {
				case 0:
					sq_flashScreen(obj, 0, 40, 0, 102, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 1:
					sq_SetMyShake(obj, 7, 150);
					break;
			}
			break;
		case 6:
			switch (frameIndex) {
				case 0:
					sq_flashScreen(obj, 0, 20, 0, 76, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 2:
					sq_flashScreen(obj, 0, 20, 0, 51, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 4:
					sq_flashScreen(obj, 0, 100, 0, 127, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
		case 7:
			switch (frameIndex) {
				case 0:
					sq_SetMyShake(obj, 10, 700);
					sq_flashScreen(obj, 0, 60, 0, 127, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
	}
}


function onEndState_Moonlightslash(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onChangeSkillEffect_Moonlightslash(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != 226) return;
	local readData = reciveData.readDword();
	if (readData == 0) {
		local aniPath = "character/swordman/effect/animation/atmakelotusslash/atmakelotusslash_step01c_dust04.ani";
		ATswordmanCreateAniPooledObj(obj, aniPath, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
	}
}


function onProc_Moonlightslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local currentAni = sq_GetCurrentAnimation(obj);
	local delay = sq_GetDelaySum(currentAni);
	local stateTimer = obj.sq_GetStateTimer();
	switch (subState) {
		case 2:
			local Moonlightslash_int = obj.getVar("Moonlightslash").getInt(1);
			local movePos = sq_GetAccel(obj.getXPos(), Moonlightslash_int, stateTimer, delay / 2, false);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 3:
			local Moonlightslash_int = obj.getVar("Moonlightslash").getInt(0);
			local movePos = sq_GetAccel(obj.getXPos(), Moonlightslash_int, stateTimer, delay / 2, false);
			local movePos1 = sq_GetAccel(obj.getZPos(), 200, stateTimer, delay / 2, false);
			sq_setCurrentAxisPos(obj, 2, movePos1);
			if (obj.isMovablePos(movePos, obj.getYPos())) sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 4:
			local movePos1 = sq_GetAccel(obj.getZPos(), 0, stateTimer, delay / 2, false);
			sq_setCurrentAxisPos(obj, 2, movePos1);
			break;
		case 5:
			local movePos1 = sq_GetAccel(obj.getZPos(), 200, stateTimer, delay / 2, false);
			sq_setCurrentAxisPos(obj, 2, movePos1);
			break;
		case 7:
			local movePos1 = sq_GetAccel(obj.getZPos(), 0, stateTimer, delay / 20, false);
			sq_setCurrentAxisPos(obj, 2, movePos1);
			break;
	}
}


function onKeyFrameFlag_Moonlightslash(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


function CreateAimPointMark(obj) {
	local jobCode = sq_getJob(obj);
	local customData = null;
	if (jobCode == ENUM_CHARACTERJOB_AT_MAGE) {
		customData = sq_CreateAnimation("", "Common/CommonEffect/Animation/atmage_cussor/AimPointMark.ani");
		customData.setRGBA(0, 78, 255, 255);
	} else if (jobCode == 10) {
		local customData1 = AIMPOINT_ATSWORDMAN;
		if (customData1 == 69)
			customData = sq_CreateAnimation("", "passiveobject/changqing_atswordman/magiccircle.ani");
		else if (customData1 == 82)
			customData = sq_CreateAnimation("", "character/swordman/effect/animation/atjihad/jihad_targettingloop_a.ani");
	}

	return customData;
}


function CNAimPointMarkCustomAnimation(obj, parentObj) {
	if (!obj) return false;
	local jobCode = sq_getJob(parentObj);
	if (jobCode == ENUM_CHARACTERJOB_AT_MAGE) {
		local ani = sq_CreateAnimation("", "Common/CommonEffect/Animation/atmage_cussor/AimPointMarkDisable.ani");
		local ani1 = sq_CreateAnimation("", "Common/CommonEffect/Animation/atmage_cussor/AimPointMarkVanish.ani");
		local ani2 = sq_CreateAnimation("", "Common/CommonEffect/Animation/atmage_cussor/AimPointMarkDisableVanish.ani");
		local ani3 = sq_CreateAnimation("", "Common/CommonEffect/Animation/atmage_cussor/AimPointMarkEnable.ani");
		if (ani && ani1 && ani2 && ani3) {
			ani.setRGBA(0, 78, 255, 255);
			ani1.setRGBA(0, 78, 255, 255);
			ani2.setRGBA(0, 78, 255, 255);
			ani3.setRGBA(0, 78, 255, 255);
			obj.addCustomAnimation(ani);
			obj.addCustomAnimation(ani1);
			obj.addCustomAnimation(ani2);
			obj.addCustomAnimation(ani3);
			return true;
		}
	} else if (jobCode == 10) {
		local customData = AIMPOINT_ATSWORDMAN;
		if (customData == 69) {
			local ani = sq_CreateAnimation("", "passiveobject/changqing_atswordman/magiccircle.ani");
			local ani1 = sq_CreateAnimation("", "passiveobject/changqing_atswordman/magiccircle.ani");
			local ani2 = sq_CreateAnimation("", "passiveobject/changqing_atswordman/magiccircle.ani");
			local ani3 = sq_CreateAnimation("", "passiveobject/changqing_atswordman/magiccircle.ani");
			ani1.setLoop(false);
			if (ani && ani1 && ani2 && ani3) {
				obj.addCustomAnimation(ani);
				obj.addCustomAnimation(ani1);
				obj.addCustomAnimation(ani2);
				obj.addCustomAnimation(ani3);
				return true;
			}
		} else if (customData == 82) {
			local ani = sq_CreateAnimation("", "character/swordman/effect/animation/atjihad/jihad_targettingloop_a.ani");
			local ani1 = sq_CreateAnimation("", "character/swordman/effect/animation/atjihad/jihad_targettingloop_a.ani");
			local ani2 = sq_CreateAnimation("", "character/swordman/effect/animation/atjihad/jihad_targettingloop_a.ani");
			local ani3 = sq_CreateAnimation("", "character/swordman/effect/animation/atjihad/jihad_targettingloop_a.ani");
			if (ani && ani1 && ani2 && ani3) {
				obj.addCustomAnimation(ani);
				obj.addCustomAnimation(ani1);
				obj.addCustomAnimation(ani2);
				obj.addCustomAnimation(ani3);
				return true;
			}
		}
	}

	return false;
}


function onProcCon_Moonlightslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	if (subState < 6) {
		if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL))
			obj.getVar("Moonlightslash").setInt(2, 0);
		else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL))
			obj.getVar("Moonlightslash").setInt(2, 1);
	}
}


function drawCustomSkillani_ATSwordman(obj) {
	if (!obj.getVar("MoonlightslashDraw").getBool(0)) return;
	local customData = 0;
	Skill_DrawAni(obj, "Moonlightslash", "etc/ultimateskillani/atsword_swordempress2nd.ani", 1.0, 1.0, 255, customData, 50, "MoonlightslashDraw");
	return;
}


function Skill_DrawAni(obj, aniMapName, aniPath, xSize, ySize, alpha, xPos, yPos, varName) {
	local sq_var = obj.getVar();
	local ani = sq_var.GetAnimationMap(aniMapName, aniPath);
	if (obj.getDirection() == 1) {
		xSize = -xSize;
		xPos = xPos + 800;
	}
	if (sq_IsEnd(ani)) {
		if (obj.getVar(varName).getBool(1)) {
			sq_Rewind(ani);
			obj.getVar(varName).setBool(1, false);
		} else
			obj.getVar(varName).setBool(0, false);
	} else {
		sq_AnimationProc(ani);
		ani.setImageRate(xSize, ySize);
		ani.setRGBA(255, 255, 255, alpha);
		sq_drawCurrentFrame(ani, xPos, yPos, false);
		obj.getVar(varName).setBool(1, false);
	}
}



function isMovablePos_CNAimPointMark(obj, parentObj, xPos, yPos) {
	if (!obj) return true;
	if (!parentObj) return true;
	local jobCode = sq_getJob(parentObj);
	if (jobCode == ENUM_CHARACTERJOB_AT_MAGE) {
		return sq_IsMovablePosCollisionObject(parentObj, xPos, yPos);
	} else if (jobCode == 10) {
		return sq_IsMovablePosCollisionObject(parentObj, xPos, yPos);
	}

	return true;
}

