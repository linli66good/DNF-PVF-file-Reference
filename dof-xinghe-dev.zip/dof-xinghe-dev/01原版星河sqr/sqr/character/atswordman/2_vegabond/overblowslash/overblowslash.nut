
function checkExecutableSkill_Overblowslash(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(217);
	if (isUse) {
		obj.sq_StopMove();
		obj.sq_IntVectClear();
		if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
			obj.sq_IntVectPush(1);
		else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
			obj.sq_IntVectPush(1);
		else
			obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(217, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Overblowslash(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Overblowslash(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_SetCurrentAnimation(564);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
			SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(565);
			obj.sq_SetStaticMoveInfo(0, 500, 800, false);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
			SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(566);
			obj.sq_SetCurrentAttackInfo(161);
			local attackRate = obj.sq_GetBonusRateWithPassive(217, -1, 1, getATSwordmanBonus(obj, 1.0, 217));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
			SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			sq_SetMyShake(obj, 2, 650);
			local ani = obj.getCurrentAnimation();
			local chrdelay = ani.getDelaySum(false);
			obj.sq_StartWrite();
			obj.sq_WriteDword(217);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(217, -1, 4, getATSwordmanBonus(obj, 1.0, 217)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(217, -1, 5, getATSwordmanBonus(obj, 1.0, 217)));
			obj.sq_WriteDword(chrdelay);
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, 0, 0);
			obj.setTimeEvent(0, 5, 15, false);
			break;
	}
}


function onTimeEvent_Overblowslash(obj, timeEventIndex, timeEventCount)
{
	local substate = obj.getSkillSubState();
	if(timeEventIndex == 0)
	{
		obj.resetHitObjectList();
	}
}

function onEndCurrentAni_Overblowslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(217, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(217, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}




function onProcCon_Overblowslash(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 2:
			if (sq_IsKeyDown(OPTION_HOTKEY_JUMP, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}
