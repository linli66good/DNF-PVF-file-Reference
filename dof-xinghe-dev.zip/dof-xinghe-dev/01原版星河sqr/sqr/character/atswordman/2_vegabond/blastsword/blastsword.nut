
function checkExecutableSkill_Blastsword(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(218);
	if (isUse) {
		obj.getVar("Blastsword").setInt(0, 450);
		obj.sq_IsEnterSkillLastKeyUnits(218);
		obj.sq_StopMove();
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(2);
		obj.sq_AddSetStatePacket(218, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Blastsword(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Blastsword(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_SetCurrentAnimation(568);
			break;
		case 1:
			obj.sq_PlaySound("SW_BLAST_SWORD");
			obj.sq_SetCurrentAnimation(567);
			obj.sq_SetCurrentAttackInfo(149);
			local attackRate = obj.sq_GetBonusRateWithPassive(218, -1, 0, getATSwordmanBonus(obj, 1.0, 218));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 2:
			obj.getVar("Blastsword").setInt(1, 3);
			obj.sq_SetCurrentAnimation(571);
			obj.sq_SetCurrentAttackInfo(149);
			local attackRate = obj.sq_GetBonusRateWithPassive(218, -1, 0, getATSwordmanBonus(obj, 1.0, 218));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(570);
			obj.sq_SetStaticMoveInfo(0, obj.getVar("Blastsword").getInt(0), 800, false);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetCurrentAttackInfo(149);
			local attackRate = obj.sq_GetBonusRateWithPassive(218, -1, 2, getATSwordmanBonus(obj, 1.0, 218));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local staticData = sq_GetIntData(obj, 218, 4);
			local staticData1 = sq_GetIntData(obj, 218, 0) / 2;
			obj.setTimeEvent(0, staticData1, staticData, true);
			break;
		case 4:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(569);
			obj.sq_SetCurrentAttackInfo(149);
			local attackRate = obj.sq_GetBonusRateWithPassive(218, -1, 0, getATSwordmanBonus(obj, 1.0, 218));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_StartWrite();
			obj.sq_WriteDword(218);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(218, -1, 1, getATSwordmanBonus(obj, 1.0, 218)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 206, 0, 0);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onKeyFrameFlag_Blastsword(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 1)
	{
		if (flagIndex == 10001)
		{
			obj.sq_StartWrite();
			obj.sq_WriteDword(218);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(218, -1, 1, getATSwordmanBonus(obj, 1.0, 218)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 206, 0, 0);
		}
	}
	return true;
}

function onTimeEvent_Blastsword(obj, timeEventIndex, timeEventCount) {
	if (!obj) return false;
	switch (timeEventIndex) {
		case 0:
			obj.resetHitObjectList();
			if (timeEventCount >= sq_GetIntData(obj, 218, 4)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(4);
				obj.sq_AddSetStatePacket(218, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}


function onEndCurrentAni_Blastsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(218, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			local Blastsword_int = obj.getVar("Blastsword").getInt(1);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(Blastsword_int);
			obj.sq_AddSetStatePacket(218, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}

function onProcCon_Blastsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 2:
			if (sq_IsKeyDown(OPTION_HOTKEY_SKILL, ENUM_SUBKEY_TYPE_ALL)) {
				obj.getVar("Blastsword").setInt(1, 1);
			}

			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.getVar("Blastsword").setInt(0, 800);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.getVar("Blastsword").setInt(0, 800);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.getVar("Blastsword").setInt(1, 1);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.getVar("Blastsword").setInt(1, 1);
			else {
				if (obj.isDownSkillLastKey())
					obj.getVar("Blastsword").setInt(1, 1);
				else
					obj.getVar("Blastsword").setInt(1, 3);
			}
			break;
		case 3:

			break;
	}
}
