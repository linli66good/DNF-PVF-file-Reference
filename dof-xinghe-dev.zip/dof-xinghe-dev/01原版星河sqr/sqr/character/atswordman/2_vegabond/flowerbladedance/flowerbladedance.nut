
function checkExecutableSkill_Flowerbladedance(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(224);
	if (isUse) {
		obj.sq_IntVectClear();
		if (obj.sq_GetState() == 6)
			obj.sq_IntVectPush(2);
		else
			obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(224, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Flowerbladedance(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Flowerbladedance(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 250);
			obj.getVar("Flowerbladedance").clear_vector();
			obj.getVar("Flowerbladedance").push_vector(dstPos);
			obj.getVar("Flowerbladedance").setBool(0, false);
			local attackRate = obj.sq_GetBonusRateWithPassive(224, -1, 3, getATSwordmanBonus(obj, 1.0, 224));
			obj.getVar("FlowerbladedanceAtk").setInt(0, attackRate);
			obj.sq_SetCurrentAnimation(602);
			obj.sq_SetCurrentAttackInfo(175);
			local attackRate = obj.sq_GetBonusRateWithPassive(224, -1, 0, getATSwordmanBonus(obj, 1.0, 224));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local appendage = sq_AttractToMe(obj, 550, 0, 2500);
			obj.getVar("Flowerbladedance1").setAppendage(0,appendage);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(603);
			obj.sq_SetCurrentAttackInfo(175);
			local attackRate = obj.sq_GetBonusRateWithPassive(224, -1, 0, getATSwordmanBonus(obj, 1.0, 224));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 2:
			obj.getVar("Flowerbladedance").set_vector(0, obj.getXPos());
			local attackRate = obj.sq_GetBonusRateWithPassive(224, -1, 4, getATSwordmanBonus(obj, 1.0, 224));
			obj.getVar("FlowerbladedanceAtk").setInt(0, attackRate);
			obj.sq_StopMove();
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 300);
			obj.getVar("Flowerbladedance").clear_vector();
			obj.getVar("Flowerbladedance").push_vector(dstPos);
			obj.getVar("Flowerbladedance").setBool(0, false);
			obj.sq_SetCurrentAnimation(604);
			obj.sq_SetCurrentAttackInfo(176);
			local attackRate = obj.sq_GetBonusRateWithPassive(224, -1, 1, getATSwordmanBonus(obj, 1.0, 224));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local appendage = sq_AttractToMe(obj, 550, 0, 2500);
			obj.getVar("Flowerbladedance1").setAppendage(0,appendage);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(605);
			obj.sq_SetCurrentAttackInfo(176);
			local attackRate = obj.sq_GetBonusRateWithPassive(224, -1, 0, getATSwordmanBonus(obj, 1.0, 224));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(606);
			obj.sq_SetCurrentAttackInfo(173);
			local attackRate = obj.getVar("FlowerbladedanceAtk").getInt(0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -400);
			if (obj.getVar("Flowerbladedance").getBool(0)) dstPos = obj.getXPos();
			obj.getVar("Flowerbladedance").clear_vector();
			obj.getVar("Flowerbladedance").push_vector(dstPos);
			local appendage = obj.getVar("Flowerbladedance1").getAppendage(0);
			if(appendage)
				appendage.setValid(false);
			break;
		case 5:
			obj.sq_SetCurrentAnimation(607);
			obj.sq_SetCurrentAttackInfo(176);
			local attackRate = obj.sq_GetBonusRateWithPassive(224, -1, 0, getATSwordmanBonus(obj, 1.0, 224));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 6:
			obj.sq_SetCurrentAnimation(608);
			obj.sq_SetCurrentAttackInfo(174);
			local attackRate = obj.sq_GetBonusRateWithPassive(224, -1, 2, getATSwordmanBonus(obj, 1.0, 224));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(obj.getXPos());
			break;
	}
	
}


function onEndCurrentAni_Flowerbladedance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(224, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(224, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(224, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 6:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(224, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEndState_Flowerbladedance(obj, new_state)
{
	if(!obj) return;
	if(new_state != 224)
	{
		local appendage = obj.getVar("Flowerbladedance1").getAppendage(0);
		if(appendage)
			appendage.setValid(false);
	}
}


function onChangeSkillEffect_Flowerbladedance(obj, skillIndex, reciveData) {
	if (!obj) return;
	local readData = reciveData.readDword();
}


function onEnterFrame_Flowerbladedance(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			switch (frameIndex) {
				case 1:
					sq_SetMyShake(obj, 1, 30);
					sq_flashScreen(obj, 0, 50, 0, 89, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
		case 1:
			switch (frameIndex) {
				case 0:
					sq_flashScreen(obj, 0, 20, 0, 127, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 3:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 224);
					break;
			}
			break;
		case 2:
			switch (frameIndex) {
				case 0:
					sq_SetMyShake(obj, 1, 150);
					sq_flashScreen(obj, 0, 20, 0, 127, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 3:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 224);
					break;
			}
			break;
		case 4:
			switch (frameIndex) {
				case 1:

					break;
				case 5:
					sq_flashScreen(obj, 10, 50, 100, 178, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					sq_SetMyShake(obj, 5, 320);
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(1);
					sq_SendChangeSkillEffectPacket(obj, 224);
					break;
				case 6:
					sq_SetMyShake(obj, 5, 320);
					break;
			}
			break;
		case 6:
			switch (frameIndex) {
				case 0:
					sq_SetMyShake(obj, 3, 160);
					sq_flashScreen(obj, 0, 20, 0, 127, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 5:
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(0);
					sq_SendChangeSkillEffectPacket(obj, 224);
					break;
			}
			break;
	}
}


function onChangeSkillEffect_Flowerbladedance(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != 224) return;
	local readData = reciveData.readDword();
	if (readData == 0)
		obj.resetHitObjectList();
	else if (readData == 1) {
		local aniPath = "character/swordman/effect/animation/atflowerbladedance/spin/flower_spin.ani";
		ATswordmanCreateAniPooledObj(obj, aniPath, false, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
	} else if (readData == 2) {
		obj.getVar("Flowerbladedance").setBool(0, true);
	} else if (readData == 3) {
		obj.getVar("Flowerbladedance").setBool(0, false);
	}
}



function onProc_Flowerbladedance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local currentAni = sq_GetCurrentAnimation(obj);
	local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
	local stateTimer = obj.sq_GetStateTimer();
	switch (subState) {
		case 2:
			local Flowerbladedance_int = obj.getVar("Flowerbladedance").get_vector(0);
			local movePos = sq_GetAccel(obj.getXPos(), Flowerbladedance_int, stateTimer, 50, false);
			local movePos1 = sq_GetAccel(obj.getZPos(), 200, stateTimer, 50, false);
			sq_setCurrentAxisPos(obj, 2, movePos1);
			if (!obj.isMovablePos(movePos, obj.getYPos())) break;
			sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 4:
			local Flowerbladedance_int = obj.getVar("Flowerbladedance").get_vector(0);
			local movePos = sq_GetAccel(obj.getXPos(), Flowerbladedance_int, stateTimer, 50, false);
			if (!obj.isMovablePos(movePos, obj.getYPos())) break;
			sq_setCurrentAxisPos(obj, 0, movePos);
			break;
		case 6:
			local movePos1 = sq_GetAccel(obj.getZPos(), 0, stateTimer, 50, false);
			sq_setCurrentAxisPos(obj, 2, movePos1);
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(2);
				sq_SendChangeSkillEffectPacket(obj, 224);
			} else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1) {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(2);
				sq_SendChangeSkillEffectPacket(obj, 224);
			} else {
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(3);
				sq_SendChangeSkillEffectPacket(obj, 224);
			}
			local ani = obj.getCurrentAnimation();
			local currentT = sq_GetCurrentTime(ani);
			local fireT = ani.getDelaySum(false);
			local objVar = obj.getVar();
			local startX = objVar.get_vector(0);
			if(startX != 0)
			{
				local dstX = sq_GetDistancePos(startX, obj.getDirection(), sq_GetUniformVelocity(0, 300, currentT, fireT/6));
				if(obj.isMovablePos(dstX, obj.getYPos()))
					sq_setCurrentAxisPos(obj, 0, dstX);
				
				else
					objVar.set_vector(0,0);
			}
			break;
	}
}

