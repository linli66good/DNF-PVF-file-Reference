function checkExecutableSkill_Coalban(obj)
{
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(216);
	if (isUse)
	{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(0);
			obj.sq_AddSetStatePacket(216, STATE_PRIORITY_IGNORE_FORCE, true);
			return true;
	}
	return false;
}

function checkCommandEnable_Coalban(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();
	if (state == STATE_STAND)
		return true;
		return true;
}

function onSetState_Coalban(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	if(substate == 0)
	{
		obj.sq_SetCurrentAnimation(716);
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ndelay = ani.getDelaySum(false);
			local speed = delay.tofloat() / ndelay.tofloat();
			locakonhit(obj, "character/swordman/effect/animation/3rd/atgonewiththepetal/ready_07.ani", 0, 0, 0, 0, 100, 0, 1, speed, 0);
			locakonhit(obj, "character/swordman/effect/animation/3rd/atgonewiththepetal/rangecheck_01.ani", 0, 0, 0, 0, 100, 0, 1, speed/2, 0);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(obj.getXPos());
			local appendage = sq_AttractToMe(obj, 550, 0, 2500);
			obj.getVar("Coalban").setAppendage(0,appendage);
	}
	else if(substate == 1)
	{
		obj.sq_SetCurrentAnimation(717);
		obj.sq_SetShake(obj,5,150);
		sq_flashScreen(obj, 0, 0, 50, 185, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_COVER);
		sq_flashScreen(obj, 10, 85, 100, 185, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		local sizemove = obj.sq_GetIntData(216, 0)-100;
		obj.sq_StartWrite();
		obj.sq_WriteDword(406);
		obj.sq_SendCreatePassiveObjectPacket(24238, 0, 115, 0, -5-sizemove/2);
			local appendage = obj.getVar("Coalban").getAppendage(0);
			if(appendage)
				appendage.setValid(false);
	}
}


function onEndState_Coalban(obj, new_state)
{
	if(!obj) return;
	if(new_state != 216)
	{
		local appendage = obj.getVar("Coalban").getAppendage(0);
		if(appendage)
			appendage.setValid(false);
	}
}



function onProc_Coalban(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local Ani = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(Ani);
	local frameindex = sq_GetCurrentFrameIndex(obj);
	if (substate == 0)
	{
			local ani = obj.getCurrentAnimation();
			local currentT = sq_GetCurrentTime(ani);
			local fireT = ani.getDelaySum(false);
			local objVar = obj.getVar();
			local startX = objVar.get_vector(0);
			if(startX != 0)
			{
				local dstX = sq_GetDistancePos(startX, obj.getDirection(), sq_GetUniformVelocity(0, 350, currentT, fireT/10));
				if(obj.isMovablePos(dstX, obj.getYPos()))
					sq_setCurrentAxisPos(obj, 0, dstX);
				
				else
					objVar.set_vector(0,0);
			}
	}
}



function onEndCurrentAni_Coalban(obj)
{
	local substate = obj.getSkillSubState();
	local sq_var = obj.getVar();
	if(substate == 0)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_AddSetStatePacket(216, STATE_PRIORITY_IGNORE_FORCE, true);
	}
	else if(substate == 1)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


function GetFindMapArea_Enemy(obj, Name, XStart, XEnd, YRange)
{
	local objectManager = obj.getObjectManager();
	for (local i = 0; i < objectManager.getCollisionObjectNumber(); i+=1)
	{
		local object = objectManager.getCollisionObject(i);
		if (object && obj.isEnemy(object) && object.isObjectType(OBJECTTYPE_ACTIVE) )
		{
			if(sq_IsinMapArea(obj, object, XStart, XEnd, YRange))
			{
				local activeObj = sq_GetCNRDObjectToActiveObject(object);
				local sq_var = obj.getVar(Name);
				sq_var.push_obj_vector(activeObj);
			}
		}
	}
}
