
function checkExecutableSkill_Coalban(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(216);
	if (isUse) {
		obj.sq_StopMove();
		obj.getVar("Coalban2").setBool(0, false);
		obj.sq_IntVectClear();
		if (obj.sq_GetState() == 6)
			obj.sq_IntVectPush(3);
		else
			obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(216, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Coalban(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Coalban(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_PlaySound("SW_COAL_BAN");
			local staticData = sq_GetIntData(obj, 216, 0);
			obj.getVar("Coalban").setInt(0, staticData);
			obj.sq_SetCurrentAnimation(558);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(560);
			local Coalban_int = obj.getVar("Coalban").getInt(0);
			obj.getVar("Coalban").setInt(0, Coalban_int - 1);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(562);
			break;
		case 3:
			obj.sq_ZStop();
			obj.sq_PlaySound("SW_COAL_BAN");
			local staticData = sq_GetIntData(obj, 216, 0);
			obj.getVar("Coalban").setInt(0, staticData);
			obj.sq_SetCurrentAnimation(559);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(561);
			local Coalban_int = obj.getVar("Coalban").getInt(0);
			obj.getVar("Coalban").setInt(0, Coalban_int - 1);
			break;
		case 5:
			obj.sq_SetCurrentAnimation(563);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Coalban(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(216, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			if (obj.getVar("Coalban").getInt(0) > 0)
				obj.sq_IntVectPush(1);
			else
				obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(216, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(216, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			if (obj.getVar("Coalban").getInt(0) > 0)
				obj.sq_IntVectPush(4);
			else
				obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(216, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(0);
			obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEnterFrame_Coalban(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			switch (frameIndex) {
				case 0:
					obj.sq_StartWrite();
					obj.sq_WriteDword(216);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(216, -1, 0, getATSwordmanBonus(obj, 1.0, 216)));
					obj.sq_WriteDword(sq_GetIntData(obj, 216, 1));
					obj.sq_WriteBool(obj.getVar("Coalban2").getBool(0));
					obj.sq_WriteFloat(0.0);
					obj.sq_SendCreatePassiveObjectPacket(24381, 0, 50, 0, 73);
					break;
				case 2:
					obj.sq_StartWrite();
					obj.sq_WriteDword(216);
					obj.sq_WriteDword(1);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(216, -1, 0, getATSwordmanBonus(obj, 1.0, 216)));
					obj.sq_WriteDword(sq_GetIntData(obj, 216, 1));
					obj.sq_WriteBool(obj.getVar("Coalban2").getBool(0));
					obj.sq_WriteFloat(0.0);
					obj.sq_SendCreatePassiveObjectPacket(24381, 0, 50, 0, 73);
					break;
				case 4:
					obj.sq_StartWrite();
					obj.sq_WriteDword(216);
					obj.sq_WriteDword(2);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(216, -1, 0, getATSwordmanBonus(obj, 1.0, 216)));
					obj.sq_WriteDword(sq_GetIntData(obj, 216, 1));
					obj.sq_WriteBool(obj.getVar("Coalban2").getBool(0));
					obj.sq_WriteFloat(0.0);
					obj.sq_SendCreatePassiveObjectPacket(24381, 0, 50, 0, 73);
					break;
			}
			break;
		case 2:

			break;
		case 4:
			switch (frameIndex) {
				case 0:
					obj.sq_StartWrite();
					obj.sq_WriteDword(216);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(216, -1, 0, getATSwordmanBonus(obj, 1.0, 216)));
					obj.sq_WriteDword(sq_GetIntData(obj, 216, 1));
					obj.sq_WriteBool(obj.getVar("Coalban2").getBool(0));
					obj.sq_WriteFloat(-40.0);
					obj.sq_SendCreatePassiveObjectPacket(24381, 0, 50, 0, 73);
					break;
				case 2:
					obj.sq_StartWrite();
					obj.sq_WriteDword(216);
					obj.sq_WriteDword(1);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(216, -1, 0, getATSwordmanBonus(obj, 1.0, 216)));
					obj.sq_WriteDword(sq_GetIntData(obj, 216, 1));
					obj.sq_WriteBool(obj.getVar("Coalban2").getBool(0));
					obj.sq_WriteFloat(-40.0);
					obj.sq_SendCreatePassiveObjectPacket(24381, 0, 50, 0, 73);
					break;
				case 4:
					obj.sq_StartWrite();
					obj.sq_WriteDword(216);
					obj.sq_WriteDword(2);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(216, -1, 0, getATSwordmanBonus(obj, 1.0, 216)));
					obj.sq_WriteDword(sq_GetIntData(obj, 216, 1));
					obj.sq_WriteBool(obj.getVar("Coalban2").getBool(0));
					obj.sq_WriteFloat(-40.0);
					obj.sq_SendCreatePassiveObjectPacket(24381, 0, 50, 0, 73);
					break;
			}
			break;
		case 5:

			break;
	}
}


function onEndState_Coalban(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
	}
}


function onProc_Coalban(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Coalban(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Coalban(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (sq_IsKeyDown(OPTION_HOTKEY_JUMP, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.getVar("Coalban2").setBool(0, true);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.getVar("Coalban2").setBool(0, true);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.getVar("Coalban2").setBool(0, false);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.getVar("Coalban2").setBool(0, false);
			break;
		case 4:
			if (sq_IsKeyDown(OPTION_HOTKEY_JUMP, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_IntVectPush(0);
				obj.sq_IntVectPush(0);
				obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.getVar("Coalban2").setBool(0, true);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.getVar("Coalban2").setBool(0, true);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.getVar("Coalban2").setBool(0, false);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.getVar("Coalban2").setBool(0, false);
			break;
	}
}
