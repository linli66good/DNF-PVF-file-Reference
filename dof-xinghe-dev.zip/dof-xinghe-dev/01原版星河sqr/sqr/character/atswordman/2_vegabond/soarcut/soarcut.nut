
function checkExecutableSkill_Soarcut(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(213);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(213, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Soarcut(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Soarcut(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	local staticData = sq_GetIntData(obj, 213, 5);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.getVar("Soarcut").clear_obj_vector();
			obj.sq_SetCurrentAnimation(552);
			obj.sq_SetCurrentAttackInfo(156);
			local attackRate = obj.sq_GetBonusRateWithPassive(213, -1, 0, getATSwordmanBonus(obj, 1.0, 213));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			obj.sq_ZStop();
			obj.sq_SetCurrentAnimation(551);
			obj.sq_SetCurrentAttackInfo(154);
			local attackRate = obj.sq_GetBonusRateWithPassive(213, -1, 1, getATSwordmanBonus(obj, 1.0, 213));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(544);
			obj.sq_SetCurrentAttackInfo(154);
			local attackRate = obj.sq_GetBonusRateWithPassive(213, -1, 2, getATSwordmanBonus(obj, 1.0, 213));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local delay = sq_GetDelaySum(sq_GetCurrentAnimation(obj));
			obj.setTimeEvent(1, delay / (staticData / 2), staticData / 2, true);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(546);
			obj.sq_SetCurrentAttackInfo(155);
			local attackRate = obj.sq_GetBonusRateWithPassive(213, -1, 2, getATSwordmanBonus(obj, 1.0, 213));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local customData = 120 / (staticData / 2);
			obj.setTimeEvent(0, customData, staticData / 2, true);
			obj.setTimeEvent(2, 123, 1, false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(549);
			obj.sq_SetCurrentAttackInfo(155);
			local attackRate = obj.sq_GetBonusRateWithPassive(213, -1, 3, getATSwordmanBonus(obj, 1.0, 213));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onEndCurrentAni_Soarcut(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (obj.getVar("Soarcut").get_obj_vector_size() < 1) {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_AddSetStatePacket(213, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(213, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(213, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(213, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Soarcut(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				local Soarcut_size = obj.getVar("Soarcut").get_obj_vector_size();
				if (Soarcut_size > 0) break;
				obj.getVar("Soarcut").push_obj_vector(damager);
				local apPath = "character/atswordman/2_vegabond/soarcut/ap_soarcut.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, false, true, 0, 0, ENUM_DIRECTION_NEUTRAL, appendage);
					sq_MoveToAppendageForce(damager, obj, obj, 100, 0, 200, 160, true, appendage, true);
					appendage.getAppendageInfo().setValidTime(1000);
				}
			}
			break;
		case 2:
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				local Soarcut_size = obj.getVar("Soarcut").get_obj_vector_size();
				if (Soarcut_size > 0) break;
				obj.getVar("Soarcut").push_obj_vector(damager);
				local apPath = "character/atswordman/2_vegabond/soarcut/ap_soarcut.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, false, true, 0, 0, ENUM_DIRECTION_NEUTRAL, appendage);
					sq_MoveToAppendageForce(damager, obj, obj, 100, 0, 200, 160, true, appendage, true);
					appendage.getAppendageInfo().setValidTime(1000);
				}
			}
			break;
	}
}


function onTimeEvent_Soarcut(obj, timeEventIndex, timeEventCount) {
	if (!obj) return false;
	local apPath = "character/atswordman/2_vegabond/soarcut/ap_soarcut.nut";
	switch (timeEventIndex) {
		case 1:
			obj.resetHitObjectList();
			local Soarcut_obj = obj.getVar("Soarcut").get_obj_vector(0);
			if (Soarcut_obj) {
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(Soarcut_obj, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(Soarcut_obj, obj, true, false, true, 0, 0, sq_GetOppositeDirection(obj.getDirection()), appendage);
					sq_MoveToAppendageForce(Soarcut_obj, obj, obj, 100, 0, 0, 10, true, appendage, true);
					appendage.getAppendageInfo().setValidTime(500);
				}
			}
			break;
		case 0:
			obj.resetHitObjectList();
			local Soarcut_obj = obj.getVar("Soarcut").get_obj_vector(0);
			if (Soarcut_obj) {
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(Soarcut_obj, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(Soarcut_obj, obj, true, true, true, 250, 100, sq_GetOppositeDirection(obj.getDirection()), appendage);
					sq_MoveToAppendageForce(Soarcut_obj, obj, obj, 100, 0, 0, 10, true, appendage, true);
					if (timeEventCount = sq_GetIntData(obj, 213, 5) / 2 - 1)
						appendage.getAppendageInfo().setValidTime(30);
					else
						appendage.getAppendageInfo().setValidTime(50);
				}
			}
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(213, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEnterFrame_Soarcut(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Soarcut(obj, new_state) {
	if (!obj) return;
	if (new_state != 213) {
		local Soarcut_size = obj.getVar("Soarcut").get_obj_vector_size();
		if (Soarcut_size < 1) return;
		local Soarcut_obj = obj.getVar("Soarcut").get_obj_vector(0);
		if (Soarcut_obj) {
			local apPath = "character/atswordman/2_vegabond/soarcut/ap_soarcut.nut";
			if (CNSquirrelAppendage.sq_IsAppendAppendage(Soarcut_obj, apPath)) CNSquirrelAppendage.sq_RemoveAppendage(Soarcut_obj, apPath);
		}
	}
}


function onProc_Soarcut(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getZPos(), 200, stateTimer, 200, false);
			sq_setCurrentAxisPos(obj, 2, movePos);
			break;
		case 3:
			local stateTimer = obj.sq_GetStateTimer();
			local movePos = sq_GetAccel(obj.getZPos(), 0, stateTimer, 100, false);
			sq_setCurrentAxisPos(obj, 2, movePos);
			break;
	}
}


function onProcCon_Soarcut(obj) {
	if (!obj) return;
}


function onKeyFrameFlag_Soarcut(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}

