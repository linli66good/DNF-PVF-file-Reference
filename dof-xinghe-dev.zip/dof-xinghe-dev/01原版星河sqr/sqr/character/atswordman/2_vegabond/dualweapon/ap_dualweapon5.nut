function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_Dualweapon5"); }



function onAttackParent_appendage_Dualweapon5(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 202);
	local randNum = sq_getRandom(0, 99);
	local levelData = sq_GetLevelData(sqrChr, 202, 13, skillLevel) / 10;
	if (randNum > levelData) return;
	local levelData1 = sq_GetLevelData(sqrChr, 202, 14, skillLevel);
	local levelData2 = sq_GetLevelData(sqrChr, 202, 15, skillLevel);
	sq_sendSetActiveStatusPacket(damager, sqrChr, 6, levelData.tofloat(), sq_GetSkillLevel(sqrChr, 174), true, levelData1, levelData2);
}

