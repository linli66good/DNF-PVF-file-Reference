function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_Dualweapon1"); }



function onAttackParent_appendage_Dualweapon1(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 202);
	local randNum = sq_getRandom(0, 99);
	local levelData = sq_GetLevelData(sqrChr, 202, 5, skillLevel) / 10;
	if (randNum > levelData) return;
	local levelData1 = sq_GetLevelData(sqrChr, 202, 6, skillLevel);
	local levelData2 = sq_GetLevelData(sqrChr, 202, 7, skillLevel);
	sq_sendSetActiveStatusPacket(damager, sqrChr, 11, levelData.tofloat(), sq_GetSkillLevel(sqrChr, 174), true, levelData1, levelData2);
}

