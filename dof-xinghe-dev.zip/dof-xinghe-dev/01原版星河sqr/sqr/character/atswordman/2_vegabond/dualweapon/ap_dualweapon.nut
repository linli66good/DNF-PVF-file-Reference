function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Dualweapon");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Dualweapon");
}



function onStart_appendage_Dualweapon(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 202);
	local levelData = sq_GetLevelData(sqrChr, 202, 16, skillLevel) / 10;
	local change_appendage = appendage.sq_getChangeStatus("Dualweapon");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Dualweapon", sqrChr, sqrChr, 0, 33, false, -levelData);
	} else {
		change_appendage.clearParameter();
		change_appendage.addParameter(33, false, -levelData.tofloat());
	}
}

function onEnd_appendage_Dualweapon(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
}

