function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_Dualweapon0"); }



function onAttackParent_appendage_Dualweapon0(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 202);
	local levelData = sq_GetLevelData(sqrChr, 202, 9, skillLevel) + sq_GetSkillLevel(sqrChr, 174);
	local randNum = sq_getRandom(0, 99);
	local levelData1 = sq_GetLevelData(sqrChr, 202, 10, skillLevel) / 10;
	if (randNum > levelData1) return;
	local levelData2 = sq_GetLevelData(sqrChr, 202, 11, skillLevel);
	sq_sendSetActiveStatusPacket(damager, sqrChr, 16, levelData1.tofloat(), levelData, false, levelData2);
}

