
function checkExecutableSkill_Dualweapon(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(202);
	if (isUse) {
		sq_BinaryStartWrite();
		sq_SendChangeSkillEffectPacket(obj, 202);
		return true;
	}
	return false;
}


function checkCommandEnable_Dualweapon(obj) {
	if (!obj) return false;
	return true;
}

