function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onStart", "onStart_appendage_Dualweapon3"); }


function onStart_appendage_Dualweapon3(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	/* 	local sourceObj = appendage.getSource()
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 202);
	local levelData = sq_GetLevelData(sqrChr,202, 8, skillLevel)/10;
	local change_appendage = appendage.sq_getChangeStatus("Dualweapon3");
	if(!change_appendage)
		{
			change_appendage = appendage.sq_AddChangeStatus("Dualweapon3",sqrChr, sqrChr, 0, 6, true, levelData);
	}
		else
		{
			change_appendage.clearParameter();
	change_appendage.addParameter(6, true, levelData.tofloat());
	} */
}

