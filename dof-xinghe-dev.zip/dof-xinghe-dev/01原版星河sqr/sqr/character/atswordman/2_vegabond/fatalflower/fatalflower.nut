
function checkExecutableSkill_Fatalflower(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(221);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(221, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Fatalflower(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Fatalflower(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(586);
			obj.sq_SetCurrentAttackInfo(172);
			local attackRate = obj.sq_GetBonusRateWithPassive(221, -1, 0, getATSwordmanBonus(obj, 1.0, 221));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			sq_flashScreen(obj, 500, 2500, 500, 200, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(587);
			obj.sq_SetCurrentAttackInfo(172);
			local attackRate = obj.sq_GetBonusRateWithPassive(221, -1, 0, getATSwordmanBonus(obj, 1.0, 221));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(588);
			obj.sq_SetCurrentAttackInfo(172);
			local attackRate = obj.sq_GetBonusRateWithPassive(221, -1, 0, getATSwordmanBonus(obj, 1.0, 221));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(589);
			obj.sq_SetCurrentAttackInfo(172);
			local attackRate = obj.sq_GetBonusRateWithPassive(221, -1, 0, getATSwordmanBonus(obj, 1.0, 221));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(590);
			obj.sq_SetCurrentAttackInfo(172);
			local attackRate = obj.sq_GetBonusRateWithPassive(221, -1, 0, getATSwordmanBonus(obj, 1.0, 221));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 5:
			obj.sq_SetCurrentAnimation(591);
			obj.sq_SetCurrentAttackInfo(172);
			local attackRate = obj.sq_GetBonusRateWithPassive(221, -1, 0, getATSwordmanBonus(obj, 1.0, 221));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
	
}



function getScrollBasisPos_Fatalflower(obj) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 400);
	if (obj.isMyControlObject()) {
		obj.sq_SetCameraScrollPosition(dstPos, obj.getYPos(), 0);
		return true;
	}
	return false;
}


function onEndCurrentAni_Fatalflower(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(221, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(221, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(221, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(221, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}



function onEnterFrame_Fatalflower(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			switch (frameIndex) {
				case 4:
					sq_SetMyShake(obj, 3, 120);
					local levelData = sq_GetLevelData(obj, 221, 3, sq_GetSkillLevel(obj, 221));
					if (sq_GetSkillLevel(obj, 221) > 5) levelData = levelData + 3;
					local customData = 0.0;
					if (sq_GetSkillLevel(obj, 221) > 8) customData = 0.1;
					obj.sq_StartWrite();
					obj.sq_WriteDword(221);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(221, -1, 1, getATSwordmanBonus(obj, 1.0 + customData, 221)));
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(221, -1, 4, getATSwordmanBonus(obj, 1.0 + customData, 221)));
					obj.sq_WriteDword(levelData);
					obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, -1, 0);
					break;
				case 21:
					sq_SetMyShake(obj, 5, 300);
					break;
				case 43:
					sq_SetMyShake(obj, 4, 180);
					break;
				case 46:
					sq_SetMyShake(obj, 5, 300);
					break;
			}
			break;
	}
}


function onEndState_Fatalflower(obj, new_state) {
	if (!obj) return;
	if (sq_GetSkillLevel(obj, 221) < 3) return;
	local apPath = "character/atswordman/2_vegabond/fatalflower/ap_fatalflower.nut";
	if (new_state != 221) {
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
		if (appendage != null) {
			appendage.sq_SetValidTime(30000);
			appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 221, sq_GetSkillLevel(obj, 221));
			appendage.setEnableIsBuff(true);
			CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
			local customData = 15;
			local change_appendage = appendage.sq_getChangeStatus("Fatalflower");
			if (!change_appendage) {
				change_appendage = appendage.sq_AddChangeStatus("Fatalflower", obj, obj, 0, 15, false, customData);
			} else {
				change_appendage.clearParameter();
				change_appendage.addParameter(15, false, customData.tofloat());
			}
		}
	}
}

