
function checkExecutableSkill_Bigjang(obj) {
	if (!obj) return false;
	local state = obj.sq_GetState();
	local staticData = sq_GetIntData(obj, 223, 2);
	if (state == 6 && obj.getZPos() < staticData) {
		return false;
	}

	local isUse = obj.sq_IsUseSkill(223);
	if (isUse) {
		local staticData1 = sq_GetIntData(obj, 223, 3);
		if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
			obj.getVar("Bigjang").setInt(0, staticData1 / 3 * 2);
		else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
			obj.getVar("Bigjang").setInt(0, staticData1 / 3 * 2);
		else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL))
			obj.getVar("Bigjang").setInt(0, staticData1);
		else
			obj.getVar("Bigjang").setInt(0, staticData1 / 2);
		obj.sq_StopMove();
		obj.sq_IntVectClear();
		if (state == 6)
			obj.sq_IntVectPush(1);
		else
			obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(223, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Bigjang(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Bigjang(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_SetCurrentAnimation(601);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(223, -1, 0, getATSwordmanBonus(obj, 1.0, 223));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			obj.sq_ZStop();
			obj.sq_SetCurrentAnimation(598);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(223, -1, 0, getATSwordmanBonus(obj, 1.0, 223));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(600);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(223, -1, 0, getATSwordmanBonus(obj, 1.0, 223));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onEndCurrentAni_Bigjang(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(223, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(200);
			obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Bigjang(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Bigjang(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local staticData = sq_GetIntData(obj, 223, 0);
	switch (subState) {
		case 0:
			if (frameIndex == 1) {
				local aniPath = "character/swordman/effect/animation/atbigjang/normal_start_ready.ani";
				ATswordmanCreateAniPooledObj(obj, aniPath, true, true, sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 23), obj.getYPos(), 63, staticData / 100.0);
			} else if (frameIndex == 5) {
				local Bigjang_int = obj.getVar("Bigjang").getInt(0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(223);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(223, -1, 0, getATSwordmanBonus(obj, 1.0, 223)));
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(223, -1, 1, getATSwordmanBonus(obj, 1.0, 223)));
				obj.sq_WriteDword(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), Bigjang_int));
				obj.sq_WriteDword(staticData);
				obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, 0, 65);
			}
			break;
		case 1:
			if (frameIndex == 5) {
				local aniPath = "character/swordman/effect/animation/atbigjang/jump_start_hand.ani";
				ATswordmanCreateAniPooledObj(obj, aniPath, true, true, sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 8), obj.getYPos(), obj.getZPos() + 80, staticData / 100.0);
			}
			break;
		case 2:
			if (frameIndex == 1) {
				local Bigjang_int = obj.getVar("Bigjang").getInt(0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(223);
				obj.sq_WriteDword(1);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(223, -1, 0, getATSwordmanBonus(obj, 1.0, 223)));
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(223, -1, 1, getATSwordmanBonus(obj, 1.0, 223)));
				obj.sq_WriteDword(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), Bigjang_int));
				obj.sq_WriteDword(staticData);
				obj.sq_SendCreatePassiveObjectPacket(24381, 0, 8, 0, 80);
			}
			break;
	}
}


function onEndState_Bigjang(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Bigjang(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Bigjang(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Bigjang(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
