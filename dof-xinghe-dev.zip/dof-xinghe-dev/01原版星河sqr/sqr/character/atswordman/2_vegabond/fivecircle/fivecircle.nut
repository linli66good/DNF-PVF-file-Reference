
function checkExecutableSkill_Fivecircle(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(209);
	if (isUse) {
		CreateBuffCutin(obj, "etc/ultimateskillani/atsword_vagabond_buff.ani");
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(209, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Fivecircle(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Fivecircle(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_FIVE_CIRCLE");
			obj.sq_SetCurrentAnimation(541);
			local castTime = sq_GetCastTime(obj, 209, sq_GetSkillLevel(obj, 209));
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local floatData = delay.tofloat() / castTime.tofloat();
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			sq_StartDrawCastGauge(obj, delay, true);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(540);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			local levelData = sq_GetLevelData(obj, 209, 0, sq_GetSkillLevel(obj, 209));
			local apPath = "character/atswordman/2_vegabond/fivecircle/ap_fivecircle.nut";
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
			appendage.sq_SetValidTime(levelData);
			appendage.setEnableIsBuff(true);
			appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 209, sq_GetSkillLevel(obj, 209));
			CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
			obj.sq_SetCurrentAnimation(539);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onEndCurrentAni_Fivecircle(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(209, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:

			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onEnterFrame_Fivecircle(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (frameIndex == 3) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(209, STATE_PRIORITY_IGNORE_FORCE, true);
			}

			break;
	}
}


function onEndState_Fivecircle(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}



function onProcCon_Fivecircle(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}


function onProc_Fivecircle(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}

function CreateBuffCutin(obj, aniPath) {
	local ani = sq_CreateAnimation("", aniPath);
	local pooledObj = sq_CreatePooledObject(ani, true);
	local objectManager = obj.getObjectManager();
	local xPos = obj.getXPos();
	local yPos = objectManager.getFieldYPos(0, 0, 7);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(xPos + 480, yPos, 0);
	sq_AddObject(obj, pooledObj, 2, false);
}
