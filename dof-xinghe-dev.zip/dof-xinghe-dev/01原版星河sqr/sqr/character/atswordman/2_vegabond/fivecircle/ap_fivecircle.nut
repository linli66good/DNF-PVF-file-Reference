function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Fivecircle");
	appendage.sq_AddFunctionName("onVaildTimeEnd", "onVaildTimeEnd_appendage_Fivecircle");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Fivecircle");
}


function onStart_appendage_Fivecircle(appendage) {
	if (!appendage) {
		return;
	}

	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local parentObj = appendage.getParent();
	local parentObj = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local skillLevel = sq_GetSkillLevel(parentObj, 209);
	local levelData = parentObj.sq_GetLevelData(209, 2, skillLevel) * 5 / 2;
	local levelData1 = parentObj.sq_GetLevelData(209, 4, skillLevel) * 5 / 10;
	local change_appendage = appendage.sq_getChangeStatus("Fivecircle");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Fivecircle", parentObj, parentObj, 0, 10, false, levelData);
		change_appendage = appendage.sq_AddChangeStatus("Fivecircle", parentObj, parentObj, 0, 11, false, levelData);
		change_appendage = appendage.sq_AddChangeStatus("Fivecircle", parentObj, parentObj, 0, 50, false, levelData1);
	}
	if (change_appendage) {
		change_appendage.clearParameter();
		change_appendage.addParameter(10, false, levelData.tofloat());
		change_appendage.addParameter(11, false, levelData.tofloat());
		change_appendage.addParameter(50, false, levelData1.tofloat());
	}
	appendage.sq_AddEffectFront("character/swordman/effect/animation/atfivecircle/buffeffect/buff_back_1.ani");
	appendage.sq_AddEffectBack("character/swordman/effect/animation/atfivecircle/buffeffect/buff_front_1.ani");
}


function onVaildTimeEnd_appendage_Fivecircle(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	appendage.sq_DeleteEffectFront();
	appendage.sq_DeleteEffectBack();
}


function onEnd_appendage_Fivecircle(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
	appendage.sq_DeleteEffectFront();
	appendage.sq_DeleteEffectBack();
}
