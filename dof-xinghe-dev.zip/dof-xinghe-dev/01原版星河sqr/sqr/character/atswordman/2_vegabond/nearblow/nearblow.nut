
function checkExecutableSkill_Nearblow(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(215);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(215, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Nearblow(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Nearblow(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_NEAR_BLOW");
			obj.getVar("Nearblow").setBool(0, false);
			obj.getVar("Nearblow").clear_obj_vector();
			obj.sq_SetCurrentAnimation(554);
			obj.sq_SetCurrentAttackInfo(157);
			local attackRate = obj.sq_GetBonusRateWithPassive(215, -1, 0, getATSwordmanBonus(obj, 1.0, 215));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(555);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(556);
			obj.sq_SetCurrentAttackInfo(157);
			local attackRate = obj.sq_GetBonusRateWithPassive(215, -1, 1, getATSwordmanBonus(obj, 1.0, 215));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(557);
			obj.sq_SetCurrentAttackInfo(157);
			local attackRate = obj.sq_GetBonusRateWithPassive(215, -1, 0, getATSwordmanBonus(obj, 1.0, 215));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
	SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Nearblow(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			if (obj.getVar("Nearblow").getBool(0))
				obj.sq_IntVectPush(2);
			else
				obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(215, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(215, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.setDirection(sq_GetOppositeDirection(obj.getDirection()));
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Nearblow(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				obj.getVar("Nearblow").setBool(0, true);
				local apPath = "character/atswordman/2_vegabond/nearblow/ap_nearblow.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, false, true, 0, 0, ENUM_DIRECTION_NEUTRAL, appendage);
					sq_MoveToAppendageForce(damager, obj, obj, 100, 0, damager.getZPos(), 20, true, appendage, true);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(1000);
				}

				if (!obj.getVar("Nearblow").is_obj_vector(damager)) obj.getVar("Nearblow").push_obj_vector(damager);
			}

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Nearblow(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local Nearblow_size = obj.getVar("Nearblow").get_obj_vector_size();
	local apPath = "character/atswordman/2_vegabond/nearblow/ap_nearblow.nut";
	switch (subState) {
		case 0:
			if (frameIndex == 1) {
				for (local customData = 0; customData < Nearblow_size; ++customData) {
					local Nearblow_obj = obj.getVar("Nearblow").get_obj_vector(customData);
					local appendage = CNSquirrelAppendage.sq_AppendAppendage(Nearblow_obj, obj, -1, false, apPath, true);
					if (appendage) {
						sq_HoldAndDelayDie(Nearblow_obj, obj, true, false, true, 0, 0, ENUM_DIRECTION_NEUTRAL, appendage);
						sq_MoveToAppendageForce(Nearblow_obj, obj, obj, 150, 0, Nearblow_obj.getZPos(), 20, true, appendage, true);
						local apInfo = appendage.getAppendageInfo();
						apInfo.setValidTime(1000);
					}
				}
			} else if (frameIndex == 3) {
				sq_SetMyShake(obj, 8, 40);
				for (local customData = 0; customData < Nearblow_size; ++customData) {
					local Nearblow_obj = obj.getVar("Nearblow").get_obj_vector(customData);
					local appendage = CNSquirrelAppendage.sq_AppendAppendage(Nearblow_obj, obj, -1, false, apPath, true);
					if (appendage) {
						sq_HoldAndDelayDie(Nearblow_obj, obj, true, false, true, 0, 0, ENUM_DIRECTION_NEUTRAL, appendage);
						sq_MoveToAppendageForce(Nearblow_obj, obj, obj, 150, 0, Nearblow_obj.getZPos(), 20, true, appendage, true);
						local apInfo = appendage.getAppendageInfo();
						apInfo.setValidTime(1000);
					}
				}
			}
			break;
		case 3:
			if (frameIndex == 5) {
				sq_SetMyShake(obj, 10, 100);
				obj.sq_StartWrite();
				obj.sq_WriteDword(215);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(215, -1, 2, getATSwordmanBonus(obj, 1.0, 215)));
				obj.sq_WriteDword(sq_GetIntData(obj, 215, 0));
				obj.sq_SendCreatePassiveObjectPacket(24381, 0, 200, 0, 0);
			} else if (frameIndex == 0) {
				sq_SetMyShake(obj, 8, 40);
				for (local customData = 0; customData < Nearblow_size; ++customData) {
					local Nearblow_obj = obj.getVar("Nearblow").get_obj_vector(customData);
					local appendage = CNSquirrelAppendage.sq_AppendAppendage(Nearblow_obj, obj, -1, false, apPath, true);
					if (appendage) {
						sq_HoldAndDelayDie(Nearblow_obj, obj, true, true, true, 200, 200, ENUM_DIRECTION_NEUTRAL, appendage);
						sq_MoveToAppendageForce(Nearblow_obj, obj, obj, 150, 0, Nearblow_obj.getZPos(), 20, true, appendage, true);
						local apInfo = appendage.getAppendageInfo();
						apInfo.setValidTime(100);
					}
				}
			}
			break;
		case 2:
			if (frameIndex == 2) {
				sq_SetMyShake(obj, 15, 100);
				obj.sq_StartWrite();
				obj.sq_WriteDword(215);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(215, -1, 2, getATSwordmanBonus(obj, 1.0, 215)));
				obj.sq_WriteDword(sq_GetIntData(obj, 215, 0));
				obj.sq_SendCreatePassiveObjectPacket(24381, 0, -200, 0, 0);
				for (local customData = 0; customData < Nearblow_size; ++customData) {
					local Nearblow_obj = obj.getVar("Nearblow").get_obj_vector(customData);
					local appendage = CNSquirrelAppendage.sq_AppendAppendage(Nearblow_obj, obj, -1, false, apPath, true);
					if (appendage) {
						sq_HoldAndDelayDie(Nearblow_obj, obj, true, true, true, 200, 200, obj.getDirection(), appendage);
						sq_MoveToAppendageForce(Nearblow_obj, obj, obj, -150, 0, Nearblow_obj.getZPos(), 20, true, appendage, true);
						local apInfo = appendage.getAppendageInfo();
						apInfo.setValidTime(100);
					}
				}
			}
			break;
	}
}


function onEndState_Nearblow(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 2:

			break;
	}
}


function onProc_Nearblow(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Nearblow(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


function onProcCon_Nearblow(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			local stateTimer = obj.sq_GetStateTimer();
			if (stateTimer < 90) break;
			if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 0)
				obj.getVar("Nearblow").setBool(0, false);
			else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == 1)
				obj.getVar("Nearblow").setBool(0, false);
			break;
	}
}
