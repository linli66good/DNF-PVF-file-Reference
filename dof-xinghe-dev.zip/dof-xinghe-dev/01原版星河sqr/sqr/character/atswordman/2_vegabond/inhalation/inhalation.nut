
function checkExecutableSkill_Inhalation(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(211);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(211, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Inhalation(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Inhalation(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(536);
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(211, -1, 0, getATSwordmanBonus(obj, 1.0, 211));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local objectManager = obj.getObjectManager();
			local staticData = sq_GetIntData(obj, 211, 2);
			obj.getVar("Inhalation").clear_obj_vector();
			for (local objectNumber = 0; objectNumber < objectManager.getCollisionObjectNumber(); objectNumber++) {
				local object = objectManager.getCollisionObject(objectNumber);
				if (object && object.isObjectType(OBJECTTYPE_ACTIVE) && obj.isEnemy(object) && !obj.getVar("Inhalation").is_obj_vector(object)) {
					local xDistance = obj.getXDistance(object);
					local yDistance = obj.getYDistance(object);
					if (IsFrontOf(obj, object) && xDistance < staticData && yDistance < 50) {
						obj.getVar("Inhalation").push_obj_vector(object);
						obj.sq_StartWrite();
						obj.sq_WriteDword(211);
						obj.sq_WriteDword(0);
						obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(211, -1, 2, getATSwordmanBonus(obj, 1.0, 211)));
						obj.sq_WriteDword(sq_GetObjectId(object));
						obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(211, -1, 2, getATSwordmanBonus(obj, 1.0, 211)));
						sq_SendCreatePassiveObjectPacketPos(obj, 24381, 0, object.getXPos(), object.getYPos(), object.getZPos());
					}
				}
			}
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(537);
			obj.sq_SetCurrentAttackInfo(152);
			local attackRate = obj.sq_GetBonusRateWithPassive(211, -1, 0, getATSwordmanBonus(obj, 1.0, 211));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local apPath = "character/atswordman/2_vegabond/inhalation/ap_inhalation.nut";
			local Inhalation_size = obj.getVar("Inhalation").get_obj_vector_size();
			for (local objectNumber = 0; objectNumber < Inhalation_size; objectNumber++) {
				local Inhalation_obj = obj.getVar("Inhalation").get_obj_vector(objectNumber);
				if (Inhalation_obj) {
					local aniPath = "character/swordman/effect/animation/atinhalation/bounds_01bottom.ani";
					local aniPath1 = "character/swordman/effect/animation/atinhalation/mon_00.ani";
					DarktemplerCreateAniPooledObj(obj, aniPath, true, false, Inhalation_obj.getXPos(), Inhalation_obj.getYPos(), Inhalation_obj.getZPos(), 1.0);
					DarktemplerCreateAniPooledObj(obj, aniPath1, true, false, Inhalation_obj.getXPos(), Inhalation_obj.getYPos(), Inhalation_obj.getZPos() + obj.getObjectHeight() / 2, 1.0);
					if (sq_IsHoldable(obj, Inhalation_obj) && sq_IsGrabable(obj, Inhalation_obj) && !sq_IsFixture(Inhalation_obj)) {
						local appendage = CNSquirrelAppendage.sq_AppendAppendage(Inhalation_obj, obj, -1, false, apPath, true);
						if (appendage) {
							sq_HoldAndDelayDie(Inhalation_obj, obj, true, false, true, 0, 0, obj.getDirection(), appendage);
							sq_MoveToAppendageForce(Inhalation_obj, obj, Inhalation_obj, 0, 0, 80, 800, true, appendage, true);
							local apInfo = appendage.getAppendageInfo();
							apInfo.setValidTime(800);
						}
					}
				}
			}
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(538);
			obj.sq_SetCurrentAttackInfo(153);
			local attackRate = obj.sq_GetBonusRateWithPassive(211, -1, 0, getATSwordmanBonus(obj, 1.0, 211));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onEndCurrentAni_Inhalation(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(211, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(211, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Inhalation(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Inhalation(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 2:
			if (frameIndex == 1) {
				if (obj.isMyControlObject()) sq_SetMyShake(obj, 1, 200);
				local apPath = "character/atswordman/2_vegabond/inhalation/ap_inhalation.nut";
				local Inhalation_size = obj.getVar("Inhalation").get_obj_vector_size();
				for (local customData = 0; customData < Inhalation_size; customData++) {
					local Inhalation_obj = obj.getVar("Inhalation").get_obj_vector(customData);
					if (Inhalation_obj) {
						if (sq_IsHoldable(obj, Inhalation_obj) && sq_IsGrabable(obj, Inhalation_obj) && !sq_IsFixture(Inhalation_obj)) {
							local appendage = CNSquirrelAppendage.sq_AppendAppendage(Inhalation_obj, obj, -1, false, apPath, true);
							if (appendage) {
								sq_HoldAndDelayDie(Inhalation_obj, obj, true, true, true, 150, 150, obj.getDirection(), appendage);
								sq_MoveToAppendageForce(Inhalation_obj, obj, obj, 90, 0, 0, 150, true, appendage, true);
								local apInfo = appendage.getAppendageInfo();
								apInfo.setValidTime(150);
							}
						}
					}
				}
			}
			break;
	}
}


function onEndState_Inhalation(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Inhalation(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Inhalation(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Inhalation(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
