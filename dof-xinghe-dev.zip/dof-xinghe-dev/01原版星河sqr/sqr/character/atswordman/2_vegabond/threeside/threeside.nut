
function checkExecutableSkill_Threeside(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(204);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(204, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Threeside(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Threeside(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.getVar("Threeside").setBool(0, false);
			obj.sq_PlaySound("SW_THREE_SIDE");
			obj.sq_SetCurrentAnimation(535);
			obj.sq_SetCurrentAttackInfo(151);
			local attackRate = obj.sq_GetBonusRateWithPassive(103, -1, 3, getATSwordmanBonus(obj, 1.0, 204));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(532);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(533);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onEndCurrentAni_Threeside(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			if (!obj.getVar("Threeside").getBool(0))
				obj.sq_IntVectPush(1);
			else
				obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(204, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Threeside(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Threeside(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 2:
			if (frameIndex != 3) break;
			obj.sq_StartWrite();
			obj.sq_WriteDword(204);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(103, -1, 4, getATSwordmanBonus(obj, 1.0, 204)));
			obj.sq_SendCreatePassiveObjectPacket(24381, 0, 0, 0, 0);
			break;
		case 4:

			break;
	}
}


function onEndState_Threeside(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Threeside(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Threeside(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Threeside(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.setSkillCommandEnable(204, true);
			local currentAni = sq_GetCurrentAnimation(obj);
			local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
			if (obj.sq_IsEnterSkill(204) != -1 && frameIndex > 1) obj.getVar("Threeside").setBool(0, true);
			break;
	}
}
