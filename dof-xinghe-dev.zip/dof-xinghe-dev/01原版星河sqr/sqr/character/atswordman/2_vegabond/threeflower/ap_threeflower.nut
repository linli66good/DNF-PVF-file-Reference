function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onStart", "onStart_appendage_Threeflower"); }


function onStart_appendage_Threeflower(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 104);
	local levelData = sq_GetLevelData(sqrChr, 104, 1, skillLevel) / 10;
	local change_appendage = appendage.sq_getChangeStatus("Threeflower");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Threeflower", sqrChr, sqrChr, 0, 15, false, levelData);
	} else {
		change_appendage.clearParameter();
		change_appendage.addParameter(15, false, levelData.tofloat());
	}
}

