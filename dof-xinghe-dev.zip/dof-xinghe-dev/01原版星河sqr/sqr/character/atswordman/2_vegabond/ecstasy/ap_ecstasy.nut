function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onStart", "onStart_appendage_Ecstasy"); }


function onStart_appendage_Ecstasy(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local parentObj = appendage.getParent();
	local parentObj = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local skillLevel = sq_GetSkillLevel(parentObj, 106);
	local levelData = parentObj.sq_GetLevelData(106, 3, skillLevel);
	local levelData1 = parentObj.sq_GetLevelData(106, 2, skillLevel);
	local change_appendage = appendage.sq_getChangeStatus("Ecstasy");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Ecstasy", parentObj, parentObj, 0, 10, false, levelData);
		change_appendage = appendage.sq_AddChangeStatus("Ecstasy", parentObj, parentObj, 0, 11, false, levelData1);
	} else {
		change_appendage.clearParameter();
		change_appendage.addParameter(10, false, levelData.tofloat());
		change_appendage.addParameter(11, false, levelData1.tofloat());
	}
}

