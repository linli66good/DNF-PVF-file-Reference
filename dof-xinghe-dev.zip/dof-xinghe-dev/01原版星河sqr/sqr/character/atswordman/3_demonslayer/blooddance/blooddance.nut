SUB_BLOODDANCE_START		<-0
SUB_BLOODDANCE_LOOP		<-1
SUB_BLOODDANCE_END		<-2

function checkExecutableSkill_Blooddance(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(155);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(155, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Blooddance(obj) {
	if (!obj) return false;
	if (sq_GetSkillLevel(obj, 163) < 1) {
		local state = obj.sq_GetState();
		if (state == 0 || state == 108 || state == 14)
			return true;
		else
			return false;
	}
	return true;
}



function onSetState_Blooddance(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_BLOODDANCE_01");
			obj.getVar("BlooddanceSpeed").setFloat(0, 1.0);
			obj.getVar("Blooddance").setInt(0, 0);
			BodyCalldaimus(obj, "blooddancestart");
			obj.sq_SetCurrentAnimation(364);
			obj.sq_SetCurrentAttackInfo(94);
			local attackRate = obj.sq_GetBonusRateWithPassive(155, -1, 0, getATSwordmanBonus(obj, 1.0, 155));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			obj.playSound("BLOODDANCE_LOOP", 2022, 0, 0, 0);
			obj.sq_SetCurrentAnimation(363);
			obj.sq_SetCurrentAttackInfo(95);
			local attackRate = obj.sq_GetBonusRateWithPassive(155, -1, 0, getATSwordmanBonus(obj, 1.0, 155));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			if (sq_GetSkillLevel(obj, 163) > 0)
			{
			local ani = obj.getCurrentAnimation();
			local customData1 = ani.getDelaySum(false);
			obj.sq_StartWrite();
			obj.sq_WriteDword(301);
			obj.sq_WriteDword(customData1);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 0, 0, 0);
			}
			break;
		case 2:
			obj.stopSound(2022);
			BodyCalldaimus(obj, "blooddancefinish");
			obj.sq_SetCurrentAnimation(362);
			obj.sq_SetCurrentAttackInfo(96);
			local attackRate = obj.sq_GetBonusRateWithPassive(155, -1, 5, getATSwordmanBonus(obj, 1.0, 155));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			if (sq_GetSkillLevel(obj, 163) > 0)
			{
			local ani = obj.getCurrentAnimation();
			local customData1 = ani.getDelaySum(false);
			obj.sq_StartWrite();
			obj.sq_WriteDword(302);
			obj.sq_WriteDword(customData1);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 0, 0, 0);
			}
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Blooddance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(155, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:

			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Blooddance(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Blooddance(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (frameIndex % 4 == 0) {
				obj.resetHitObjectList();
				obj.getVar("Blooddance").setInt(0, obj.getVar("Blooddance").getInt(0) + 1);
			}
			break;
		case 4:

			break;
	}
}


function onEndState_Blooddance(obj, new_state) {
	if (!obj) return;
	if (new_state != 155) obj.stopSound(2022);
}


function onProc_Blooddance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			local staticData = sq_GetIntData(obj, 155, 1);
			if (sq_IsKeyDown(OPTION_HOTKEY_ATTACK, ENUM_SUBKEY_TYPE_ALL)) {
				if (IsInterval(obj, 50)) {
					local BlooddanceSpeed_float = obj.getVar("BlooddanceSpeed").getFloat(0);
					obj.getVar("BlooddanceSpeed").setFloat(0, BlooddanceSpeed_float + 0.15);
					staticData = sq_GetIntData(obj, 155, 2);
				}
			} else if (sq_IsKeyDown(OPTION_HOTKEY_JUMP, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			local BlooddanceSpeed_float1 = obj.getVar("BlooddanceSpeed").getFloat(0);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, BlooddanceSpeed_float1);
			local Blooddance_int = obj.getVar("Blooddance").getInt(0);
			if (Blooddance_int == staticData) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(155, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}


function onKeyFrameFlag_Blooddance(obj, flagIndex) {
	if (!obj) return false;
	return true;
}



function onProcCon_Blooddance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
