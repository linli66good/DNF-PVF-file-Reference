SUB_WILDWHIP_START		<-0
SUB_WILDWHIP_LOOP		<-1
SUB_WILDWHIP_END		<-2

function checkExecutableSkill_Wildwhip(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(153);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(153, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Wildwhip(obj) {
	if (!obj) return false;
	if (sq_GetSkillLevel(obj, 163) < 1) {
		local state = obj.sq_GetState();
		if (state == 0 || state == 108 || state == 14)
			return true;
		else
			return false;
	}
	return true;
}



function onSetState_Wildwhip(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("WILDWHIP_SPIRAL_READY");
			obj.getVar("WildwhipSpeed").setFloat(0, 1.0);
			obj.getVar("WildwhipC").setInt(0, 0);
			obj.sq_SetCurrentAnimation(452);
			obj.sq_SetCurrentAttackInfo(92);
			local attackRate = obj.sq_GetBonusRateWithPassive(153, -1, 1, getATSwordmanBonus(obj, 1.0, 153));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(453);
			obj.sq_SetCurrentAttackInfo(92);
			local attackRate = obj.sq_GetBonusRateWithPassive(153, -1, 1, getATSwordmanBonus(obj, 1.0, 153));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			if (sq_GetSkillLevel(obj, 163) > 0)
			{
			local ani = obj.getCurrentAnimation();
			local customData1 = ani.getDelaySum(false);
			obj.sq_StartWrite();
			obj.sq_WriteDword(303);
			obj.sq_WriteDword(customData1);
			obj.sq_SendCreatePassiveObjectPacket(24238, 0, 0, 0, 0);
			}
			break;
		case 2:
			obj.stopSound(2021);
			obj.sq_PlaySound("WILDWHIP_SPIRAL_FINISH");
			obj.sq_SetCurrentAnimation(454);
			obj.sq_SetCurrentAttackInfo(93);
			local attackRate = obj.sq_GetBonusRateWithPassive(153, -1, 1, getATSwordmanBonus(obj, 1.0, 153));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Wildwhip(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.playSound("WILDWHIP_SPIRAL_LOOP", 2021, 0, 0, 0);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(153, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			local WildwhipC_int = obj.getVar("WildwhipC").getInt(0);
			if (WildwhipC_int == 1) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(153, STATE_PRIORITY_IGNORE_FORCE, true);
			} else {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_AddSetStatePacket(153, STATE_PRIORITY_IGNORE_FORCE, true);
				obj.getVar("WildwhipC").setInt(0, WildwhipC_int + 1);
			}
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Wildwhip(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Wildwhip(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (frameIndex % 3 == 0) {
				obj.resetHitObjectList();
				if (obj.isMyControlObject()) obj.sq_SetShake(obj, 2, 85);
			}
			break;
		case 4:

			break;
	}
}


function onEndState_Wildwhip(obj, new_state) {
	if (!obj) return;
	if (new_state != 153) obj.stopSound(2021);
}


function onProcCon_Wildwhip(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (sq_IsKeyDown(OPTION_HOTKEY_ATTACK, ENUM_SUBKEY_TYPE_ALL)) {
				if (IsInterval(obj, 50)) {
					local WildwhipSpeed_float = obj.getVar("WildwhipSpeed").getFloat(0);
					obj.getVar("WildwhipSpeed").setFloat(0, WildwhipSpeed_float + 0.15);
				}
			} else if (sq_IsKeyDown(OPTION_HOTKEY_JUMP, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			local WildwhipSpeed_float1 = obj.getVar("WildwhipSpeed").getFloat(0);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, WildwhipSpeed_float1);
			break;
	}
}

function onProc_Wildwhip(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Wildwhip(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}


