
function checkExecutableSkill_Splitdemonsword(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(156);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(156, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Splitdemonsword(obj) {
	if (!obj) return false;
	if (sq_GetSkillLevel(obj, 163) < 1) {
		local state = obj.sq_GetState();
		if (state == 0 || state == 108 || state == 14)
			return true;
		else
			return false;
	}
	return true;
}



function onSetState_Splitdemonsword(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.getVar().setBool(0, false);
			BodyCalldaimus(obj, "splitdemonsword_body");
			obj.sq_SetCurrentAnimation(435);
			obj.sq_SetCurrentAttackInfo(97);
			local attackRate = obj.sq_GetBonusRateWithPassive(156, -1, 0, getATSwordmanBonus(obj, 1.0, 156));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Splitdemonsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Splitdemonsword(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				local apPath = "character/atswordman/3_demonslayer/splitdemonsword/ap_splitdemonsword.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				local customData = 400;
				local customData1 = 250;
				if (obj.getVar().getBool(0)) {
					customData = 170;
					customData1 = 300;
				}
				if (appendage) {
					sq_MoveToAppendageForce(damager, obj, obj, customData, 0, damager.getZPos(), customData1, true, appendage, true);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(customData1);
				}
			}
			break;
		case 1:

			break;
	}
}


function onEnterFrame_Splitdemonsword(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (frameIndex) {
		case 7:
			obj.resetHitObjectList();
			obj.getVar().setBool(0, true);
			sq_SetMyShake(obj, 3, 200);
			obj.sq_SetCurrentAttackInfo(98);
			local attackRate = obj.sq_GetBonusRateWithPassive(156, -1, 0, getATSwordmanBonus(obj, 1.0, 156));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
}


function onEndState_Splitdemonsword(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Splitdemonsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Splitdemonsword(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Splitdemonsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
