
function checkExecutableSkill_Ultimateblade(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(165);
	if (isUse) {
		obj.getVar("Ultimateblade").clear_obj_vector();
		obj.getVar("Ultimateblade").setInt(0, obj.getDirection());
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(165, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Ultimateblade(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Ultimateblade(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL))
		obj.getVar("Ultimateblade").setInt(0, 0);
	else if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL))
		obj.getVar("Ultimateblade").setInt(0, 1);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyCalldaimus(obj, "ultimateblade_start_grab");
			obj.sq_SetCurrentAnimation(446);
			obj.sq_SetCurrentAttackInfo(111);
			local attackRate = obj.sq_GetBonusRateWithPassive(165 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local customArr =
				[ "character/swordman/effect/animation/atultimateblade/start/start_grab_clawn02.ani", "character/swordman/effect/animation/atultimateblade/start/start_grab_floor01.ani" ];
			foreach (path in customArr) DarktemplerCreateAniPooledObj(obj, path, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			break;
		case 1:

			obj.sq_SetCurrentAnimation(447);
			obj.sq_SetCurrentAttackInfo(111);
			local attackRate = obj.sq_GetBonusRateWithPassive(165 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local customArr =
				[ "character/swordman/effect/animation/atultimateblade/start/start_pull_floorn01.ani", "character/swordman/effect/animation/atultimateblade/start/start_pull_clawn02.ani" ];
			foreach (path in customArr) DarktemplerCreateAniPooledObj(obj, path, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			break;
		case 2:

			obj.sq_SetCurrentAnimation(436);
			obj.sq_SetCurrentAttackInfo(111);
			local attackRate = obj.sq_GetBonusRateWithPassive(165 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local customArr = ["character/swordman/effect/animation/atultimateblade/attackbasic/basic_attack01_clawn03.ani"];
			foreach (path in customArr) DarktemplerCreateAniPooledObj(obj, path, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			break;
		case 3:

			obj.sq_SetCurrentAnimation(437);
			obj.sq_SetCurrentAttackInfo(111);
			local attackRate = obj.sq_GetBonusRateWithPassive(165 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local customArr = ["character/swordman/effect/animation/atultimateblade/attackbasic/basic_attack02_clawn03.ani"];
			foreach (path in customArr) DarktemplerCreateAniPooledObj(obj, path, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			break;
		case 4:

			obj.sq_SetCurrentAnimation(438);
			obj.sq_SetCurrentAttackInfo(111);
			local attackRate = obj.sq_GetBonusRateWithPassive(165 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local customArr = ["character/swordman/effect/animation/atultimateblade/attackbasic/basic_attack03_clawn03.ani"];
			foreach (path in customArr) DarktemplerCreateAniPooledObj(obj, path, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			break;
		case 5:

			obj.sq_SetCurrentAnimation(439);
			obj.sq_SetCurrentAttackInfo(111);
			local attackRate = obj.sq_GetBonusRateWithPassive(165 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local customArr = ["character/swordman/effect/animation/atultimateblade/attackbasic/basic_attack04_clawn03.ani"];
			foreach (path in customArr) DarktemplerCreateAniPooledObj(obj, path, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			break;
		case 6:
			obj.sq_SetCurrentAnimation(445);
			obj.sq_SetCurrentAttackInfo(111);
			local attackRate = obj.sq_GetBonusRateWithPassive(165 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.setDirection(obj.getVar("Ultimateblade").getInt(0));
			local customArr = [ "character/swordman/effect/animation/atultimateblade/finish/finish_floorn01.ani", "character/swordman/effect/animation/atultimateblade/finish/finish_dust02.ani" ];
			foreach (path in customArr) DarktemplerCreateAniPooledObj(obj, path, true, true, obj.getXPos(), obj.getYPos(), 0, 1.0);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Ultimateblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(165, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(165, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(165, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(165, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(165, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(165, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 6:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Ultimateblade(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:
			if (!obj.getVar("Ultimateblade").is_obj_vector(damager)) {
				local apPath = "character/atswordman/3_demonslayer/ultimateblade/ap_ultimateblade.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
					obj.getVar("Ultimateblade").push_obj_vector(damager);
					if (appendage) {
						sq_HoldAndDelayDie(damager, obj, true, true, true, 100, 100, ENUM_DIRECTION_NEUTRAL, appendage);
						local apInfo = appendage.getAppendageInfo();
						apInfo.setValidTime(1600);
					}
				}
			}
			break;
		case 1:

			break;
	}
}


function onEnterFrame_Ultimateblade(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			switch (frameIndex) {
				case 0:
					sq_flashScreen(obj, 160, 0, 0, 102, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 2:
					sq_flashScreen(obj, 0, 0, 160, 102, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 4:
					sq_SetMyShake(obj, 4, 160);
					sq_flashScreen(obj, 0, 0, 160, 51, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
			}
			break;
		case 1:
			switch (frameIndex) {
				case 0:
					sq_SetMyShake(obj, 3, 40);
					break;
				case 1:
					sq_SetMyShake(obj, 2, 80);
					break;
				case 2:
					sq_SetMyShake(obj, 1, 180);
					break;
				case 3:
					GrabMons_Ultimateblade(obj, -37, 0, 148);
					break;
				case 4:
					GrabMons_Ultimateblade(obj, -27, 0, 182);
					break;
			}
			break;
		case 2:
			switch (frameIndex) {
				case 0:
					sq_SetMyShake(obj, 3, 40);
					sq_flashScreen(obj, 0, 0, 40, 25, sq_RGB(255, 255, 255), GRAPHICEFFECT_LINEARDODGE, ENUM_DRAWLAYER_BOTTOM);
					obj.sq_StartWrite();
					obj.sq_WriteDword(165);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(165 , -1, 2, 1.0));
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, 133, 0, 0);
					break;
				case 1:
					GrabMons_Ultimateblade(obj, 133, 0, 130);
					break;
				case 2:
					GrabMons_Ultimateblade(obj, 133, 0, 130);
					break;
			}
			break;
		case 3:
			switch (frameIndex) {
				case 0:
					obj.sq_StartWrite();
					obj.sq_WriteDword(165);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(165 , -1, 2, 1.0));
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, -87, 0, 0);
					sq_SetMyShake(obj, 3, 40);
					sq_flashScreen(obj, 0, 0, 40, 25, sq_RGB(255, 255, 255), GRAPHICEFFECT_LINEARDODGE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 1:
					GrabMons_Ultimateblade(obj, -87, 0, 166);
					break;
				case 2:
					GrabMons_Ultimateblade(obj, -132, 0, 171);
					break;
			}
			break;
		case 4:
			switch (frameIndex) {
				case 0:
					obj.sq_StartWrite();
					obj.sq_WriteDword(165);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(165 , -1, 2, 1.0));
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, 155, 0, 0);
					sq_SetMyShake(obj, 3, 40);
					sq_flashScreen(obj, 0, 0, 40, 25, sq_RGB(255, 255, 255), GRAPHICEFFECT_LINEARDODGE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 1:
					GrabMons_Ultimateblade(obj, 155, 0, 124);
					break;
				case 2:
					GrabMons_Ultimateblade(obj, 149, 0, 171);
					break;
			}
			break;
		case 5:
			switch (frameIndex) {
				case 0:
					obj.sq_StartWrite();
					obj.sq_WriteDword(165);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(165 , -1, 2, 1.0));
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, -90, 0, 0);
					sq_SetMyShake(obj, 3, 40);
					sq_flashScreen(obj, 0, 0, 40, 25, sq_RGB(255, 255, 255), GRAPHICEFFECT_LINEARDODGE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 1:
					GrabMons_Ultimateblade(obj, -90, 0, 168);
					break;
				case 2:
					GrabMons_Ultimateblade(obj, -127, 0, 170);
					break;
			}
			break;
		case 6:
			switch (frameIndex) {
				case 0:
					GrabMons_Ultimateblade(obj, -47, 0, 224);
					sq_flashScreen(obj, 160, 0, 0, 165, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 1:
					GrabMons_Ultimateblade(obj, -25, 0, 242);
					break;
				case 2:
					obj.sq_StartWrite();
					obj.sq_WriteDword(165);
					obj.sq_WriteDword(1);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(165 , -1, 4, 1.0));
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, 228, 0, 0);
					sq_SetMyShake(obj, 6, 240);
					sq_flashScreen(obj, 0, 0, 160, 165, sq_RGB(255, 255, 255), GRAPHICEFFECT_LINEARDODGE, ENUM_DRAWLAYER_BOTTOM);
					break;
				case 3:
					GrabMons_Ultimateblade2(obj, 228, 0, 65);
					break;
			}
			break;
	}
}


function onChangeSkillEffect_Ultimateblade(obj, skillIndex, reciveData) {
	if (!obj || skillIndex != 165) return;
	local readData = reciveData.readDword();
	local readData1 = reciveData.readDword();
	local readData2 = reciveData.readDword();
	local readData3 = reciveData.readDword();
	local dstPos = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), readData);
	local Ultimateblade_size = obj.getVar("Ultimateblade").get_obj_vector_size();
	for (local customData = 0; customData < Ultimateblade_size; ++customData) {
		local Ultimateblade_obj = obj.getVar("Ultimateblade").get_obj_vector(customData);
		if (Ultimateblade_obj) sq_SetCurrentPos(Ultimateblade_obj, dstPos, obj.getYPos(), readData2);
	}
}


function GrabMons_Ultimateblade(obj, writeData1, writeData2, writeData3) {
	sq_BinaryStartWrite();
	sq_BinaryWriteDword(writeData1);
	sq_BinaryWriteDword(writeData2);
	sq_BinaryWriteDword(writeData3);
	sq_BinaryWriteDword(0);
	sq_SendChangeSkillEffectPacket(obj, 165);
}


function GrabMons_Ultimateblade2(obj, writeData1, writeData2, writeData3) {
	sq_BinaryStartWrite();
	sq_BinaryWriteDword(writeData1);
	sq_BinaryWriteDword(writeData2);
	sq_BinaryWriteDword(writeData3);
	sq_BinaryWriteDword(1);
	sq_SendChangeSkillEffectPacket(obj, 165);
}


function onEndState_Ultimateblade(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Ultimateblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Ultimateblade(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}

