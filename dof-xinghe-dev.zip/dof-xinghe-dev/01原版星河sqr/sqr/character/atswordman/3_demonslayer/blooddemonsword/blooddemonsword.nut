
function checkExecutableSkill_Blooddemonsword(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(162);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(162, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Blooddemonsword(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Blooddemonsword(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyCalldaimus(obj, "blooddemonswordcast_body");
			obj.sq_SetCurrentAnimation(365);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ani = obj.sq_CreateCNRDAnimation("effect/animation/atblooddemonsword/daimus/daimuscast_body.ani");
			obj.sq_AddStateLayerAnimation(-1, ani, 0, 0);
			break;
		case 1:
			BodyCalldaimus(obj, "blooddemonswordhit_body");
			obj.sq_SetCurrentAnimation(366);
			obj.sq_SetCurrentAttackInfo(110);
			local attackRate = obj.sq_GetBonusRateWithPassive(162 , -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ndelay = ani.getDelaySum(false);
			local speed = delay.tofloat() / ndelay.tofloat();
			local size = sq_GetIntData(obj, 162, 0);
			local sizeRate = size.tofloat() / 100.0;
			sq_SetAttackBoundingBoxSizeRate(ani, sizeRate, sizeRate, sizeRate);
			Common_Image_Als(obj,"character/swordman/effect/animation/atblooddemonsword/hitfront_07.ani", 0, 0, 0, 0, size, 0, speed);
			Common_Image_Als(obj,"character/swordman/effect/animation/atblooddemonsword/daimus/daimushit_body.ani", 0, 0, 0, 0, 100, 1, speed);
			Common_Image_Als(obj,"character/swordman/effect/animation/atblooddemonsword/daimus/daimushitback_00.ani", 0, 0, 0, 0, 100, 1, speed);
			Common_Image_Als(obj,"character/swordman/effect/animation/atblooddemonsword/hitback_dust.ani", 0, 0, 0, 0, size, 0, speed);
			break;
	}
}


function onEndCurrentAni_Blooddemonsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(162, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Blooddemonsword(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Blooddemonsword(obj, frameIndex) {
	if (!obj || !obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (frameIndex == 2)
				sq_flashScreen(obj, 0, 80, 240, 204, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_CLOSEBACK);
			else if (frameIndex == 1) {
				sq_SetMyShake(obj, 7, 200);
				sq_flashScreen(obj, 0, 120, 400, 204, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_CLOSEBACK);
			}
			break;
	}
}


function onEndState_Blooddemonsword(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Blooddemonsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Blooddemonsword(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Blooddemonsword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
