
function checkExecutableSkill_Clawblade(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(152);
	if (isUse) {
		obj.getVar("Clawblade").clear_obj_vector();
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(152, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Clawblade(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Clawblade(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_CLAWBLADE");
			BodyCalldaimus(obj, "clawblade1");
			obj.sq_SetCurrentAnimation(403);
			obj.sq_SetCurrentAttackInfo(90);
			local attackRate = obj.sq_GetBonusRateWithPassive(152, -1, 0, getATSwordmanBonus(obj, 1.0, 152));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(404);
			obj.sq_SetCurrentAttackInfo(90);
			local attackRate = obj.sq_GetBonusRateWithPassive(152, -1, 1, getATSwordmanBonus(obj, 1.0, 152));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(405);
			obj.sq_SetCurrentAttackInfo(90);
			local attackRate = obj.sq_GetBonusRateWithPassive(152, -1, 2, getATSwordmanBonus(obj, 1.0, 152));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(406);
			obj.sq_SetCurrentAttackInfo(91);
			local attackRate = obj.sq_GetBonusRateWithPassive(152, -1, 2, getATSwordmanBonus(obj, 1.0, 152));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Clawblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(152, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(152, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Clawblade(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:
			if (!obj.getVar("Clawblade").is_obj_vector(damager) && sq_GetSkillLevel(obj, 163) > 0) {
				obj.getVar("Clawblade").push_obj_vector(damager);
				local levelData = sq_GetLevelData(obj, 163, 5, sq_GetSkillLevel(obj, 163)) / 100.0;
				obj.sq_StartWrite();
				obj.sq_WriteDword(152);
				obj.sq_WriteDword(1);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(152, -1, 0, getATSwordmanBonus(obj, levelData, 152)));
				obj.sq_WriteDword(sq_GetObjectId(damager));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, damager.getXPos(), damager.getYPos(), damager.getZPos() + obj.getObjectHeight() / 2);
			}
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				local apPath = "character/atswordman/3_demonslayer/clawblade/ap_clawblade.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, true, false, 100, 100, ENUM_DIRECTION_NEUTRAL, appendage);
					sq_MoveToAppendageForce(damager, obj, obj, 250, 0, 0, 300, true, appendage, true);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(300);
				}
			}
			break;
		case 1:
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				local apPath = "character/atswordman/3_demonslayer/clawblade/ap_clawblade.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_HoldAndDelayDie(damager, obj, true, true, false, 100, 100, ENUM_DIRECTION_NEUTRAL, appendage);
					sq_MoveToAppendageForce(damager, obj, obj, 250, 0, 120, 300, true, appendage, true);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(300);
				}
			}
			break;
	}
}


function onEnterFrame_Clawblade(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 1:
			if (frameIndex == 3 || frameIndex == 5 || frameIndex == 7) obj.resetHitObjectList();
			break;
		case 2:

			break;
	}
}


function onEndState_Clawblade(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Clawblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Clawblade(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Clawblade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
