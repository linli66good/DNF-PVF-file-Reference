
function checkExecutableSkill_Ragnarok(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(166);
	if (isUse) {
		obj.getVar("Ragnarok").clear_vector();
		obj.getVar("Ragnarok").push_vector(obj.getXPos());
		obj.getVar("Ragnarok").push_vector(obj.getYPos());
		local Ragnarok = obj.getVar("Ragnarok");
		local flashScreenObj = sq_flashScreen(obj, 150, 10500, 300, 255, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		Ragnarok.setObject(0, flashScreenObj);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(166, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Ragnarok(obj) {
	if (!obj) return false;
	return true;
}


function onSetState_Ragnarok(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			local objectManager = obj.getObjectManager();
			local xPos = objectManager.getFieldXPos(533, ENUM_DRAWLAYER_NORMAL);
			local yPos = objectManager.getFieldYPos(500, 0, ENUM_DRAWLAYER_NORMAL);
			local direction = obj.getDirection();
			local objectManager1 = obj.getObjectManager();
			local xPos1 = objectManager1.getFieldXPos(direction == ENUM_DIRECTION_LEFT ? 800 : 0, ENUM_DRAWLAYER_NORMAL);
			local yPos1 = objectManager1.getFieldYPos(0, 0, ENUM_DRAWLAYER_NORMAL);
			local zPos = objectManager.getFieldZPos(200, 0, ENUM_DRAWLAYER_NORMAL);
			if (obj.isMyControlObject()) {
				sq_SetMyShake(obj, 12, 400);
				sq_flashScreen(obj, 0, 120, 540, 204, sq_RGB(255, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
				createPooledObjEff(obj, "character/swordman/effect/animation/atragnarok/transformation/rtransformation_body.ani", xPos1, yPos1, zPos, ENUM_DRAWLAYER_COVER, direction);
				obj.sq_StartWrite();
				obj.sq_WriteDword(166);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(166 , -1, 0, 1.0));
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(166 , -1, 2, 1.0));
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(166 , -1, 3, 1.0));
				obj.sq_WriteDword(sq_GetLevelData(obj, 166, 1, sq_GetSkillLevel(obj, 166)));
				obj.sq_WriteDword(sq_GetIntData(obj, 166, 1));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, xPos, yPos, 0);
			}
			obj.setCurrentAnimation(null);
			break;
	}
}



function onEndCurrentAni_Ragnarok(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Ragnarok(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Ragnarok(obj, frameIndex) {
	if (!obj) return;
	if (!obj) return false;
	switch (frameIndex) {
		case 4:
			obj.sq_PlaySound("SW_RAGNAROK_02");
			break;
		case 7:
			obj.sq_PlaySound("SW_RAGNAROK_03");
			break;
		case 9:
			obj.sq_PlaySound("SW_RAGNAROK_04");
			break;
	}
}


function onEndState_Ragnarok(obj, new_state) {
	if (!obj) return;
	if (new_state != 166) {
		obj.sq_SetCurrentPos(obj, obj.getVar("Ragnarok").get_vector(0), obj.getVar("Ragnarok").get_vector(1), 0);
		local Ragnarok_obj = obj.getVar("Ragnarok").getObject(0);
		if (Ragnarok_obj) {
			local pflashScreen = sq_GetCNRDObjectToFlashScreen(Ragnarok_obj);
			if (pflashScreen) pflashScreen.fadeOut();
		}
	}
}


function onProc_Ragnarok(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Ragnarok(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Ragnarok(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
