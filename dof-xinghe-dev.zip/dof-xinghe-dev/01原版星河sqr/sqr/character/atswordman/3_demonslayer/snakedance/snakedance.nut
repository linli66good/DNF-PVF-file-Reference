
function checkExecutableSkill_Snakedance(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(167);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(167, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Snakedance(obj) {
	if (!obj) return false;
	if (sq_GetSkillLevel(obj, 163) < 1) {
		local state = obj.sq_GetState();
		if (state == 0 || state == 108 || state == 14)
			return true;
		else
			return false;
	}
	return true;
}



function onSetState_Snakedance(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_SNAKEDANCE_01");
			BodyCalldaimus(obj, "snakedance1");
			obj.sq_SetCurrentAnimation(455);
			obj.sq_SetCurrentAttackInfo(112);
			local attackRate = obj.sq_GetBonusRateWithPassive(167, -1, 0, getATSwordmanBonus(obj, 1.0, 167));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			obj.sq_PlaySound("SW_SNAKEDANCE_02");
			BodyCalldaimus(obj, "snakedance2");
			obj.sq_SetCurrentAnimation(456);
			obj.sq_SetCurrentAttackInfo(113);
			local attackRate = obj.sq_GetBonusRateWithPassive(167, -1, 1, getATSwordmanBonus(obj, 1.0, 167));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 2:
			obj.sq_PlaySound("SW_SNAKEDANCE_03");
			BodyCalldaimus(obj, "snakedance3");
			obj.sq_SetCurrentAnimation(457);
			obj.sq_SetCurrentAttackInfo(114);
			local attackRate = obj.sq_GetBonusRateWithPassive(167, -1, 2, getATSwordmanBonus(obj, 1.0, 167));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Snakedance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(167, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(167, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Snakedance(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
}


function onEnterFrame_Snakedance(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Snakedance(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Snakedance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Snakedance(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Snakedance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
