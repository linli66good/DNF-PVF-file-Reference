
function checkExecutableSkill_Whipswordbal(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(149);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(149, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Whipswordbal(obj) {
	if (!obj) return false;
	if (sq_GetSkillLevel(obj, 163) < 1) {
		local state = obj.sq_GetState();
		if (state == 0 || state == 108 || state == 14)
			return true;
		else
			return false;
	}

	return true;
}



function onSetState_Whipswordbal(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_WHIPSWORDBAL");
			if (sq_GetSkillLevel(obj, 163) > 0) {
				BodyCalldaimus(obj, "whipswordbal1");
				obj.sq_SetCurrentAnimation(448);
			} else {
				BodyCalldaimus(obj, "whipswordbal1_devil");
				obj.sq_SetCurrentAnimation(449);
			}
			obj.sq_SetCurrentAttackInfo(86);
			local attackRate = obj.sq_GetBonusRateWithPassive(149, -1, 0, getATSwordmanBonus(obj, 1.0, 149));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			if (sq_GetSkillLevel(obj, 163) > 0) {
				BodyCalldaimus(obj, "whipswordbal2");
				obj.sq_SetCurrentAnimation(450);
			} else {
				BodyCalldaimus(obj, "Whipswordbal3");
				obj.sq_SetCurrentAnimation(451);
			}
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(149, -1, 0, getATSwordmanBonus(obj, 1.0, 149));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Whipswordbal(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Whipswordbal(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Whipswordbal(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (frameIndex) {
		case 4:
			if (sq_GetSkillLevel(obj, 163) == 0)
			{
				local customData1 = sq_GetIntData(obj, 149, 12);
				obj.sq_StartWrite();
				obj.sq_WriteDword(307);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 150 + customData1 / 12, 0, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(307);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 200 + customData1 / 10, 0, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(307);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 250 + customData1 / 8, 0, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(307);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 300 + customData1 / 6, 0, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(307);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 350 + customData1 / 4, 0, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(307);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 400 + customData1 / 3, 0, 0);
			}
			else if (sq_GetSkillLevel(obj, 163) > 0)
			{
				local customData1 = sq_GetIntData(obj, 149, 12);
				obj.sq_StartWrite();
				obj.sq_WriteDword(309);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 290 + customData1 / 12, 0, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 150 + customData1 / 12, 30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 200 + customData1 / 10, 30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 250 + customData1 / 8, 30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 300 + customData1 / 6, 30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 350 + customData1 / 4, 30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 400 + customData1 / 3, 30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 150 + customData1 / 12, -30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 200 + customData1 / 10, -30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 250 + customData1 / 8, -30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 300 + customData1 / 6, -30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 350 + customData1 / 4, -30, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(308);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 400 + customData1 / 3, -30, 0);
			}
			break;
	}
}


function onEndState_Whipswordbal(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Whipswordbal(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Whipswordbal(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 1:

			break;
	}
	return true;
}



function onProcCon_Whipswordbal(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
