function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onVaildTimeEnd", "onVaildTimeEnd_appendage_ATGreedbuff");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_ATGreedbuff");
}


function onVaildTimeEnd_appendage_ATGreedbuff(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	sqrChr.getVar("ATGreedbuff").setInt(0, 0);
}


function onEnd_appendage_ATGreedbuff(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	sqrChr.getVar("ATGreedbuff").setInt(0, 0);
}

