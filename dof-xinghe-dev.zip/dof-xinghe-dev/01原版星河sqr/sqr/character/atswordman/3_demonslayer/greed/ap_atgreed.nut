function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_ATGreed"); }



function onAttackParent_appendage_ATGreed(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage || isStuck) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local sqrChr = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local damager = sq_GetCNRDObjectToActiveObject(damager);
	local skillLevel = sq_GetSkillLevel(sqrChr, 159);
	local levelData = sq_GetLevelData(sqrChr, 159, 0, skillLevel);
	local staticData = sq_GetIntData(sqrChr, 159, 0);
	local randNum = sq_getRandom(0, 99);
	if (randNum < levelData && damager.isDead()) {
		sqrChr.sq_StartWrite();
		sqrChr.sq_WriteDword(159);
		sqrChr.sq_WriteDword(0);
		sqrChr.sq_WriteDword(staticData);
		sq_SendCreatePassiveObjectPacketPos(sqrChr, 24383, 0, damager.getXPos(), damager.getYPos(), 0);
	}
}
