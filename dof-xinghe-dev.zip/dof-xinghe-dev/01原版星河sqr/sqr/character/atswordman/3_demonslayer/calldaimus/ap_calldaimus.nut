function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onStart", "onStart_appendage_Calldaimus"); }



function onStart_appendage_Calldaimus(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 148);
	local levelData = sq_GetLevelData(sqrChr, 148, 3, skillLevel) / 10;
	local levelData1 = sq_GetLevelData(sqrChr, 148, 4, skillLevel);
	local change_appendage = appendage.sq_getChangeStatus("Calldaimus");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Calldaimus", sqrChr, sqrChr, 0, 33, false, -levelData);
		change_appendage = appendage.sq_AddChangeStatus("Calldaimus", sqrChr, sqrChr, 0, 34, false, levelData1);
	} else {
		change_appendage.clearParameter();
		change_appendage.addParameter(33, false, -levelData.tofloat());
		change_appendage.addParameter(34, false, levelData1.tofloat());
	}
}

