
function checkExecutableSkill_Phnom(obj) {
	if (!obj) return false;
	if (obj.getHp() < sq_GetLevelData(obj, 161, 0, sq_GetSkillLevel(obj, 161))) {
		sq_AddMessage(3599);
		return false;
	}
	local isUse = obj.sq_IsUseSkill(161);
	if (isUse) {
		local levelData = sq_GetLevelData(obj, 161, 0, sq_GetSkillLevel(obj, 161));
		obj.setHp(obj.getHp() - levelData, null, true);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(161, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Phnom(obj) {
	if (!obj) return false;
	if (sq_GetSkillLevel(obj, 163) < 1) {
		local state = obj.sq_GetState();
		if (state == 0 || state == 108 || state == 14)
			return true;
		else
			return false;
	}
	return true;
}



function onSetState_Phnom(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyCalldaimus(obj, "phnomcast");
			obj.sq_SetCurrentAnimation(425);
			break;
		case 1:
			BodyCalldaimus(obj, "phnomkelkus");
			obj.sq_SetCurrentAnimation(429);
			obj.sq_SetCurrentAttackInfo(107);
			local attackRate = obj.sq_GetBonusRateWithPassive(161, -1, 0, getATSwordmanBonus(obj, 1.0, 161));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.setTimeEvent(0, sq_GetIntData(obj, 161, 2), sq_GetIntData(obj, 161, 1), false);
			break;
		case 2:
			BodyCalldaimus(obj, "phnomdaimus");
			obj.sq_SetCurrentAnimation(426);
			obj.sq_SetCurrentAttackInfo(108);
			local attackRate = obj.sq_GetBonusRateWithPassive(161, -1, 0, getATSwordmanBonus(obj, 1.0, 161));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.setTimeEvent(1, 160, sq_GetIntData(obj, 161, 0), false);
			break;
		case 3:
			BodyCalldaimus(obj, "phnomexplosion");
			obj.sq_SetCurrentAnimation(427);
			obj.sq_SetCurrentAttackInfo(109);
			local attackRate = obj.sq_GetBonusRateWithPassive(161, -1, 0, getATSwordmanBonus(obj, 1.0, 161));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Phnom(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(161, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(161, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(161, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Phnom(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onTimeEvent_Phnom(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	switch (timeEventIndex) {
		case 0:
			obj.resetHitObjectList();
			break;
		case 1:
			local customData = timeEventCount % 4;
			obj.sq_StartWrite();
			obj.sq_WriteDword(161);
			obj.sq_WriteDword(1);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(161, -1, 2, getATSwordmanBonus(obj, 1.0, 161)));
			obj.sq_WriteDword(customData);
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 60);
			if (obj.isMyControlObject()) {
				obj.sq_SetShake(obj, 3, 40);
				sq_flashScreen(obj, 35, 15, 35, 180, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, 0);
			}
			if (timeEventCount >= sq_GetIntData(obj, 161, 0)) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(3);
				obj.sq_AddSetStatePacket(161, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}


function onEnterFrame_Phnom(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:
			if (frameIndex == 3 && obj.isMyControlObject()) {
				obj.sq_SetShake(obj, 4, 40);
				sq_flashScreen(obj, 35, 50, 35, 180, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, 0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(161);
				obj.sq_WriteDword(2);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(161, -1, 4, getATSwordmanBonus(obj, 1.0, 161)));
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 0, 0, 60);
			}
			break;
		case 4:

			break;
	}
}


function onEndState_Phnom(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Phnom(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Phnom(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Phnom(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 2:
			if (sq_IsKeyDown(OPTION_HOTKEY_JUMP, ENUM_SUBKEY_TYPE_ALL)) {
				obj.sq_IntVectClear();
				obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}
