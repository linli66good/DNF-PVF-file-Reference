function checkExecutableSkill_Phnom(obj)
{
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(161);
	if (isUse)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(161, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}

function checkCommandEnable_Phnom(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();
	if(state == STATE_STAND)
		return true;
	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(161);
	}
	return true;
}

function onSetState_Phnom(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();

	if(substate == 0)
	{
			obj.sq_SetCurrentAnimation(712);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
	}

}

function onEndCurrentAni_Phnom(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


function onKeyFrameFlag_Phnom(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		local ani = obj.getCurrentAnimation();
		local customData1 = ani.getDelaySum(false);
		if (flagIndex == 15)
		{
				sq_SetMyShake(obj, 6, 400);
				obj.sq_StartWrite();
				obj.sq_WriteDword(305);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 0, 0, 0);
		}
		if (flagIndex == 36)
		{
				sq_SetMyShake(obj, 8, 300);
				obj.sq_StartWrite();
				obj.sq_WriteDword(306);
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24238, 0, 0, 0, 0);
		}
	}
	return true;
}
