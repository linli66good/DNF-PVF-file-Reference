function sq_AddFunctionName(appendage) { appendage.sq_AddFunctionName("onStart", "onStart_appendage_Controldemonsword"); }


function onStart_appendage_Controldemonsword(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 154);
	local levelData = sq_GetLevelData(sqrChr, 154, 0, skillLevel) / 10;
	local levelData1 = sq_GetLevelData(sqrChr, 154, 1, skillLevel) / 10;
	local change_appendage = appendage.sq_getChangeStatus("Controldemonsword");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Controldemonsword", sqrChr, sqrChr, 0, 4, true, levelData);
		change_appendage = appendage.sq_AddChangeStatus("Controldemonsword", sqrChr, sqrChr, 0, 15, false, levelData1);
	} else {
		change_appendage.clearParameter();
		change_appendage.addParameter(4, true, levelData.tofloat());
		change_appendage.addParameter(15, false, levelData1.tofloat());
	}
}

