
function checkExecutableSkill_Atfrenzy(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(150);
	if (isUse) {
		CreateBuffCutin(obj, "etc/ultimateskillani/atsword_demonslayer_neo_buff.ani");
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(150, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Atfrenzy(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Atfrenzy(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("FRENZY_CAST");
			local castTime = sq_GetCastTime(obj, 150, sq_GetSkillLevel(obj, 150));
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local floatData = delay.tofloat() / castTime.tofloat();
			sq_StartDrawCastGauge(obj, castTime, true);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, floatData, floatData);
			BodyCalldaimus(obj, "frenzycast");
			obj.sq_SetCurrentAnimation(413);
			break;
		case 1:
			sq_EndDrawCastGauge(obj);
			BodyCalldaimus(obj, "frenzy");
			obj.sq_SetCurrentAnimation(412);
			local levelData = sq_GetLevelData(obj, 150, 2, sq_GetSkillLevel(obj, 150));
			local apPath = "character/atswordman/3_demonslayer/atfrenzy/ap_atfrenzy.nut";
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
			appendage.sq_SetValidTime(levelData);
			appendage.setEnableIsBuff(true);
			appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 150, sq_GetSkillLevel(obj, 150));
			CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
			appendage.setBuffIconImage(146);
			
			break;
	}
}


function onEndCurrentAni_Atfrenzy(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(150, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Atfrenzy(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Atfrenzy(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Atfrenzy(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Atfrenzy(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Atfrenzy(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Atfrenzy(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
