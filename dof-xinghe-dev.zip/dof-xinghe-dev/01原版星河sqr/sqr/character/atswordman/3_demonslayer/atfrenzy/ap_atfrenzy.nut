function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_Atfrenzy");
	appendage.sq_AddFunctionName("onVaildTimeEnd", "onVaildTimeEnd_appendage_Atfrenzy");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_Atfrenzy");
}



function onStart_appendage_Atfrenzy(appendage) {
	if (!appendage) return;
	if (!appendage.getParent()) {
		appendage.setValid(false);
		return;
	}
	local sourceObj = appendage.getSource();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(sourceObj);
	local skillLevel = sq_GetSkillLevel(sqrChr, 150);
	local levelData = sq_GetLevelData(sqrChr, 150, 0, skillLevel);
	local levelData1 = sq_GetLevelData(sqrChr, 150, 0, skillLevel);
	local change_appendage = appendage.sq_getChangeStatus("Atfrenzy");
	if (!change_appendage) {
		change_appendage = appendage.sq_AddChangeStatus("Atfrenzy", sqrChr, sqrChr, 0, 10, false, levelData);
		change_appendage = appendage.sq_AddChangeStatus("Atfrenzy", sqrChr, sqrChr, 0, 11, false, levelData1);
	} else {
		change_appendage.clearParameter();
		change_appendage.addParameter(10, false, levelData.tofloat());
		change_appendage.addParameter(11, false, levelData1.tofloat());
	}
	appendage.sq_AddEffectBack("character/swordman/effect/animation/atfrenzy/loop_loop.ani");
	appendage.sq_AddEffectFront("character/swordman/effect/animation/atfrenzy/loop_up.ani");
	local levelData2 = sq_GetLevelData(sqrChr, 150, 2, sq_GetSkillLevel(sqrChr, 150));
	if (levelData2 < 1000) levelData2 = 1000000;
	sq_EffectLayerAppendage(sqrChr, sq_RGB(255, 0, 0), 75, 0, levelData2, 0);
}



function onVaildTimeEnd_appendage_Atfrenzy(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
	appendage.sq_DeleteEffectFront();
	appendage.sq_DeleteEffectBack();
}


function onEnd_appendage_Atfrenzy(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local attacker = appendage.sq_GetSourceChrTarget();
	appendage.sq_DeleteEffectFront();
	appendage.sq_DeleteEffectBack();
}

