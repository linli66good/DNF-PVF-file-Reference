
function checkExecutableSkill_Gigablade(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(160);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(6);
		obj.sq_AddSetStatePacket(160, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Gigablade(obj) {
	if (!obj) return false;
	if (sq_GetSkillLevel(obj, 163) < 1) {
		local state = obj.sq_GetState();
		if (state == 0 || state == 108 || state == 14)
			return true;
		else
			return false;
	}
	return true;
}



function onSetState_Gigablade(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	local customData = 1.0;
	if (sq_GetSkillLevel(obj, 160) > 2) customData = 1.1;
	switch (subState) {
		case 0:
			BodyCalldaimus(obj, "gigabladecast");
			obj.sq_SetCurrentAnimation(414);
			if (obj.isMyControlObject()) {
				local sq_var = obj.getVar();
				local flashScreenObj = sq_flashScreen(obj, 150, 10500, 300, 100, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
				sq_var.setObject(0, flashScreenObj);
			}
			break;
		case 1:
			obj.sq_PlaySound("GIGA_SWORD");
			BodyCalldaimus(obj, "gigabladeslash");
			obj.sq_SetCurrentAnimation(420);
			obj.sq_SetCurrentAttackInfo(106);
			local attackRate = obj.sq_GetBonusRateWithPassive(160, -1, 4, getATSwordmanBonus(obj, customData, 160));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			BodyCalldaimus(obj, "gigabladegate");
			obj.sq_SetCurrentAnimation(417);
			obj.sq_SetCurrentAttackInfo(104);
			local attackRate = obj.sq_GetBonusRateWithPassive(160, -1, 4, getATSwordmanBonus(obj, customData, 160));
			local attackRate1 = obj.sq_GetBonusRateWithPassive(160, -1, 7, getATSwordmanBonus(obj, customData, 160));
			if (sq_GetSkillLevel(obj, 160) > 5) attackRate = attackRate + attackRate1;
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetStaticMoveInfo(0, 1000, -1000, false);
			break;
		case 3:
			obj.sq_StopMove();
			BodyCalldaimus(obj, "gigabladedash");
			obj.sq_SetCurrentAnimation(415);
			obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetStaticMoveInfo(0, 300, -1000, false);
			break;
		case 4:
			obj.sq_StopMove();
			BodyCalldaimus(obj, "gigabladefinish");
			obj.sq_SetCurrentAnimation(416);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetStaticMoveInfo(0, 300, -1000, false);
			break;
		case 5:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(419);
			obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetStaticMoveInfo(0, 300, -1000, false);
			break;
		case 6:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(418);
			obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onEndCurrentAni_Gigablade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(160, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:

			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(160, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(160, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(160, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 5:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(160, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 6:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onTimeEvent_Gigablade(obj, timeEventIndex, timeEventCount) {
	if (!obj) return;
	switch (timeEventIndex) {
		case 1:
			obj.resetHitObjectList();
			break;
	}
}


function onAttack_Gigablade(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	local customData = 1.0;
	if (sq_GetSkillLevel(obj, 160) > 2) customData = 1.1;
	switch (subState) {
		case 2:
			if (sq_GetSkillLevel(obj, 160) > 5) {
				local aniPath = "passiveobject/changqing_atswordman/animation/atgigabladekelkusexp/gigablade_specialatk_06.ani";
				DarktemplerCreateAniPooledObj(damager, aniPath, true, true, damager.getXPos(), damager.getYPos(), damager.getZPos() + damager.getObjectHeight() / 3, 1.0);
			}
			break;
		case 1:

			break;
	}
}


function onEnterFrame_Gigablade(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	local customData = 1.0;
	if (sq_GetSkillLevel(obj, 160) > 2) customData = 1.1;
	switch (subState) {
		case 6:
			if (frameIndex == 5) {
				local customData1 = 100;
				if (sq_GetSkillLevel(obj, 160) > 8) customData1 = 250;
				obj.sq_PlaySound("GIGASLASH_SMASH");
				obj.sq_StartWrite();
				obj.sq_WriteDword(160);
				obj.sq_WriteDword(1);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(160, -1, 3, getATSwordmanBonus(obj, customData, 160)));
				obj.sq_WriteDword(customData1);
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, 180, 0, 0);
			}
			break;
		case 4:

			break;
	}
}


function onEndState_Gigablade(obj, new_state) {
	if (!obj) return;
	if (new_state != 160) {
		local sq_var_obj = obj.getVar().getObject(0);
		if (sq_var_obj) {
			local pflashScreen = sq_GetCNRDObjectToFlashScreen(sq_var_obj);
			if (pflashScreen) pflashScreen.fadeOut();
		}
	}
}


function onProc_Gigablade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 4:
			local currentAni = sq_GetCurrentAnimation(obj);
			local frameIndex = obj.sq_GetCurrentFrameIndex(currentAni);
			if (frameIndex > 4) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(5);
				obj.sq_AddSetStatePacket(160, STATE_PRIORITY_IGNORE_FORCE, true);
			}
			break;
	}
}


function onKeyFrameFlag_Gigablade(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Gigablade(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
