
function checkExecutableSkill_Darkstrike(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(158);
	local customData = 0;
	local customData1 = 0;
	if (sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL)) {
		customData = 3;
		customData1 = obj.getZPos();
	} else {
		if (obj.sq_GetState() == 6) {
			customData1 = obj.getZPos();
			customData = 1;
		}
	}

	if (isUse) {
		obj.getVar("Darkstrike").clear_vector();
		obj.getVar("Darkstrike").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 350));
		obj.getVar("Darkstrike").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 350));
		obj.getVar("Darkstrike").clear_obj_vector();
		obj.sq_StopMove();
		obj.getVar("Darkstrike").setBool(0, false);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(customData);
		obj.sq_IntVectPush(customData1);
		obj.sq_AddSetStatePacket(158, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Darkstrike(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Darkstrike(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_PlaySound("R_SW_LIFTSLASH");
			obj.sq_SetCurrentAnimation(410);
			obj.sq_SetCurrentAttackInfo(99);
			local attackRate = obj.sq_GetBonusRateWithPassive(158, -1, 3, getATSwordmanBonus(obj, 1.0, 158));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 1:
			BodyCalldaimus(obj, "darkstrikeattack");
			obj.sq_PlaySound("R_SW_LIFTSLASH");
			if (obj.sq_GetVectorData(datas, 1) < 1) {
				obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
				obj.sq_SetStaticMoveInfo(0, 800, -1000, false);
				sq_SetZVelocity(obj, -400, -600);
			}
			obj.sq_SetCurrentAnimation(407);
			obj.sq_SetCurrentAttackInfo(99);
			local attackRate = obj.sq_GetBonusRateWithPassive(158, -1, 3, getATSwordmanBonus(obj, 1.0, 158));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
		case 2:
			BodyCalldaimus(obj, "darkstrikejump");
			obj.sq_SetCurrentAnimation(409);
			obj.sq_SetCurrentAttackInfo(100);
			local attackRate = obj.sq_GetBonusRateWithPassive(158, -1, 3, getATSwordmanBonus(obj, 1.0, 158));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 3:
			obj.sq_ZStop();
			obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			obj.sq_SetStaticMoveInfo(0, 800, -1000, false);
			BodyCalldaimus(obj, "darkstrikejump");
			obj.sq_SetCurrentAnimation(409);
			obj.sq_SetCurrentAttackInfo(100);
			local attackRate = obj.sq_GetBonusRateWithPassive(158, -1, 3, getATSwordmanBonus(obj, 1.0, 158));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 4:
			obj.sq_StopMove();
			sq_SimpleMoveToNearMovablePos(obj, 400);
			BodyCalldaimus(obj, "darkstrikelanding");
			obj.sq_SetCurrentAnimation(411);
			obj.sq_SetCurrentAttackInfo(100);
			local attackRate = obj.sq_GetBonusRateWithPassive(158, -1, 3, getATSwordmanBonus(obj, 1.0, 158));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			break;
	}
}


function onEndCurrentAni_Darkstrike(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			local Darkstrike_obj = obj.getVar("Darkstrike").get_obj_vector(0);
			if (Darkstrike_obj) {
				obj.sq_StartWrite();
				obj.sq_WriteDword(158);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 1, getATSwordmanBonus(obj, 1.0, 158)));
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 2, getATSwordmanBonus(obj, 1.0, 158)));
				obj.sq_WriteDword(sq_GetLevelData(obj, 158, 0, sq_GetSkillLevel(obj, 158)));
				obj.sq_WriteDword(sq_GetIntData(obj, 158, 3));
				sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Darkstrike_obj.getXPos(), Darkstrike_obj.getYPos(), Darkstrike_obj.getZPos() + Darkstrike_obj.getObjectHeight() / 2);
			} else {
				obj.sq_StartWrite();
				obj.sq_WriteDword(158);
				obj.sq_WriteDword(0);
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 1, getATSwordmanBonus(obj, 1.0, 158)));
				obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 2, getATSwordmanBonus(obj, 1.0, 158)));
				obj.sq_WriteDword(sq_GetLevelData(obj, 158, 0, sq_GetSkillLevel(obj, 158)));
				obj.sq_WriteDword(sq_GetIntData(obj, 158, 3));
				obj.sq_SendCreatePassiveObjectPacket(24383, 0, -80, 0, 70);
			}
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(0);
			obj.sq_AddSetStatePacket(6, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(158, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(158, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			obj.sq_StartWrite();
			obj.sq_WriteDword(158);
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 1, getATSwordmanBonus(obj, 1.0, 158)));
			obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 2, getATSwordmanBonus(obj, 1.0, 158)));
			obj.sq_WriteDword(sq_GetLevelData(obj, 158, 0, sq_GetSkillLevel(obj, 158)));
			obj.sq_WriteDword(sq_GetIntData(obj, 158, 3));
			obj.sq_SendCreatePassiveObjectPacket(24383, 0, -80, 0, 70);
			break;
	}
}


function onAttack_Darkstrike(obj, damager, boundingBox, isStuck) {
	if (!obj || isStuck) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:
			obj.getVar("Darkstrike").clear_obj_vector();
			obj.getVar("Darkstrike").push_obj_vector(damager);
			break;
		case 1:
			obj.getVar("Darkstrike").clear_obj_vector();
			obj.getVar("Darkstrike").push_obj_vector(damager);
			break;
	}
}


function onEnterFrame_Darkstrike(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			if (frameIndex == 4 && obj.isMyControlObject()) {
				sq_SetMyShake(obj, 3, 200);
				sq_flashScreen(obj, 1, 30, 40, 63, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			} else if (frameIndex == 8 && obj.isMyControlObject()) {
				local Darkstrike_obj = obj.getVar("Darkstrike").get_obj_vector(0);
				if (Darkstrike_obj) {
					obj.sq_StartWrite();
					obj.sq_WriteDword(158);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 1, getATSwordmanBonus(obj, 1.0, 158)));
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 2, getATSwordmanBonus(obj, 1.0, 158)));
					obj.sq_WriteDword(sq_GetLevelData(obj, 158, 0, sq_GetSkillLevel(obj, 158)));
					obj.sq_WriteDword(sq_GetIntData(obj, 158, 3));
					sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, Darkstrike_obj.getXPos(), Darkstrike_obj.getYPos(), Darkstrike_obj.getZPos() + Darkstrike_obj.getObjectHeight() / 2);
				} else {
					obj.sq_StartWrite();
					obj.sq_WriteDword(158);
					obj.sq_WriteDword(0);
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 1, getATSwordmanBonus(obj, 1.0, 158)));
					obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(158, -1, 2, getATSwordmanBonus(obj, 1.0, 158)));
					obj.sq_WriteDword(sq_GetLevelData(obj, 158, 0, sq_GetSkillLevel(obj, 158)));
					obj.sq_WriteDword(sq_GetIntData(obj, 158, 3));
					obj.sq_SendCreatePassiveObjectPacket(24383, 0, 180, 0, 70);
				}
			}
			break;
		case 4:

			break;
	}
}


function onEndState_Darkstrike(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Darkstrike(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:
			local currentAni = sq_GetCurrentAnimation(obj);
			local delay = sq_GetDelaySum(currentAni);
			local stateTimer = obj.sq_GetStateTimer();
			local Darkstrike_int = obj.getVar("Darkstrike").get_vector(0);
			local Darkstrike_int1 = obj.getVar("Darkstrike").get_vector(1);
			if (obj.getZPos() < 3 && stateTimer < 300)
				sq_SetZVelocity(obj, 400, -600);
			else if (stateTimer > 300)
				sq_SetZVelocity(obj, -400, -600);
			if (stateTimer > 600) {
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(4);
				obj.sq_AddSetStatePacket(158, STATE_PRIORITY_IGNORE_FORCE, true);
			}

			if (stateTimer > 100) {
				obj.setSkillCommandEnable(158, true);
				local useskill = obj.sq_IsEnterSkill(158);
				if (useskill != -1 && !obj.getVar("Darkstrike").getBool(0)) {
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(1);
					obj.sq_AddSetStatePacket(158, STATE_PRIORITY_IGNORE_FORCE, true);
					obj.getVar("Darkstrike").setBool(0, true);
				}
			}
			break;
	}
}


function onKeyFrameFlag_Darkstrike(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Darkstrike(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
