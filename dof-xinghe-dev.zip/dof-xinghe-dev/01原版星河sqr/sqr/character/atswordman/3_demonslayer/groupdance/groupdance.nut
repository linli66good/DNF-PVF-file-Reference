
function checkExecutableSkill_Groupdance(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(157);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(157, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Groupdance(obj) {
	if (!obj) return false;
	return true;
}



function onSetState_Groupdance(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			BodyCalldaimus(obj, "groupdance");
			obj.sq_SetCurrentAnimation(424);
			obj.getVar("Groupdance").clear_obj_vector();
			local staticData = sq_GetIntData(obj, 157, 0);
			local objectManager = obj.getObjectManager();
			if (!objectManager) break;
			obj.getVar("GroupdanceTarget").clear_obj_vector();
			local customData = 0;
			for (local objectNumber = 0; objectNumber < objectManager.getCollisionObjectNumber(); ++objectNumber) {
				local object = objectManager.getCollisionObject(objectNumber);
				local distFromObj = sq_GetDistanceObject(obj, object, false);
				if (object && object.isObjectType(OBJECTTYPE_ACTIVE) && obj.isEnemy(object) && object.isInDamagableState(obj)) {
					if (distFromObj < staticData && customData < 5) {
						obj.getVar("GroupdanceTarget").push_obj_vector(object);
						local dstPos = sq_GetDistancePos(object.getXPos(), object.getDirection(), 100);
						local yPos = object.getYPos();
						local aniPath = "passiveobject/changqing_atswordman/animation/atgroupdance/appear_dance_fog.ani";
						DarktemplerCreateAniPooledObj(obj, aniPath, true, true, dstPos, yPos, 0, 1.0);
						obj.sq_StartWrite();
						obj.sq_WriteDword(157);
						obj.sq_WriteDword(0);
						obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(157, -1, customData, getATSwordmanBonus(obj, 1.0, 157)));
						obj.sq_WriteDword(sq_GetOppositeDirection(object.getDirection()));
						obj.sq_WriteDword(customData);
						sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, dstPos, yPos, 0);
						customData++;
					}
				}
			}

			local GroupdanceTarget_size = obj.getVar("GroupdanceTarget").get_obj_vector_size();
			if (GroupdanceTarget_size < 1 || GroupdanceTarget_size > 4) break;
			if (customData < 5) {
				for (local objectNumber = 0; objectNumber < 5 - customData; ++objectNumber) {
					local object = obj.getVar("GroupdanceTarget").get_obj_vector(2 % GroupdanceTarget_size);
					if (object) {
						local dstPos = sq_GetDistancePos(object.getXPos(), object.getDirection(), 100);
						local yPos = object.getYPos();
						local aniPath = "passiveobject/changqing_atswordman/animation/atgroupdance/appear_dance_fog.ani";
						DarktemplerCreateAniPooledObj(obj, aniPath, true, true, dstPos, yPos, 0, 1.0);
						obj.sq_StartWrite();
						obj.sq_WriteDword(157);
						obj.sq_WriteDword(0);
						obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(157, -1, customData + objectNumber, getATSwordmanBonus(obj, 1.0, 157)));
						obj.sq_WriteDword(sq_GetOppositeDirection(object.getDirection()));
						obj.sq_WriteDword(customData + objectNumber);
						sq_SendCreatePassiveObjectPacketPos(obj, 24383, 0, dstPos, yPos, 0);
					}
				}
			}

			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Groupdance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Groupdance(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:

			break;
	}
}


function onEnterFrame_Groupdance(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Groupdance(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Groupdance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Groupdance(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Groupdance(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
