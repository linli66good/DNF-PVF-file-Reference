
function checkExecutableSkill_Pikesword(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(151);
	if (isUse) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(151, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_Pikesword(obj) {
	if (!obj) return false;
	if (sq_GetSkillLevel(obj, 163) < 1) {
		local state = obj.sq_GetState();
		if (state == 0 || state == 108 || state == 14)
			return true;
		else
			return false;
	}
	return true;
}



function onSetState_Pikesword(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("SW_PIKESWORD");
			if (sq_GetSkillLevel(obj, 163) < 1) {
				BodyCalldaimus(obj, "pikesword");
				obj.sq_SetCurrentAnimation(430);
			} else {
				BodyCalldaimus(obj, "pikesword_start_body");
				obj.sq_SetCurrentAnimation(433);
			}
			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(151, -1, 0, getATSwordmanBonus(obj, 1.0, 151));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
		case 1:
			if (sq_GetSkillLevel(obj, 163) < 1) {
				BodyCalldaimus(obj, "pikesworddrag");
				obj.sq_SetCurrentAnimation(431);
			} else {
				BodyCalldaimus(obj, "pikesword_end_body");
				obj.sq_SetCurrentAnimation(432);
			}

			obj.sq_SetCurrentAttackInfo(0);
			local attackRate = obj.sq_GetBonusRateWithPassive(151, -1, 1, getATSwordmanBonus(obj, 1.0, 151));
			obj.sq_SetCurrentAttackBonusRate(attackRate);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_Pikesword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(151, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, true);
			break;
	}
}


function onAttack_Pikesword(obj, damager, boundingBox, isStuck) {
	if (!obj) return false;
	local subState = obj.getSkillSubState();
	Calldaimus_onAttack(obj, damager, boundingBox, isStuck);
	switch (subState) {
		case 0:

			break;
		case 1:
			if (sq_IsHoldable(obj, damager) && sq_IsGrabable(obj, damager) && !sq_IsFixture(damager)) {
				local apPath = "character/atswordman/3_demonslayer/pikesword/ap_pikesword.nut";
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, -1, false, apPath, true);
				if (appendage) {
					sq_MoveToAppendageForce(damager, obj, obj, 100, 0, damager.getZPos(), 550, true, appendage, true);
					local apInfo = appendage.getAppendageInfo();
					apInfo.setValidTime(400);
					return;
				}
			}
			break;
	}
}


function onEnterFrame_Pikesword(obj, frameIndex) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onEndState_Pikesword(obj, new_state) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 3:

			break;
		case 4:

			break;
	}
}


function onProc_Pikesword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
}


function onKeyFrameFlag_Pikesword(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 0:

			break;
	}
	return true;
}



function onProcCon_Pikesword(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:

			break;
	}
}
