SUB_DECISIVEBATTLE_STARTSTAY <- 0
SUB_DECISIVEBATTLE_START <- 1
SUB_DECISIVEBATTLE_ATTACK <- 2
SUB_DECISIVEBATTLE_END <- 3
SUB_DECISIVEBATTLE_ENDSTAY <- 4


function checkExecutableSkill_DecisiveBattle(obj)
{
		if (!obj) return false;
		local isUseSkill = obj.sq_IsUseSkill(SKILL_DECISIVEBATTLE);
		if (isUseSkill)
		{
	local RadomSound = sq_getRandom(0,1);
	obj.getVar("Sound").clear_vector();
	obj.getVar("Sound").push_vector(RadomSound);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DECISIVEBATTLE_STARTSTAY);
		obj.sq_AddSetStatePacket(STATE_DECISIVEBATTLE, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_DecisiveBattle(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();

	return true;
}

function onSetState_DecisiveBattle(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();

	local skilllevel = sq_GetSkillLevel(obj, SKILL_DECISIVEBATTLE);
	if(subState == SUB_DECISIVEBATTLE_STARTSTAY)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_DECISIVEBATTLE_STARTSTAY);
		}else if(subState == SUB_DECISIVEBATTLE_START)
		{
		local ani = obj.getVar().GetAnimationMap("DecisiveBattle_Start", "character/gunner/atanimation/decisivebattlestart_body1.ani"); 
		obj.setCurrentAnimation(ani);
		CreatDecisiveBattleBody_Start(obj);
		}else if(subState == SUB_DECISIVEBATTLE_ATTACK)
		{
		local ani = null;
		if(!obj.isMyControlObject())
		{
		ani = obj.getVar().GetAnimationMap("DecisiveBattle_PartyAttack", "character/gunner/atanimation/decisivebattleattackpartyview_body1.ani"); 
		CreatDecisiveBattleBody_PartyAttack(obj);
		}else{
		ani = obj.getVar().GetAnimationMap("DecisiveBattle_Attack", "character/gunner/atanimation/decisivebattleattack_body1.ani"); 
		CreatDecisiveBattleBody_Attack(obj);
		}
		obj.setCurrentAnimation(ani);
		}else if(subState == SUB_DECISIVEBATTLE_END)
		{
		local ani = obj.getVar().GetAnimationMap("DecisiveBattle_End", "character/gunner/atanimation/decisivebattleend_body1.ani"); 
		obj.setCurrentAnimation(ani);
		CreatDecisiveBattleBody_End(obj);
		}else if(subState == SUB_DECISIVEBATTLE_ENDSTAY)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_DECISIVEBATTLE_ENDSTAY);
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 0);
		}

}

function onKeyFrameFlag_DecisiveBattle(obj,flagIndex)
{
	local subState = obj.getSkillSubState();
	local Sounds = obj.getVar("Sound").get_vector(0);
	if(obj.isMyControlObject())
	{
	if(subState == SUB_DECISIVEBATTLE_START)
	{
		if(flagIndex == 0)
		{
		if(Sounds == 0)
		{
		obj.sq_PlaySound("R_FG_DECISIVEBATTLE_01");
		}else{
		obj.sq_PlaySound("FG_DECISIVEBATTLE_01_3");
			}
		}
	return true;
	}
	else if(subState == SUB_DECISIVEBATTLE_ATTACK)
	{
		if(flagIndex == 0) 
		{

		}
		else if(flagIndex == 2)
		{
		sq_SetMyShake(obj,80,5);
		obj.setTimeEvent(0,100,0,true);
		}
		else if(flagIndex == 6)
		{
		sq_SetMyShake(obj,40,10);
		}
		else if(flagIndex == 7)
		{
		obj.sq_PlaySound("DECISIVEBATTLE_EXP");
		sq_SetMyShake(obj,200,15);
		CreateDecisiveBattle_CoverEffect(obj);
		CreateDecisiveBattle_BottomEffect(obj);
		}
		else if(flagIndex == 20)
		{

		}
		else if(flagIndex == 26)
		{
		obj.setTimeEvent(1,100,0,true);
		}
		else if(flagIndex == 29)
		{
	CreateDecisiveBattle_FrontEffect(obj);
	CreateDecisiveBattle_BackEffect(obj);
		}
		else if(flagIndex == 30)
		{
		sq_SetMyShake(obj,1840,6);
		}
		else if(flagIndex == 40)
		{
		if(Sounds == 0)
		{
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT )
		{
		obj.sq_PlaySound("R_FG_DECISIVEBATTLE_02_1_R");
		}else{
		obj.sq_PlaySound("R_FG_DECISIVEBATTLE_02_1_L");
			}
		}else if(Sounds == 1)
			{
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT )
		{
		obj.sq_PlaySound("R_FG_DECISIVEBATTLE_02_2_R");
		}else{
		obj.sq_PlaySound("R_FG_DECISIVEBATTLE_02_2_L");
			}
			}
		}
		else if(flagIndex == 49)
		{
		obj.setTimeEvent(2,100,0,true);
		}
		else if(flagIndex == 75)
		{
			local objectManager = obj.getObjectManager();
		
		if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
		{
			local xPos = objectManager.getFieldXPos(1000, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtGunner_Launcher_Neo(obj, xPos, yPos)
		}
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
		{
			local xPos = objectManager.getFieldXPos(-180, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtGunner_Launcher_Neo(obj, xPos, yPos)
		}

		}
		else if(flagIndex == 79)
		{
		
		}
		else if(flagIndex == 82)
		{
		obj.sq_PlaySound("DECISIVEBATTLE_FINISH");
		}
		else if(flagIndex == 94)
		{
		sq_SetMyShake(obj,320,25);
		}
		else if(flagIndex == 105)
		{
		if(Sounds == 0)
		{
		obj.sq_PlaySound("FG_DECISIVEBATTLE_03_1");
		}else{
		obj.sq_PlaySound("FG_DECISIVEBATTLE_03_2");
			}
		}
		else if(flagIndex == 111)
		{
		obj.setTimeEvent(3,100,0,true);
		}
	return true;
	}else if(SUB_DECISIVEBATTLE_END)
	{
		if(flagIndex == 1)
		{
		CreateDecisiveBattle_PartyEndFrontEffect(obj);
		}
		else if(flagIndex == 2)
		{
		CreateDecisiveBattle_PartyEndCoverEffect(obj);
		}
		else if(flagIndex == 6)
		{
		CreateDecisiveBattle_EndBackEffect(obj);
		}
	return true;
	}
	}else if(SUB_DECISIVEBATTLE_ATTACK && !obj.isMyControlObject())
	{
		if(flagIndex == 2)
		{
		CreateDecisiveBattle_PartyFrontEffect(obj);
		}
	}
	return true;
}



function onTimeEvent_DecisiveBattle(obj, timeEventIndex, timeEventCount)
{
	if (timeEventIndex == 0 && timeEventCount <= 5)
	{
		CreateDecisiveBattle_FirstMultiHit(obj);
	}else if (timeEventIndex == 1 && timeEventCount <= 5)
	{
		CreateDecisiveBattle_FirstMultiHit(obj);
	}
	else if (timeEventIndex == 2 && timeEventCount <= 5)
	{
		CreateDecisiveBattle_SecondMultiHit(obj);
	}
	else if (timeEventIndex == 3 && timeEventCount <= 10)
	{
		CreateDecisiveBattle_ThirdMultiHit(obj);
	}
}

function onProc_DecisiveBattle(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();
	if (subState >= SUB_DECISIVEBATTLE_START && subState <= SUB_DECISIVEBATTLE_END)
	{
	obj.sq_ZStop();
	obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 1000);
	}
	return true;
}


function onEndCurrentAni_DecisiveBattle(obj)
{
	if(!obj) return;
	if(!obj.isMyControlObject())return;
	local subState = obj.getSkillSubState();
	if (subState == SUB_DECISIVEBATTLE_STARTSTAY)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DECISIVEBATTLE_START);
		obj.sq_AddSetStatePacket(STATE_DECISIVEBATTLE, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_DECISIVEBATTLE_START)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DECISIVEBATTLE_ATTACK);
		obj.sq_AddSetStatePacket(STATE_DECISIVEBATTLE, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_DECISIVEBATTLE_ATTACK)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DECISIVEBATTLE_END);
		obj.sq_AddSetStatePacket(STATE_DECISIVEBATTLE, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_DECISIVEBATTLE_END)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DECISIVEBATTLE_ENDSTAY);
		obj.sq_AddSetStatePacket(STATE_DECISIVEBATTLE, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_DECISIVEBATTLE_ENDSTAY)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}
function CreateDecisiveBattle_PartyEndFrontEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdecisivebattle/partyview/decisivebattleendfrontpartyview_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateDecisiveBattle_PartyEndCoverEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdecisivebattle/partyview/decisivebattleendcoverpartyview_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateDecisiveBattle_EndBackEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdecisivebattle/decisivebattleendback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateDecisiveBattle_BottomEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdecisivebattle/decisivebattleattackbottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateDecisiveBattle_BackEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdecisivebattle/decisivebattleattackback_21.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateDecisiveBattle_FrontEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdecisivebattle/decisivebattleattackfront_18.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function CreateDecisiveBattle_CoverEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdecisivebattle/decisivebattleattackcover_33.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function CreatDecisiveBattleBody_Start(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/decisivebattlestart_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDecisiveBattleBody_Attack(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/decisivebattleattack_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDecisiveBattleBody_End(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/decisivebattleend_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDecisiveBattleBody_PartyAttack(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/decisivebattleattackpartyview_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function CreateDecisiveBattle_PartyFrontEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdecisivebattle/partyview/decisivebattleattackfrontpartyview_33.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}



function CreateDecisiveBattle_ExplosionMultiHit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DECISIVEBATTLE , STATE_DECISIVEBATTLE, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/decisivebattle/dummyattackbox.ani", "passiveobject/new_skill/new_atgunner/attackinfo/decisivebattlestart.atk",true,atk,100,0,0,-obj.getZPos());
}
function CreateDecisiveBattle_FirstMultiHit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DECISIVEBATTLE , STATE_DECISIVEBATTLE, 3, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/decisivebattle/dummyattackbox.ani", "passiveobject/new_skill/new_atgunner/attackinfo/decisivebattleboom.atk",true,atk,100,0,0,-obj.getZPos());
}
function CreateDecisiveBattle_SecondMultiHit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DECISIVEBATTLE , STATE_DECISIVEBATTLE, 1, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/decisivebattle/dummyattackbox.ani", "passiveobject/new_skill/new_atgunner/attackinfo/decisivebattleattack.atk",true,atk,100,0,0,-obj.getZPos());
}
function CreateDecisiveBattle_ThirdMultiHit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DECISIVEBATTLE , STATE_DECISIVEBATTLE, 2, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/decisivebattle/dummyattackbox.ani", "passiveobject/new_skill/new_atgunner/attackinfo/decisivebattleend.atk",true,atk,100,0,0,-obj.getZPos());
}

function create_AtGunner_Launcher_Neo(obj, xPos, yPos)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/neo/atgunner_launcher_neo.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	pooledObj.setCurrentPos(xPos ,yPos, 0);
	if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
	{
		pooledObj.setCurrentDirection(ENUM_DIRECTION_RIGHT);
	}
	else if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
	{
		pooledObj.setCurrentDirection(ENUM_DIRECTION_LEFT);
	}
	sq_AddObject(obj, pooledObj, 0, false);
}
