SUB_PHLEGETHON_START		<-0
SUB_PHLEGETHON_LOOP		<-1
SUB_PHLEGETHON_END		<-2


function checkExecutableSkill_Phlegethon(obj)  
{
	local isUseSkill = obj.sq_IsUseSkill(SKILL_PHLEGETHON);

	if (isUseSkill)
	{
		obj.sq_IsEnterSkillLastKeyUnits(SKILL_PHLEGETHON);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_PHLEGETHON_START);
		obj.sq_AddSetStatePacket(STATE_PHLEGETHON, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}

	return false;
}

function checkCommandEnable_Phlegethon(obj)
{
	local state = obj.sq_GetState();

	if (state == STATE_STAND || state == STATE_ATTACK || state == STATE_DASH )
	
	return true;
}





function onSetState_Phlegethon(obj, state, datas, isResetTimer)
{
	
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);

	if (substate == SUB_PHLEGETHON_START)
	{
	obj.sq_SetCurrentAnimation(CUSTOM_ANI_PHLEGETHON_START);
	obj.sq_StopMove();
	}
	else if (substate == SUB_PHLEGETHON_LOOP)
	{
	obj.sq_SetCurrentAnimation(CUSTOM_ANI_PHLEGETHON_LOOP);
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_PHLEGETHON, STATE_PHLEGETHON, 0, 1.0);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(11);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0, 1, 0);
		obj.getVar("Once").clear_vector();
		obj.getVar("Once").push_vector(0);
		obj.setTimeEvent(0,500,0,true);
	}
	else if (substate == SUB_PHLEGETHON_END)
	{
	obj.sq_SetCurrentAnimation(CUSTOM_ANI_PHLEGETHON_END);
	}
		obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}

function onEndCurrentAni_Phlegethon(obj)
{
	local substate = obj.getSkillSubState();

	if (substate == SUB_PHLEGETHON_START)
	{
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_PHLEGETHON, STATE_PHLEGETHON, 0, 1.0);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(10);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0, 1, 0);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_PHLEGETHON_LOOP);
		obj.sq_AddSetStatePacket(STATE_PHLEGETHON, STATE_PRIORITY_USER, true);
	}else if (substate == SUB_PHLEGETHON_END)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}

}

function onKeyFrameFlag_Phlegethon(obj,flagIndex)
{
	local subState = obj.getSkillSubState();
	if (subState == SUB_PHLEGETHON_LOOP)
	{
	if(flagIndex >= 0 && flagIndex <= 10)
		{
		sq_SetMyShake(obj,3,20);
		}
	return true;
	}
}




function onProcCon_Phlegethon(obj)
{
	local substate = obj.getSkillSubState();

	if (substate == SUB_PHLEGETHON_LOOP)
	{
		local bDownKey = obj.isDownSkillLastKey();
		local stateTimer = obj.sq_GetStateTimer();
		local grabMaxTime = sq_GetIntData(obj,SKILL_PHLEGETHON,0); 
		if(stateTimer >= grabMaxTime)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(SUB_PHLEGETHON_END);
			obj.sq_AddSetStatePacket(STATE_PHLEGETHON, STATE_PRIORITY_USER, true);
			return;
		}
		local x = obj.getXPos();
		local x1 = x;
		local y = obj.getYPos();
		local y1 = y;
		local z = obj.getZPos();
		local xSpeed = 2;
		local ySpeed = 2;
		if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL)) {
		x1 = x1 + xSpeed;
		}
		if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL)) {
		x1 = x1 - xSpeed;
		}
		if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL)) {
		y1 = y1 - ySpeed;
		}
		if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) {
		y1 = y1 + ySpeed;
		}
    
		sq_MoveToNearMovablePos(obj, x1, y1, z, x, y, z, 1, 1, 1);
		}
}

function onTimeEvent_Phlegethon(obj, timeEventIndex, timeEventCount)
{
	local substate = obj.getSkillSubState();

	if (timeEventIndex == 0)
		{
		obj.sq_StartWrite();
		obj.sq_WriteDword(0);
		obj.sq_WriteDword(100);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 310, 0, -30);
		}
}

function CreatePhlegethonBoostStart(obj)
{

	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atphlegethon/booststartback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 0);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(posX,obj.getYPos(), obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_moveWithParent(obj, pooledObj);
	sq_AddObject(obj,pooledObj,2,false);	
}
function CreatePhlegethonBoostLoop(obj)
{

	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atphlegethon/boostloopback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 0);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(posX,obj.getYPos(), obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_moveWithParent(obj, pooledObj);
	sq_AddObject(obj,pooledObj,2,false);	

}
function CreatePhlegethonBoostEnd(obj)
{

	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atphlegethon/boostendback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 0);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(posX,obj.getYPos(), obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_moveWithParent(obj, pooledObj);
	sq_AddObject(obj,pooledObj,2,false);	
}
