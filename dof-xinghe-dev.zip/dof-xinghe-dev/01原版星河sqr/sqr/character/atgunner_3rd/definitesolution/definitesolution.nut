SUB_DEFINITESOLUTION_START <- 0
SUB_DEFINITESOLUTION_FLY <- 1
SUB_DEFINITESOLUTION_ATTACK1 <- 2
SUB_DEFINITESOLUTION_ATTACK2 <- 3


function checkExecutableSkill_DefiniteSolution(obj)
{
		if (!obj) return false;
		local isUseSkill = obj.sq_IsUseSkill(SKILL_DEFINITESOLUTION);
		if (isUseSkill)
		{
	local RadomSound = sq_getRandom(0,1);
	obj.getVar("Sound").clear_vector();
	obj.getVar("Sound").push_vector(RadomSound);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DEFINITESOLUTION_START);
		obj.sq_AddSetStatePacket(STATE_DEFINITESOLUTION, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_DefiniteSolution(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();

	return true;
}

function onSetState_DefiniteSolution(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();
	obj.sq_ZStop();
	obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 800);
	local ani = null;

	local skilllevel = sq_GetSkillLevel(obj, SKILL_DEFINITESOLUTION);
	if(subState == SUB_DEFINITESOLUTION_START)
		{
		if(!obj.isMyControlObject())
		{
		ani = obj.getVar().GetAnimationMap("DefiniteSolution_Start_Party", "character/gunner/atanimation/definitesolutionpartybodya_body1.ani"); 
		CreatDefiniteSolution_AttackA_Party(obj);
		}else{
		ani = obj.getVar().GetAnimationMap("DefiniteSolution_Start", "character/gunner/atanimation/definitesolutionstart_body1.ani"); 
		CreatDefiniteSolution_Start(obj);
		CreatDefiniteSolution_StartCover(obj);
		CreatDefiniteSolution_StartBackGround(obj);
			}
		obj.setCurrentAnimation(ani);
		}else if(subState == SUB_DEFINITESOLUTION_FLY)
		{
		if(!obj.isMyControlObject())
		{
		ani = obj.getVar().GetAnimationMap("DefiniteSolution_AttackB_Party", "character/gunner/atanimation/definitesolutionpartybodyb_body1.ani"); 
		CreatDefiniteSolution_AttackB_Party(obj);
		}else{
		ani = obj.getVar().GetAnimationMap("DefiniteSolution_DashFly", "character/gunner/atanimation/definitesolutionskydash_body1.ani"); 
		CreatDefiniteSolution_SkyFly(obj);
			}
		obj.setCurrentAnimation(ani);
		}else if(subState == SUB_DEFINITESOLUTION_ATTACK1)
		{
		if(!obj.isMyControlObject())
		{
		ani = obj.getVar().GetAnimationMap("DefiniteSolution_Attack1_Party", "character/gunner/atanimation/definitesolutionpartybodyc_body1.ani"); 
		CreatDefiniteSolution_AttackC_Party(obj);
		}else{
		ani = obj.getVar().GetAnimationMap("DefiniteSolution_Attack1", "character/gunner/atanimation/definitesolutionattacka_body1.ani"); 
		CreatDefiniteSolution_AttackA(obj);
			}
		obj.setCurrentAnimation(ani);
		}else if(subState == SUB_DEFINITESOLUTION_ATTACK2)
		{
		if(!obj.isMyControlObject())
		{
		ani = obj.getVar().GetAnimationMap("DefiniteSolution_Attack2_Party", "character/gunner/atanimation/definitesolutionpartybodyd_body1.ani"); 
		CreatDefiniteSolution_AttackD_Party(obj);
		}else{
		ani = obj.getVar().GetAnimationMap("DefiniteSolution_Attack2", "character/gunner/atanimation/definitesolutionattackb_body1.ani"); 
		CreatDefiniteSolution_AttackB(obj);
			}
		obj.setCurrentAnimation(ani);
		}

}

function onKeyFrameFlag_DefiniteSolution(obj,flagIndex)
{
	local subState = obj.getSkillSubState();
	local Sounds = obj.getVar("Sound").get_vector(0);
	if(obj.isMyControlObject())
	{

	if (subState == SUB_DEFINITESOLUTION_START)
	{
		if(flagIndex == 0)
		{
		sq_SetMyShake(obj,13,140);
		obj.sq_PlaySound("NEO_D_SOLU_START");
		if(Sounds == 0)
		{
		obj.sq_PlaySound("R_FG_NEO_D_SOLU_A_01");
		}else{
		obj.sq_PlaySound("FG_NEO_D_SOLU_B_01");
			}
		}else if(flagIndex == 1)
		{
		local objectManager = obj.getObjectManager();
		
		if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
		{
			local xPos = objectManager.getFieldXPos(950, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtGunner_SpitFire_Neo(obj, xPos, yPos)
		}
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
		{
			local xPos = objectManager.getFieldXPos(-100, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtGunner_SpitFire_Neo(obj, xPos, yPos)
		}
			
		}
	}else if (subState == SUB_DEFINITESOLUTION_FLY)
	{
		if(flagIndex == 14)
		{
		sq_SetMyShake(obj,7,60);
		}
	}else if (subState == SUB_DEFINITESOLUTION_ATTACK1)
	{
		if(flagIndex == 0)
		{
		CreatDefiniteSolution_FrontEffect(obj);
		CreatDefiniteSolution_BoomEffect(obj);
		CreatDefiniteSolution_BoomA(obj);
		CreatDefiniteSolution_Flash(obj);
		}
		else if(flagIndex == 1)
		{
		obj.setTimeEvent(0,200,0,true);

		}

		else if(flagIndex == 4)
		{
		sq_SetMyShake(obj,8,670);
		}
		else if(flagIndex == 12)
		{
		sq_SetMyShake(obj,8,180);
		}else if(flagIndex == 22)
		{
		if(Sounds == 0)
		{
		obj.sq_PlaySound("R_FG_NEO_D_SOLU_A_02");
		}else{
		obj.sq_PlaySound("FG_NEO_D_SOLU_B_02");
			}
		}else if(flagIndex == 28)
		{
		sq_SetMyShake(obj,12,200);
		}else if(flagIndex == 33)
		{
		}else if(flagIndex == 42)
		{
		sq_SetMyShake(obj,6,250);
		}else if(flagIndex == 57)
		{
		}
	}else if (subState == SUB_DEFINITESOLUTION_ATTACK2)
	{
		if(flagIndex == 16)
		{
		if(Sounds == 1)
		obj.sq_PlaySound("FG_NEO_D_SOLU_B_03");
		}else if(flagIndex == 20)
		{
		sq_SetMyShake(obj,20,600);
		obj.sq_PlaySound("NEO_D_SOLU_BOMB_EXP");
		if(Sounds == 0)
		obj.sq_PlaySound("R_FG_NEO_D_SOLU_A_03");
		obj.setTimeEvent(0,100,0,true);

		}
		else if(flagIndex == 25)
		{
		CreatDefiniteSolution_EndAeffect(obj);
		CreatDefiniteSolution_EndBeffect(obj);
		}
	}

	}
	return true;
}



function onTimeEvent_DefiniteSolution(obj, timeEventIndex, timeEventCount)
{
	if (timeEventIndex == 0 && timeEventCount <= obj.sq_GetIntData(SKILL_DEFINITESOLUTION, 0))
	{
		CreatDefiniteSolution_FirstAttack(obj);
	}else if (timeEventIndex == 1 && timeEventCount <= obj.sq_GetIntData(SKILL_DEFINITESOLUTION, 2))
	{
		CreatDefiniteSolution_FinishAttack(obj);
	}
}

function onProc_DefiniteSolution(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();
	local CutSenseObj = obj.getVar("CutSenseObj").get_obj_vector(0);
	if (subState >= SUB_DEFINITESOLUTION_START && subState <= SUB_DEFINITESOLUTION_ATTACK2)
	{
	sq_ChangeDrawLayer(CutSenseObj, ENUM_DRAWLAYER_COVER);
	}
	return true;
}


function onEndCurrentAni_DefiniteSolution(obj)
{
	if(!obj) return;
	if(!obj.isMyControlObject())return;
	local subState = obj.getSkillSubState();
	if (subState == SUB_DEFINITESOLUTION_START)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DEFINITESOLUTION_FLY);
		obj.sq_AddSetStatePacket(STATE_DEFINITESOLUTION, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_DEFINITESOLUTION_FLY)
	{
		CreatDefiniteSolution_BackGround(obj);
		CreatDefiniteSolution_AttackBBottom(obj);
		CreatDefiniteSolution_AttackBeffect(obj);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DEFINITESOLUTION_ATTACK1);
		obj.sq_AddSetStatePacket(STATE_DEFINITESOLUTION, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_DEFINITESOLUTION_ATTACK1)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_DEFINITESOLUTION_ATTACK2);
		obj.sq_AddSetStatePacket(STATE_DEFINITESOLUTION, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_DEFINITESOLUTION_ATTACK2)
	{
	obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 0);
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


function CreatDefiniteSolution_BackGround(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionattackbackground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(500, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function CreatDefiniteSolution_AttackBBottom(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionattackbottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(450, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(500, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_AttackBeffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionattackbeffect_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_EndAeffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionendeffecta_11.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CLOSEBACK);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_EndBeffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionendeffectb_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CLOSEBACK);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_StartCover(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionstartcover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_StartBackGround(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionstartbackground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CLOSEBACK);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_FrontEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionattackaeffect_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 6, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_BoomEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionattackaeffect_bomb_27.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 6, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_BoomA(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionattackaboom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 6, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_Flash(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atdefinitesolution/definitesolutionattackaeffect_flash_36.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 6, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function CreatDefiniteSolution_Start(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/definitesolutionstart_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_SkyFly(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/definitesolutionskydash_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_AttackA(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/definitesolutionattacka_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_AttackB(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/definitesolutionattackb_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function CreatDefiniteSolution_AttackA_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/definitesolutionpartybodya_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_AttackB_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/definitesolutionpartybodyb_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_AttackC_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/definitesolutionpartybodyc_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatDefiniteSolution_AttackD_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/definitesolutionpartybodyd_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function CreatDefiniteSolution_FirstAttack(obj)
{
	local atk = obj.sq_GetPowerWithPassive(SKILL_DEFINITESOLUTION , STATE_DEFINITESOLUTION, 0, -1, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atdefinitesolution/atdefinitesolutionfirstmultihit.ani", "passiveobject/new_skill/new_atgunner/attackinfo/atdefinitesolutionfirstmultihit.atk",false,atk,100,0,0,-obj.getZPos());
}
function CreatDefiniteSolution_FinishAttack(obj)
{
	local atk = obj.sq_GetPowerWithPassive(SKILL_DEFINITESOLUTION , STATE_DEFINITESOLUTION, 1, -1, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atdefinitesolution/atdefinitesolutionfinishmultihit.ani", "passiveobject/new_skill/new_atgunner/attackinfo/atdefinitesolutionfinishmultihit.atk",false,atk,100,0,0,-obj.getZPos());
}

function create_AtGunner_SpitFire_Neo(obj, xPos, yPos)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/neo/atgunner_spitfire_neo.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	pooledObj.setCurrentPos(xPos ,yPos, 0);
	if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
	{	
		pooledObj.setCurrentDirection(ENUM_DIRECTION_RIGHT);
	}
	else if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
	{
		pooledObj.setCurrentDirection(ENUM_DIRECTION_LEFT);
	}
	sq_AddObject(obj, pooledObj, 0, false);
}
