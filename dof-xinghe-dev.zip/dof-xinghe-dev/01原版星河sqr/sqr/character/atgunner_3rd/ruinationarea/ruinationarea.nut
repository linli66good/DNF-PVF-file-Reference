SUB_RUINATIONAREA1_BODY <- 0
SUB_RUINATIONAREA2_BODY <- 1
SUB_RUINATIONAREA3_BODY <- 2
SUB_RUINATIONAREA4_BODY <- 3
SUB_RUINATIONAREA5_BODY <- 4
SUB_RUINATIONAREA6_BODY <- 5

function checkExecutableSkill_RuinationArea(obj)
{
		if (!obj) return false;
		local isUseSkill = obj.sq_IsUseSkill(SKILL_RUINATIONAREA);
		if (isUseSkill)
		{
obj.getVar("Anispeed").clear_vector();
obj.getVar("Anispeed").push_vector(100);
obj.getVar("Anispeed").push_vector(obj.sq_GetIntData(SKILL_RUINATIONAREA,5));
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_RUINATIONAREA1_BODY);
		obj.sq_AddSetStatePacket(STATE_RUINATIONAREA, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_RuinationArea(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();

	return true;
}

function onSetState_RuinationArea(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();

	local skilllevel = sq_GetSkillLevel(obj, SKILL_RUINATIONAREA);
	if(subState == SUB_RUINATIONAREA1_BODY)
		{

			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RUINATIONAREA1_BODY);
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_RUINATIONAREA, STATE_RUINATIONAREA, 0, 1.03);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(3);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0, 1, 0);
		}else if(subState == SUB_RUINATIONAREA2_BODY)
		{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RUINATIONAREA2_BODY);
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_RUINATIONAREA, STATE_RUINATIONAREA, 0, 1.06);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(4);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0, 1, 0);
		}else if(subState == SUB_RUINATIONAREA3_BODY)
		{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RUINATIONAREA1_BODY);
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_RUINATIONAREA, STATE_RUINATIONAREA, 0, 1.09);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(3);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0, 1, 0);
		}else if(subState == SUB_RUINATIONAREA4_BODY)
		{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RUINATIONAREA2_BODY);
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_RUINATIONAREA, STATE_RUINATIONAREA, 0, 1.12);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(4);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0, 1, 0);
		}else if(subState == SUB_RUINATIONAREA5_BODY)
		{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RUINATIONAREA3_BODY);
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_RUINATIONAREA, STATE_RUINATIONAREA, 0, 1.15);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(5);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0, 1, 0);
		}else if(subState == SUB_RUINATIONAREA6_BODY)
		{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RUINATIONAREA4_BODY);
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_RUINATIONAREA, STATE_RUINATIONAREA, 0, 1.0);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(6);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0, 1, 0);
		}

}

function onKeyFrameFlag_RuinationArea(obj,flagIndex)
{
	local subState = obj.getSkillSubState();
	if(obj.isMyControlObject())
	{
	if(subState == SUB_RUINATIONAREA1_BODY)
		{
		if ( flagIndex == 0 )
		{
		obj.sq_PlaySound("RUINATION_AREA_GUNBLADE_01");
		sq_SetMyShake(obj,7,100);
		sq_flashScreen(obj, 60, 0, 60, 10, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
	return true;
		}
	else if(subState == SUB_RUINATIONAREA2_BODY)
		{
		if ( flagIndex == 0 )
		{
		obj.sq_PlaySound("RUINATION_AREA_GUNBLADE_02");
		sq_SetMyShake(obj,1,100);
		sq_flashScreen(obj, 40, 0, 40, 10, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
	return true;
		}
	else if(subState == SUB_RUINATIONAREA3_BODY)
		{
		if ( flagIndex == 0 )
		{
		obj.sq_PlaySound("RUINATION_AREA_GUNBLADE_03");
		sq_SetMyShake(obj,7,100);
		sq_flashScreen(obj, 60, 0, 60, 10, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
	return true;
		}
else if(subState == SUB_RUINATIONAREA4_BODY)
		{
		if ( flagIndex == 0 )
		{
		obj.sq_PlaySound("RUINATION_AREA_GUNBLADE_02");
		sq_SetMyShake(obj,1,100);
		sq_flashScreen(obj, 40, 0, 40, 10, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
	return true;
		}
	else if(subState == SUB_RUINATIONAREA5_BODY)
		{
		if ( flagIndex == 0 )
		{
		obj.sq_PlaySound("RUINATION_AREA_GUNBLADE_03");
		sq_SetMyShake(obj,4,100);
		sq_flashScreen(obj, 50, 0, 50, 10, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
	return true;
		}
	else if(subState == SUB_RUINATIONAREA6_BODY)
		{
		if ( flagIndex == 0 )
		{
		obj.sq_PlaySound("R_FG_RUINATION_AREA_02");
		obj.sq_PlaySound("RUINATION_AREA_EXP");
		sq_SetMyShake(obj,15,400);
		sq_flashScreen(obj, 0, 300, 500, 255, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
	return true;
		}
	}
}

function onProc_RuinationArea(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();
	if(subState > SUB_RUINATIONAREA1_BODY)
	{
	obj.setSkillCommandEnable(SKILL_RUINATIONAREA,true);
	local IsEnterSkill = obj.sq_IsEnterSkill(SKILL_RUINATIONAREA);
	sq_SetKeyxEnable(obj, E_ATTACK_COMMAND, true); 
	local IsEnterCommand = sq_IsEnterCommand(obj, E_ATTACK_COMMAND);
	if(IsEnterSkill == -1 && !IsEnterCommand) return;
	local SpeedRate = obj.getVar("Anispeed").get_vector(0) + obj.getVar("Anispeed").get_vector(1);
	local pAni = sq_GetCurrentAnimation(obj);
	pAni.setSpeedRate(SpeedRate.tofloat());
	obj.getVar("Anispeed").set_vector(0,SpeedRate);
	}

}


function onEndCurrentAni_RuinationArea(obj)
{

	if(!obj) return;
	if(!obj.isMyControlObject())return;
	local subState = obj.getSkillSubState();
	if (subState == SUB_RUINATIONAREA1_BODY)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_RUINATIONAREA2_BODY);
		obj.sq_AddSetStatePacket(STATE_RUINATIONAREA, STATE_PRIORITY_IGNORE_FORCE, true);

	}else if (subState == SUB_RUINATIONAREA2_BODY)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_RUINATIONAREA3_BODY);
		obj.sq_AddSetStatePacket(STATE_RUINATIONAREA, STATE_PRIORITY_IGNORE_FORCE, true);

	}else if (subState == SUB_RUINATIONAREA3_BODY)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_RUINATIONAREA4_BODY);
		obj.sq_AddSetStatePacket(STATE_RUINATIONAREA, STATE_PRIORITY_IGNORE_FORCE, true);

	}else if (subState == SUB_RUINATIONAREA4_BODY)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_RUINATIONAREA5_BODY);
		obj.sq_AddSetStatePacket(STATE_RUINATIONAREA, STATE_PRIORITY_IGNORE_FORCE, true);

	}else if (subState == SUB_RUINATIONAREA5_BODY)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_RUINATIONAREA6_BODY);
		obj.sq_AddSetStatePacket(STATE_RUINATIONAREA, STATE_PRIORITY_IGNORE_FORCE, true);

	}else if (subState == SUB_RUINATIONAREA6_BODY)
	{
		
		
		
		
		
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}
