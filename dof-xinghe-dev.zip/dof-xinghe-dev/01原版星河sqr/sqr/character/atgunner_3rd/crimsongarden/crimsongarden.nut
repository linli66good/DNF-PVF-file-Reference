SUB_CRIMSONGARDEN_START <- 0
SUB_CRIMSONGARDEN_1 <- 1
SUB_CRIMSONGARDEN_2 <- 2
SUB_CRIMSONGARDEN_3 <- 3
SUB_CRIMSONGARDEN_4 <- 4
SUB_CRIMSONGARDEN_END <- 5

function checkExecutableSkill_CrimsonGarden(obj)
{
		if (!obj) return false;
		local isUseSkill = obj.sq_IsUseSkill(SKILL_CRIMSONGARDEN);
		if (isUseSkill)
		{
	local RadomSound = sq_getRandom(0,1);
	obj.getVar("Sound").clear_vector();
	obj.getVar("Sound").push_vector(RadomSound);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_CRIMSONGARDEN_START);
		obj.sq_AddSetStatePacket(STATE_CRIMSONGARDEN, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_CrimsonGarden(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();

	return true;
}

function onSetState_CrimsonGarden(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();
	obj.sq_ZStop();
	obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 800);

	local skilllevel = sq_GetSkillLevel(obj, SKILL_CRIMSONGARDEN);
	if(subState == SUB_CRIMSONGARDEN_START)
		{
	if(!obj.isMyControlObject())
	{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_CRIMSONGARDENPARTY_START);
	CreatCrimsonGardenStrartBack_Party(obj);
	CreatCrimsonGardenStrartFront_Party(obj);
	}else{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_CRIMSONGARDEN_START);
	CreatCrimsonGardenStrartBack(obj);
	CreatCrimsonGardenStrartFront(obj);
	CreatCrimsonGardenStrartBackGround(obj);
	CreatCrimsonGardenStrartCover(obj);
			}
		}else if(subState == SUB_CRIMSONGARDEN_1)
		{
		local ani = obj.getVar().GetAnimationMap("CrimsonGarden_Attack1", "character/gunner/atanimation/atcrimsongardenscene01_body1.ani"); 
		obj.setCurrentAnimation(ani);
	if(!obj.isMyControlObject())
	{
	CreatCrimsonGardenBodyParty_Attack1(obj);
	}else{
	CreatCrimsonGardenBody_Attack1(obj);
	CreatCrimsonGardenOneBack(obj);
	CreatCrimsonGardenOneFront(obj);
	CreatCrimsonGardenOneBackGround(obj);
	CreatCrimsonGardenOneCover(obj);
		}
		}else if(subState == SUB_CRIMSONGARDEN_2)
		{
		local ani = obj.getVar().GetAnimationMap("CrimsonGarden_Attack2", "character/gunner/atanimation/atcrimsongardenscene02_body1.ani"); 
		obj.setCurrentAnimation(ani);
	if(!obj.isMyControlObject())
	{
	CreatCrimsonGardenBodyParty_Attack2(obj);
	CreatCrimsonGardenTwoBack_Party(obj);
	CreatCrimsonGardenTwoFront_Party(obj);
	}else{
	CreatCrimsonGardenBody_Attack2(obj);
	CreatCrimsonGardenTwoBack(obj);
	CreatCrimsonGardenTwoFront(obj);
	CreatCrimsonGardenTwoBackGround(obj);
	CreatCrimsonGardenTwoCover(obj);
		}
		}else if(subState == SUB_CRIMSONGARDEN_3)
		{
		local ani = obj.getVar().GetAnimationMap("CrimsonGarden_Attack3", "character/gunner/atanimation/atcrimsongardenscene03_body1.ani"); 
		obj.setCurrentAnimation(ani);
	if(!obj.isMyControlObject())
	{
	CreatCrimsonGardenBodyParty_Attack3(obj);
	CreatCrimsonGardenThreeFront_Party(obj);
	}else{
	CreatCrimsonGardenBody_Attack3(obj);
	CreatCrimsonGardenThreeBack(obj);
	CreatCrimsonGardenThreeFront(obj);
	CreatCrimsonGardenThreeBackGround(obj);
	CreatCrimsonGardenThreeCover(obj);
		}
		}else if(subState == SUB_CRIMSONGARDEN_4)
		{
		local ani = obj.getVar().GetAnimationMap("CrimsonGarden_Attack4", "character/gunner/atanimation/atcrimsongardenscene04_body1.ani"); 
		obj.setCurrentAnimation(ani);
	if(!obj.isMyControlObject())
	{
	CreatCrimsonGardenBodyParty_Attack4(obj);
	CreatCrimsonGardenFourFront_Party(obj);
	}else{
	CreatCrimsonGardenBody_Attack4(obj);
	CreatCrimsonGardenFourBack(obj);
	CreatCrimsonGardenFourFront(obj);
	CreatCrimsonGardenFourBackGround(obj);
	CreatCrimsonGardenFourCover(obj);
		}
		}else if(subState == SUB_CRIMSONGARDEN_END)
		{
			
	obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 0);
	CreatCrimsonGardenEnd(obj);
		}

}

function onKeyFrameFlag_CrimsonGarden(obj,flagIndex)
{
	local subState = obj.getSkillSubState();
	local Sounds = obj.getVar("Sound").get_vector(0);
	if(obj.isMyControlObject())
	{
	if (subState == SUB_CRIMSONGARDEN_START)
	{
		if ( flagIndex == 0 )
		{
		if(Sounds == 0)
		{
		obj.sq_PlaySound("FG_CRIMSON_GARDEN_01_B");
		}else{
		obj.sq_PlaySound("FG_CRIMSON_GARDEN_01_C");
			}
		sq_flashScreen(obj, 0, 400, 0, 255, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
		else if ( flagIndex == 3 )
		{
		local objectManager = obj.getObjectManager();
		
		if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
		{
			local xPos = objectManager.getFieldXPos(950, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtGunner_Ranger_Neo(obj, xPos, yPos)
		}
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
		{
			local xPos = objectManager.getFieldXPos(-100, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtGunner_Ranger_Neo(obj, xPos, yPos)
		}
			
		}
	return true;
	}
	else if (subState == SUB_CRIMSONGARDEN_1)
	{
	if(flagIndex == 2)
	{
		CreateCrimsonGardenCreate_Chain(obj);
		sq_SetMyShake(obj,5,300);
	}else if(flagIndex == 7)
	{
		sq_SetMyShake(obj,30,30);
	}
	else if(flagIndex == 21)
	{
	if(Sounds == 0)
		obj.sq_PlaySound("FG_CRIMSON_GARDEN_01_A");
	}
	return true;
	}
	else if (subState == SUB_CRIMSONGARDEN_2)
	{
	if(flagIndex == 1)
	{
		CreateCrimsonGardenPull_Gunblader(obj);
		sq_SetMyShake(obj,15,20);
	}
	else if(flagIndex == 3)
	{
		sq_SetMyShake(obj,10,20);
	}
	else if(flagIndex == 5)
	{
		sq_SetMyShake(obj,10,20);
	}
	else if(flagIndex == 7)
	{
		sq_SetMyShake(obj,10,20);
	}
	else if(flagIndex == 8)
	{
		sq_SetMyShake(obj,50,10);
		sq_flashScreen(obj, 0, 30, 10, 110, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		CreateCrimsonGardenPull_Gunblader(obj);
	}
	else if(flagIndex == 10)
	{
		sq_SetMyShake(obj,30,2);
	}
	else if(flagIndex == 11)
	{
		sq_SetMyShake(obj,10,2);
	}
	else if(flagIndex == 12)
	{
		sq_SetMyShake(obj,20,1);
	}
	else if(flagIndex == 14)
	{
		sq_SetMyShake(obj,10,20);
	}
	else if(flagIndex == 15)
	{
		sq_SetMyShake(obj,60,2);
	}
	return true;
	}
	else if (subState == SUB_CRIMSONGARDEN_3)
	{
	if(flagIndex == 5)
	{
		CreateCrimsonGardenPull_Gunblader(obj);
		sq_SetMyShake(obj,30,20);
		sq_flashScreen(obj, 0, 30, 10, 70, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
	}
	else if(flagIndex == 11)
	{
		obj.setTimeEvent(0,100,0,true);
		sq_SetMyShake(obj,40,10);
		sq_flashScreen(obj, 0, 30, 10, 120, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
	}
	else if(flagIndex == 13)
	{
		sq_SetMyShake(obj,60,3);
	}
	else if(flagIndex == 18)
	{
		sq_SetMyShake(obj,50,3);
		sq_flashScreen(obj, 0, 30, 10, 90, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
	}
	return true;
	}
	else if (subState == SUB_CRIMSONGARDEN_4)
	{
	if(flagIndex == 0)
	{
		sq_SetMyShake(obj,40,2);
	}
	else if(flagIndex == 14)
	{
	if(Sounds == 0)
		obj.sq_PlaySound("FG_CRIMSON_GARDEN_02_A");
		sq_flashScreen(obj, 60, 60, 0, 50, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
	}
	else if(flagIndex == 16)
	{
		sq_SetMyShake(obj,40,40);
		obj.stopTimeEvent(0);
	}
	else if(flagIndex == 18)
	{
	if(Sounds == 1)
		obj.sq_PlaySound("FG_CRIMSON_GARDEN_02_C");
	}
	else if(flagIndex == 21)
	{
		sq_SetMyShake(obj,40,7);
		CreateCrimsonGardenChain_Crash(obj);
	}
	return true;
	}

	}
}



function onTimeEvent_CrimsonGarden(obj, timeEventIndex, timeEventCount)
{
	if (timeEventIndex == 0)
	{
		CreateCrimsonGardenSpin_MultiHit(obj);
	}else if (timeEventIndex == 1)
	{
	}
}

function onProc_CrimsonGarden(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();
}


function onEndCurrentAni_CrimsonGarden(obj)
{
	if(!obj) return;
	if(!obj.isMyControlObject()) return;
	local subState = obj.getSkillSubState();
	if (subState == SUB_CRIMSONGARDEN_START)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_CRIMSONGARDEN_1);
		obj.sq_AddSetStatePacket(STATE_CRIMSONGARDEN, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_CRIMSONGARDEN_1)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_CRIMSONGARDEN_2);
		obj.sq_AddSetStatePacket(STATE_CRIMSONGARDEN, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_CRIMSONGARDEN_2)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_CRIMSONGARDEN_3);
		obj.sq_AddSetStatePacket(STATE_CRIMSONGARDEN, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_CRIMSONGARDEN_3)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_CRIMSONGARDEN_4);
		obj.sq_AddSetStatePacket(STATE_CRIMSONGARDEN, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_CRIMSONGARDEN_4)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_CRIMSONGARDEN_END);
		obj.sq_AddSetStatePacket(STATE_CRIMSONGARDEN, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_CRIMSONGARDEN_END)
	{
		obj.sq_IntVectClear();
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, true);
	}
}

function CreatCrimsonGardenStrartBack(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenstartback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenStrartBackGround(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenstartbackground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenStrartFront(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenstartfront_02.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenStrartCover(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenstartcover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenOneBack(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene01back_09.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenOneBackGround(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene01background_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenOneFront(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene01front_03.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenOneCover(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene01cover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}


function CreatCrimsonGardenTwoBack(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene02back_31.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenTwoBackGround(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene02background_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenTwoFront(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene02front_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenTwoCover(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene02cover_85.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}


function CreatCrimsonGardenThreeBack(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene03back_02.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenThreeBackGround(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene03background_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenThreeFront(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene03front_14.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenThreeCover(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene03cover_45.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}


function CreatCrimsonGardenFourBack(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene04back_02.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenFourBackGround(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene04background_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenFourFront(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene04front_02.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenFourCover(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenscene04cover_61.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}



function CreatCrimsonGardenEnd(obj)
{
	obj.sq_SetCurrentAnimation(143);
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/atcrimsongardenend_background00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}


function CreatCrimsonGardenStrartBack_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/party/atcrimsongardenstartbackparty_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function CreatCrimsonGardenStrartFront_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/party/atcrimsongardenstartfrontparty_06.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}



function CreatCrimsonGardenTwoBack_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/party/atcrimsongardenscene02partyback_07.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}

function CreatCrimsonGardenTwoFront_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/party/atcrimsongardenscene02partyfront_58.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}


function CreatCrimsonGardenThreeFront_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/party/atcrimsongardenscene03partyfront_36.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}



function CreatCrimsonGardenFourFront_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atcrimsongarden/party/atcrimsongardenscene04partyfront_32.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}


function CreatCrimsonGardenBody_Attack1(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/atcrimsongardenscene01_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}
function CreatCrimsonGardenBody_Attack2(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/atcrimsongardenscene02_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}
function CreatCrimsonGardenBody_Attack3(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/atcrimsongardenscene03_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}
function CreatCrimsonGardenBody_Attack4(obj)
{

	local ani = sq_CreateAnimation("","character/gunner/atanimation/atcrimsongardenscene04_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}


function CreatCrimsonGardenBodyParty_Attack1(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/atcrimsongardenscene01party_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatCrimsonGardenBodyParty_Attack2(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/atcrimsongardenscene02party_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}
function CreatCrimsonGardenBodyParty_Attack3(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/atcrimsongardenscene03party_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}
function CreatCrimsonGardenBodyParty_Attack4(obj)
{

	local ani = sq_CreateAnimation("","character/gunner/atanimation/atcrimsongardenscene04party_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());	
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);

}


function CreateCrimsonGardenCreate_Chain(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_CRIMSONGARDEN , STATE_CRIMSONGARDEN, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atcrimsongarden/crimsongardencreatechain.ani", "passiveobject/new_skill/new_atgunner/attackinfo/crimsongardencreatechain.atk",true,atk,100,0,0,-obj.getZPos());
}
function CreateCrimsonGardenPull_Gunblader(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_CRIMSONGARDEN , STATE_CRIMSONGARDEN, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atcrimsongarden/crimsongardenpullgunblader.ani", "passiveobject/new_skill/new_atgunner/attackinfo/crimsongardenpullgunblader.atk",true,atk,100,0,0,-obj.getZPos());
}
function CreateCrimsonGardenSpin_MultiHit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_CRIMSONGARDEN , STATE_CRIMSONGARDEN, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atcrimsongarden/crimsongardenspinmultihit.ani", "passiveobject/new_skill/new_atgunner/attackinfo/crimsongardenspinmultihit.atk",true,atk,100,0,0,-obj.getZPos());
}
function CreateCrimsonGardenChain_Crash(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_CRIMSONGARDEN , STATE_CRIMSONGARDEN, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atcrimsongarden/crimsongardenchaincrash.ani", "passiveobject/new_skill/new_atgunner/attackinfo/crimsongardenchaincrash.atk",true,atk,100,0,0,-obj.getZPos());
}



function create_AtGunner_Ranger_Neo(obj, xPos, yPos)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/neo/atgunner_ranger_neo.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	pooledObj.setCurrentPos(xPos ,yPos, 0);
	if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
	{	
		pooledObj.setCurrentDirection(ENUM_DIRECTION_RIGHT);
	}
	else if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
	{
		pooledObj.setCurrentDirection(ENUM_DIRECTION_LEFT);
	}
	sq_AddObject(obj, pooledObj, 0, false);
}
