SUB_STANDBYREADY_READYJUMP	<-0
SUB_STANDBYREADY_READY	<-1
SUB_STANDBYREADY_READYLOOP	<-2
SUB_STANDBYREADY_READYEND	<-3
SUB_STANDBYREADY_DAMAGERECOVERY	<-4

function checkExecutableSkill_StandbyReady(obj)
{
		if (!obj) return false;
		local isUseSkill = obj.sq_IsUseSkill(SKILL_STANDBYREADY);
		if (isUseSkill)
		{
	local RadomSound = sq_getRandom(0,1);
	obj.getVar("Sound").clear_vector();
	obj.getVar("Sound").push_vector(RadomSound);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_STANDBYREADY_READYJUMP);
		obj.sq_AddSetStatePacket(STATE_STANDBYREADY, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_StandbyReady(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();

	return true;
}

function onSetState_StandbyReady(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	
	local skilllevel = sq_GetSkillLevel(obj, SKILL_STANDBYREADY);
	if(subState == SUB_STANDBYREADY_READYJUMP)
		{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_STANDBYREADY_READYJUMP_BODY);
		}else if(subState == SUB_STANDBYREADY_READY)
		{
			sq_SetZVelocity(obj, 800, -1200);
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_STANDBYREADY_READY_BODY);
		}else if(subState == SUB_STANDBYREADY_READYLOOP)
		{
		obj.sq_ZStop();
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_STANDBYREADY_READYLOOP_BODY);
		}else if(subState == SUB_STANDBYREADY_READYEND)
		{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_STANDBYREADY_READYEND_BODY);
		}else if(subState == SUB_STANDBYREADY_DAMAGERECOVERY)
		{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_STANDBYREADY_DAMAGERECOVERY_BODY);
		}

}

function onKeyFrameFlag_StandbyReady(obj,flagIndex)
{
	local subState = obj.getSkillSubState();
	local Sounds = obj.getVar("Sound").get_vector(0);
	if(subState == SUB_STANDBYREADY_READYEND)
		{
		if(flagIndex == 1)
		{
		local attackBonusRate = obj.sq_GetPowerWithPassive(SKILL_STANDBYREADY , STATE_STANDBYREADY, 0, -1, 1.0);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(16);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 100, 1, -obj.getZPos());
		local attackBonusRate2 = obj.sq_GetPowerWithPassive(SKILL_STANDBYREADY , STATE_STANDBYREADY, 2, -1, 1.0);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate2);
		obj.sq_WriteDword(17);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 100, 1, -obj.getZPos());
		local attackBonusRate3 = obj.sq_GetPowerWithPassive(SKILL_STANDBYREADY , STATE_STANDBYREADY, 1, -1, 1.0);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate3);
		obj.sq_WriteDword(18);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 100, 1, -obj.getZPos());
		local attackBonusRate4 = obj.sq_GetPowerWithPassive(SKILL_STANDBYREADY , STATE_STANDBYREADY, 3, -1, 1.0);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate4);
		obj.sq_WriteDword(19);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 100, 1, -obj.getZPos());
		}
	return true;
		}
}



function onTimeEvent_StandbyReady(obj, timeEventIndex, timeEventCount)
{
	if (timeEventIndex == 0)
	{
	}else if (timeEventIndex == 1)
	{
	}
}

function onProc_StandbyReady(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();
	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local currentT = sq_GetCurrentTime(pAni);

	if(subState == SUB_STANDBYREADY_READYLOOP)
		{
		
		if (sq_GetZPos(obj) != 200)
		{
			obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 200);
		}
		}
}

function onProcCon_StandbyReady(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();

	if (subState == SUB_STANDBYREADY_READYLOOP)
	{
		local bDownKey = obj.isDownSkillLastKey();
		local stateTimer = obj.sq_GetStateTimer();
		local grabMaxTime = sq_GetIntData(obj,SKILL_STANDBYREADY,1); 
		obj.setSkillCommandEnable(SKILL_STANDBYREADY,true);
		local IsEnterSkill = obj.sq_IsEnterSkill(SKILL_STANDBYREADY);
		if( IsEnterSkill != -1 || stateTimer >= grabMaxTime)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(SUB_STANDBYREADY_READYEND);
			obj.sq_AddSetStatePacket(STATE_STANDBYREADY, STATE_PRIORITY_USER, true);
			return;
		}
	}
}


function onEndCurrentAni_StandbyReady(obj)
{
	if(!obj) return;
	if(!obj.isMyControlObject())return;
	local subState = obj.getSkillSubState();
	if (subState == SUB_STANDBYREADY_READYJUMP)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_STANDBYREADY_READY);
		obj.sq_AddSetStatePacket(STATE_STANDBYREADY, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_STANDBYREADY_READY)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_STANDBYREADY_READYLOOP);
		obj.sq_AddSetStatePacket(STATE_STANDBYREADY, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_STANDBYREADY_READYLOOP)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_STANDBYREADY_READYEND);
		obj.sq_AddSetStatePacket(STATE_STANDBYREADY, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_STANDBYREADY_READYEND)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_STANDBYREADY_DAMAGERECOVERY);
		obj.sq_AddSetStatePacket(STATE_STANDBYREADY, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_STANDBYREADY_DAMAGERECOVERY)
	{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(0);
			obj.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
		
	}
}
