SUB_GXSTARDUST_START <- 0
SUB_GXSTARDUST_END <- 1

function checkExecutableSkill_GXStardust(obj)
{
		if (!obj) return false;
		local isUseSkill = obj.sq_IsUseSkill(SKILL_GXSTARDUST);
		if (isUseSkill)
		{
	local RadomSound = sq_getRandom(0,1);
	obj.getVar("Sound").clear_vector();
	obj.getVar("Sound").push_vector(RadomSound);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_GXSTARDUST_START);
		obj.sq_AddSetStatePacket(STATE_GXSTARDUST, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_GXStardust(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();

	return true;
}

function onSetState_GXStardust(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();
	obj.sq_ZStop();
	obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 800);
	obj.getVar().clear_vector();
	obj.getVar().push_vector(0);

	local skilllevel = sq_GetSkillLevel(obj, SKILL_GXSTARDUST);
	if(subState == SUB_GXSTARDUST_START)
		{
		local ani = obj.getVar().GetAnimationMap("GXStardust_Attack", "character/gunner/atanimation/gxstardust_attack_body.ani"); 
		obj.setCurrentAnimation(ani);

		if(obj.isMyControlObject())
		{
		CreatGXStardustBody_Attack(obj);
		CreatGXStardustStartEffect(obj);
		CreatGXStardustFrontEffect(obj);
		}else if(!obj.isMyControlObject())
			{
		CreatGXStardustBody_Attack_Party(obj);
		CreatGXStardustBackEffect_Party(obj);
			}
		}else if(subState == SUB_GXSTARDUST_END)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_GXSTARDUST_END);
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 0);
		}

}

function onKeyFrameFlag_GXStardust(obj,flagIndex)
{
	local subState = obj.getSkillSubState();
	local Sounds = obj.getVar("Sound").get_vector(0);

	if(!obj.isMyControlObject())
	{
	if(subState == SUB_GXSTARDUST_START && flagIndex == 9)
		{
		CreatGXStardustCoverEffect_Party(obj);
		}
	return true;
	}else if(obj.isMyControlObject())
	{
	if(subState == SUB_GXSTARDUST_START)
		{
		if(flagIndex == 0)
		{
		sq_SetMyShake(obj,60,2);
		obj.sq_PlaySound("GXSTARDUST_1_START");
		}
		else if(flagIndex == 2)
		{
		if(Sounds == 0)
		obj.sq_PlaySound("FG_GXSTARDUST_A_1");
		}
		else if(flagIndex == 9)
		{
		CreatGXStardustCoverEffect(obj);
		}
		else if(flagIndex == 11)
		{
		if(Sounds == 1)
		obj.sq_PlaySound("FG_GXSTARDUST_B_1");
		}
		else if(flagIndex == 15)
		{
		local objectManager = obj.getObjectManager();
		
		if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
		{
			local xPos = objectManager.getFieldXPos(920, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtGunner_Mechanic_Neo(obj, xPos, yPos)
		}
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
		{
			local xPos = objectManager.getFieldXPos(-100, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtGunner_Mechanic_Neo(obj, xPos, yPos)
		}
		}
		else if(flagIndex == 65)
		{
		sq_SetMyShake(obj,360,2);
		}
		else if(flagIndex == 71)
		{
		sq_SetMyShake(obj,360,8);
		obj.setTimeEvent(0,120,0,true);
		}
		else if(flagIndex == 79)
		{
		sq_SetMyShake(obj,240,10);
		}
		else if(flagIndex == 82)
		{
		if(Sounds == 0)
		obj.sq_PlaySound("FG_GXSTARDUST_A_2");
		}
		else if(flagIndex == 83)
		{
		sq_SetMyShake(obj,240,4);
		}
		else if(flagIndex == 87)
		{
		sq_SetMyShake(obj,360,6);
		}
		else if(flagIndex == 89)
		{
		obj.setTimeEvent(1,110,0,true);
		}
		else if(flagIndex == 93)
		{
		sq_SetMyShake(obj,300,8);
		}
		else if(flagIndex == 97)
		{
		if(Sounds == 0)
		obj.sq_PlaySound("FG_GXSTARDUST_B_2_01");
		}
		else if(flagIndex == 98)
		{
		sq_SetMyShake(obj,180,2);
		}
		else if(flagIndex == 98)
		{
		sq_SetMyShake(obj,240,13);
		}
		else if(flagIndex == 104)
		{
		CreatGXStardustBottomEffect(obj);
		}
	return true;
		}

	}
}


function onProc_GXStardust(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();
	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local currentT = sq_GetCurrentTime(pAni);
	local BodyObj = obj.getVar("Body").get_obj_vector(0);
	local FrontObj = obj.getVar("FrontObj").get_obj_vector(0);
	local BackObj = obj.getVar("BackObj").get_obj_vector(0);
	local CoverObj = obj.getVar("CoverObj").get_obj_vector(0);
	local CutSenseObj = obj.getVar("CutSenseObj").get_obj_vector(0);
	local objectManager = obj.getObjectManager();

	if(subState == SUB_GXSTARDUST_START)
	{

		if(frmIndex >= 0 && frmIndex <= 20 )
		{
	local delayT = pAni.getDelaySum(0 ,20);
	local Ypos = sq_GetAccel(400, 500, currentT , delayT, true);
	local yPos = objectManager.getFieldYPos(Ypos, 0, ENUM_DRAWLAYER_CONTACT);
	sq_setCurrentAxisPos(BodyObj, 1, yPos);
	sq_setCurrentAxisPos(FrontObj, 1, yPos);
		}
		else if(frmIndex >= 21 && frmIndex <= 26 )
			{
	local delayT = pAni.getDelaySum(21 ,26);
	local Ypos = sq_GetAccel(1000, 1500, currentT , delayT, true);
	local yPos = objectManager.getFieldYPos(Ypos, 0, ENUM_DRAWLAYER_CONTACT);
	sq_ChangeDrawLayer(BodyObj, ENUM_DRAWLAYER_NORMAL);
	sq_ChangeDrawLayer(FrontObj, ENUM_DRAWLAYER_NORMAL);
	sq_setCurrentAxisPos(CoverObj, 1, yPos);
			}
		else if(frmIndex >= 27 && frmIndex <= 35 )
			{
	local delayT = pAni.getDelaySum(27 ,35);
	local Ypos = sq_GetAccel(400, 1600, currentT , delayT, true);
	local yPos = objectManager.getFieldYPos(Ypos, 0, ENUM_DRAWLAYER_CONTACT);
	sq_ChangeDrawLayer(BackObj, ENUM_DRAWLAYER_NORMAL);
	sq_ChangeDrawLayer(CutSenseObj, ENUM_DRAWLAYER_COVER);
	sq_setCurrentAxisPos(BackObj, 1, yPos);
			}
		else if(frmIndex >= 36 && frmIndex <= 40 )
			{
	local delayT = pAni.getDelaySum(36 ,40);
	local yPos = objectManager.getFieldYPos(1600, 0, ENUM_DRAWLAYER_COVER);
	sq_ChangeDrawLayer(BackObj, ENUM_DRAWLAYER_CONTACT);
	sq_setCurrentAxisPos(CoverObj, 1, yPos);
			}
		else if(frmIndex >= 40 && frmIndex <= 41 )
			{
	local delayT = pAni.getDelaySum(40 ,41);
	local Ypos = sq_GetAccel(1500, 400, currentT , delayT, true);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_COVER);
	sq_setCurrentAxisPos(BackObj, 1, yPos);
	sq_setCurrentAxisPos(CoverObj, 1, yPos);
			}
	}
}

function onTimeEvent_GXStardust(obj, timeEventIndex, timeEventCount)
{
	if (timeEventIndex == 0)
	{
		if(timeEventCount <= 8 )
		{
		CreatGXStardust_SparkAttackBox(obj);
		}else{
		obj.stopTimeEvent(0);
			}
	}else if (timeEventIndex == 1)
	{
		if(timeEventCount <= 7 )
		{
		CreatGXStardust_FinishExpAttackBox(obj);
		}else{
		obj.stopTimeEvent(1);
			}
	}
}


function onEndCurrentAni_GXStardust(obj)
{
	if(!obj) return;
	if(!obj.isMyControlObject())return;
	local subState = obj.getSkillSubState();
	if (subState == SUB_GXSTARDUST_START)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_GXSTARDUST_END);
		obj.sq_AddSetStatePacket(STATE_GXSTARDUST, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_GXSTARDUST_END)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


function CreatGXStardustBody_Attack(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/gxstardust_attack_body1.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos , yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
	obj.getVar("Body").push_obj_vector( pooledObj );
}
function CreatGXStardustBody_Attack_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/atanimation/gxstardust_attack_body1.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos , yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function CreatGXStardustStartEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atgxstardust/atgxstardustbackgrounds_02.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local size = 100;
	local sizeRate = size.tofloat()/100.0;
	ani.setImageRateFromOriginal(sizeRate, sizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
	obj.getVar("BackObj").push_obj_vector( pooledObj );
}

function CreatGXStardustCoverEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atgxstardust/atgxstardustcover.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local size = 100;
	local sizeRate = size.tofloat()/100.0;
	ani.setImageRateFromOriginal(sizeRate, sizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
	obj.getVar("CoverObj").push_obj_vector( pooledObj );
}
function CreatGXStardustFrontEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atgxstardust/atgxstardustfront_116.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local size = 100;
	local sizeRate = size.tofloat()/100.0;
	ani.setImageRateFromOriginal(sizeRate, sizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos( xPos, yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
	obj.getVar("FrontObj").push_obj_vector( pooledObj );
}
function CreatGXStardustBottomEffect(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atgxstardust/atgxstardustbottom_295_01.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local size = 100;
	local sizeRate = size.tofloat()/100.0;
	ani.setImageRateFromOriginal(sizeRate, sizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_CONTACT);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos( obj.getXPos(), obj.getYPos(), 0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatGXStardustCoverEffect_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atgxstardust/party/atgxstardustcoverparty_07.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local size = 100;
	local sizeRate = size.tofloat()/100.0;
	ani.setImageRateFromOriginal(sizeRate, sizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}
function CreatGXStardustBackEffect_Party(obj)
{
	local ani = sq_CreateAnimation("","character/gunner/effect/animation/atgxstardust/party/atgxstardustbackparty_255_01.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local size = 100;
	local sizeRate = size.tofloat()/100.0;
	ani.setImageRateFromOriginal(sizeRate, sizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function CreatGXStardust_SparkAttackBox(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_GXSTARDUST , STATE_GXSTARDUST, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atgxstardust/spark.ani", "passiveobject/new_skill/new_atgunner/attackinfo/atgxstardustspark.atk",true,atk,100,0,0,-obj.getZPos());
}
function CreatGXStardust_FinishExpAttackBox(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_GXSTARDUST , STATE_GXSTARDUST, 1, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atgxstardust/finishexplosion.ani", "passiveobject/new_skill/new_atgunner/attackinfo/atgxstardustfinishexp.atk",true,atk,100,0,0,-obj.getZPos());
}

function create_AtGunner_Mechanic_Neo(obj, xPos, yPos)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/neo/atgunner_mechanic_neo.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	pooledObj.setCurrentPos(xPos ,yPos, 0);
	if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
	{	
		pooledObj.setCurrentDirection(ENUM_DIRECTION_RIGHT);
	}
	else if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
	{
		pooledObj.setCurrentDirection(ENUM_DIRECTION_LEFT);
	}
	sq_AddObject(obj, pooledObj, 0, false);
}
