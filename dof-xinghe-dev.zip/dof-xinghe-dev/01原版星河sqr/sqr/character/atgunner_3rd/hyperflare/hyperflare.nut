SUB_HYPERFLARE_ATTACK1 <- 0
SUB_HYPERFLARE_ATTACK2 <- 1



function checkExecutableSkill_HyperFlare(obj)
{
		if (!obj) return false;
		local isUseSkill = obj.sq_IsUseSkill(SKILL_HYPERFLARE);
		if (isUseSkill)
		{
	local RadomSound = sq_getRandom(0,1);
	obj.getVar("Sound").clear_vector();
	obj.getVar("Sound").push_vector(RadomSound);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_HYPERFLARE_ATTACK1);
		obj.sq_AddSetStatePacket(STATE_HYPERFLARE, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_HyperFlare(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();

	return true;
}

function onSetState_HyperFlare(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();
	local skilllevel = sq_GetSkillLevel(obj, SKILL_HYPERFLARE);
	if(subState == SUB_HYPERFLARE_ATTACK1)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_HYPERFLARE_ATTACK1);
		CreateHyperFlare1Attack_Front2(obj ,0 ,0 ,0);
		CreateHyperFlare1Attack_Back2(obj ,0 ,0 ,0);
		CreateHyperFlare1Attack_Bottom(obj ,0 ,0 ,0);
		CreateHyperFlare1Attack_Front(obj ,0 ,0 ,0);
		CreateHyperFlare1Attack_Back(obj ,0 ,0 ,0);
		CreateHyperFlare1Attack_Front3(obj ,0 ,0 ,0);
		}else if(subState == SUB_HYPERFLARE_ATTACK2)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_HYPERFLARE_ATTACK2);
		CreateHyperFlare2Attack_Front(obj ,0 ,0,0);
		CreateHyperFlare2Attack_Back3(obj ,0 ,0 ,0)
		}

}

function onKeyFrameFlag_HyperFlare(obj,flagIndex)
{
	local subState = obj.getSkillSubState();
	local Sounds = obj.getVar("Sound").get_vector(0);
	if(subState == SUB_HYPERFLARE_ATTACK1)
		{
		if ( flagIndex == 0 )
		{
		if(Sounds == 0)
		{
		obj.sq_PlaySound("FG_HYPERFLARE_A_1");
		}else{
		obj.sq_PlaySound("FG_HYPERFLARE_B_1");
			}

		obj.setTimeEvent(0,30,0,true);

		}
		else if ( flagIndex == 8 )
		{
		sq_SetMyShake(obj,8,300);
		}
	return true;
		}
	else if(subState == SUB_HYPERFLARE_ATTACK2)
		{
		if ( flagIndex == 1 )
		{
		obj.sq_PlaySound("HYPERFLARE_CAST");
		}
		else if ( flagIndex == 2 )
		{
		if(Sounds == 1)
		obj.sq_PlaySound("FG_HYPERFLARE_B_2_01");
		}
		else if ( flagIndex == 15 )
		{
		if(Sounds == 0)
		obj.sq_PlaySound("FG_HYPERFLARE_A_2");
		CreateHyperFlare2Attack_Back(obj ,0 ,0,0);
		CreateHyperFlare2Attack_Back2(obj ,0 ,0,0);
		CreateHyperFlare2Attack_Bottom(obj ,0 ,0,0);
		CreateHyperFlare2Attack_BottomAfter(obj ,0 ,0,0);
		CreateHyperFlare2Attack_Front2(obj ,0 ,0,0);
		local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_HYPERFLARE, STATE_HYPERFLARE, 1, 1.0);
		local AttackCount = obj.sq_GetIntData(SKILL_HYPERFLARE, 2);
		obj.sq_StartWrite();
		obj.sq_WriteDword(attackBonusRate);
		obj.sq_WriteDword(9);
		obj.sq_WriteDword(AttackCount);
		obj.sq_SendCreatePassiveObjectPacket(24360, 0, 0,-25, 0);
		}
		else if ( flagIndex == 16 )
		{
		obj.sq_PlaySound("HYPERFLARE_SHOT");
		sq_SetMyShake(obj,15,300);
		}
		else if ( flagIndex == 22 )
		{
		sq_SetMyShake(obj,2,150);
		}
	return true;
		}

}

function onTimeEvent_HyperFlare(obj, timeEventIndex, timeEventCount)
{
	if (timeEventIndex == 0)
	{
		if(timeEventCount <= 6 )
		{
		CreatHyperFlare_AttackBox(obj);
		}else{
		obj.stopTimeEvent(0);
			}
	}
}

function onEndCurrentAni_HyperFlare(obj)
{

	if(!obj) return;
	if(!obj.isMyControlObject())return;
	local subState = obj.getSkillSubState();
	if (subState == SUB_HYPERFLARE_ATTACK1)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_HYPERFLARE_ATTACK2);
		obj.sq_AddSetStatePacket(STATE_HYPERFLARE, STATE_PRIORITY_IGNORE_FORCE, true);
	}else if (subState == SUB_HYPERFLARE_ATTACK2)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


function CreatHyperFlare_AttackBox(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_HYPERFLARE , STATE_HYPERFLARE, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/Animation/ATHyperFlare/HyperFlare1AttackFront_Dummy.ani", "passiveobject/new_skill/new_atgunner/attackinfo/athyperflarefirstexplosion.atk",true,atk,100,0,0,-obj.getZPos());
}


function CreateHyperFlare1Attack_Back(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare1attackback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare1Attack_Back2(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare1attackback_33.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}

function CreateHyperFlare1Attack_Front(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare1attackfront_34.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare1Attack_Front2(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare1attackfront_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare1Attack_Front3(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare1attackfront_30.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare1Attack_Bottom(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare1attackbottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}

function CreateHyperFlare2Attack_Back(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare2attackback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare2Attack_Back2(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare2attackback_34.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare2Attack_Back3(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare2attackback_35.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare2Attack_Bottom(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare2attackbottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare2Attack_BottomAfter(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare2attackbottom_after_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare2Attack_Front(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare2attackfront_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
function CreateHyperFlare2Attack_Front2(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/athyperflare/hyperflare2attackfront_34.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}
