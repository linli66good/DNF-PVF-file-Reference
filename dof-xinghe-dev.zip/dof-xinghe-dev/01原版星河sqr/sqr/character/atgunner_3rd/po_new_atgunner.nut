ATGUNNEROBJ_0 <- 50
ATGUNNEROBJ_1 <- 51
ATGUNNEROBJ_2 <- 52
ATGUNNEROBJ_3 <- 53
ATGUNNEROBJ_4 <- 54

function setCustomData_po_New_Atgunner(obj, receiveData)
{
		if(!obj) return;
		local attackBonusRate = receiveData.readDword();
		local id = receiveData.readDword();
		local pChr = obj.getTopCharacter();
		obj.getVar("id").clear_vector();
		obj.getVar("id").push_vector(id);
	if (id == 19 )
	{
		local ani = obj.getVar().GetAnimationMap("StandbyReadyOverheat", "passiveobject/new_skill/new_atgunner/Animation/ATStandby-Ready/OverheatFront_00.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 12);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, attackBonusRate);
	}else if (id == 18 )
	{
		local attackInfo = sq_GetCustomAttackInfo(obj, 11);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, attackBonusRate);

	obj.getVar("state").clear_vector();
	obj.getVar("state").push_vector(ATGUNNEROBJ_0);
	local pIntVec = sq_GetGlobalIntVector();
	sq_IntVectorClear(pIntVec);
	sq_IntVectorPush(pIntVec, 0);
	obj.addSetStatePacket(ATGUNNEROBJ_0, pIntVec, STATE_PRIORITY_AUTO, false, "");

	obj.getVar("AttackInfo").clear_vector();
	obj.getVar("AttackInfo").push_vector(attackBonusRate);
	obj.getVar("AttackInfo").push_vector(attackInfo);
	}
	else if (id == 17 )
	{
		local attackInfo = sq_GetCustomAttackInfo(obj, 10);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, attackBonusRate);

	obj.getVar("state").clear_vector();
	obj.getVar("state").push_vector(ATGUNNEROBJ_0);
	local pIntVec = sq_GetGlobalIntVector();
	sq_IntVectorClear(pIntVec);
	sq_IntVectorPush(pIntVec, 0);
	obj.addSetStatePacket(ATGUNNEROBJ_0, pIntVec, STATE_PRIORITY_AUTO, false, "");

	obj.getVar("AttackInfo").clear_vector();
	obj.getVar("AttackInfo").push_vector(attackBonusRate);
	obj.getVar("AttackInfo").push_vector(attackInfo);
	}
	else if (id == 16 )
	{
		local ani = obj.getVar().GetAnimationMap("StandbyReadyGrenadeNone", "passiveobject/new_skill/new_atgunner/Animation/ATStandby-Ready/GrenadeFront_02.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 9);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, attackBonusRate);
	}

	else if (id >= 13 && id <= 15)
	{
		local ani = null;
		if(id == 13)
		{
		ani = obj.getVar().GetAnimationMap("Phlegethon_BoostStart", "passiveobject/new_skill/new_atgunner/Animation/Phlegethon/BoostStartFront_00.ani"); 
CreatePhlegethonBoostStart(obj);
		}else if(id == 14)
		{
		ani = obj.getVar().GetAnimationMap("Phlegethon_BoostLoop", "passiveobject/new_skill/new_atgunner/Animation/Phlegethon/BoostLoopFront_00.ani"); 
CreatePhlegethonBoostLoop(obj);
		}else if(id == 15)
		{
		ani = obj.getVar().GetAnimationMap("Phlegethon_BoostEnd", "passiveobject/new_skill/new_atgunner/Animation/Phlegethon/BoostEndFront_01.ani"); 
CreatePhlegethonBoostEnd(obj);
		}
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 8);
		local power = receiveData.readDword();
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		sq_SetCurrentAttackPower(attackInfo, power);
		obj.setTimeEvent(0,90,0,true);
		obj.getVar("AttackInfo").clear_vector();
		obj.getVar("AttackInfo").push_vector(attackBonusRate);
		obj.getVar("AttackInfo").push_vector(power);
	}else if (id >= 10 && id<= 12)
	{
		local ani = null;
		if(id == 12)
		{
		ani = obj.getVar().GetAnimationMap("PhlegethonEnd", "passiveobject/new_skill/new_atgunner/Animation/Phlegethon/BoostEndFront_01.ani"); 

		}else if(id == 11)
		{
		ani = obj.getVar().GetAnimationMap("PhlegethonLoop", "passiveobject/new_skill/new_atgunner/Animation/Phlegethon/BoostLoopFront_00.ani"); 
		}else if(id == 10)
		{
		 ani = obj.getVar().GetAnimationMap("PhlegethonStart", "passiveobject/new_skill/new_atgunner/Animation/Phlegethon/BoostStartFront_00.ani"); 
		}
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 8);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		obj.getVar("AttackInfo").clear_vector();
		obj.getVar("AttackInfo").push_vector(attackBonusRate);
		obj.setTimeEvent(0,45,0,true);
	}
	else if (id == 100)
	{
		local ani = obj.getVar().GetAnimationMap("HyperFlareSecondAttack", "character/gunner/effect/animation/atphlegethon/flamebottomend_00.ani"); 
		obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_BOTTOM);
		local size = 150;
		local sizeRate = size.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setImageRateFromOriginal(sizeRate, sizeRate);
		currentAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	}
	else if (id == 9)
	{
		local AttackCount = receiveData.readDword();
		local ani = obj.getVar().GetAnimationMap("HyperFlareSecondAttack", "passiveobject/new_skill/new_atgunner/Animation/ATHyperFlare/HyperFlare2AttackFront_Dummy.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 7);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		local Delay = ani.getDelaySum(false);
		obj.setTimeEvent(1,Delay / AttackCount,0,true);
		obj.getVar("AttackInfo").clear_vector();
		obj.getVar("AttackInfo").push_vector(AttackCount);
	}
	else if (id == 8)
	{
		local AttackCount = receiveData.readDword();
		local ani = obj.getVar().GetAnimationMap("HyperFlareFirstAttack", "passiveobject/new_skill/new_atgunner/Animation/ATHyperFlare/HyperFlare1AttackFront_Dummy.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 6);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		obj.setTimeEvent(0, 10 ,0,true);
		obj.getVar("AttackInfo1").clear_vector();
		obj.getVar("AttackInfo1").push_vector(AttackCount);
	}
	else if (id == 7)
	{
		local ani = obj.getVar().GetAnimationMap("RuinationAreaFinishShot", "passiveobject/new_skill/new_atgunner/Animation/ATRuinationArea/FinishShot/RuinationareaSt4Front_09.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 5);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);

	}
	else if (id == 6)
	{
		local ani = obj.getVar().GetAnimationMap("RuinationAreaFinish", "passiveobject/new_skill/new_atgunner/Animation/ATRuinationArea/St4/RuinationareaSt4Front_00.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 4);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);

	}
	else if (id == 5)
	{
		local ani = obj.getVar().GetAnimationMap("RuinationAreaAtk3", "passiveobject/new_skill/new_atgunner/Animation/ATRuinationArea/St3/RuinationareaSt3Front_00.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 3);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);

	}
	else if (id == 4)
	{
		local ani = obj.getVar().GetAnimationMap("RuinationAreaAtk2", "passiveobject/new_skill/new_atgunner/Animation/ATRuinationArea/St2/RuinationareaSt2Front_00.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 2);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);

	}
	else if (id == 3)
	{
		local ani = obj.getVar().GetAnimationMap("RuinationAreaAtk1", "passiveobject/new_skill/new_atgunner/Animation/ATRuinationArea/St1/RuinationareaSt1Front_00.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 1);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
	}

}



function setState_po_New_Atgunner(obj, state, datas)
{
	if(!obj) return;
	local id = obj.getVar("id").get_vector(0);
	local pChr = obj.getTopCharacter();
	local passiveState = state;
	obj.getVar("state").set_vector(0, passiveState);
	if (id == 18)
	{
	local Rate = obj.getVar("AttackInfo").get_vector(0);
	local AttackInfo = obj.getVar("AttackInfo").get_vector(1);
	if(passiveState == ATGUNNEROBJ_0)
	{
		local ani = obj.getVar().GetAnimationMap("SBRFlash", "passiveobject/new_skill/new_atgunner/animation/atstandby-ready/flashbottomstart_00.ani"); 
		obj.setCurrentAnimation(ani);
		local Ani = obj.getCurrentAnimation();
		local dodge = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/Animation/ATStandby-Ready/FlashFrontStart_00.ani");
		Ani.addLayerAnimation(10001,dodge,true);
		local attackInfo = sq_GetCustomAttackInfo(obj, 10);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, Rate);
	}
	else if(passiveState == ATGUNNEROBJ_1)
	{
		local ani = obj.getVar().GetAnimationMap("SBRFlashLoop", "passiveobject/new_skill/new_atgunner/animation/atstandby-ready/flashbottomloop_00.ani"); 
		obj.setCurrentAnimation(ani);
		sq_SetCurrentAttackPower(AttackInfo, Rate);
		local Ani = obj.getCurrentAnimation();
		local dodge = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/animation/ATStandby-Ready/FlashFrontLoop_00.ani");
		Ani.addLayerAnimation(10001,dodge,true);
	}else if(passiveState == ATGUNNEROBJ_2)
	{
		local ani = obj.getVar().GetAnimationMap("SBRFlashEnd", "passiveobject/new_skill/new_atgunner/animation/atstandby-ready/flashbottomend_00.ani"); 
		obj.setCurrentAnimation(ani);
		local Ani = obj.getCurrentAnimation();
		local dodge = sq_CreateAnimation("","passiveobject/new_skill/new_atgunner/Animation/ATStandby-Ready/FlashFrontEnd_00.ani");
		Ani.addLayerAnimation(10001,dodge,true);
	}
	}

	else if (id == 17)
	{
	local Rate = obj.getVar("AttackInfo").get_vector(0);
	local AttackInfo = obj.getVar("AttackInfo").get_vector(1);
	if(passiveState == ATGUNNEROBJ_0)
	{
		local ani = obj.getVar().GetAnimationMap("SBRGrenadeWater", "passiveobject/new_skill/new_atgunner/Animation/ATStandby-Ready/FrozenStart_01.ani"); 
		obj.setCurrentAnimation(ani);
		local attackInfo = sq_GetCustomAttackInfo(obj, 10);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, Rate);
	}
	else if(passiveState == ATGUNNEROBJ_1)
	{
		local ani = obj.getVar().GetAnimationMap("SBRFrozenLoop", "passiveobject/new_skill/new_atgunner/Animation/ATStandby-Ready/FrozenLoop_00.ani"); 
		obj.setCurrentAnimation(ani);
		sq_SetCurrentAttackPower(AttackInfo, Rate);
	}else if(passiveState == ATGUNNEROBJ_2)
	{
		local ani = obj.getVar().GetAnimationMap("SBRFrozenEnd", "passiveobject/new_skill/new_atgunner/Animation/ATStandby-Ready/FrozenEnd_00.ani"); 
		obj.setCurrentAnimation(ani);
	}
	}

}

function onKeyFrameFlag_po_New_Atgunner(obj,flagIndex)
{
	local id = obj.getVar("id").get_vector(0);
	local pChr = obj.getTopCharacter();
	local passiveState = obj.getVar("state").get_vector(0);
	if(id == 18 && passiveState == ATGUNNEROBJ_0 ) 
	{
		if(flagIndex == 6)
		obj.setTimeEvent(0,100,0,true);
	}
	else if(id == 17 && passiveState == ATGUNNEROBJ_0 ) 
	{
		if(flagIndex == 2)
		{
		sq_SetMyShake(obj,1,600);
		}else if(flagIndex == 4)
		{
		obj.setTimeEvent(0,100,0,true);
		}
	}else if(id == 16 && flagIndex == 0) 
	{
		sq_SetMyShake(obj,10,150);
	}else if(id == 8 && flagIndex == 1) 
	{
		local Count = obj.getVar("AttackInfo").get_vector(0);
		obj.setTimeEvent(0, 80 / Count,0,true);
	}
	return true;
}

function onTimeEvent_po_New_Atgunner(obj, timeEventIndex, timeEventCount)
{
	local id = obj.getVar("id").get_vector(0);
	if(id == 18)
	{
	if(timeEventIndex == 0)
		{
		CreateStandbyReady_FlashAttack(obj);
		sq_SetMyShake(obj,1,100);
		}
	}
	else if(id == 17)
	{
	if(timeEventIndex == 0)
		{
		obj.resetHitObjectList();
		sq_SetMyShake(obj,1,100);
		}
	}else if(id >= 10 && id <= 15 )
	{
	if(timeEventIndex == 0)
		{
		obj.resetHitObjectList();
		}
	}else if(id == 9 )
	{
	local Count = obj.getVar("AttackInfo").get_vector(0);
	if(timeEventIndex == 1 && timeEventCount <= Count)
		{
		obj.resetHitObjectList();
		}else
		{
		obj.stopTimeEvent(1);
		}
	}else if(id == 8 )
	{
	local Count = obj.getVar("AttackInfo1").get_vector(0);
	if(timeEventIndex == 0 && timeEventCount <= Count)
		{
		obj.resetHitObjectList();
		}else
		{
		obj.stopTimeEvent(0);
		}

	}

}


function procAppend_po_New_Atgunner(obj)
{
	local id = obj.getVar("id").get_vector(0);
	local pChr = obj.getTopCharacter();
	pChr = sq_ObjectToSQRCharacter(pChr);
	local pAni = obj.getCurrentAnimation();
	local frmIndex = sq_GetAnimationFrameIndex(pAni);
	local currentT = sq_GetCurrentTime(pAni);
	local AttackAni = obj.getVar("AttackInfo").get_vector(1);
	local passiveState = obj.getVar("state").get_vector(0);
	if( id == 18 && currentT >= 1500 && passiveState == ATGUNNEROBJ_1 )
	{
		local pIntVec = sq_GetGlobalIntVector();
		sq_IntVectorClear(pIntVec);
		sq_IntVectorPush(pIntVec, 0);
		obj.addSetStatePacket(ATGUNNEROBJ_2, pIntVec, STATE_PRIORITY_AUTO, false, "");
	}
	else if( id == 17 && currentT >= 1500 && passiveState == ATGUNNEROBJ_1 )
	{
		local pIntVec = sq_GetGlobalIntVector();
		sq_IntVectorClear(pIntVec);
		sq_IntVectorPush(pIntVec, 0);
		obj.addSetStatePacket(ATGUNNEROBJ_2, pIntVec, STATE_PRIORITY_AUTO, false, "");
	}else if( id == 14 && pChr.getSkillSubState() == SUB_PHLEGETHON_END )
	{
		local attackBonusRate = obj.getVar("AttackInfo").get_vector(0);
		local power = obj.getVar("AttackInfo").get_vector(1);
		sq_BinaryStartWrite();
		sq_BinaryWriteDword(attackBonusRate );
		sq_BinaryWriteDword(15);
		sq_BinaryWriteDword(power );
		sq_SendCreatePassiveObjectPacketPos(obj,24360, 0, obj.getXPos() , obj.getYPos() , 0);
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if( id == 11 && (currentT >= 2350 || pChr.getSkillSubState() == SUB_PHLEGETHON_END) )
	{
		local attackBonusRate = obj.getVar("AttackInfo").get_vector(0);
		sq_BinaryStartWrite();
		sq_BinaryWriteDword(attackBonusRate );
		sq_BinaryWriteDword(12);
		sq_SendCreatePassiveObjectPacketPos(obj,24360, 0, obj.getXPos() , obj.getYPos() , 0);
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if(id >= 10 && id <= 15)
	{
		local ParentObj = obj.getParent();
		local x = sq_GetXPos(ParentObj);
		local y = sq_GetYPos(ParentObj);
		local z = sq_GetZPos(ParentObj);
		obj.setCurrentPos(x, y, z);
	}

}

function onEndCurrentAni_po_New_Atgunner(obj)
{
	local id = obj.getVar("id").get_vector(0);
	local pChr = obj.getTopCharacter();
	local passiveState = obj.getVar("state").get_vector(0);
	if (id == 19)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if (id == 18)
	{
	if (passiveState == ATGUNNEROBJ_2)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}else if (passiveState == ATGUNNEROBJ_0)
	{
		local pIntVec = sq_GetGlobalIntVector();
		sq_IntVectorClear(pIntVec);
		sq_IntVectorPush(pIntVec, 0);
		obj.addSetStatePacket(ATGUNNEROBJ_1, pIntVec, STATE_PRIORITY_AUTO, false, "");
	}
	}
	else if (id == 17)
	{
	if (passiveState == ATGUNNEROBJ_2)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}else if (passiveState == ATGUNNEROBJ_0)
	{
		local pIntVec = sq_GetGlobalIntVector();
		sq_IntVectorClear(pIntVec);
		sq_IntVectorPush(pIntVec, 0);
		obj.addSetStatePacket(ATGUNNEROBJ_1, pIntVec, STATE_PRIORITY_AUTO, false, "");
	}
	}
	else if (id == 100)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if (id == 16)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if (id == 15)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if (id == 13 )
	{
		local attackBonusRate = obj.getVar("AttackInfo").get_vector(0);
		local power = obj.getVar("AttackInfo").get_vector(1);
		sq_BinaryStartWrite();
		sq_BinaryWriteDword(attackBonusRate );
		sq_BinaryWriteDword(14);
		sq_BinaryWriteDword(power );
		sq_SendCreatePassiveObjectPacketPos(obj,24360, 0, obj.getXPos() , obj.getYPos() , 0);
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if (id == 12)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if (id == 11)
	{

	}
	else if (id == 10)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	else if (id == 3)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
}

function CreateStandbyReady_FlashAttack(obj)
{
	local atk = obj.sq_GetPowerWithPassive(SKILL_STANDBYREADY , STATE_STANDBYREADY, 1, -1, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atgunner/animation/atstandby-ready/flashattackbox.ani", "passiveobject/new_skill/new_atgunner/AttackInfo/StandbyReadyGrenadeLightAttack.atk",false,atk,100,0,0,-obj.getZPos());
}
