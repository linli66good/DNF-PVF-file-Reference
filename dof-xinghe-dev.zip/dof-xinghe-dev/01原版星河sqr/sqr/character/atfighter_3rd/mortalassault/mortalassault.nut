function checkExecutableSkill_MortalAssault(obj) {

	local isUseSkill = obj.sq_IsUseSkill(SKILL_MORTAL_ASSAULT);
	if (isUseSkill) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(STATE_MORTAL_ASSAULT, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}

function checkCommandEnable_MortalAssault(obj) {

	return true;

}

function onSetState_MortalAssault(obj, state, datas, isResetTimer) 
{
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	if (substate == 0)
	{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_MORTAL_ASSAULT_CAST);
		local ani = obj.getCurrentAnimation();
		local delay = ani.getDelaySum(false);
		obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
		SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
		local ndelay = ani.getDelaySum(false);
		local speed = delay.tofloat() / ndelay.tofloat();
		als_ani(obj, "character/fighter/effect/animation/atmortalassault/cast/castfront_00.ani", 0, 0, 0, 0, 100, 1, 0, speed);
		als_ani(obj, "character/fighter/effect/animation/atmortalassault/cast/jumpcastfront_06.ani", 0, 0, 0, 0, 100, 0, 0, speed);
		als_ani(obj, "character/fighter/effect/animation/atmortalassault/cast/castfloor_01.ani", 0, 0, 0, 0, 100, 0, 0, speed);
		obj.getVar().clear_vector();
		obj.getVar().push_vector(obj.getZPos());
	} 
	if (substate == 1) 
	{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_MORTAL_ASSAULT_SHOOT);
		local ani = obj.getCurrentAnimation();
		local delay = ani.getDelaySum(false);
		obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
		SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
		local ndelay = ani.getDelaySum(false);
		local speed = delay.tofloat() / ndelay.tofloat();
		obj.getVar().clear_vector();
		obj.getVar().push_vector(obj.getZPos());
		als_ani(obj, "character/fighter/effect/animation/atmortalassault/attack/ahitfront_00.ani", 0, 0, -500, 0, 100, 0, 0, speed);
		als_ani(obj, "character/fighter/effect/animation/atmortalassault/attack/ahitback_01.ani", 0, 0, -500, 0, 100, 0, 0, speed);
		als_ani(obj, "character/fighter/effect/animation/atmortalassault/fallfiretail_00.ani", 0, 0, -500, 0, 100, 0, 0, speed);
		obj.sq_StartWrite();
		obj.sq_WriteDword(604);
		obj.sq_SendCreatePassiveObjectPacket(24333, 0, 0, 0, -500);
		if(sq_GetSkillLevel(obj, 234) > 0)
		{
		obj.sq_StartWrite();
		obj.sq_WriteDword(605);
		obj.sq_SendCreatePassiveObjectPacket(24333, 0, 0, 0, -500);
		}
	}
}

function onAttack_MortalAssault(obj, damager, boundingBox, isStuck) {
	if (!obj) return;
	local substate = obj.getSkillSubState();
	if (substate == 1) {
		obj.sq_SetShake(obj, 5, 200);
		sq_flashScreen(obj, 0, 80, 240, 153, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		SetAHit_back(obj, damager);
		SetAHit_front(obj, damager);

	}
}

function onEndCurrentAni_MortalAssault(obj)
{
	if(!obj) return;
	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(STATE_MORTAL_ASSAULT, STATE_PRIORITY_IGNORE_FORCE, true);
		break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_IGNORE_FORCE, true);
		break;
	}
}




function onProc_MortalAssault(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local Ani = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(Ani);
	local frameindex = sq_GetCurrentFrameIndex(obj);
	local objVar = obj.getVar();
	if (substate == 0)
	{
			local ani = obj.getCurrentAnimation();
			local currentT = sq_GetCurrentTime(ani);
			local fireT = ani.getDelaySum(false);
			local startZ = objVar.get_vector(0);
			local dstZ = sq_GetUniformVelocity(startZ, 500, currentT*15, fireT);
			sq_setCurrentAxisPos(obj, 2, dstZ);
	}
	if (substate == 1)
	{
			local ani = obj.getCurrentAnimation();
			local currentT = sq_GetCurrentTime(ani);
			local fireT = ani.getDelaySum(false);
			local startZ = objVar.get_vector(0);
			local dstZ = sq_GetUniformVelocity(startZ, 0, currentT*15, fireT);
			sq_setCurrentAxisPos(obj, 2, dstZ);
	}
}

