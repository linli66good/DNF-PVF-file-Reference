function checkExecutableSkill_StoneShower(obj)
{

		local isUseSkill = obj.sq_IsUseSkill(SKILL_STONE_SHOWER);
		if (isUseSkill)
		{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(STATE_STONE_SHOWER, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_StoneShower(obj)
{

		return true;

}


function onSetState_StoneShower(obj, state, datas, isResetTimer)
{


	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);

	obj.sq_StopMove();
	local isMyControlObject = obj.sq_IsMyControlObject();
	local skilllevel = sq_GetSkillLevel(obj, SKILL_STONE_SHOWER);

	local posX = obj.getXPos();
	local posY = obj.getYPos();
	local posZ = obj.getZPos();

		if(substate == 0)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_STONE_SHOWER_CASTA);
SetStoneShowerSpeed_Back(obj);
SetStoneShowerSpeed_Front(obj);
SetCast_GroundFrontA(obj);
SetAttack_BackA(obj);
		obj.getVar("posZ").clear_vector();
		obj.getVar("posZ").push_vector(obj.getZPos());
		}else if(substate == 1)
		{
		obj.sq_ZStop();
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 300);
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_STONE_SHOWER_2HIT);
		}else if(substate == 2)
		{

		obj.sq_ZStop();
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 300);
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_STONE_SHOWER_END);
		}
}

function onKeyFrameFlag_StoneShower(obj,flagIndex)
{
	local substate = obj.getSkillSubState();
	local isMyControlObject = obj.sq_IsMyControlObject();
	local pAni = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(pAni);

	if(substate == 0 && isMyControlObject)
	{
		if(flagIndex == 0)
		{
		Create_stone_shower_frontcyclone(obj);
		obj.sq_PlaySound("MF_STONESHOWER_START");
		obj.sq_SetShake(obj, 8, 300);
		return true;
		}else if(flagIndex == 13)
		{

SetStoneShowerexplosionaground(obj , 100, -70, 0);
SetStoneShowerexplosionaground(obj , 250, -70, 0);
SetStoneShowerexplosionaground(obj , 400, -70, 0);
SetStoneShowerexplosionaground(obj , 550, -70, 0);
SetStoneShowerexplosionaground(obj , 100, 0, 0);
SetStoneShowerexplosionaground(obj , 250, 0, 0);
SetStoneShowerexplosionaground(obj , 400, 0, 0);
SetStoneShowerexplosionaground(obj , 550, 0, 0);
SetStoneShowerexplosionaground(obj , 100, 70, 0);
SetStoneShowerexplosionaground(obj , 250, 70, 0);
SetStoneShowerexplosionaground(obj , 400, 70, 0);
SetStoneShowerexplosionaground(obj , 550, 70, 0);
SetStoneShowerexplosiona(obj , 200, -70, 5);
SetStoneShowerexplosiona(obj , 400, -70, 5);
SetStoneShowerexplosiona(obj , 550, -70, 5);
SetStoneShowerexplosiona(obj , 100, 0, 5);
SetStoneShowerexplosiona(obj , 250, 0, 5);
SetStoneShowerexplosiona(obj , 400, 0, 5);
SetStoneShowerexplosiona(obj , 550, 0, 5);
SetStoneShowerexplosiona(obj , 100, 70, 5);
SetStoneShowerexplosiona(obj , 250, 70, 5);
SetStoneShowerexplosiona(obj , 400, 70, 5);
SetStoneShowerexplosiona(obj , 550, 70, 5);
SetAttack_FrontA(obj);
		obj.setTimeEvent(0,100,10,true);
		obj.sq_SetShake(obj, 3, 1500);
		return true;
		}else if(flagIndex == 17)
		{
		return true;
		}else if(flagIndex == 21)
		{
obj.sq_SetShake(obj, 4, 100);
SetAttack_FrontA(obj);

SetStoneShowerexplosionaground(obj , 100, -70, 0);
SetStoneShowerexplosionaground(obj , 250, -70, 0);
SetStoneShowerexplosionaground(obj , 400, -70, 0);
SetStoneShowerexplosionaground(obj , 550, -70, 0);
SetStoneShowerexplosionaground(obj , 100, 0, 0);
SetStoneShowerexplosionaground(obj , 250, 0, 0);
SetStoneShowerexplosionaground(obj , 400, 0, 0);
SetStoneShowerexplosionaground(obj , 550, 0, 0);
SetStoneShowerexplosionaground(obj , 100, 70, 0);
SetStoneShowerexplosionaground(obj , 250, 70, 0);
SetStoneShowerexplosionaground(obj , 400, 70, 0);
SetStoneShowerexplosionaground(obj , 550, 70, 0);
SetStoneShowerexplosiona(obj , 200, -70, 5);
SetStoneShowerexplosiona(obj , 400, -70, 5);
SetStoneShowerexplosiona(obj , 550, -70, 5);
SetStoneShowerexplosiona(obj , 100, 0, 5);
SetStoneShowerexplosiona(obj , 250, 0, 5);
SetStoneShowerexplosiona(obj , 400, 0, 5);
SetStoneShowerexplosiona(obj , 550, 0, 5);
SetStoneShowerexplosiona(obj , 100, 70, 5);
SetStoneShowerexplosiona(obj , 250, 70, 5);
SetStoneShowerexplosiona(obj , 400, 70, 5);
SetStoneShowerexplosiona(obj , 550, 70, 5);
		return true;
		}else if(flagIndex == 22)
		{
		return true;
		}else if(flagIndex == 25)
		{
		return true;
		}else if(flagIndex == 29)
		{
SetAttack_FrontA(obj);
obj.sq_SetShake(obj, 4, 100);
SetStoneShowerexplosionaground(obj , 100, -70, 0);
SetStoneShowerexplosionaground(obj , 250, -70, 0);
SetStoneShowerexplosionaground(obj , 400, -70, 0);
SetStoneShowerexplosionaground(obj , 550, -70, 0);
SetStoneShowerexplosionaground(obj , 100, 0, 0);
SetStoneShowerexplosionaground(obj , 250, 0, 0);
SetStoneShowerexplosionaground(obj , 400, 0, 0);
SetStoneShowerexplosionaground(obj , 550, 0, 0);
SetStoneShowerexplosionaground(obj , 100, 70, 0);
SetStoneShowerexplosionaground(obj , 250, 70, 0);
SetStoneShowerexplosionaground(obj , 400, 70, 0);
SetStoneShowerexplosionaground(obj , 550, 70, 0);
SetStoneShowerexplosiona(obj , 200, -70, 5);
SetStoneShowerexplosiona(obj , 400, -70, 5);
SetStoneShowerexplosiona(obj , 550, -70, 5);
SetStoneShowerexplosiona(obj , 100, 0, 5);
SetStoneShowerexplosiona(obj , 250, 0, 5);
SetStoneShowerexplosiona(obj , 400, 0, 5);
SetStoneShowerexplosiona(obj , 550, 0, 5);
SetStoneShowerexplosiona(obj , 100, 70, 5);
SetStoneShowerexplosiona(obj , 250, 70, 5);
SetStoneShowerexplosiona(obj , 400, 70, 5);
SetStoneShowerexplosiona(obj , 550, 70, 5);
		return true;
		}
	}else if(substate == 1 && isMyControlObject)
	{

	}else if(substate == 2 && isMyControlObject)
	{
		if(flagIndex == 4)
		{
		obj.sq_PlaySound("R_MF_STONESHOWER_END");
		obj.setTimeEvent(0,10 ,1,false);
		obj.sq_SetShake(obj, 8, 200);
		CreateFinishAttack_hit(obj);
SetStoneShowerexplosionagroundC(obj , 250, 0, -1);
SetStoneShowerexplosionC(obj , 250, 0, 1);
SetAttack_FrontD(obj);
		sq_flashScreen(obj,0,0,400,191, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}

	}


}


function onTimeEvent_StoneShower(obj, timeEventIndex, timeEventCount)
{

	local substate = obj.getSkillSubState();

    if (timeEventIndex == 0)
    {
		CreateAttack_hit(obj);
    }

}


function onProc_StoneShower(obj)
{

	if(!obj) return;

	local substate = obj.getSkillSubState();

	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local sq_var = obj.getVar();
	local currentT = sq_GetCurrentTime(pAni);
	
	local posX = obj.getXPos();
	local posY = obj.getYPos();
	local posZ = obj.getZPos();

	if(substate == 0 ) 
	{

		local delayT = pAni.getDelaySum(false);
		local v = sq_GetAccel(0, 300, currentT , delayT, true);
		local srcZ = obj.getVar("posZ").get_vector(0);
		
		local dstZ = sq_GetDistancePos(srcZ, obj.getDirection(), v);
		
		if(obj.isMovablePos(posX, posY ))
		{
			sq_setCurrentAxisPos(obj, 2, v);
		}
	}


}

function onProcCon_StoneShower(obj)
{
	if(!obj) return
	local ani = sq_GetCurrentAnimation(obj)
	local ani_index = sq_GetAnimationFrameIndex(ani)
	if(ani_index < 2)
		return;
	if(sq_IsKeyDown(OPTION_HOTKEY_ATTACK, ENUM_SUBKEY_TYPE_ALL))
	{

	}
}


function onAttack_StoneShower(obj, damager, boundingBox, isStuck)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	if (substate == 1)
		{
	obj.sq_SetShake(obj, 5, 200);
	sq_flashScreen(obj,0,80,240,153, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
}

function onEndCurrentAni_StoneShower(obj)
{

	local substate = obj.getSkillSubState();

		if(substate == 0)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(STATE_STONE_SHOWER,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 1)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(STATE_STONE_SHOWER,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 2)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
		}

	return true;
}


function SetAttack_FrontD(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atstoneshower/stoneshowerfrontd_01.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	
	sq_AddObject(obj,pooledObj,2,false);
}

function SetStoneShowerexplosionC(obj ,disX ,disY ,disZ)
{

	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atfighter/animation/atstoneshower/stoneshowerexplosionc_03.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetStoneShowerexplosionagroundC(obj ,disX ,disY ,disZ)
{

	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atfighter/animation/atstoneshower/stoneshowerexplosioncground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetStoneShowerexplosiona(obj ,disX ,disY ,disZ)
{

	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atfighter/animation/atstoneshower/stoneshowerexplosiona_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}


function SetStoneShowerexplosionaground(obj ,disX ,disY ,disZ)
{

	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atfighter/animation/atstoneshower/stoneshowerexplosionaground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}


function SetStoneShowerSpeed_Front(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atstoneshower/stoneshowerspeed_front.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos() - 1,0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetStoneShowerSpeed_Back(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atstoneshower/stoneshowerspeed_back.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos() - 1,0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}


function SetCast_GroundFrontA(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atstoneshower/stoneshowergroundcracka_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),0);
	pooledObj.setCurrentDirection(obj.getDirection());
	
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetAttack_FrontC(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atstoneshower/stoneshowerfrontc_01.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetAttack_BackA(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atstoneshower/stoneshowerbacka_02.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetAttack_FrontA(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atstoneshower/stoneshowerfronta_02.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),obj.getYPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	
	sq_AddObject(obj,pooledObj,2,false);
}

function CreateAttack_hit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_STONE_SHOWER , STATE_STONE_SHOWER, 3, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atstoneshower/stoneshowermultihitattackbox.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atstoneshowermultihit.atk",true,atk,100,0,0,-300);		
}

function Create_stone_shower_frontcyclone(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_STONE_SHOWER , STATE_STONE_SHOWER, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atstoneshower/stoneshowerfrontcyclone_00.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atstoneshowercyclone.atk",true,atk,100,0,0,0);		
}

function CreateFinishAttack_hit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_STONE_SHOWER , STATE_STONE_SHOWER, 9, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atstoneshower/stoneshowermultihitattackbox.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atstoneshowerdashfinish.atk",true,atk,100,0,0,-300);		
}
