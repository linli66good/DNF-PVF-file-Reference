function checkExecutableSkill_MortalFist(obj)
{

		local isUseSkill = obj.sq_IsUseSkill(SKILL_MORTAL_FIST);
		if (isUseSkill)
		{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(STATE_MORTAL_FIST, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_MortalFist(obj)
{

		return true;

}


function onSetState_MortalFist(obj, state, datas, isResetTimer)
{


	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	local isMyControlObject = obj.sq_IsMyControlObject();
	local skilllevel = sq_GetSkillLevel(obj, SKILL_MORTAL_FIST);
	local ani = null;
	local posX = obj.getXPos();
	local posY = obj.getYPos();
	local posZ = obj.getZPos();

	obj.getVar().clear_vector();
	obj.getVar().push_vector(0);
	obj.getVar().push_vector(0);



		if(substate == 0)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_MORTAL_FIST_CAST);
		}else if(substate == 1)
		{
		ani = obj.getVar().GetAnimationMap("MortalFist_body", "character/fighter/atanimation/mortalfiststartb_addbody.ani"); 
		obj.setCurrentAnimation(ani);

		}else if(substate == 2 && isMyControlObject)
		{
		local group = obj.sq_GetVectorData(datas, 1);
		local uniqueId = obj.sq_GetVectorData(datas, 2);
		local targetObj = sq_GetObject(obj, group, uniqueId);
		obj.getVar().push_vector(posX);
		obj.getVar().push_vector(posY);
		if(targetObj) {
			local disX = sq_Abs(targetObj.getXPos() - posX);
			local disY = targetObj.getYPos() - posY;
			disX = disX - 1;
			if(disX <= 0)
				disX = 0;
			obj.getVar().push_vector(disX); 
			obj.getVar().push_vector(disY); 
		}
		else { 
			local defaultDistance = obj.sq_GetIntData(SKILL_MORTAL_FIST, 1); 
			obj.getVar().push_vector(defaultDistance); 
			obj.getVar().push_vector(0); 
		}
		ani = obj.getVar().GetAnimationMap("MortalFist_attack", "character/fighter/atanimation/mortalfistattack_addbody.ani"); 
		obj.setCurrentAnimation(ani);
		local ani = obj.sq_GetCurrentAni();
		local delay = ani.getDelaySum(false);
		sq_flashScreen(obj,100,delay,300,255, sq_RGB(0,0,0), GRAPHICEFFECT_DARK, ENUM_DRAWLAYER_NORMAL);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_CONTACT);
		}else if(substate == 3)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_MORTAL_FIST_END);

		}


}

function onKeyFrameFlag_MortalFist(obj,flagIndex)
{
	local substate = obj.getSkillSubState();
	local isMyControlObject = obj.sq_IsMyControlObject();
	local pAni = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(pAni);
	if( substate == 1)
	{
	if(flagIndex == 1)
	{
		obj.sq_PlaySound("MTL_FIST_CAST");
		return true;
	}else if(flagIndex == 1)
	{
		obj.sq_SetShake(obj, 3, 180);
		sq_flashScreen(obj,0,60,180,153, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
	}

	}else if(isMyControlObject && substate == 2)
		{

		if(flagIndex == 0)
		{

		return true;
		}else if(flagIndex == 5)
		{
		obj.sq_PlaySound("MF_MTL_FIST_V1_01");

		return true;
		}else if(flagIndex == 6)
		{
CreatMortalFistDashhit_1(obj);
		obj.sq_SetShake(obj, 5, 300);
		sq_flashScreen(obj,0,0,240,153, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 17)
		{
		obj.sq_PlaySound("MF_MTL_FIST_V1_02");

		return true;
		}else if(flagIndex == 19)
		{
CreatMortalFisthit_1(obj);
		obj.sq_SetShake(obj, 10, 80);
		sq_flashScreen(obj,0,0,120,153, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 23)
		{
CreatMortalFisthit_2(obj);
		obj.sq_SetShake(obj, 10, 80);
		sq_flashScreen(obj,0,0,120,153, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 27)
		{
CreatMortalFisthit_3(obj);
		obj.sq_SetShake(obj, 10, 80);
		sq_flashScreen(obj,0,0,120,153, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 35)
		{
		obj.sq_PlaySound("MF_MTL_FIST_V1_03");

		return true;
		}else if(flagIndex == 38)
		{
CreatMortalFisthit_4(obj);
		obj.sq_SetShake(obj, 5, 200);
		sq_flashScreen(obj,0,0,300,153, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 43)
		{

		return true;
		}else if(flagIndex == 45)
		{

		local objectManager = obj.getObjectManager();
		
		if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
		{
			local xPos = objectManager.getFieldXPos(950, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtFighter_Striker_Neo(obj, xPos, yPos)
		}
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
		{
			local xPos = objectManager.getFieldXPos(-100, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtFighter_Striker_Neo(obj, xPos, yPos)
		}

		sq_flashScreen(obj,540,0,0,76, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 46)
		{

		return true;
		}else if(flagIndex == 53)
		{
		obj.sq_PlaySound("MF_MTL_FIST_V3_01");

		return true;
		}else if(flagIndex == 55)
		{
		obj.sq_PlaySound("MF_MTL_FIST_V1_04");

		return true;
		}else if(flagIndex == 56)
		{
CreatMortalFistFinish_1(obj);
		sq_flashScreen(obj,0,60,0,153, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 59)
		{
		sq_flashScreen(obj,240,60,0,102, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 64)
		{
CreatMortalFistFinish_2(obj);
		sq_flashScreen(obj,0,30,0,153, sq_RGB(65,105,225), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 65)
		{
MortalFistSmoke_front(obj);
		sq_flashScreen(obj,0,30,0,153, sq_RGB(238,130,238), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 66)
		{
		sq_flashScreen(obj,0,30,300,153, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}else if(flagIndex == 67)
		{

		return true;
		}else if(flagIndex == 68)
		{
MortalFistSmoke_back(obj);
		return true;
		}

		}
}



function onProc_MortalFist(obj)
{

	if(!obj) return;

	local substate = obj.getSkillSubState();

	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local sq_var = obj.getVar();
	local currentT = sq_GetCurrentTime(pAni);
	
	local posX = obj.getXPos();
	local posY = obj.getYPos();
	local posZ = obj.getZPos();

	if(substate == 0 ) 
	{
	}
	else if(substate == 2 && frmIndex >= 1) 
	{
		local dash_t = pAni.getDelaySum(0, 1) ;
		local dash_z = pAni.getDelaySum(0, 1) ;

		local srcX = obj.getVar().get_vector(2); 
		local srcY = obj.getVar().get_vector(3); 


		local dis_x_len = obj.getVar().get_vector(4);
		local dis_y_len = obj.getVar().get_vector(5);


		local v = sq_GetAccel(0, dis_x_len, currentT, dash_t, true);
		local my = sq_GetUniformVelocity(0, dis_y_len, currentT, dash_t);

		local dstX = sq_GetDistancePos(srcX, obj.getDirection(), v);
		local dstY = srcY + my;

		if(obj.getVar().get_vector(0)) 
		{
			if(obj.getVar().get_vector(1) != posY) 
			{
				obj.getVar().set_vector(0, 0); 
				obj.getVar().set_vector(1, posY);
			}
		}
		 
		if(obj.isMovablePos(dstX, dstY) && !obj.getVar().get_vector(0)) 
		{
			sq_setCurrentAxisPos(obj, 0, dstX);
			sq_setCurrentAxisPos(obj, 1, dstY);
		}
		else 
		{
			obj.getVar().set_vector(0,1);
			local offset = dstX - posX;
			
			if(offset != 0)
			{
				if(offset < 0)
					offset = -offset;
				local totalLen = obj.getVar().get_vector(4); 
				obj.getVar().set_vector(4, totalLen - offset);
			}
		}
	}

}

function onProcCon_MortalFistA(obj)
{
	local substate = obj.getSkillSubState();
	local stateTimer = obj.sq_GetStateTimer();
	local grabMaxTime = 500; 
if (substate == 9)
    {
		if( stateTimer >= 160)
		{
			obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 0);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(STATE_MORTAL_FIST,STATE_PRIORITY_IGNORE_FORCE, true);
			return;
		}
    } else if (substate == 99)
    {
		if( stateTimer >= grabMaxTime)
		{
			obj.sq_AddSetStatePacket(STATE_STAND,STATE_PRIORITY_USER, false);
			return;
		}
    }
}


function onAttack_MortalFist(obj, damager, boundingBox, isStuck)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	if (substate == 2)
		{

		if( !sq_IsFixture(damager)) 
        {
            obj.getVar("dama").push_obj_vector(damager);
            local masterAppendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, SKILL_MORTAL_FIST, false, "character/atfighter_3rd/mortalfist/ap_mortalfist.nut", true);
            if(masterAppendage) 
            {
                
		sq_ChangeDrawLayer(damager, ENUM_DRAWLAYER_COVER);
            }
            sq_SetMyShake(obj,4,150);

        }

		}
}

function onEndCurrentAni_MortalFist(obj)
{

	local substate = obj.getSkillSubState();

		 if(substate == 0)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(STATE_MORTAL_FIST,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 1)
		{

			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);

		local distance = obj.sq_GetIntData(SKILL_MORTAL_FIST, 0);
		local angle = obj.sq_GetIntData(SKILL_MORTAL_FIST, 1); 
		
		local targetObj = findAngleTarget(obj, distance, angle, 100);
		if(targetObj) {
			local group = sq_GetGroup(targetObj);
			local uniqueId = sq_GetUniqueId(targetObj);
			obj.sq_IntVectPush(group); 
			obj.sq_IntVectPush(uniqueId);
		}
		else {
			obj.sq_IntVectPush(-1); 
			obj.sq_IntVectPush(-1); 
		}
			obj.sq_AddSetStatePacket(STATE_MORTAL_FIST,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 2)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(STATE_MORTAL_FIST,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 3)
		{
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);
			obj.sq_AddSetStatePacket(STATE_STAND,STATE_PRIORITY_USER, false);
		}

	return true;
}

function CreatMortalFistDashhit_1(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_MORTAL_FIST , STATE_MORTAL_FIST, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atmortalfist/dashsub.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atmortalfistdashsub.atk",true,atk,100,9,0,-55);		
}

function CreatMortalFisthit_1(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_MORTAL_FIST , STATE_MORTAL_FIST, 1, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atmortalfist/hit1.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atmortalfisthit1.atk",true,atk,100,53,0,50);		
}

function CreatMortalFisthit_2(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_MORTAL_FIST , STATE_MORTAL_FIST, 2, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atmortalfist/hit2.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atmortalfisthit2.atk",true,atk,100,74,0,78);		
}

function CreatMortalFisthit_3(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_MORTAL_FIST , STATE_MORTAL_FIST, 3, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atmortalfist/hit3.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atmortalfisthit3.atk",true,atk,100,49,0,109);		
}

function CreatMortalFisthit_4(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_MORTAL_FIST , STATE_MORTAL_FIST, 4, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atmortalfist/hit4.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atmortalfisthit4.atk",true,atk,100,73,0,133);		
}

function CreatMortalFistFinish_1(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_MORTAL_FIST , STATE_MORTAL_FIST, 5, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atmortalfist/finish1.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atmortalfistfinish1.atk",true,atk,100,52,0,89);		
}

function CreatMortalFistFinish_2(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_MORTAL_FIST , STATE_MORTAL_FIST, 6, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atmortalfist/finish2.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atmortalfistfinish2.atk",true,atk,100,94,0,72);		
}


function MortalFistSmoke_back(obj,damager)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atmortalfist/mortalfistattacksmokeback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentPos(obj.getXPos() + 75 ,obj.getYPos(),obj.getZPos() + 27);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}
function MortalFistSmoke_front(obj,obj)
{
	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atmortalfist/mortalfistattacksmokeback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentPos(obj.getXPos() + 93,obj.getYPos(),obj.getZPos() + 27);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function create_AtFighter_Striker_Neo(obj, xPos, yPos)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atfighter/neo/atfigher_striker_neo.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	pooledObj.setCurrentPos(xPos ,yPos, 0);
	if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
	{	
		pooledObj.setCurrentDirection(ENUM_DIRECTION_RIGHT);
	}
	else if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
	{
		pooledObj.setCurrentDirection(ENUM_DIRECTION_LEFT);
	}
	sq_AddObject(obj, pooledObj, 0, false);
}

