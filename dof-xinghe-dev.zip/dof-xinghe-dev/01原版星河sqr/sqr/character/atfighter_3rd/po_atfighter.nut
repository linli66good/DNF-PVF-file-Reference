function setCustomData_po_New_Atfighter(obj, receiveData)
{
	if(!obj)
	return;

	local attackBonusRate = receiveData.readDword();
	local id = receiveData.readDword();
	obj.getVar("id").clear_vector();
	obj.getVar("id").push_vector(id);


	if (id == 4)
	{
		local BurnProb = receiveData.readDword();
		local BurnTime = receiveData.readDword();
		local BurnAttack = receiveData.readDword();

		local ani = obj.getCustomAnimation(3);
		obj.setCurrentAnimation(ani);
	local addAni = null;
	addAni = obj.getCustomAnimation(4);
	if(ani && addAni)
		ani.addLayerAnimation(2,addAni,false);

		local attackInfo = sq_GetCustomAttackInfo(obj, 2);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);

		sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,ACTIVESTATUS_BURN, BurnProb, BurnTime,BurnAttack);
	}

	if (id == 1)
	{

		local BleedProb = receiveData.readDword();
		local BleedTime = receiveData.readDword();
		local BleedAttack = receiveData.readDword();

		local ani = obj.getCustomAnimation(0);
		obj.setCurrentAnimation(ani);

		local attackInfo = sq_GetCustomAttackInfo(obj, 0);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,ACTIVESTATUS_BLEEDING, BleedProb, BleedTime,BleedAttack);
	}

	if (id == 2)
	{

		local zdProb = receiveData.readDword();
		local zdTime = receiveData.readDword();
		local zdAttack = receiveData.readDword();

		local ani = obj.getCustomAnimation(1);
		obj.setCurrentAnimation(ani);

		local attackInfo = sq_GetCustomAttackInfo(obj, 1);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);

		sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,ACTIVESTATUS_POISON, zdProb, zdTime,zdAttack);
	}

	if (id == 3)
	{

		local BurnProb = receiveData.readDword();
		local BurnTime = receiveData.readDword();
		local BurnAttack = receiveData.readDword();

		local ani = obj.getCustomAnimation(2);
		obj.setCurrentAnimation(ani);

		local attackInfo = sq_GetCustomAttackInfo(obj, 2);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);

		sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,ACTIVESTATUS_BURN, BurnProb, BurnTime,BurnAttack);
	}

}


function onEndCurrentAni_po_New_Atfighter(obj)
{
	local id = obj.getVar("id").get_vector(0);
	if (id == 1)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	if (id == 2)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	if (id == 3)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	if (id == 4)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
}
