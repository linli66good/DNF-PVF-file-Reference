function checkExecutableSkill_BadEnding(obj)
{

		local isUseSkill = obj.sq_IsUseSkill(SKILL_BAD_ENDING);
		if (isUseSkill)
		{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(STATE_BAD_ENDING, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_BadEnding(obj)
{

		return true;

}


function onSetState_BadEnding(obj, state, datas, isResetTimer)
{


	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	local isMyControlObject = obj.sq_IsMyControlObject();
	local skilllevel = sq_GetSkillLevel(obj, SKILL_BAD_ENDING);
	local ani = null;
	local posX = obj.getXPos();
	local posY = obj.getYPos();
	local posZ = obj.getZPos();

	obj.getVar().clear_vector();
if(isMyControlObject)
	{
		if(substate == 0)
		{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_BAD_ENDING_CAST);
BadEnding_UnderScreen(obj);
BadEndingStartDust_Back(obj);
BadEndingStartDust_Bottom(obj);
BadEndingStartDust_Front(obj);
        obj.getVar("Startpos").clear_vector();
        obj.getVar("Startpos").push_vector(obj.getXPos());
        obj.getVar("Startpos").push_vector(obj.getYPos());
        obj.getVar("Startpos").push_vector(obj.getDirection());
		}else if(substate == 1)
		{
		ani = obj.getVar().GetAnimationMap("badending_body", "character/fighter/atanimation/atbadend2sin_body1.ani"); 
		obj.setCurrentAnimation(ani);
		obj.sq_ZStop();
		local zPos = 800;
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), zPos);
BadEndingBody_2(obj);
BadEndingSin1Attack_Front(obj);
BadEndingSin1Attack_Back(obj);
BadEndingSin1Attack_Front00(obj);
BadEndingSin1Attack_Front21(obj);
		}else if(substate == 2)
		{
		ani = obj.getVar().GetAnimationMap("badending_3body", "character/fighter/atanimation/atbadend3sin_body1.ani"); 
		obj.setCurrentAnimation(ani);
BadEndingBody_3(obj);
BadEndingSin1Attack2_Front(obj);
BadEndingSin1Attack2_Back(obj);
		obj.sq_ZStop();
		local zPos = 800;
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), zPos);
		local ani = obj.sq_GetCurrentAni();
		local delay = ani.getDelaySum(false);
		
		}else if(substate == 3)
		{
		ani = obj.getVar().GetAnimationMap("badending_4body", "character/fighter/atanimation/atbadend4sin_body1.ani"); 
		obj.setCurrentAnimation(ani);
BadEndingBody_4(obj);
BadEndingSin2_UnderScreen(obj);
BadEndingSin2_Screen(obj);

		obj.sq_ZStop();
		local zPos = 800;
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), zPos);
		}else if(substate == 4)
		{
		ani = obj.getVar().GetAnimationMap("badending_5body", "character/fighter/atanimation/atbadend5sin_body1.ani"); 
		obj.setCurrentAnimation(ani);
BadEndingBody_5(obj);
BadEndingSin5_Rock(obj);
BadEndingSin3Attack_Front(obj);
BadEndingSin3Attack_Back(obj);
BadEndingSin3Attack_Bottom(obj);
		obj.sq_ZStop();
		local zPos = 800;
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), zPos);
		}else if(substate == 5)
		{
		
		
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_BAD_ENDING_END);
		obj.sq_ZStop();
		local zPos = 800;
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), zPos);
		}
	}
}


function onKeyFrameFlag_BadEnding(obj,flagIndex)
{
	local substate = obj.getSkillSubState();
	local isMyControlObject = obj.sq_IsMyControlObject();
	local pAni = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(pAni);
	local atkCount = obj.sq_GetLevelData(1);
	local atkCount2 = obj.sq_GetLevelData(5);
	local ani = obj.sq_GetCurrentAni();
	local delay = ani.getDelaySum(false);
	local level = sq_GetSkillLevel(obj, SKILL_BAD_ENDING);
	local attackBonusRate = 0;
	if( isMyControlObject)
	{
	if( substate == 0)
	{
	if(flagIndex == 0)
	{
		obj.sq_PlaySound("R_MF_BAD_ENDING_01");
		sq_flashScreen(obj,0,200,0,255, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
	}else if(flagIndex == 1)
		{
		obj.sq_SetShake(obj, 15, 200);
		return true;
		}
	}else if ( substate == 1)
	{

	if(flagIndex == 3)
	{
		obj.setTimeEvent(0,delay / atkCount,0,true);
		return true;
	}else if(flagIndex == 5)
		{
		obj.sq_SetShake(obj, 15, 600);
		return true;
		}

	}else if ( substate == 2)
	{

	if(flagIndex == 1)
	{
		obj.sq_PlaySound("MF_BAD_ENDING_01_LAUGH");
		obj.sq_SetShake(obj, 8, 200);
		obj.setTimeEvent(0,10,1,false);
		BadEndingChainDummyObject(obj);
		return true;
	}else if(flagIndex == 2)
		{
		obj.sq_SetShake(obj, 8, 700);
		return true;
		}else if(flagIndex == 5)
		{
		obj.sq_PlaySound("R_MF_BAD_ENDING_02");

		obj.setTimeEvent(1,delay / atkCount2,0,true);

		obj.sq_SetShake(obj, 8, 700);

		return true;
		}else if(flagIndex == 9)
		{
		obj.setTimeEvent(1,10,1,false);

        attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_BAD_ENDING, STATE_BAD_ENDING, 3, 1.0);
		local BleedProb = sq_GetLevelData(obj, SKILL_BAD_ENDING, 10, level);
		local BleedTime = sq_GetLevelData(obj, SKILL_BAD_ENDING, 9, level);
        local BleedAttack = sq_GetLevelData(obj, SKILL_BAD_ENDING, 11, level);
			obj.sq_StartWrite();
			obj.sq_WriteDword(attackBonusRate);
			obj.sq_WriteDword(1);
			obj.sq_WriteDword(BleedProb);
			obj.sq_WriteDword(BleedTime);
			obj.sq_WriteDword(BleedAttack);
			obj.sq_SendCreatePassiveObjectPacket(24320, 0, 0, 0, -800);
		return true;
		}
	}else if ( substate == 3)
	{

	if(flagIndex == 0)
	{

		return true;
	}

	}else if ( substate == 4)
	{

	if(flagIndex == 5)
	{

sq_setFullScreenEffect(obj,"etc/ultimateskillani/atfigher_streetfighter_neo.ani");
		obj.sq_SetShake(obj, 30, 200);
		obj.sq_PlaySound("R_MF_BAD_ENDING_03");
        attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_BAD_ENDING, STATE_BAD_ENDING, 7, 1.0);
		local zdProb = sq_GetLevelData(obj, SKILL_BAD_ENDING, 13, level);
		local zdTime = sq_GetLevelData(obj, SKILL_BAD_ENDING, 12, level);
        local zdAttack = sq_GetLevelData(obj, SKILL_BAD_ENDING, 14, level);
			obj.sq_StartWrite();
			obj.sq_WriteDword(attackBonusRate);
			obj.sq_WriteDword(2);
			obj.sq_WriteDword(zdProb);
			obj.sq_WriteDword(zdTime);
			obj.sq_WriteDword(zdAttack);
			obj.sq_SendCreatePassiveObjectPacket(24320, 0, 0, 0, -800);
		return true;
	}else if(flagIndex == 12)
		{
        attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_BAD_ENDING, STATE_BAD_ENDING, 8, 1.0);
		local BurnProb = sq_GetLevelData(obj, SKILL_BAD_ENDING, 16, level);
		local BurnTime = sq_GetLevelData(obj, SKILL_BAD_ENDING, 15, level);
        local BurnAttack = sq_GetLevelData(obj, SKILL_BAD_ENDING, 17, level);
			obj.sq_StartWrite();
			obj.sq_WriteDword(attackBonusRate);
			obj.sq_WriteDword(3);
			obj.sq_WriteDword(BurnProb);
			obj.sq_WriteDword(BurnTime);
			obj.sq_WriteDword(BurnAttack);
			obj.sq_SendCreatePassiveObjectPacket(24320, 0, 0, 0, -800);
		obj.sq_SetShake(obj, 10, 800);
		return true;
		}

	}else if ( substate == 5)
	{

	if(flagIndex == 0)
	{
		sq_flashScreen(obj,0,300,100,255, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
	}
	}
	}
}


function onEndCurrentAni_BadEnding(obj)
{

	local substate = obj.getSkillSubState();

		 if(substate == 0)
		{
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	obj.sq_SetCurrentPos(obj, xPos, yPos, 800);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(STATE_BAD_ENDING,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 1)
		{
BadEndingSin1_Screen(obj);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(STATE_BAD_ENDING,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 2)
		{

			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(STATE_BAD_ENDING,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 3)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(STATE_BAD_ENDING,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 4)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(STATE_BAD_ENDING,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 5)
		{
	local startX = obj.getVar("Startpos").get_vector(0);
	local startY = obj.getVar("Startpos").get_vector(1);
	local startDir = obj.getVar("Startpos").get_vector(2);
	obj.sq_SetCurrentPos(obj, startX, startY, 0);
			obj.sq_AddSetStatePacket(0,STATE_PRIORITY_USER, false);
		}

}

function onTimeEvent_BadEnding(obj, timeEventIndex, timeEventCount)
{
	local substate = obj.getSkillSubState();

	if (timeEventIndex == 0)
		{
		BadEndingMultiHitDummyObject1(obj);
		}else if (timeEventIndex == 1)
		{
		BadEndingMultiHitDummyObject2(obj);
		}else if (timeEventIndex == 2)
		{
		}

}

function BadEndingMultiHitDummyObject2(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_BAD_ENDING , STATE_BAD_ENDING, 4, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/Animation/ATBadEnding/ATBadEndingMultiHitDummy2.ani", "passiveobject/new_skill/new_atfighter/AttackInfo/ATBadEndingMultiHitDummy2.atk",true,atk,100,0,0,-800);		
}

function BadEndingChainDummyObject(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_BAD_ENDING , STATE_BAD_ENDING, 3, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/Animation/ATBadEnding/ATBadEndingChainDummy.ani", "passiveobject/new_skill/new_atfighter/AttackInfo/AttackInfo/ATBadEndingChainDummy.atk",true,atk,100,0,0,-800);		
}

function BadEndingMultiHitDummyObject1(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_BAD_ENDING , STATE_BAD_ENDING, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/Animation/ATBadEnding/ATBadEndingMultiHitDummy1.ani", "passiveobject/new_skill/new_atfighter/AttackInfo/ATBadEndingMultiHitDummy1.atk",true,atk,100,0,0,-800);		
}



function BadEndingBody_5(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/atanimation/atbadend5sin_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos - 310 ,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function BadEndingBody_4(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/atanimation/atbadend4sin_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos ,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function BadEndingBody_3(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/atanimation/atbadend3sin_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos ,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function BadEndingBody_2(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/atanimation/atbadend2sin_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos ,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin5_Rock(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadend5sin_rock.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos - 300 ,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin4_Rock(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadend4sin_rock.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function BadEndingSin3_Screen(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin3screencover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(450, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(350, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin3Attack_Bottom(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin3bottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin3Attack_Back(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin3back_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin3Attack_Front(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin3front_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin2_Screen(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin2screencover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(450, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(350, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin2_UnderScreen(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin2undercover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(450, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(350, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function BadEndingSin1Attack2_Back(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin1attack2back_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin1Attack2_Front(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin1attack2front_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function BadEndingSin1Attack_Back(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin1attack1back_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin1Attack_Front(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin1attack1front_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function BadEndingSin1Attack_Front00(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadend_sin1attack1front00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingSin1Attack_Front21(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadend_sin1attack1front21.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEnding_UnderScreen(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendundercover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local XSize = sq_GetUniformVelocity(100, 85, 500,200);
	local SizeRateX = XSize.tofloat()/100.0;
	local YSize = sq_GetUniformVelocity(100, 70, 500,200);
	local SizeRateY = YSize.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRateX, SizeRateY);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRateX);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(300, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(500, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}


function BadEndingSin1_Screen(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendsin1screencover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(450, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(350, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
}

function BadEndingStartDust_Back(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendchaingebodyfxback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos() - 1 ,obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}




function BadEndingStartDust_Bottom(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendchaingebodyfxbottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos() ,obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function BadEndingStartDust_Front(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atbadending/atbadendchaingebodyfxfront_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos() ,obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function onAttack_BadEnding(obj, damager, boundingBox, isStuck)
{
	if(!obj) return;
	
	local attackInfo = sq_GetCurrentAttackInfo(obj);


}

