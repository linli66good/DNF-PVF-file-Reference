
function checkExecutableSkill_GlowingTiger(obj)  
{
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(SKILL_GLOWING_TIGER);
	
	if (isUse)
	{
		obj.sq_AddSetStatePacket(STATE_GLOWING_TIGER , STATE_PRIORITY_USER, false);
		return true;
	}
	
	return false;
}



function checkCommandEnable_GlowingTiger(obj)
{
	if (!obj) return false;
	local state = obj.sq_GetState();
	
	if (state == STATE_STAND)
	
		return true;

		return true;
}


function onSetState_GlowingTiger(obj, state, datas, isResetTimer)
{
		obj.sq_StopMove();
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_GLOWING_TIGER);
		obj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED,SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
		obj.sq_PlaySound("R_MF_GLOWING_TIGER_01");
		obj.sq_StartWrite();
		obj.sq_WriteDword(512);
		obj.sq_SendCreatePassiveObjectPacket(24333, 0, 0, 0, 0);
		if(sq_GetSkillLevel(obj, 237) > 0 && CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut") == true)
		{
		obj.sq_StartWrite();
		obj.sq_WriteDword(514);
		obj.sq_SendCreatePassiveObjectPacket(24333, 0, 0, 0, 0);
		}
}


function onEndCurrentAni_GlowingTiger(obj)
{
	obj.sq_AddSetStatePacket(0, STATE_PRIORITY_USER, false);
}


function onKeyFrameFlag_GlowingTiger(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		if (flagIndex == 10001)
		{
		obj.sq_AddSetStatePacket(0, STATE_PRIORITY_USER, false);
		}
	}
	return true;
}
