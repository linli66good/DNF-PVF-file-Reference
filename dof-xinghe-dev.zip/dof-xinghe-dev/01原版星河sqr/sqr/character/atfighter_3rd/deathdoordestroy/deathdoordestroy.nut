function checkExecutableSkill_DeathDoorDestroy(obj)
{

		local isUseSkill = obj.sq_IsUseSkill(SKILL_DEATH_DOOR_DESTROY);
		if (isUseSkill)
		{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(STATE_DEATH_DOOR_DESTROY, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}


function checkCommandEnable_DeathDoorDestroy(obj)
{

		return true;

}


function onSetState_DeathDoorDestroy(obj, state, datas, isResetTimer)
{


	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	local isMyControlObject = obj.sq_IsMyControlObject();
	local skilllevel = sq_GetSkillLevel(obj, SKILL_DEATH_DOOR_DESTROY);
	local ani = null;
	local posX = obj.getXPos();
	local posY = obj.getYPos();
	local posZ = obj.getZPos();

	obj.getVar().clear_vector();
	obj.getVar().push_vector(0);
	obj.getVar().push_vector(0);
	if( isMyControlObject)
	{
		if(substate == 0)
		{
		ani = obj.getVar().GetAnimationMap("DeathDoorDestroy_Ready", "character/fighter/atanimation/deathdoordestroyreadya_body.ani"); 
		obj.setCurrentAnimation(ani);
	obj.getVar("dama").clear_obj_vector();
        obj.getVar("Startpos").clear_vector();
        obj.getVar("Startpos").push_vector(obj.getXPos());
        obj.getVar("Startpos").push_vector(obj.getYPos());
        obj.getVar("Startpos").push_vector(obj.getDirection());
		}else if(substate == 1)
		{
DeathDoorDestroyDisappear_Ground(obj);

		ani = obj.getVar().GetAnimationMap("DeathDoorDestroy_Dis", "character/fighter/atanimation/deathdoordestroydisappeara_body.ani");
		obj.setCurrentAnimation(ani);
		obj.sq_SetCurrentAttackInfo(64);
		local damage = obj.sq_GetBonusRateWithPassive(SKILL_DEATH_DOOR_DESTROY , STATE_DEATH_DOOR_DESTROY, 0, 1.0);
		obj.sq_SetCurrentAttackBonusRate(damage);
		local group = obj.sq_GetVectorData(datas, 1);
		local uniqueId = obj.sq_GetVectorData(datas, 2);
		local targetObj = sq_GetObject(obj, group, uniqueId);
		obj.getVar().push_vector(posX);
		obj.getVar().push_vector(posY);
		if(targetObj) {
			local disX = sq_Abs(targetObj.getXPos() - posX);
			local disY = targetObj.getYPos() - posY;
			disX = disX - 1;
			if(disX <= 0)
				disX = 0;
			obj.getVar().push_vector(disX); 
			obj.getVar().push_vector(disY); 
		}
		else { 
			local defaultDistance = obj.sq_GetIntData(SKILL_DEATH_DOOR_DESTROY, 1); 
			obj.getVar().push_vector(defaultDistance); 
			obj.getVar().push_vector(0); 
		}
		}else if(substate == 2)
		{
		ani = obj.getVar().GetAnimationMap("DeathDoorDestroy_StartA", "character/fighter/atanimation/deathdoordestroystarta_body.ani"); 
		obj.setCurrentAnimation(ani);
DeathDoorDestroyStart_A(obj);
DeathDoorDestroyStartA_Ground(obj);
        obj.getVar("pos").clear_vector();
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
		}else if(substate == 3)
		{
		ani = obj.getVar().GetAnimationMap("DeathDoorDestroy_Startc", "character/fighter/atanimation/deathdoordestroystartc_body.ani"); 
		obj.setCurrentAnimation(ani);
        obj.getVar("pos").clear_vector();
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
		}else if(substate == 4)
		{
		
		ani = obj.getVar().GetAnimationMap("DeathDoorDestroy_AttackA", "character/fighter/atanimation/deathdoordestroyattacka_body.ani"); 
		obj.setCurrentAnimation(ani);
		DeathDoorDestroyAttack_A(obj);
        obj.getVar("pos").clear_vector();
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
		}else if(substate == 5)
		{
		ani = obj.getVar().GetAnimationMap("DeathDoorDestroy_StartB", "character/fighter/atanimation/deathdoordestroystartb_body.ani"); 
		obj.setCurrentAnimation(ani);
        obj.getVar("pos").clear_vector();
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
		}else if(substate == 6)
		{
		ani = obj.getVar().GetAnimationMap("DeathDoorDestroy_AttackB", "character/fighter/atanimation/deathdoordestroyattackb_body.ani"); 
		obj.setCurrentAnimation(ani);
DeathDoorDestroyAttack_B(obj);
DeathDoorDestroyGround_B(obj);
DeathDoorDestroyBack_B(obj);
        obj.getVar("pos").clear_vector();
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
		}else if(substate == 7)
		{
		ani = obj.getVar().GetAnimationMap("DeathDoorDestroy_End", "character/fighter/atanimation/deathdoordestroyend_body.ani"); 
		obj.setCurrentAnimation(ani);
DeathDoorDestroyEnd_Ground(obj);
        obj.getVar("pos").clear_vector();
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
        obj.getVar("pos").push_vector(0);
		}
	}
}



function onKeyFrameFlag_DeathDoorDestroy(obj,flagIndex)
{
	local substate = obj.getSkillSubState();
	local isMyControlObject = obj.sq_IsMyControlObject();
	local pAni = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(pAni);
	if( isMyControlObject)
    {

	if( substate == 0)
	{
	if(flagIndex == 0)
	{
		obj.sq_PlaySound("MF_DEATHDOORDESTROY_01_1");
		DeathDoorDestroyReady_Ground(obj);
		sq_flashScreen(obj,50,500,0,127, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
	}else if(flagIndex == 3)
	{
		DeathDoorDestroyReady_GroundHit(obj);
		obj.sq_SetShake(obj, 2, 800);
		return true;
	}

	}else if(substate == 1 )
	{
	if(flagIndex == 3)
	{
		return true;
	}else if(flagIndex == 5 )
		{
		return true;
		}
	}else if(substate == 4 )
	{
	if(flagIndex == 0)
	{
		obj.sq_SetShake(obj, 5, 240);
		return true;
	}else if(flagIndex == 4)
		{
		obj.sq_SetShake(obj, 2, 480);
		return true;
		}else if(flagIndex == 8)
		{
		obj.sq_SetShake(obj, 2, 480);
		obj.sq_PlaySound("DEATHDOORDESTROY_SOUND_3_2");
		return true;
		}else if(flagIndex == 12)
		{
		obj.sq_SetShake(obj, 10, 240);
		DeathDoorDestroyAttact_1Hit(obj);
		obj.sq_PlaySound("DEATHDOORDESTROY_SOUND_3_1");
		return true;
		}else if(flagIndex == 16)
		{
		obj.sq_SetShake(obj, 2, 180);
		return true;
		}else if(flagIndex == 19)
		{
		obj.sq_SetShake(obj, 10, 240);
		DeathDoorDestroyAttact_2Hit(obj);
		return true;
		}else if(flagIndex == 29)
		{
		obj.sq_SetShake(obj, 3, 60);
		DeathDoorDestroyAttact_3Hit(obj);
		obj.sq_PlaySound("DEATHDOORDESTROY_SOUND_4_2");
		return true;
		}
	}else if(substate == 5 ) 
	{
		if(flagIndex == 2)
		{
		sq_flashScreen(obj,0,200,0,127, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		return true;
		}
	}else if(substate == 6 ) 
	{
		if(flagIndex == 0)
		{
		DeathDoorDestroyAttact_Grab(obj);
		return true;
		}else if(flagIndex == 5)
		{

		local objectManager = obj.getObjectManager();
		
		if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
		{
			local xPos = objectManager.getFieldXPos(950, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtFighter_Grappler_Neo(obj, xPos, yPos)
		}
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
		{
			local xPos = objectManager.getFieldXPos(-100, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtFighter_Grappler_Neo(obj, xPos, yPos)
		}



		return true;
		}else if(flagIndex == 13)
		{
		obj.sq_PlaySound("DEATHDOORDESTROY_SOUND_4_1");
		return true;
		}else if(flagIndex == 24)
		{
		DeathDoorDestroyAttact_Stone(obj);
		obj.sq_SetShake(obj, 15, 200);
		obj.sq_PlaySound("DEATHDOORDESTROY_SOUND_5");
		return true;
		}else if(flagIndex == 31)
		{
		DeathDoorDestroyAttact_Stone(obj);
		obj.sq_SetShake(obj, 10, 400);
		return true;
		}
	}

    }

}

function onProc_DeathDoorDestroy(obj)
{

	if(!obj) return;

	local substate = obj.getSkillSubState();

	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local sq_var = obj.getVar();
	local currentT = sq_GetCurrentTime(pAni);
	
	local posX = obj.getXPos();
	local posY = obj.getYPos();
	local posZ = obj.getZPos();

	if(substate == 0 ) 
	{
	}
	else if(substate == 1 ) 
	{
		local dash_t = pAni.getDelaySum(false) ;
		local srcX = obj.getVar().get_vector(2); 
		local srcY = obj.getVar().get_vector(3); 
		local dis_x_len = obj.getVar().get_vector(4);
		local dis_y_len = obj.getVar().get_vector(5);
		local v = sq_GetAccel(0, dis_x_len, currentT , dash_t, true);
		local my = sq_GetUniformVelocity(0, dis_y_len, currentT, dash_t);
		local dstX = sq_GetDistancePos(srcX, obj.getDirection(), v);
		local dstY = srcY + my + 1 ;

		if(obj.getVar().get_vector(0)) 
		{
			if(obj.getVar().get_vector(1) != posY) 
			{
				obj.getVar().set_vector(0, 0); 
				obj.getVar().set_vector(1, posY);
			}
		}
		 
		if(obj.isMovablePos(dstX, dstY) && !obj.getVar().get_vector(0)) 
		{
			sq_setCurrentAxisPos(obj, 0, dstX);
			sq_setCurrentAxisPos(obj, 1, dstY);
		}
		else 
		{
			obj.getVar().set_vector(0,1);
			local offset = dstX - posX;
			
			if(offset != 0)
			{
				if(offset < 0)
					offset = -offset;
				local totalLen = obj.getVar().get_vector(4); 
				obj.getVar().set_vector(4, totalLen - offset);
			}
		}
	}else if(substate == 2 ) 
	{
        if (obj.getVar("dama").get_obj_vector_size() > 0)
        {
            for(local i = 0;i< obj.getVar("dama").get_obj_vector_size();++i)
            {
                
                local damager = obj.getVar("dama").get_obj_vector(i);
				if (frmIndex == 6)
                {
                    obj.getVar("pos").set_vector(0,-19);
                    obj.getVar("pos").set_vector(1,0);
                    obj.getVar("pos").set_vector(2,70);
                }else if (frmIndex == 7)
                {
                    obj.getVar("pos").set_vector(0,-8);
                    obj.getVar("pos").set_vector(1,0);
                    obj.getVar("pos").set_vector(2,82);
                }else if (frmIndex == 8)
                {
                    obj.getVar("pos").set_vector(0,9);
                    obj.getVar("pos").set_vector(1,15);
                    obj.getVar("pos").set_vector(2,78);

                }else if (frmIndex == 9)
                {
                    obj.getVar("pos").set_vector(0,24);
                    obj.getVar("pos").set_vector(1,60);
                    obj.getVar("pos").set_vector(2,67);

                }else if (frmIndex == 10)
                {
                    obj.getVar("pos").set_vector(0,33);
                    obj.getVar("pos").set_vector(1,90);
                    obj.getVar("pos").set_vector(2,50);

                }else if (frmIndex == 11)
                {
                    obj.getVar("pos").set_vector(0,36);
                    obj.getVar("pos").set_vector(1,-50);
                    obj.getVar("pos").set_vector(2,32);

                }
				local X = obj.getVar("pos").get_vector(0);
                local Y = obj.getVar("pos").get_vector(1);
                local Z = obj.getVar("pos").get_vector(2) ;
                if (Z < 0 )
                {
                    posZ = 0;
                }
                local dstX = sq_GetDistancePos(obj.getXPos() , obj.getDirection(), X);
                damager.setCurrentPos(dstX,obj.getYPos() + Y,obj.getZPos() + Z);
            }
        }
	} else if(substate == 6 ) 
	{
        if (obj.getVar("dama").get_obj_vector_size() > 0)
        {
            for(local i = 0;i< obj.getVar("dama").get_obj_vector_size();++i)
            {
                
                local damager = obj.getVar("dama").get_obj_vector(i);
				if (frmIndex == 9)
                {
                    obj.getVar("pos").set_vector(0,-9);
                    obj.getVar("pos").set_vector(1,0);
                    obj.getVar("pos").set_vector(2,140);
                }else if (frmIndex == 10)
                {
                    obj.getVar("pos").set_vector(0,-9);
                    obj.getVar("pos").set_vector(1,0);
                    obj.getVar("pos").set_vector(2,137);
                }else if (frmIndex == 11)
                {
                    obj.getVar("pos").set_vector(0,-9);
                    obj.getVar("pos").set_vector(1,0);
                    obj.getVar("pos").set_vector(2,130);
                }else if (frmIndex == 13)
                {
                    obj.getVar("pos").set_vector(0,-7);
                    obj.getVar("pos").set_vector(1,0);
                    obj.getVar("pos").set_vector(2,150);
                }
				local X = obj.getVar("pos").get_vector(0);
                local Y = obj.getVar("pos").get_vector(1);
                local Z = obj.getVar("pos").get_vector(2) ;
                if (Z < 0 )
                {
                    posZ = 0;
                }
                local dstX = sq_GetDistancePos(obj.getXPos() , obj.getDirection(), X);
                damager.setCurrentPos(dstX,obj.getYPos() + Y,obj.getZPos() + Z);
            }
        }
removeAllDeathDoorDestroyAppendage(obj);
	}


}


function onEndCurrentAni_DeathDoorDestroy(obj)
{

	local substate = obj.getSkillSubState();

		 if(substate == 0)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
		local distance = obj.sq_GetIntData(SKILL_DEATH_DOOR_DESTROY, 8);
		local angle = obj.sq_GetIntData(SKILL_DEATH_DOOR_DESTROY, 9); 
		local targetObj = findAngleTarget(obj, distance, angle, 100);
		if(targetObj) {
			local group = sq_GetGroup(targetObj);
			local uniqueId = sq_GetUniqueId(targetObj);
			obj.sq_IntVectPush(group); 
			obj.sq_IntVectPush(uniqueId);
		}
		else {
			obj.sq_IntVectPush(-1); 
			obj.sq_IntVectPush(-1); 
		}
			obj.sq_AddSetStatePacket(STATE_DEATH_DOOR_DESTROY,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 1)
		{
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	obj.sq_SetCurrentPos(obj, xPos, yPos, 0);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(STATE_DEATH_DOOR_DESTROY,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 2)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(STATE_DEATH_DOOR_DESTROY,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 3)
		{

			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(STATE_DEATH_DOOR_DESTROY,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 4)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(5);
			obj.sq_AddSetStatePacket(STATE_DEATH_DOOR_DESTROY,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 5)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6);
			obj.sq_AddSetStatePacket(STATE_DEATH_DOOR_DESTROY,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 6)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(7);
			obj.sq_AddSetStatePacket(STATE_DEATH_DOOR_DESTROY,STATE_PRIORITY_IGNORE_FORCE, true);
		}else if(substate == 7)
		{
		removeAllDeathDoorDestroyAppendage(obj);
	
	
	
	
			obj.sq_AddSetStatePacket(STATE_STAND,STATE_PRIORITY_USER, false);
			
			
			
		}else if(substate == 8)
		{

		}

	return true;
}

function setCurrentPosWithDeathDoorDestroyByOffset(obj,offsetX,offsetY)
{
	local startX = obj.getVar("Startpos").get_vector(0);
	local startY = obj.getVar("Startpos").get_vector(1);
	local startDir = obj.getVar("Startpos").get_vector(2);
	local posX = sq_GetDistancePos(startX, startDir, offsetX);
	local posY = startY + offsetY;
	obj.sq_SetfindNearLinearMovablePos(posX posY,obj.getXPos(), obj.getYPos(), 10);
}


function onAttack_DeathDoorDestroy(obj, damager, boundingBox, isStuck)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	if (substate >= 0 )
		{

		if( !sq_IsFixture(damager)) 
        {
            obj.getVar("dama").push_obj_vector(damager);
            
            local masterAppendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, SKILL_DEATH_DOOR_DESTROY, false, "character/atfighter/deathdoordestroy/ap_deathdoordestroy.nut", true);
            if(masterAppendage) 
            {
                sq_HoldAndDelayDie(damager, obj, true, true, true, 0, 0, ENUM_DIRECTION_DOWN , masterAppendage);
				damager.setCurrentDirection(sq_GetOppositeDirection(obj.getDirection()));
            }
		}

		}
}


function DeathDoorDestroyStart_A(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/start/deathdoordestroystartafront_03.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() - 2,obj.getYPos(),obj.getZPos() - 43);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function DeathDoorDestroyStartA_Ground(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/start/deathdoordestroystartaground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);

	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos(),obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function DeathDoorDestroyReady_Ground(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/ready/deathdoordestroyreadyaground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos(),obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}

function DeathDoorDestroyDisappear_Ground(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/ready/deathdoordestroydisappearb_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos(),obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);	
}


function DeathDoorDestroyAttack_A(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/attack/deathdoordestroyattacka_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local Size = 110;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
    obj.getVar("effectObj").push_obj_vector( pooledObj );
}

function DeathDoorDestroyGround_B(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/attack/deathdoordestroyattackbbackground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
    obj.getVar("effectObj").push_obj_vector( pooledObj );
}

function DeathDoorDestroyBack_B(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/attack/deathdoordestroyattackbback_03.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
    obj.getVar("effectObj").push_obj_vector( pooledObj );
}

function DeathDoorDestroyAttack_B(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/attack/deathdoordestroyattackbfront_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local Size = 100;
	local SizeRate = Size.tofloat()/100.0;
	ani.setImageRateFromOriginal(SizeRate, SizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(SizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);
    obj.getVar("effectObj").push_obj_vector( pooledObj );
}

function DeathDoorDestroyEnd_Ground(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atdeathdoordestroy/end/deathdoordestroyendscreen_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	local size = 100;
	local sizeRate = size.tofloat()/100.0;
	ani.setImageRateFromOriginal(sizeRate, sizeRate);
	ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(300, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	sq_AddObject(obj,pooledObj,2,false);	
}

function DeathDoorDestroyReady_GroundHit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DEATH_DOOR_DESTROY , STATE_DEATH_DOOR_DESTROY, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atdeathdoordestroy/deathdoordestroyreadyaground_00.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atdeathdoordestroygroundsmash.atk",true,atk,100,0,0,0);		
}

function DeathDoorDestroyAttact_1Hit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DEATH_DOOR_DESTROY , STATE_DEATH_DOOR_DESTROY, 4, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atdeathdoordestroy/deathdoordestroyattackbox.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atdeathdoordestroyhit.atk",true,atk,100,0,0,0);		
}

function DeathDoorDestroyAttact_2Hit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DEATH_DOOR_DESTROY , STATE_DEATH_DOOR_DESTROY, 5, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atdeathdoordestroy/deathdoordestroyattackbox.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atdeathdoordestroyhit.atk",true,atk,100,0,0,0);		
}

function DeathDoorDestroyAttact_3Hit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DEATH_DOOR_DESTROY , STATE_DEATH_DOOR_DESTROY, 6, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atdeathdoordestroy/deathdoordestroyattackbox.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atdeathdoordestroyhit.atk",true,atk,100,0,0,0);		
}
function DeathDoorDestroyAttact_Grab(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DEATH_DOOR_DESTROY , STATE_DEATH_DOOR_DESTROY, 7, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atdeathdoordestroy/deathdoordestroyattackbox.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atdeathdoordestroyhit.atk",true,atk,100,0,0,0);		
}
function DeathDoorDestroyAttact_Stone(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_DEATH_DOOR_DESTROY , STATE_DEATH_DOOR_DESTROY, 8, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atdeathdoordestroy/deathdoordestroyattackbox.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atdeathdoordestroyhit.atk",true,atk,100,0,0,0);		
}



function removeAllDeathDoorDestroyAppendage(obj)
{
	if(!obj)
		return;

	local var = obj.getVar();  		
	local objectsSize = var.get_obj_vector_size();
	
	for(local i=0;i<objectsSize;++i)
	{
		local damager = var.get_obj_vector(i);
		if(damager)
			CNSquirrelAppendage.sq_RemoveAppendage(damager, "character/atfighter_3rd/deathdoordestroy/ap_deathdoordestroy.nut");
	}
}

function create_AtFighter_Grappler_Neo(obj, xPos, yPos)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atfighter/neo/atfigher_grappler_neo.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	pooledObj.setCurrentPos(xPos ,yPos, 0);
	if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
	{	
		pooledObj.setCurrentDirection(ENUM_DIRECTION_RIGHT);
	}
	else if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
	{
		pooledObj.setCurrentDirection(ENUM_DIRECTION_LEFT);
	}
	sq_AddObject(obj, pooledObj, 0, false);
}
