function checkExecutableSkill_RoadToHell(obj)  
{

	local isUseSkill = obj.sq_IsUseSkill(SKILL_ROAD_TO_HELL);
	if (isUseSkill) 
	{
		obj.sq_AddSetStatePacket(STATE_ROAD_TO_HELL, STATE_PRIORITY_USER, true);
		return true;
	}
	return false;
}


function checkCommandEnable_RoadToHell(obj)
{

		return true;

}


function onSetState_RoadToHell(obj, state, datas, isResetTimer)
{
		local skilllevel = sq_GetSkillLevel(obj, SKILL_ROAD_TO_HELL);
		obj.sq_StopMove();
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_ROAD_TO_HELL_KICK);













		local damage = obj.sq_GetBonusRateWithPassive(SKILL_ROAD_TO_HELL, STATE_ROAD_TO_HELL, 7, 1.0);
		obj.sq_SetCurrentAttackBonusRate(damage);
		obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);


}

function onEndCurrentAni_RoadToHell(obj)
{
setDelteRoadToHell(obj);
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
}

function onKeyFrameFlag_RoadToHell(obj,flagIndex)
{

	local atkCount = obj.sq_GetLevelData(5);
	local ani = obj.sq_GetCurrentAni();
	local delay = ani.getDelaySum(0,9);

	if (flagIndex == 2)
	{
		sq_flashScreen(obj,400,400,400,127, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			sq_SetMyShake(obj,1,1000);
		return true;
	}else if (flagIndex == 8)
	{

	return true;
	}else if (flagIndex == 10)
	{
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ROAD_TO_HELL, STATE_ROAD_TO_HELL, 10, 1.0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(attackBonusRate);
			obj.sq_WriteDword(4);
			obj.sq_WriteDword( obj.sq_GetLevelData(12) );
			obj.sq_WriteDword( obj.sq_GetLevelData(11) );
			obj.sq_WriteDword( obj.sq_GetLevelData(13) );
			obj.sq_SendCreatePassiveObjectPacket(24320, 0, 200, 1, 0);

			sq_SetMyShake(obj,8,300);

		obj.setTimeEvent(0,10,1,false);

	return true;
	}else if (flagIndex == 14)
	{

	return true;
	}
}

function onTimeEvent_RoadToHell(obj, timeEventIndex, timeEventCount)
{
	local substate = obj.getSkillSubState();

	if (timeEventIndex == 0)
		{
		CreateRoadToHell_hit(obj);
		}else if (timeEventIndex == 1)
		{
		}else if (timeEventIndex == 2)
		{
		}

}

function getScrollBasisPos_RoadToHell(obj)
{
	if (!obj) return;
	local subState = obj.getSkillSubState();

	if (obj.isMyControlObject())
	{
		local dstX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 137);
		local xPos = obj.getXPos();
		local stateTimer = obj.sq_GetStateTimer();
		xPos = sq_GetUniformVelocity(xPos, dstX, stateTimer, 300);
		obj.sq_SetCameraScrollPosition(xPos, obj.getYPos(), 0);
		return true;
	}
	
	return false;
}

function createRoadToHell_Drop(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atroadtohell/barrelbombdrop_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);

}

function createRoadToHell_Drop_Flip(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atroadtohell/barrelbombdropflip_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);

}


function createRoadToHell_loop(obj ,disX ,disY ,disZ)
{
	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atroadtohell/barrelbombrollloop_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);

    obj.getVar("effect").push_obj_vector( pooledObj );
}


function CreateRoadToHell_hit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_ROAD_TO_HELL , STATE_ROAD_TO_HELL, 7, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atroadtohell/atroadtohellmultihitdummyex.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atroadtohellmultihitdummyex.atk",true,atk,100,0,0,0);		
}




function setDelteRoadToHell(obj)
{

    local var = obj.getVar("effect");
    local objectsSize = var.get_obj_vector_size();

    for(local i=0;i<objectsSize;++i)
    {
        local effect = var.get_obj_vector(i);
        if (effect)
        {
            effect.setValid(false);
        }
    }

}


