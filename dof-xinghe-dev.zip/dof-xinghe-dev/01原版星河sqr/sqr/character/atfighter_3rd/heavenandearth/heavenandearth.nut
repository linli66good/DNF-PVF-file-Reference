function checkExecutableSkill_HeavenAndEarth(obj)
{
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(SKILL_HEAVEN_AND_EARTH);

	if (isUse)
	{
		obj.sq_AddSetStatePacket(STATE_HEAVEN_AND_EARTH , STATE_PRIORITY_USER, false);
		return true;
	}

	return false;
}

function checkCommandEnable_HeavenAndEarth(obj)
{
	if (!obj) return false;

	return true;
}


function onSetState_HeavenAndEarth(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	obj.sq_StopMove();
	obj.sq_ZStop();
	local ani = null;


		ani = obj.getVar().GetAnimationMap("HeavenAndEarth_Body", "character/fighter/atanimation/atheavenandearth_body.ani"); 
		obj.setCurrentAnimation(ani);

SetCast_HeavenAndEarth(obj);

		obj.getVar("pos").clear_vector();
		obj.getVar("pos").push_vector(obj.getXPos());
		obj.getVar("pos").push_vector(obj.getYPos());
		obj.getVar("pos").push_vector(obj.getZPos());

}

function onProc_HeavenAndEarth(obj)
{

	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local currentT = sq_GetCurrentTime(pAni);
	local mz = null;
	local nz = null;
	if (frmIndex >= 3 && frmIndex <= 36)
	{
		local delayT = pAni.getDelaySum(2 ,35);
		 mz = sq_GetAccel(0, 10, currentT , delayT, true);
		sq_setCurrentAxisPos(obj, 2, mz);
		
	}else if (frmIndex >= 37 && frmIndex <= 87)
	{
		local delayT = pAni.getDelaySum(37,87);
		currentT = currentT - pAni.getDelaySum(0,36)  ;
		 nz = sq_GetAccel(0, 200, currentT * 2, delayT, true);
		sq_setCurrentAxisPos(obj, 2, nz);
	}



}

function onEndCurrentAni_HeavenAndEarth(obj)
{

	obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
}


function onKeyFrameFlag_HeavenAndEarth(obj,flagIndex)
{
	if(!obj)
		return false;
	local isMyControlObject = obj.sq_IsMyControlObject();

	if (isMyControlObject )
    {
	if(flagIndex == 0)
	{
SetCreateCover01(obj);
SetCreateBackGround(obj);
SetCreateFront(obj);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	obj.sq_SetCurrentPos(obj, xPos, yPos, 0);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_COVER);
		
		return true;
	}else if(flagIndex == 1)
	{
		obj.sq_PlaySound("R_MF_HEAVEN_AND_EARTH_01");
		return true;
	}else if(flagIndex == 24)
	{
		return true;
	}else if(flagIndex == 33)
	{
		obj.sq_PlaySound("R_MF_HEAVEN_AND_EARTH_02");
	obj.sq_SetShake(obj, 2, 300);
		return true;
	}else if(flagIndex == 36)
	{

		local objectManager = obj.getObjectManager();
		
		if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
		{
			local xPos = objectManager.getFieldXPos(950, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtFighter_Nenmaster_Neo(obj, xPos, yPos)
		}
		if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
		{
			local xPos = objectManager.getFieldXPos(-100, ENUM_DRAWLAYER_COVER);
			local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
			
			create_AtFighter_Nenmaster_Neo(obj, xPos, yPos)
		}

		return true;
	}else if(flagIndex == 37)
	{
		obj.sq_SetShake(obj, 1, 700);
		return true;
	}else if(flagIndex == 38)
	{
		return true;
	}else if(flagIndex == 39)
	{
SetCast_HeavenAndEarth_Spectrum(obj);
		return true;
	}else if(flagIndex == 55)
	{
SetCreateHeavenAndEarthBack(obj);
sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_COVER);
		return true;
	}else if(flagIndex == 56)
	{

		return true;
	}else if(flagIndex == 72)
	{
		obj.sq_PlaySound("R_MF_HEAVEN_AND_EARTH_03");
		return true;
	}else if(flagIndex == 80)
	{
SetCreateCover02(obj);
		return true;
	}else if(flagIndex == 87)
	{
HeavenAndEarth_Finish(obj);
	obj.sq_SetShake(obj, 15, 850);
		return true;
	}else if(flagIndex == 88)
	{
		return true;
	}else if(flagIndex == 90)
	{
SetCreateCover03(obj);
		return true;
	}else if(flagIndex == 92)
	{
	local atkCount = obj.sq_GetIntData(SKILL_HEAVEN_AND_EARTH, 2);
	local ani = obj.sq_GetCurrentAni();
	local delay = ani.getDelaySum(92,112);
		obj.setTimeEvent(0,delay / atkCount,0,true);
		return true;
	}else if(flagIndex == 112)
	{
		obj.setTimeEvent(1,10,0,false);
		local Sx = obj.getVar("pos").get_vector(0);
		local Sy = obj.getVar("pos").get_vector(1);
		local Sz = obj.getVar("pos").get_vector(2);
		obj.sq_SetCurrentPos(obj,Sx, Sy, Sz);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);
		return true;
	}else if(flagIndex == 115)
	{
SetCreateEndBody(obj);
SetCreateEndBottom(obj);
SetCreateEndFront(obj);
		return true;
	}else if(flagIndex == 117)
	{
SetCreateEndBack(obj);
		return true;
	}

    }


}

function onTimeEvent_HeavenAndEarth(obj, timeEventIndex, timeEventCount)
{
	if (timeEventIndex == 0)
	{
HeavenAndEarth_FinishMultiHit(obj);
	}else if (timeEventIndex == 1)
	{

	}
}


function SetCreateEndBack(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthendback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(380, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetCreateEndBody(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthspectrumsoft.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetCreateEndFront(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthendfront_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetCreateEndBottom(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthendbottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	
	sq_AddObject(obj,pooledObj,2,false);	
}



function SetCast_HeavenAndEarth(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearth_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_moveWithParent(obj, pooledObj);
	sq_AddObject(obj,pooledObj,2,false);	
}
function SetCast_HeavenAndEarth_Spectrum(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthspectrum.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(),obj.getZPos());
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_moveWithParent(obj, pooledObj);
	sq_AddObject(obj,pooledObj,2,false);	
}


function SetCreateHeavenAndEarthBack(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthback_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(200, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetCreateFront(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthfront_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(380, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	
	sq_AddObject(obj,pooledObj,2,false);	
}


function SetCreateBackGround(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthbackground_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);

	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(500, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	
	sq_AddObject(obj,pooledObj,2,false);
}


function SetCreateCover01(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthcover01_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(500, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetCreateCover02(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthcover02_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(200, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	
	sq_AddObject(obj,pooledObj,2,false);	
}

function SetCreateCover03(obj)
{

	local ani = sq_CreateAnimation("","character/fighter/effect/animation/atheavenandearth/atheavenandearthcover03_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
	local yPos = objectManager.getFieldYPos(200, 0, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(xPos ,yPos,0);
	
	sq_AddObject(obj,pooledObj,2,false);	
}


function HeavenAndEarth_Finish(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_HEAVEN_AND_EARTH , STATE_HEAVEN_AND_EARTH, 0, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atheavenandearth/atheavenandearthfinish.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atheavenandearthfinish.atk",true,atk,100,0,0,0);		
}

function HeavenAndEarth_FinishMultiHit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_HEAVEN_AND_EARTH , STATE_HEAVEN_AND_EARTH, 1, 1.0);
	sq_createAttackObjectWithPath(obj, "passiveobject/new_skill/new_atfighter/animation/atheavenandearth/atheavenandearthfinishmultihit.ani", "passiveobject/new_skill/new_atfighter/attackinfo/atheavenandearthfinishmultihit.atk",true,atk,100,0,0,0);		
}

function create_AtFighter_Nenmaster_Neo(obj, xPos, yPos)
{
	local ani = sq_CreateAnimation("","passiveobject/new_skill/new_atfighter/neo/atfigher_nenmaster_neo.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	pooledObj.setCurrentPos(xPos ,yPos, 0);
	if (sq_GetDirection(obj) == ENUM_DIRECTION_RIGHT)
	{	
		pooledObj.setCurrentDirection(ENUM_DIRECTION_RIGHT);
	}
	else if (sq_GetDirection(obj) == ENUM_DIRECTION_LEFT)
	{
		pooledObj.setCurrentDirection(ENUM_DIRECTION_LEFT);
	}
	sq_AddObject(obj, pooledObj, 0, false);
}
