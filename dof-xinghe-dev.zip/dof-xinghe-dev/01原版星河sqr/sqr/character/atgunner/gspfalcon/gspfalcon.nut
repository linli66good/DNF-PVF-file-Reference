





 
function checkExecutableSkill_atgunner_gspfalcon(uG_GG7WDDWHfa1WnV_ZbX)
{
 if(!uG_GG7WDDWHfa1WnV_ZbX) return false; 
 local WxaRxFm1SHcmggJteK6 = onGetMyPassiveObject_My(uG_GG7WDDWHfa1WnV_ZbX, 24376, 247, 1); 
 if(WxaRxFm1SHcmggJteK6)
 return true;
 local uoQrgXbhfy4kZvivxqRHrSJ = uG_GG7WDDWHfa1WnV_ZbX.sq_IsUseSkill(247); 
 if(uoQrgXbhfy4kZvivxqRHrSJ) 
 {
 uG_GG7WDDWHfa1WnV_ZbX.sq_IntVectClear();
 uG_GG7WDDWHfa1WnV_ZbX.sq_IntVectPush(0); 
 uG_GG7WDDWHfa1WnV_ZbX.sq_AddSetStatePacket(247, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_gspfalcon(K_j1DiRSUgpd)
{
 if(!K_j1DiRSUgpd) return false; 
 local sQiKj5YJp72RghelVNu = onGetMyPassiveObject_My(K_j1DiRSUgpd, 24376, 247, 1); 
 if(sQiKj5YJp72RghelVNu)
 return false;
 local i4TAMi8n3BPUYTlTuQLsTpc = K_j1DiRSUgpd.sq_GetState(); 
 if(i4TAMi8n3BPUYTlTuQLsTpc == STATE_STAND) 
 return true; 
 if(i4TAMi8n3BPUYTlTuQLsTpc == STATE_ATTACK) 
 {
 return K_j1DiRSUgpd.sq_IsCommandEnable(247); 
 }
 return true; 
} 

 
function onSetState_atgunner_gspfalcon(K_j1DiRSUgpd, sQiKj5YJp72RghelVNu, i4TAMi8n3BPUYTlTuQLsTpc, zhgZjpSj3lc8VnZ9B7FfgfB)
{
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 if(!K_j1DiRSUgpd) return; 
 local Nmws5VuJQDdmZu7AeoEe9 = K_j1DiRSUgpd.sq_GetVectorData(i4TAMi8n3BPUYTlTuQLsTpc, 0); 
 K_j1DiRSUgpd.setSkillSubState(Nmws5VuJQDdmZu7AeoEe9); 
 switch(Nmws5VuJQDdmZu7AeoEe9)
 {
 case 0:
 K_j1DiRSUgpd.getVar().clear_vector(); 
 K_j1DiRSUgpd.sq_StopMove(); 
 K_j1DiRSUgpd.sq_SetCurrentAnimation(137);
 local SPOPgbb8x_lTVK = sq_GetSkillLevel(K_j1DiRSUgpd, 247); 
 local ca7wYm9wpuU = sq_GetCastTime(K_j1DiRSUgpd, 247, SPOPgbb8x_lTVK); 
 local eq5SSWRKzRfbApkof6yauRFN = sq_GetCurrentAnimation(K_j1DiRSUgpd); 
 local qxSmngzObxNgtI3o1 = sq_GetFrameStartTime(eq5SSWRKzRfbApkof6yauRFN, 3); 
 local HNWld8KGr1dAjg7uA6L = qxSmngzObxNgtI3o1.tofloat() / ca7wYm9wpuU.tofloat(); 
 K_j1DiRSUgpd.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED,
 SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, HNWld8KGr1dAjg7uA6L, HNWld8KGr1dAjg7uA6L);
 sq_StartDrawCastGauge(K_j1DiRSUgpd, qxSmngzObxNgtI3o1, true);
 break;
 case 1:
 K_j1DiRSUgpd.sq_SetCurrentAnimation(138);
 K_j1DiRSUgpd.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
 if(K_j1DiRSUgpd.sq_IsMyControlObject())
 {
 
 
 local BtCJeHzC8hw2tN = 10; 
 if(K_j1DiRSUgpd.getMyPassiveObjectCount(22249) > 0) BtCJeHzC8hw2tN = 11; 
 else if(K_j1DiRSUgpd.getMyPassiveObjectCount(22251) > 0) BtCJeHzC8hw2tN = 12; 
 local SPOPgbb8x_lTVK = sq_GetSkillLevel(K_j1DiRSUgpd, 247); 
 K_j1DiRSUgpd.sq_StartWrite();
 K_j1DiRSUgpd.sq_WriteDword(247); 
 K_j1DiRSUgpd.sq_WriteDword(1); 
 K_j1DiRSUgpd.sq_WriteDword(K_j1DiRSUgpd.sq_GetLevelData(247, 0, SPOPgbb8x_lTVK)); 
 K_j1DiRSUgpd.sq_WriteDword(K_j1DiRSUgpd.sq_GetLevelData(247, 1, SPOPgbb8x_lTVK)); 
 K_j1DiRSUgpd.sq_WriteDword(BtCJeHzC8hw2tN); 
 K_j1DiRSUgpd.sq_SendCreatePassiveObjectPacket(24376, 0, 0, 0, 0);
 }
 break;
 }
} 

 
function onEndCurrentAni_atgunner_gspfalcon(YJlyKsrm000U57V1MIiX)
{
 if(!YJlyKsrm000U57V1MIiX) return;
 if(!YJlyKsrm000U57V1MIiX.sq_IsMyControlObject()) return;
 local fbYKGbwoisq5m7Q = YJlyKsrm000U57V1MIiX.getSkillSubState(); 
 switch(fbYKGbwoisq5m7Q)
 {
 case 0:
 YJlyKsrm000U57V1MIiX.sq_IntVectClear();
 YJlyKsrm000U57V1MIiX.sq_IntVectPush(1); 
 YJlyKsrm000U57V1MIiX.sq_AddSetStatePacket(247, STATE_PRIORITY_USER, true); 
 break;
 case 1:
 YJlyKsrm000U57V1MIiX.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 }
} 


if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onEndState_atgunner_gspfalcon(h1LzJvtnXF, PjpVSX8x2oN7r8nkW)
{
 if(!h1LzJvtnXF) return;
 if(PjpVSX8x2oN7r8nkW != 247)
 sq_EndDrawCastGauge(h1LzJvtnXF); 
} 


