function checkExecutableSkill_ATLockOnSupport(obj)
{
	if(!obj) return false;
	local isUse = obj.sq_IsUseSkill(SKILL_ATLockOnSupport);
	if(isUse)
	{
		obj.sq_IntVectClear();
		if(sq_GetZPos(obj) > 0)
			obj.sq_IntVectPush(2);
		else
			obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(STATE_ATLockOnSupport, STATE_PRIORITY_USER, true);
		return true;
	}
	return false;
}

function checkCommandEnable_ATLockOnSupport(obj)
{
	if(!obj) return;
	local state = obj.sq_GetState();
	return true;
}

function onSetState_ATLockOnSupport(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();
	obj.sq_ZStop();
	switch(subState)
	{
		case 0:
			local ani = obj.sq_GetThrowChargeAni(2);
			obj.setCurrentAnimation(ani);
			sq_SetFrameDelayTime(ani, 0, 200);
		break;
		case 1:
			local ani = obj.sq_GetThrowShootAni(2);
			obj.setCurrentAnimation(ani);
			sq_SetFrameDelayTime(ani, 1, 500);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATLockOnSupport, STATE_ATLockOnSupport, 0, 1.0);
			local skill_level = sq_GetSkillLevel(obj, SKILL_ATLockOnSupport);	
			local STUN_prob = sq_GetLevelData(obj, SKILL_ATLockOnSupport, 1, skill_level) / 10;
			local STUN_lv = sq_GetLevelData(obj, SKILL_ATLockOnSupport, 2, skill_level);
			local STUN_time = sq_GetLevelData(obj, SKILL_ATLockOnSupport, 3, skill_level);
			obj.sq_StartWrite();
			obj.sq_WriteDword(attackBonusRate);
			obj.sq_WriteDword(0);
			obj.sq_WriteWord(0);
			obj.sq_WriteDword(1);
			obj.sq_WriteDword(obj.sq_GetIntData(SKILL_ATLockOnSupport, 0));
			obj.sq_WriteDword(obj.sq_GetIntData(SKILL_ATLockOnSupport, 1));
			obj.sq_WriteDword(STUN_prob);
			obj.sq_WriteDword(STUN_lv);
			obj.sq_WriteDword(STUN_time);
			obj.sq_SendCreatePassiveObjectPacket(24201, 0, 120, 1, 0);
		break;
		case 2:
			obj.sq_SetCurrentAnimation(61);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATLockOnSupport, STATE_ATLockOnSupport, 0, 1.0);
			local skill_level = sq_GetSkillLevel(obj, SKILL_ATLockOnSupport);	
			local STUN_prob = sq_GetLevelData(obj, SKILL_ATLockOnSupport, 1, skill_level) / 10;	
			local STUN_lv = sq_GetLevelData(obj, SKILL_ATLockOnSupport, 2, skill_level);
			local STUN_time = sq_GetLevelData(obj, SKILL_ATLockOnSupport, 3, skill_level);
			obj.sq_StartWrite();
			obj.sq_WriteDword(attackBonusRate);
			obj.sq_WriteDword(0);
			obj.sq_WriteWord(0);
			obj.sq_WriteDword(2);
			obj.sq_WriteDword(obj.sq_GetIntData(SKILL_ATLockOnSupport, 0));
			obj.sq_WriteDword(obj.sq_GetIntData(SKILL_ATLockOnSupport, 1));
			obj.sq_WriteDword(STUN_prob);
			obj.sq_WriteDword(STUN_lv);
			obj.sq_WriteDword(STUN_time);
			obj.sq_WriteDword(sq_GetZPos(obj));
			obj.sq_SendCreatePassiveObjectPacket(24201, 0, 120, 1, 0);
		break;
	}
}

function onEndCurrentAni_ATLockOnSupport(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(subState + 1);
			obj.sq_AddSetStatePacket(STATE_ATLockOnSupport, STATE_PRIORITY_USER, true);
		break;
		case 1:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(200);
			obj.sq_AddSetStatePacket(6, STATE_PRIORITY_USER, true);
		break;
	}
}
