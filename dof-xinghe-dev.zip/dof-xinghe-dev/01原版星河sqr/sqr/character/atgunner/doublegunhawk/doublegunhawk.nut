function atgunner_doublegunhawk(obj)
{
	if(sq_GetSkillLevel(obj, 16)<1) return;
	local WeaponSubType = obj.getWeaponSubType();
	if(WeaponSubType == 0 && SetIsInterval(obj, 50, "shuangying"))
	{
		local count = obj.getMyPassiveObjectCount(22254);
		local aRange = obj.sq_GetIntData(51, 21);
		for(local i=0;i<count;++i)
		{
			local object = obj.getMyPassiveObject(22254, i);
			if(!object) continue;
			if(!object.getVar("isLimit").getBool(0))
			{
				object.getVar("isLimit").setBool(0,true);
				local range = 500;
				local suckVel = 500;
				local dis = sq_GetDistanceObject(object, obj, true);
	
					local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, object, 38, false, "Character/ATMage/DarknessMantle/ap_ATDarknessMantle_suck.nut", false);
					appendage.sq_SetValidTime(200);
					if(appendage)
					{
						local pAni = object.getCurrentAnimation();
						local sizeRate = aRange;
						sizeRate = sizeRate.tofloat()/100.0;
						pAni.setImageRateFromOriginal(sizeRate, sizeRate);
						pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
						sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
						CNSquirrelAppendage.sq_Append(appendage, obj, object);
						local auraAppendage = appendage.sq_getAuraMaster("auraMaster1");
						if(!auraAppendage)
							auraAppendage = appendage.sq_AddAuraMaster("auraMaster1", obj, object, 1200, 18, 5, 0);
						if(auraAppendage)
							auraAppendage.setAttractionInfo(suckVel, suckVel, range, 1200);
					}
				
				
	
			}
		}
	}
}

