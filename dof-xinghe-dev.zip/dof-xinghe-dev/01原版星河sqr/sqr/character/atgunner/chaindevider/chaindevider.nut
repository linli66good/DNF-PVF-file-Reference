






 
function checkExecutableSkill_atgunner_chaindevider(iEAWniCoQoPkEPvPs2U3qw)
{
 if(!iEAWniCoQoPkEPvPs2U3qw) return false; 
 local JrCNUDD2_DcY6nmo = iEAWniCoQoPkEPvPs2U3qw.sq_IsUseSkill(238); 
 if(JrCNUDD2_DcY6nmo) 
 {
 iEAWniCoQoPkEPvPs2U3qw.sq_IntVectClear();
 iEAWniCoQoPkEPvPs2U3qw.sq_IntVectPush(0); 
 iEAWniCoQoPkEPvPs2U3qw.sq_AddSetStatePacket(238, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_chaindevider(iEAWniCoQoPkEPvPs2U3qw)
{
 if(!iEAWniCoQoPkEPvPs2U3qw) return false; 
 local JrCNUDD2_DcY6nmo = iEAWniCoQoPkEPvPs2U3qw.sq_GetState(); 
 if(JrCNUDD2_DcY6nmo == STATE_STAND) 
 return true; 
 if(JrCNUDD2_DcY6nmo == STATE_ATTACK) 
 {
 return iEAWniCoQoPkEPvPs2U3qw.sq_IsCommandEnable(238); 
 }
 return true; 
} 

 
function onSetState_atgunner_chaindevider(KG9HvkBux5rj, VcluzZw5Z2dvUL6YIyjw5ddk, xluIEyUQBGyWlT, K6BSFpKQKEF)
{
 if(!KG9HvkBux5rj) return; 
 local HuKm90N5jChiFIBA3K4tWo = KG9HvkBux5rj.sq_GetVectorData(xluIEyUQBGyWlT, 0); 
 KG9HvkBux5rj.setSkillSubState(HuKm90N5jChiFIBA3K4tWo); 
 switch(HuKm90N5jChiFIBA3K4tWo)
 {
 case 0:
 KG9HvkBux5rj.sq_StopMove(); 
 KG9HvkBux5rj.sq_SetCurrentAnimation(118);
 KG9HvkBux5rj.sq_SetCurrentAttackInfo(28);
 local MhWY_bZj4HjXa5t = KG9HvkBux5rj.sq_GetBonusRateWithPassive(238, 238, 0, 1.0); 
 KG9HvkBux5rj.sq_SetCurrentAttackBonusRate(MhWY_bZj4HjXa5t); 
 break;
 case 1:
 KG9HvkBux5rj.sq_SetCurrentAnimation(119);
 KG9HvkBux5rj.sq_SetCurrentAttackInfo(29);
 local MhWY_bZj4HjXa5t = KG9HvkBux5rj.sq_GetBonusRateWithPassive(238, 238, 1, 1.0); 
 KG9HvkBux5rj.sq_SetCurrentAttackBonusRate(MhWY_bZj4HjXa5t); 
 break;
 case 2:
 KG9HvkBux5rj.sq_SetCurrentAnimation(120);
 KG9HvkBux5rj.sq_SetCurrentAttackInfo(30);
 local MhWY_bZj4HjXa5t = KG9HvkBux5rj.sq_GetBonusRateWithPassive(238, 238, 2, 1.0); 
 KG9HvkBux5rj.sq_SetCurrentAttackBonusRate(MhWY_bZj4HjXa5t); 
 break;
 }
 KG9HvkBux5rj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0); 
} 

function onAttack_atgunner_chaindevider(didWRqz708, FAjZSmZIqDjiJqmqyArelna, HULXMkupqZ, pitsrnwHuH0vk30tgFVl)
{
 if(!didWRqz708) return;
 if(pitsrnwHuH0vk30tgFVl || !FAjZSmZIqDjiJqmqyArelna.isObjectType(OBJECTTYPE_ACTIVE))return;
} 


if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onKeyFrameFlag_atgunner_chaindevider(didWRqz708, FAjZSmZIqDjiJqmqyArelna)
{
 if(!didWRqz708) return false;
 local HULXMkupqZ = didWRqz708.getSkillSubState(); 
 if(HULXMkupqZ == 2 && FAjZSmZIqDjiJqmqyArelna == 1 && didWRqz708.sq_IsMyControlObject())
 {
 sq_SetMyShake(didWRqz708, 6, 100); 
 sq_flashScreen(didWRqz708, 0, 0, 400, 178, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM); 
 }
 return true;
} 

 
function onEndCurrentAni_atgunner_chaindevider(BzDHEac6CCjA3RK)
{
 if(!BzDHEac6CCjA3RK) return;
 if(!BzDHEac6CCjA3RK.sq_IsMyControlObject()) return;
 local mpZoI7Lhla4YR8jXB = BzDHEac6CCjA3RK.getSkillSubState(); 
 if(mpZoI7Lhla4YR8jXB != 2)
 {
 BzDHEac6CCjA3RK.sq_IntVectClear();
 BzDHEac6CCjA3RK.sq_IntVectPush(mpZoI7Lhla4YR8jXB + 1); 
 BzDHEac6CCjA3RK.sq_AddSetStatePacket(238, STATE_PRIORITY_USER, true); 
 }
 else
 BzDHEac6CCjA3RK.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
} 



