






 
function checkExecutableSkill_atgunner_g4(iEAWniCoQoPkEPvPs2U3qw)
{
 if(!iEAWniCoQoPkEPvPs2U3qw) return false; 
 if(!checkPassiveObjectIsSub_qq506807329_atgunner_g4(iEAWniCoQoPkEPvPs2U3qw))
 return false;
 local JrCNUDD2_DcY6nmo = iEAWniCoQoPkEPvPs2U3qw.sq_IsUseSkill(246); 
 if(JrCNUDD2_DcY6nmo) 
 {
 iEAWniCoQoPkEPvPs2U3qw.sq_IntVectClear();
 iEAWniCoQoPkEPvPs2U3qw.sq_IntVectPush(0); 
 iEAWniCoQoPkEPvPs2U3qw.sq_AddSetStatePacket(246, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_g4(KG9HvkBux5rj)
{
 if(!KG9HvkBux5rj) return false; 
 local VcluzZw5Z2dvUL6YIyjw5ddk = KG9HvkBux5rj.sq_GetState(); 
 if(VcluzZw5Z2dvUL6YIyjw5ddk == STATE_STAND) 
 return true; 
 if(VcluzZw5Z2dvUL6YIyjw5ddk == STATE_ATTACK) 
 {
 return KG9HvkBux5rj.sq_IsCommandEnable(246); 
 }
 return true; 
} 

 
function onSetState_atgunner_g4(KG9HvkBux5rj, VcluzZw5Z2dvUL6YIyjw5ddk, xluIEyUQBGyWlT, K6BSFpKQKEF)
{
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 if(!KG9HvkBux5rj) return; 
 local HuKm90N5jChiFIBA3K4tWo = KG9HvkBux5rj.sq_GetVectorData(xluIEyUQBGyWlT, 0); 
 KG9HvkBux5rj.setSkillSubState(HuKm90N5jChiFIBA3K4tWo); 
 switch(HuKm90N5jChiFIBA3K4tWo)
 {
 case 0:
 KG9HvkBux5rj.getVar().clear_vector(); 
 KG9HvkBux5rj.sq_StopMove(); 
 KG9HvkBux5rj.sq_SetCurrentAnimation(137);
 local MhWY_bZj4HjXa5t = sq_GetSkillLevel(KG9HvkBux5rj, 246); 
 local YcmOXOYM6f7 = sq_GetCastTime(KG9HvkBux5rj, 246, MhWY_bZj4HjXa5t); 
 local _nmtxXL9nsNnbcazd = sq_GetCurrentAnimation(KG9HvkBux5rj); 
 local UTHDxP2WliSRmRjfjbyeh = sq_GetFrameStartTime(_nmtxXL9nsNnbcazd, 3); 
 local s5nyb1qhfeEpSzIt = UTHDxP2WliSRmRjfjbyeh.tofloat() / YcmOXOYM6f7.tofloat(); 
 KG9HvkBux5rj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED,
 SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, s5nyb1qhfeEpSzIt, s5nyb1qhfeEpSzIt);
 sq_StartDrawCastGauge(KG9HvkBux5rj, UTHDxP2WliSRmRjfjbyeh, true);
 break;
 case 1:
 KG9HvkBux5rj.sq_SetCurrentAnimation(138);
 KG9HvkBux5rj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED,
 SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
 if(KG9HvkBux5rj.sq_IsMyControlObject())
 {
 
 local MhWY_bZj4HjXa5t = sq_GetSkillLevel(KG9HvkBux5rj, 246); 
 KG9HvkBux5rj.sq_StartWrite();
 KG9HvkBux5rj.sq_WriteDword(246); 
 KG9HvkBux5rj.sq_WriteDword(1); 
 KG9HvkBux5rj.sq_WriteDword(KG9HvkBux5rj.sq_GetBonusRateWithPassive(246, 246, 1, 1.0)); 
 KG9HvkBux5rj.sq_WriteDword(KG9HvkBux5rj.sq_GetBonusRateWithPassive(246, 246, 3, 1.0)); 
 KG9HvkBux5rj.sq_WriteDword(KG9HvkBux5rj.sq_GetLevelData(246, 0, MhWY_bZj4HjXa5t)); 
 KG9HvkBux5rj.sq_WriteDword(KG9HvkBux5rj.sq_GetLevelData(246, 2, MhWY_bZj4HjXa5t)); 
 KG9HvkBux5rj.sq_WriteDword(KG9HvkBux5rj.sq_GetLevelData(246, 4, MhWY_bZj4HjXa5t)); 
 KG9HvkBux5rj.sq_WriteDword(KG9HvkBux5rj.sq_GetLevelData(246, 5, MhWY_bZj4HjXa5t)); 
 KG9HvkBux5rj.sq_SendCreatePassiveObjectPacket(24376, 0, 0, 0, 0);
 }
 KG9HvkBux5rj.sq_PlaySound("FG_G4"); 
 break;
 }
} 

 
function onEndCurrentAni_atgunner_g4(UTw2Wcb5GOCAgHLrhA4jE)
{
 if(!UTw2Wcb5GOCAgHLrhA4jE) return;
 if(!UTw2Wcb5GOCAgHLrhA4jE.sq_IsMyControlObject()) return;
 local nMA5_5v2Radcgoxd4naQV2 = UTw2Wcb5GOCAgHLrhA4jE.getSkillSubState(); 
 switch(nMA5_5v2Radcgoxd4naQV2)
 {
 case 0:
 UTw2Wcb5GOCAgHLrhA4jE.sq_IntVectClear();
 UTw2Wcb5GOCAgHLrhA4jE.sq_IntVectPush(1); 
 UTw2Wcb5GOCAgHLrhA4jE.sq_AddSetStatePacket(246, STATE_PRIORITY_USER, true); 
 break;
 case 1:
 UTw2Wcb5GOCAgHLrhA4jE.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 }
} 

function onEndState_atgunner_g4(w8gHOr3BsSE3watvO9, vpdIkgMitWQQdAA2POVW3x9)
{
 if(!w8gHOr3BsSE3watvO9) return;
 if(vpdIkgMitWQQdAA2POVW3x9 != 246)
 sq_EndDrawCastGauge(w8gHOr3BsSE3watvO9); 
} 


if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function setSonPassiveObjectIsProc_qq506807329_atgunner_g4(w8gHOr3BsSE3watvO9)
{
 local vpdIkgMitWQQdAA2POVW3x9 = w8gHOr3BsSE3watvO9.getMyPassiveObjectCount(24376); 
 for(local BiUCLkGhOStoYkBjPBH = 0; BiUCLkGhOStoYkBjPBH < vpdIkgMitWQQdAA2POVW3x9; BiUCLkGhOStoYkBjPBH++)
 {
 local GwualivHFmJV8AA = w8gHOr3BsSE3watvO9.getMyPassiveObject(24376, BiUCLkGhOStoYkBjPBH); 
 if(!GwualivHFmJV8AA)continue;
 sq_BinaryStartWrite();
 sq_BinaryWriteBool(false);
 sq_SendChangeSkillEffectPacket(GwualivHFmJV8AA, 246); 
 }
} 

function checkPassiveObjectIsSub_qq506807329_atgunner_g4(w8gHOr3BsSE3watvO9)
{
 local vpdIkgMitWQQdAA2POVW3x9 = onGetMyPassiveObject_My(w8gHOr3BsSE3watvO9, 24376, 246, 1); 
 if(vpdIkgMitWQQdAA2POVW3x9)
 {
 if(vpdIkgMitWQQdAA2POVW3x9.getState() == 13) return false; 
 local BiUCLkGhOStoYkBjPBH = 0; 
 local GwualivHFmJV8AA = vpdIkgMitWQQdAA2POVW3x9.getMyPassiveObjectCount(24376); 
 for(local D4jFGqLWclgi = 0; D4jFGqLWclgi < GwualivHFmJV8AA; D4jFGqLWclgi++)
 {
 local QL7YHKD1slQVME9Vp9CID = vpdIkgMitWQQdAA2POVW3x9.getMyPassiveObject(24376, D4jFGqLWclgi); 
 if(!QL7YHKD1slQVME9Vp9CID)continue;
 if(QL7YHKD1slQVME9Vp9CID.getVar("isProc").getBool(0) == true)
 switch(QL7YHKD1slQVME9Vp9CID.getState())
 {
 case 13:
 case 16:
 BiUCLkGhOStoYkBjPBH++; 
 break;
 }
 }
 
 if(BiUCLkGhOStoYkBjPBH != GwualivHFmJV8AA) return false;
 local Ov2nWpYH0Xt3iIOuaZ_8 = w8gHOr3BsSE3watvO9.getXPos(); 
 local UJLHnPUeozWMGrQ = w8gHOr3BsSE3watvO9.getYPos(); 
 local guzdvlIIVslr2H1ITa2 = w8gHOr3BsSE3watvO9.getDirection(); 
 
 local pA2Q_ROjT4xx7T4RbDKq = vpdIkgMitWQQdAA2POVW3x9.getVar("isHome").get_vector(0);
 if(pA2Q_ROjT4xx7T4RbDKq == 1)
 {
 local pZrulqxkXszq = sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL); 
 local bbrZfXAu3KKN6gShqLzZn0J = sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL); 
 
 
 local jnztMAA0arebhThNkZ72do = w8gHOr3BsSE3watvO9.sq_GetLevelData(246, 5, sq_GetSkillLevel(w8gHOr3BsSE3watvO9, 246));
 
 local GA2Az_idkUgmJjc = 2; 
 
 local j6KTZwr_vzvlUL = -1;
 
 if(guzdvlIIVslr2H1ITa2 == ENUM_DIRECTION_LEFT && pZrulqxkXszq
 || guzdvlIIVslr2H1ITa2 == ENUM_DIRECTION_RIGHT && bbrZfXAu3KKN6gShqLzZn0J)
 {
 Ov2nWpYH0Xt3iIOuaZ_8 = w8gHOr3BsSE3watvO9.sq_findNearLinearMovableXPos(sq_GetDistancePos(Ov2nWpYH0Xt3iIOuaZ_8, guzdvlIIVslr2H1ITa2, jnztMAA0arebhThNkZ72do), UJLHnPUeozWMGrQ, Ov2nWpYH0Xt3iIOuaZ_8, UJLHnPUeozWMGrQ, 5); 
 j6KTZwr_vzvlUL = guzdvlIIVslr2H1ITa2; 
 }
 
 else if(guzdvlIIVslr2H1ITa2 == ENUM_DIRECTION_LEFT && bbrZfXAu3KKN6gShqLzZn0J
 || guzdvlIIVslr2H1ITa2 == ENUM_DIRECTION_RIGHT && pZrulqxkXszq)
 {
 Ov2nWpYH0Xt3iIOuaZ_8 = w8gHOr3BsSE3watvO9.sq_findNearLinearMovableXPos(sq_GetDistancePos(Ov2nWpYH0Xt3iIOuaZ_8, guzdvlIIVslr2H1ITa2, jnztMAA0arebhThNkZ72do / -1), UJLHnPUeozWMGrQ, Ov2nWpYH0Xt3iIOuaZ_8, UJLHnPUeozWMGrQ, 5); 
 j6KTZwr_vzvlUL = sq_GetOppositeDirection(guzdvlIIVslr2H1ITa2); 
 }
 
 else if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL))
 {
 
 UJLHnPUeozWMGrQ = w8gHOr3BsSE3watvO9.sq_findNearLinearMovableYPos(Ov2nWpYH0Xt3iIOuaZ_8, UJLHnPUeozWMGrQ - jnztMAA0arebhThNkZ72do, Ov2nWpYH0Xt3iIOuaZ_8, UJLHnPUeozWMGrQ, 5);
 j6KTZwr_vzvlUL = ENUM_DIRECTION_UP; 
 }
 
 else if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL))
 {
 
 UJLHnPUeozWMGrQ = w8gHOr3BsSE3watvO9.sq_findNearLinearMovableYPos(Ov2nWpYH0Xt3iIOuaZ_8, UJLHnPUeozWMGrQ + jnztMAA0arebhThNkZ72do, Ov2nWpYH0Xt3iIOuaZ_8, UJLHnPUeozWMGrQ, 5);
 j6KTZwr_vzvlUL = ENUM_DIRECTION_DOWN; 
 }
 else 
 {
 return false; 
 }
 
 setSonPassiveObjectIsProc_qq506807329_atgunner_g4(vpdIkgMitWQQdAA2POVW3x9);
 local n1eOcB0i02LDK05mbVQGVv = sq_GetGlobalIntVector(); 
 sq_IntVectorClear(n1eOcB0i02LDK05mbVQGVv); 
 sq_IntVectorPush(n1eOcB0i02LDK05mbVQGVv, GA2Az_idkUgmJjc); 
 sq_IntVectorPush(n1eOcB0i02LDK05mbVQGVv, Ov2nWpYH0Xt3iIOuaZ_8); 
 sq_IntVectorPush(n1eOcB0i02LDK05mbVQGVv, UJLHnPUeozWMGrQ); 
 sq_IntVectorPush(n1eOcB0i02LDK05mbVQGVv, j6KTZwr_vzvlUL); 
 vpdIkgMitWQQdAA2POVW3x9.addSetStatePacket(12, n1eOcB0i02LDK05mbVQGVv, STATE_PRIORITY_AUTO, false, ""); 
 }
 else if(pA2Q_ROjT4xx7T4RbDKq == 2)
 {
 
 setSonPassiveObjectIsProc_qq506807329_atgunner_g4(vpdIkgMitWQQdAA2POVW3x9);
 local GA2Az_idkUgmJjc = 1; 
 local j6KTZwr_vzvlUL =
 (Ov2nWpYH0Xt3iIOuaZ_8 > sq_GetXPos(vpdIkgMitWQQdAA2POVW3x9))
 ? ENUM_DIRECTION_RIGHT
 : ENUM_DIRECTION_LEFT; 
 local n1eOcB0i02LDK05mbVQGVv = sq_GetGlobalIntVector(); 
 sq_IntVectorClear(n1eOcB0i02LDK05mbVQGVv); 
 sq_IntVectorPush(n1eOcB0i02LDK05mbVQGVv, GA2Az_idkUgmJjc); 
 sq_IntVectorPush(n1eOcB0i02LDK05mbVQGVv, j6KTZwr_vzvlUL); 
 vpdIkgMitWQQdAA2POVW3x9.addSetStatePacket(12, n1eOcB0i02LDK05mbVQGVv, STATE_PRIORITY_AUTO, false, ""); 
 }
 vpdIkgMitWQQdAA2POVW3x9.flushSetStatePacket(); 
 return false;
 }
 return true;
} 



