






 
function checkExecutableSkill_atgunner_dday(BzDHEac6CCjA3RK)
{
 if(!BzDHEac6CCjA3RK) return false; 
 local mpZoI7Lhla4YR8jXB = BzDHEac6CCjA3RK.sq_IsUseSkill(244); 
 if(mpZoI7Lhla4YR8jXB) 
 {
 local S2QE_uZj7WM7jJsekwl1IGW = BzDHEac6CCjA3RK.getZPos(); 
 local zouJxFcvF9VJCLa = BzDHEac6CCjA3RK.getState(); 
 if(S2QE_uZj7WM7jJsekwl1IGW > 0 && (zouJxFcvF9VJCLa == 6 || zouJxFcvF9VJCLa == 7)) 
 {
 BzDHEac6CCjA3RK.sq_IntVectClear();
 BzDHEac6CCjA3RK.sq_IntVectPush(1); 
 BzDHEac6CCjA3RK.sq_AddSetStatePacket(244, STATE_PRIORITY_USER, true); 
 }
 else
 {
 BzDHEac6CCjA3RK.sq_IntVectClear();
 BzDHEac6CCjA3RK.sq_IntVectPush(0); 
 BzDHEac6CCjA3RK.sq_AddSetStatePacket(244, STATE_PRIORITY_USER, true); 
 }
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_dday(UTw2Wcb5GOCAgHLrhA4jE)
{
 if(!UTw2Wcb5GOCAgHLrhA4jE) return false; 
 local nMA5_5v2Radcgoxd4naQV2 = UTw2Wcb5GOCAgHLrhA4jE.sq_GetState(); 
 if(nMA5_5v2Radcgoxd4naQV2 == STATE_STAND) 
 return true; 
 if(nMA5_5v2Radcgoxd4naQV2 == STATE_ATTACK) 
 {
 return UTw2Wcb5GOCAgHLrhA4jE.sq_IsCommandEnable(244); 
 }
 return true; 
} 

 
function onSetState_atgunner_dday(UTw2Wcb5GOCAgHLrhA4jE, nMA5_5v2Radcgoxd4naQV2, TUhl3TGOt8F, sovvlmD4QgXj)
{
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 if(!UTw2Wcb5GOCAgHLrhA4jE) return; 
 UTw2Wcb5GOCAgHLrhA4jE.getVar().clear_vector(); 
 UTw2Wcb5GOCAgHLrhA4jE.sq_StopMove(); 
 local D3Ub62CjXwhWRlgHR7 = UTw2Wcb5GOCAgHLrhA4jE.sq_GetVectorData(TUhl3TGOt8F, 0); 
 UTw2Wcb5GOCAgHLrhA4jE.setSkillSubState(D3Ub62CjXwhWRlgHR7); 
 switch(D3Ub62CjXwhWRlgHR7)
 {
 case 0:
 UTw2Wcb5GOCAgHLrhA4jE.sq_SetCurrentAnimation(125);
 break;
 case 1:
 UTw2Wcb5GOCAgHLrhA4jE.sq_ZStop(); 
 UTw2Wcb5GOCAgHLrhA4jE.sq_SetCurrentAnimation(61);
 break;
 }
 UTw2Wcb5GOCAgHLrhA4jE.sq_PlaySound("FG_D_DAY"); 
 sq_SetCustomDamageType(UTw2Wcb5GOCAgHLrhA4jE, true, 2); 
 UTw2Wcb5GOCAgHLrhA4jE.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 

function onKeyFrameFlag_atgunner_dday(w8gHOr3BsSE3watvO9, vpdIkgMitWQQdAA2POVW3x9)
{
 if(!w8gHOr3BsSE3watvO9) return false;
 if(!w8gHOr3BsSE3watvO9.sq_IsMyControlObject())return true;
 local BiUCLkGhOStoYkBjPBH = w8gHOr3BsSE3watvO9.getSkillSubState(); 
 if(vpdIkgMitWQQdAA2POVW3x9 == 1)
 {
 
 
 local GwualivHFmJV8AA = 1; 
 if(BiUCLkGhOStoYkBjPBH == 1) GwualivHFmJV8AA = 2; 
 local D4jFGqLWclgi = 40; 
 w8gHOr3BsSE3watvO9.sq_StartWrite();
 w8gHOr3BsSE3watvO9.sq_WriteDword(244); 
 w8gHOr3BsSE3watvO9.sq_WriteDword(1); 
 w8gHOr3BsSE3watvO9.sq_WriteDword(GwualivHFmJV8AA); 
 w8gHOr3BsSE3watvO9.sq_WriteDword(w8gHOr3BsSE3watvO9.sq_GetBonusRateWithPassive(244, 244, 0, 1.0)); 
 w8gHOr3BsSE3watvO9.sq_WriteDword(D4jFGqLWclgi); 
 if(BiUCLkGhOStoYkBjPBH == 1)
 w8gHOr3BsSE3watvO9.sq_SendCreatePassiveObjectPacket(24376, 0, 35, 0, 68);
 else
 w8gHOr3BsSE3watvO9.sq_SendCreatePassiveObjectPacket(24376, 0, 48, 0, 76);
 }
 return true;
} 

 
function onEndCurrentAni_atgunner_dday(SaG2Ig4Cyn63vvryRQ4nt4o0)
{
 if(!SaG2Ig4Cyn63vvryRQ4nt4o0) return;
 if(!SaG2Ig4Cyn63vvryRQ4nt4o0.sq_IsMyControlObject()) return;
 local DeTxxGF8aAMEYUsVpkfd = SaG2Ig4Cyn63vvryRQ4nt4o0.getSkillSubState(); 
 switch(DeTxxGF8aAMEYUsVpkfd)
 {
 case 0:
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 case 1:
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_IntVectClear();
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_IntVectPush(1);
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_IntVectPush(0);
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_IntVectPush(250);
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
 break;
 }
} 


if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onEndState_atgunner_dday(uG_GG7WDDWHfa1WnV_ZbX, WxaRxFm1SHcmggJteK6)
{
 if(!uG_GG7WDDWHfa1WnV_ZbX) return;
 sq_SetCustomDamageType(uG_GG7WDDWHfa1WnV_ZbX, false, 2); 
} 


