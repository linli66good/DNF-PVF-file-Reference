function setCustomData_po_nmy_skill(obj, receiveData)
{
	if(!obj) return;
	local Id = receiveData.readDword();
	local pChrOBJ = obj.getTopCharacter();
	pChrOBJ = sq_GetCNRDObjectToSQRCharacter(pChrOBJ);
	obj.getVar("po_nmy_skill_Id").clear_vector();
	obj.getVar("po_nmy_skill_Id").push_vector(Id);
	switch (Id)
	{
		case 2:
			local type = receiveData.readDword();
			obj.getVar("state").clear_vector();
			obj.getVar("state").push_vector(type);
			local power = receiveData.readDword();
			obj.getVar("power").clear_vector();
			obj.getVar("power").push_vector(power);
			local size = receiveData.readDword();
			obj.getVar("size").clear_vector();
			obj.getVar("size").push_vector(size);
			if(type == 10 || type == 20 || type == 30)
			{
				local aorl = receiveData.readDword();
				obj.getVar("state").push_vector(aorl);
			}
			local pIntVec = sq_GetGlobalIntVector();
			sq_IntVectorClear(pIntVec);
			obj.addSetStatePacket(type, pIntVec, STATE_PRIORITY_AUTO, false, "");
		break;
		case 3:
			obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atphotobilizer/atphotobilizerbullet_00.ani"));
			obj.getVar("state").clear_vector();
			obj.getVar("state").push_vector(0);
			obj.getVar("pos").clear_vector();
			obj.getVar("pos").push_vector(obj.getXPos());
			obj.getVar("pos").push_vector(220);
			obj.getVar("pos").push_vector(150);
			obj.getVar("pos").push_vector(obj.getZPos());
			local zmove = obj.getZPos();
			local angle = -38+zmove/45;
			local rotate = angle.tointeger() * 0.017453;
			obj.setCustomRotate(true,rotate);
			local sizeRate = 50;
			local ani = obj.getCurrentAnimation();
			ani.setImageRateFromOriginal(sizeRate.tofloat() / 100, sizeRate.tofloat() / 100);
			ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate.tofloat() / 100);
		break;
		case 4:
			obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atphotobilizer/photogranade_00.ani"));
			local x = receiveData.readDword();
			local y = receiveData.readDword();
			local z = receiveData.readDword();
			obj.getVar("pos").clear_vector();
			obj.getVar("pos").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 0));
			obj.getVar("pos").push_vector(obj.getYPos() + y);
			obj.getVar("pos").push_vector(obj.getZPos());
			obj.getVar("pos").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), sq_getRandom(250, 320)));
			obj.getVar("pos").push_vector(0);
			obj.getVar("pos").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -x));
			obj.getVar("pos").push_vector(600);
			obj.getVar("pos").push_vector(obj.getZPos()+z);
			obj.getVar("pos").push_vector(obj.getYPos()+sq_getRandom(-35, 35));
			obj.getVar("pos").push_vector(sq_getRandom(-50, 50));
		break;
		case 5:
			obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atphotobilizer/atphotobilizerexplosionattackbox.ani"));
			sq_SetCurrentAttackInfoFromCustomIndex(obj, 11);
			local ani = obj.getCurrentAnimation();
			local size = sq_GetIntData(pChrOBJ, SKILL_photobilizer, 1);
			local sizeRate = size.tofloat() / 100.0;
			ani.setImageRateFromOriginal(sizeRate, sizeRate);
			ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
			sq_SetAttackBoundingBoxSizeRate(ani, sizeRate, sizeRate, sizeRate);
			sq_SetMyShake(obj, 8, 700);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionfront_00.ani", 120 + size / 100, 0, 0, 0, size, 0, 1, 1.0, 0);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionback_05.ani", 120 + size / 100, -1, 0, 0, size, 0, 1, 1.0, 0);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionbottom_00.ani", 120 + size / 100, 0, 0, 0, size, 0, 2, 1.0, 0);

			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionfront_00.ani", 0, 60, 0, 0, size, 0, 1, 1.0, 0);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionback_05.ani", 0, 59, 0, 0, size, 0, 1, 1.0, 0);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionbottom_00.ani", 0, 60, 0, 0, size, 0, 2, 1.0, 0);

			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionfront_00.ani", 0, -60, 0, 0, size, 0, 1, 1.0, 0);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionback_05.ani", 0, -61, 0, 0, size, 0, 1, 1.0, 0);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionbottom_00.ani", 0, -60, 0, 0, size, 0, 2, 1.0, 0);

			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionfront_00.ani", -120 - size / 100, 0, 0, 0, size, 0, 1, 1.0, 0);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionback_05.ani", -120 - size / 100, -1, 0, 0, size, 0, 1, 1.0, 0);
			gunner_als(obj, "character/gunner/effect/animation/atphotobilizer/explosion/atphotobilizerexplosionbottom_00.ani", -120 - size / 100, 0, 0, 0, size, 0, 2, 1.0, 0);
			
			local count = sq_GetIntData(pChrOBJ, SKILL_photobilizer, 0);
			local power = pChrOBJ.sq_GetPowerWithPassive(SKILL_photobilizer, STATE_photobilizer, 0, -1, 1.0);
			local attackInfo = sq_GetCurrentAttackInfo(obj);
			sq_SetCurrentAttackPower(attackInfo, power);
			obj.setTimeEvent(0, 10, count, true);
		break;
		case 6:
			local attackBonusRate = receiveData.readDword();
			local expIndex = receiveData.readDword();
			local subExpRotate = receiveData.readDword();
			obj.getVar("subExp").clear_vector();
			obj.getVar("subExp").push_vector(attackBonusRate);
			obj.getVar("subExp").push_vector(subExpRotate);
			if(expIndex == 0)
			{
				obj.setTimeEvent(1,40,1,false);
				obj.setTimeEvent(2,70,1,false);
			}
			local size = pChrOBJ.sq_GetIntData(252, 2);
			local sizeRate = size.tofloat() / 140.0;
			if(expIndex == 1)
				sizeRate = size.tofloat() / 150.0;
			else if(expIndex == 2)
				sizeRate = size.tofloat() / 160.0;
			local gunner = sq_GetCNRDObjectToSQRCharacter(obj.getTopCharacter());
			local throwstate = gunner.getVar("overcharge").getInt(0);
			local aniIndex = 0;
			if(obj.getZPos() <= 8)
				aniIndex += 1;
			local elementatk = ENUM_ELEMENT_NONE;
			switch (throwstate)
			{
				case ENUM_ELEMENT_NONE:
				case ENUM_ELEMENT_DARK:
					break;
				case ENUM_ELEMENT_FIRE:
					elementatk = ENUM_ELEMENT_FIRE;
					aniIndex += 2;
					break;
				case ENUM_ELEMENT_WATER:
					elementatk = ENUM_ELEMENT_WATER;
					aniIndex += 4;
					break;
				case ENUM_ELEMENT_LIGHT:
					elementatk = ENUM_ELEMENT_LIGHT;
					aniIndex = 6;
					break;
			}
			setCurrentAnimationFromCutomIndex(obj, aniIndex);
			local ani = sq_GetCurrentAnimation(obj);
			ani.setImageRateFromOriginal(sizeRate, sizeRate);
			ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
			sq_SetAttackBoundingBoxSizeRate(ani, sizeRate, sizeRate, sizeRate);
			local attackInfo = sq_GetCustomAttackInfo(obj, 12);
			attackInfo.setElement(elementatk);
			if(sq_getJob(pChrOBJ) == ENUM_CHARACTERJOB_GUNNER)
				attackInfo.setAttackType(ATTACKTYPE_PHYSICAL); 
			sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
			sq_SetCurrentAttackInfo(obj, attackInfo);
			gunner.applyBasicAttackUp(sq_GetCurrentAttackInfo(obj),8);
			sq_SetCurrentAttackInfo(obj,sq_GetCurrentAttackInfo(obj));
		break;
	}
}

function setState_po_nmy_skill(obj, state, datas)
{
	if(!obj) return;
	local Id = obj.getVar("po_nmy_skill_Id").get_vector(0);
	local passiveState = state;
	obj.getVar("state").set_vector(0, passiveState);
	local x = sq_GetXPos(obj);
	local y = sq_GetYPos(obj);
	local z = sq_GetZPos(obj);
	local pChrOBJ = obj.getTopCharacter();
	pChrOBJ = sq_GetCNRDObjectToSQRCharacter(pChrOBJ);
	switch (Id)
	{
		case 2:
			local sizeRate = obj.getVar("size").get_vector(0).tofloat();
			switch (state)
			{
				case 10:
					sq_SetCurrentAttackInfoFromCustomIndex(obj, 7);
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/grenadeweaponthrow_00.ani"));
					if(obj.getVar("state").get_vector(1) == 0)
						obj.sq_SetMoveParticle("particle/grenadecenter.ptl", 0.0, 0.0);
					if(obj.getVar("state").get_vector(1) == 1)
						obj.sq_SetMoveParticle("particle/grenadejump.ptl", 0.0, 0.0);
					if(obj.getVar("state").get_vector(1) == 2)
						obj.sq_SetMoveParticle("particle/grenadedrop.ptl", 0.0, 0.0);
				break;
				case 11:
					sq_SetCurrentAttackInfoFromCustomIndex(obj, 8);
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/grenadefront_02.ani"));
					local ani = obj.getCurrentAnimation();
					ani.setImageRateFromOriginal(sizeRate / 100, sizeRate / 100);
					locakonhit(obj, "passiveobject/skillre/atgunner/animation/atstandby-ready/grenadeback_01.ani", 0, -1, 0, 0, sizeRate, 0, 1, 1.0, 0);
					locakonhit(obj, "passiveobject/skillre/atgunner/animation/atstandby-ready/grenadebottom_00.ani", 0, -1, 0, 0, sizeRate, 0, 2, 1.0, 0);
					local attackInfo = sq_GetCurrentAttackInfo(obj);
					sq_SetCurrentAttackPower(attackInfo, obj.getVar("power").get_vector(0));
					if(sq_GetSkillLevel(pChrOBJ, 99) > 0)
					{
						attackInfo.setElement(0);
						local level = sq_GetSkillLevel(pChrOBJ, 99);
						local burn_proc = sq_GetLevelData(pChrOBJ, 99, 9, level) / 10;
						local burn_level = sq_GetLevelData(pChrOBJ, 99, 10, level);
						local burn_time = sq_GetLevelData(pChrOBJ, 99, 11, level);
						local burn_attackRate = sq_GetLevelData(pChrOBJ, 99, 12, level);
						sq_SetChangeStatusIntoAttackInfo(attackInfo, 0, ACTIVESTATUS_BURN, burn_proc, burn_level, burn_time, burn_attackRate);
					}
				break;
				case 20:
					sq_SetCurrentAttackInfoFromCustomIndex(obj, 7);
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/flashweaponthrow_00.ani"));
					if(obj.getVar("state").get_vector(1) == 0)
						obj.sq_SetMoveParticle("particle/grenadecenter.ptl", 0.0, 0.0);
					if(obj.getVar("state").get_vector(1) == 1)
						obj.sq_SetMoveParticle("particle/grenadejump.ptl", 0.0, 0.0);
					if(obj.getVar("state").get_vector(1) == 2)
						obj.sq_SetMoveParticle("particle/grenadedrop.ptl", 0.0, 0.0);
				break;
				case 21:
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/flashfrontstart_00.ani"));
					locakonhit(obj, "passiveobject/skillre/atgunner/animation/atstandby-ready/flashbottomstart_00.ani", 0, -1, 0, 0, sizeRate, 1, 2, 1.0, 0);
				break;
				case 22:
					local group = sq_GetGroup(obj);
					local uniqueId = sq_GetUniqueId(obj);
					sq_BinaryStartWrite();
					sq_BinaryWriteDword(2);
					sq_BinaryWriteDword(25);
					sq_BinaryWriteDword(obj.getVar("power").get_vector(0));
					sq_BinaryWriteDword(obj.getVar("size").get_vector(0));
					sq_SendCreatePassiveObjectPacketPos(obj, 24350, 0, x, y, z);
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/flashfrontloop_00.ani"));
					locakonhit(obj, "passiveobject/skillre/atgunner/animation/atstandby-ready/flashbottomloop_00.ani", 0, -1, 0, 0, sizeRate, 1, 2, 1.0, 0);
					local time = sq_GetIntData(pChrOBJ, SKILL_NITROMOTOR, 5);
					obj.setTimeEvent(1, time, 1, false);
				break;
				case 23:
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/flashfrontend_00.ani"));
					locakonhit(obj, "passiveobject/skillre/atgunner/animation/atstandby-ready/flashbottomend_00.ani", 0, -1, 0, 0, sizeRate, 0, 2, 1.0, 0);
				break;
				case 25:
					local time = sq_GetIntData(pChrOBJ, SKILL_NITROMOTOR, 5);
					local count = sq_GetIntData(pChrOBJ, SKILL_NITROMOTOR, 6);
					obj.setTimeEvent(0, time / count , count, false);
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/flashattackbox.ani"));
					sq_SetCurrentAttackInfoFromCustomIndex(obj, 9);
					local level = sq_GetSkillLevel(pChrOBJ, 57);
					local light_proc = sq_GetLevelData(pChrOBJ, 57, 2, level) / 10;
					local light_level = sq_GetLevelData(pChrOBJ, 57, 3, level);
					local light_time = sq_GetLevelData(pChrOBJ, 57, 4, level);
					local light_attackRate = sq_GetLevelData(pChrOBJ, 57, 5, level);
					local attackInfo = sq_GetCurrentAttackInfo(obj);
					sq_SetChangeStatusIntoAttackInfo(attackInfo, 0, ACTIVESTATUS_LIGHTNING, light_proc, light_level, light_time, light_attackRate);
					sq_SetCurrentAttackPower(attackInfo, obj.getVar("power").get_vector(0));
					local ani = sq_GetCurrentAnimation(obj);
					ani.setSpeedRate(1.0);
				break;
				case 30:
					sq_SetCurrentAttackInfoFromCustomIndex(obj, 7);
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/frozenweaponthrow_00.ani"));
					if(obj.getVar("state").get_vector(1) == 0)
						obj.sq_SetMoveParticle("particle/grenadecenter.ptl", 0.0, 0.0);
					if(obj.getVar("state").get_vector(1) == 1)
						obj.sq_SetMoveParticle("particle/grenadejump.ptl", 0.0, 0.0);
					if(obj.getVar("state").get_vector(1) == 2)
						obj.sq_SetMoveParticle("particle/grenadedrop.ptl", 0.0, 0.0);
				break;
				case 31:
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/frozenstart_01.ani"));
				break;
				case 32:
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/frozenloop_00.ani"));
					sq_SetCurrentAttackInfoFromCustomIndex(obj, 10);
					local level = sq_GetSkillLevel(pChrOBJ, 57);
					local ice_proc = sq_GetLevelData(pChrOBJ, 58, 2, level) / 10;
					local ice_level = sq_GetLevelData(pChrOBJ, 58, 3, level);
					local ice_time = sq_GetLevelData(pChrOBJ, 58, 4, level);
					local attackInfo = sq_GetCurrentAttackInfo(obj);
					sq_SetChangeStatusIntoAttackInfo(attackInfo, 0, ACTIVESTATUS_FREEZE , ice_proc, ice_level, ice_time);
					sq_SetCurrentAttackPower(attackInfo, obj.getVar("power").get_vector(0));
					local count = sq_GetIntData(pChrOBJ, SKILL_NITROMOTOR, 7);
					obj.setTimeEvent(2, 1499 / count, count, false);
				break;
				case 33:
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atstandby-ready/frozenend_00.ani"));
				break;
			}
			if(state != 10 && state!= 20 && state != 30)
			{
				local ani = obj.getCurrentAnimation();
				local sizeRate = obj.getVar("size").get_vector(0).tofloat() / 100.0;
				ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
				sq_SetAttackBoundingBoxSizeRate(ani, sizeRate, sizeRate, sizeRate);
			}
		break;
		case 3:
			switch (state)
			{
				case 10:
					obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atphotobilizer/atphotobilizershoteffectbottom_00.ani"));
					obj.setTimeEvent(5, 800, 1, false);
				break;
			}
		break;
	}
}

function onTimeEvent_po_nmy_skill(obj, timeEventIndex, timeEventCount)
{
	if(!obj) return;
	local Id = obj.getVar("po_nmy_skill_Id").get_vector(0);
	if(Id == 6)
	{
		local gunner = sq_GetCNRDObjectToSQRCharacter(obj.getTopCharacter());
		local attackBonus = obj.getVar("subExp").get_vector(0);
		local subExpRotate = obj.getVar("subExp").get_vector(1);
		gunner.sq_StartWrite();
		gunner.sq_WriteDword(6);
		gunner.sq_WriteDword(attackBonus * sq_GetIntData(gunner,252,timeEventIndex - 1) / 100);
		gunner.sq_WriteDword(timeEventIndex);
		gunner.sq_WriteDword(0);
		if(timeEventIndex == 1)
		{
			local xpos =obj.getXPos() + (gunner.getXPos() > obj.getXPos() ? -sq_getRandom(80,100) : sq_getRandom(80,100));
			local zpos = obj.getZPos() + sq_getRandom(-20,20) +( subExpRotate > 0 ? -30 : 0);
			zpos = zpos < 0 ? 0 : zpos;
			sq_SendCreatePassiveObjectPacketPos(obj, 24350, 0, xpos, obj.getYPos() + 1, zpos);
		}
		else if(timeEventIndex == 2)
		{
			local xpos = obj.getXPos() + (gunner.getXPos() > obj.getXPos() ? -sq_getRandom(40,60) : sq_getRandom(40,60));
			local zpos = obj.getZPos() + sq_getRandom(-40,40) + (subExpRotate > 0 ? -30 : 0);
			zpos = zpos < 0 ? 0 : zpos; 
			sq_SendCreatePassiveObjectPacketPos(obj, 24350, 0, xpos, obj.getYPos() + 1, zpos );
		}
	}else
	{
		if(timeEventIndex == 0)
		{
			obj.resetHitObjectList();
		}
		if(timeEventIndex == 1)
		{
			local x = sq_GetXPos(obj);
			local y = sq_GetYPos(obj);
			local z = sq_GetZPos(obj);
			sq_BinaryStartWrite();
			sq_BinaryWriteDword(2);
			sq_BinaryWriteDword(23);
			sq_BinaryWriteDword(obj.getVar("power").get_vector(0));
			sq_BinaryWriteDword(obj.getVar("size").get_vector(0));
			sq_SendCreatePassiveObjectPacketPos(obj, 24350, 0, x, y, z);
			sq_SendDestroyPacketPassiveObject(obj);
		}
		if(timeEventIndex == 2)
		{
			obj.resetHitObjectList();
		}
		if(timeEventIndex == 5)
		{
			local x = sq_GetXPos(obj);
			local y = sq_GetYPos(obj);
			local z = sq_GetZPos(obj);
			sq_BinaryStartWrite();
			sq_BinaryWriteDword(5);
			sq_SendCreatePassiveObjectPacketPos(obj, 24350, 0, x, y, z);
		}
	}
}

function procAppend_po_nmy_skill(obj)
{
	if(!obj) return;
	local Id = obj.getVar("po_nmy_skill_Id").get_vector(0);
	local pChrOBJ = obj.getTopCharacter();
	local parentChr = sq_ObjectToSQRCharacter(obj.getTopCharacter());
	local state = obj.getVar("state").get_vector(0);
	local pAni = obj.getCurrentAnimation();
	local currentT = sq_GetCurrentTime(pAni);
	local frameindex = sq_GetAnimationFrameIndex(pAni);
	local time = sq_GetObjectTime(obj);
	local x = sq_GetXPos(obj);
	local y = sq_GetYPos(obj);
	local z = sq_GetZPos(obj);
	switch (Id)
	{
		case 2:
			local state = obj.getVar("state").get_vector(0);
			switch (state)
			{
				case 10:
				case 20:
				case 30:
					if(obj.getZPos() <= 0)
					{
						obj.sendStateOnlyPacket(state + 1);
						obj.flushSetStatePacket();
					}
				break;
				case 25:
					if(!obj.isExistTimeEvent(0))
					{
						local time = sq_GetObjectTime(obj);
						if(time < 100) return;
						sq_SendDestroyPacketPassiveObject(obj);
					}
				break;
				case 32:
					if(!obj.isExistTimeEvent(2))
					{
						obj.sendStateOnlyPacket(33);
						obj.flushSetStatePacket();
					}
				break;
			}
		break;
		case 3:
			local vx = sq_GetUniformVelocity(0, obj.getVar("pos").get_vector(3), currentT, obj.getVar("pos").get_vector(2));
			local dstX = sq_GetDistancePos(obj.getVar("pos").get_vector(0), obj.getDirection(), vx);
			local zAccel = sq_GetUniformVelocity(obj.getVar("pos").get_vector(3), 0, currentT, 150);
			if(state != 10)
			{
			sq_setCurrentAxisPos(obj, 0, dstX);
			sq_setCurrentAxisPos(obj, 2, zAccel);
				if(obj.getZPos() <= 0)
				{
					obj.sendStateOnlyPacket(10);
					obj.flushSetStatePacket();
				}
			}
		break;
		case 4:
			local pAni = obj.getCurrentAnimation();
			local currentT = sq_GetCurrentTime(pAni);
			local frameindex = sq_GetAnimationFrameIndex(pAni);
			local backdstX = sq_GetAccel(obj.getVar("pos").get_vector(0), obj.getVar("pos").get_vector(5), currentT, obj.getVar("pos").get_vector(6), true);
			local dstX = sq_GetAccel(obj.getVar("pos").get_vector(4), obj.getVar("pos").get_vector(3), currentT - obj.getVar("pos").get_vector(6), obj.getVar("pos").get_vector(6) + obj.getVar("pos").get_vector(9), false);
			local zup = sq_GetAccel(obj.getVar("pos").get_vector(2), obj.getVar("pos").get_vector(7), currentT, obj.getVar("pos").get_vector(6) , true);
			local y = sq_GetAccel(obj.getVar("pos").get_vector(1), obj.getVar("pos").get_vector(8), currentT - obj.getVar("pos").get_vector(6), obj.getVar("pos").get_vector(6) + obj.getVar("pos").get_vector(9), false);
			local z = sq_GetAccel(obj.getVar("pos").get_vector(2),0, currentT - obj.getVar("pos").get_vector(6), obj.getVar("pos").get_vector(6) + obj.getVar("pos").get_vector(9), false);
			if(currentT <= obj.getVar("pos").get_vector(6))
			{
				sq_setCurrentAxisPos(obj, 0, backdstX);
				sq_setCurrentAxisPos(obj, 2, zup);
				obj.getVar("pos").set_vector(4, obj.getXPos());
				obj.getVar("pos").set_vector(2, obj.getZPos());
			}
			else
			{
				sq_setCurrentAxisPos(obj, 0, dstX);
				sq_setCurrentAxisPos(obj, 2, z);
			}
			sq_setCurrentAxisPos(obj, 1, y);
			if(obj.getZPos() <= 0)
			{
				sq_SendDestroyPacketPassiveObject(obj);
			}
		break;
	}
}

function onEndCurrentAni_po_nmy_skill(obj)
{
	if(!obj) return;
	local Id = obj.getVar("po_nmy_skill_Id").get_vector(0);
	local pChrOBJ = obj.getTopCharacter();
	pChrOBJ = sq_GetCNRDObjectToSQRCharacter(pChrOBJ);
	local state = obj.getVar("state").get_vector(0);
	if(Id == 2)
	{
		if(state == 21 || state == 31)
		{
			obj.sendStateOnlyPacket(state + 1);
			obj.flushSetStatePacket();
		}
		else
			sq_SendDestroyPacketPassiveObject(obj);
	}
	if(Id == 3 || Id == 5 || Id == 6)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
}


