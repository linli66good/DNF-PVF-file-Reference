


function procAppend_photobilizer(obj)
{
	local skill_level = sq_GetSkillLevel(obj, SKILL_photobilizer);
	if(skill_level > 0)
	{
		if(obj.getZPos() <= 60)
			obj.setSkillCommandEnable(SKILL_photobilizer,false);
		else
			obj.setSkillCommandEnable(SKILL_photobilizer,true);
	}
}

function addSetStatePacket_ATGunner(obj, state, datas)
{
	if(!obj) return;
	ATgunner_Launcher_addSetStatePacket(obj, state, datas);
	ATgunner_Ranger_addSetStatePacket(obj, state, datas);
	return;
}

function ATgunner_Ranger_addSetStatePacket(obj, state, datas)
{
	if(sq_GetSkillLevel(obj, 16)<1) return;
		local SubState = obj.sq_GetVectorData(datas, 0);
		switch(state)
		{
			case 38:
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(0);
					obj.sq_AddSetStatePacket(152, STATE_PRIORITY_FORCE, true);
			break;
		}
	return;
}

function ATgunner_Launcher_addSetStatePacket(obj, state, datas)
{
	if(sq_GetSkillLevel(obj, 112)<1) return;
		local SubState = obj.sq_GetVectorData(datas, 0);
		switch(state)
		{
			case 232:
					if(SubState == 2)
					{
					obj.sq_StartWrite();
					obj.sq_WriteDword(111);
					obj.sq_SendCreatePassiveObjectPacket(24334, 0, 170, 0, 75);
					}
			break;
			case 36:
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(0);
					obj.sq_AddSetStatePacket(150, STATE_PRIORITY_FORCE, true);
			break;
			case 234:
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(0);
					obj.sq_AddSetStatePacket(151, STATE_PRIORITY_FORCE, true);
			break;
		}
	return;
}
 
function setEnableCancelSkill_ATGunner(iEAWniCoQoPkEPvPs2U3qw, JrCNUDD2_DcY6nmo)
{
 if(!iEAWniCoQoPkEPvPs2U3qw)
 return false;
 
 if(!iEAWniCoQoPkEPvPs2U3qw.isMyControlObject())
 return false;
 if(!JrCNUDD2_DcY6nmo)
 return true;
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(232, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(233, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(234, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(235, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(236, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(237, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(238, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(239, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(240, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(241, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(242, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(243, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(244, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(245, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(246, JrCNUDD2_DcY6nmo); 
 local KbGHW8Iy7Ay1 = onGetMyPassiveObject_My(iEAWniCoQoPkEPvPs2U3qw, 24376, 247, 1); 
 if(!KbGHW8Iy7Ay1)
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(247, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(248, JrCNUDD2_DcY6nmo); 
 iEAWniCoQoPkEPvPs2U3qw.setSkillCommandEnable(249, JrCNUDD2_DcY6nmo); 
 return true;
} 




function onChangeSkillEffect_ATGunner111(didWRqz708, FAjZSmZIqDjiJqmqyArelna, HULXMkupqZ)
{
 if(!didWRqz708) return;
 switch(FAjZSmZIqDjiJqmqyArelna)
 {
 case 250:
 local pitsrnwHuH0vk30tgFVl = CNSquirrelAppendage.sq_GetAppendage(didWRqz708, "character/atgunner/appendage/ap_stylish_buff.nut");
 if(pitsrnwHuH0vk30tgFVl)
 {
 local vj55IMOAc77V = HULXMkupqZ.readWord(); 
 if(vj55IMOAc77V == 1)
 pitsrnwHuH0vk30tgFVl.getVar().set_vector(0, pitsrnwHuH0vk30tgFVl.getVar().get_vector(0) - 1); 
 }
 break;
 }
} 

 
function procAppend_NitroMotor(obj)
{
	if(!obj) return;

	local appendage = obj.GetSquirrelAppendage("character/atgunner/nitromotor/ap_nitromotor.nut");

	if(appendage)
	{
		if(appendage.isValid())
		{
			local loadSlot = obj.sq_GetSkillLoad(17);
			if(loadSlot)
			{
				local remain_number = loadSlot.getRemainLoadNumber();
				if(remain_number > 0)
				{
					NitroMotor(obj);
				}
			}
		}
	}
}



function useSkill_after_ATGunner(obj, skillIndex, consumeMp, consumeItem, oldSkillMpRate)
{
	if(!obj) return false;
	local skill = sq_GetSkill(obj, skillIndex);
	local isCool = skill.isInCoolTime();
	local growtype = sq_getGrowType(obj);
	if(!isCool && skillIndex == 1 && growtype == 4)
	{
		
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, 1, false, "character/atgunner/appendage/ap_flamebullet.nut", false);
		CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, 251, true);
		local appendage_light = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_silverbullet.nut");
		appendage_light = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_silverbullet.nut");
		if(appendage_light)
		{
			if(appendage_light.isValid())
			{
				appendage_light.setValid(false);
			}
		}
		local appendage_water = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_freezebullet.nut");
		appendage_water = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_freezebullet.nut");
		if(appendage_water)
		{
			if(appendage_water.isValid())
			{
				appendage_water.setValid(false);
			}
		}
	}
	if(!isCool && skillIndex == 2 && growtype == 4)
	{
		
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, 2, false, "character/atgunner/appendage/ap_freezebullet.nut", false);
		CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, 252, true);
		local appendage_light = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_silverbullet.nut");
		appendage_light = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_silverbullet.nut");
		if(appendage_light)
		{
			if(appendage_light.isValid())
			{
				appendage_light.setValid(false);
			}
		}
		local appendage_fire = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_flamebullet.nut");
		appendage_fire = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_flamebullet.nut");
		if(appendage_fire)
		{
			if(appendage_fire.isValid())
			{
				appendage_fire.setValid(false);
			}
		}
	}
	if(!isCool && skillIndex == 30 && growtype == 4)
	{
		
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, 30, false, "character/atgunner/appendage/ap_silverbullet.nut", false);
		CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, 253, true);
		local appendage_fire = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_flamebullet.nut");
		appendage_fire = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_flamebullet.nut");
		if(appendage_fire)
		{
			if(appendage_fire.isValid())
			{
				appendage_fire.setValid(false);
			}
		}
		local appendage_water = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_freezebullet.nut");
		appendage_water = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_freezebullet.nut");
		if(appendage_water)
		{
			if(appendage_water.isValid())
			{
				appendage_water.setValid(false);
			}
		}
	}
	if(!isCool && skillIndex == 52 && growtype == 4)
	{
		
		local appendage_light = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_silverbullet.nut");
		appendage_light = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_silverbullet.nut");
		if(appendage_light)
		{
			if(appendage_light.isValid())
			{
				appendage_light.setValid(false);
			}
		}
		local appendage_fire = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_flamebullet.nut");
		appendage_fire = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_flamebullet.nut");
		if(appendage_fire)
		{
			if(appendage_fire.isValid())
			{
				appendage_fire.setValid(false);
			}
		}
		local appendage_water = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/appendage/ap_freezebullet.nut");
		appendage_water = obj.GetSquirrelAppendage("character/atgunner/appendage/ap_freezebullet.nut");
		if(appendage_water)
		{
			if(appendage_water.isValid())
			{
				appendage_water.setValid(false);
			}
		}
	}
	return true;
}





function als_ani_ATG(obj, aniFilename, disX, disY, disZ, imgangle, imgRate, Parent, SpeedRate)

{
	local angle = imgangle;	
	local ani = sq_CreateAnimation("", aniFilename);
	sq_SetfRotateAngle(ani, sq_ToRadian(-angle.tofloat()));
	local sizeRate = imgRate;
	local size = sizeRate.tofloat() / 100.0;
	ani.setImageRateFromOriginal(size, size);
	ani.setAutoLayerWorkAnimationAddSizeRate(size);
	local setSpeedRateF = 100 * SpeedRate;
	ani.setSpeedRate(setSpeedRateF.tofloat()); 
	local pooledObj = sq_CreatePooledObject(ani,true);
	sq_ChangeDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	if(Parent == 0) 
	{
		sq_moveWithParent(obj, pooledObj);
	}
	sq_AddObject(obj, pooledObj, 2, false);
}


function setState_ATGunner(obj, state, datas, isResetTimer)
{
	
	
	setState_dragonslayerlaser(obj, state, datas, isResetTimer);
	
	local substate0 = obj.sq_GetVectorData(datas, 0);
	local substate1 = obj.sq_GetVectorData(datas, 1);
	local substate2 = obj.sq_GetVectorData(datas, 2);
	local substate3 = obj.sq_GetVectorData(datas, 3);
	local substate4 = obj.sq_GetVectorData(datas, 4);
	local substate5 = obj.sq_GetVectorData(datas, 5);
	local substate6 = obj.sq_GetVectorData(datas, 6);
	local substate7 = obj.sq_GetVectorData(datas, 7);
	local substate8 = obj.sq_GetVectorData(datas, 8);
	local substate9 = obj.sq_GetVectorData(datas, 9);
	local substate10 = obj.sq_GetVectorData(datas, 10);
	local WeaponSubType = obj.getWeaponSubType();
	

	obj.getVar("substate").clear_vector();
	obj.getVar("substate").push_vector(substate0);
	obj.getVar("substate").push_vector(substate1);
	obj.getVar("substate").push_vector(substate2);
	obj.getVar("substate").push_vector(substate2);
	obj.getVar("substate").push_vector(substate2);
	obj.getVar("substate").push_vector(substate2);
	obj.getVar("substate").push_vector(substate2);
	obj.getVar("substate").push_vector(substate2);

	obj.getVar("state").clear_vector();
	obj.getVar("state").push_vector(state);

}
