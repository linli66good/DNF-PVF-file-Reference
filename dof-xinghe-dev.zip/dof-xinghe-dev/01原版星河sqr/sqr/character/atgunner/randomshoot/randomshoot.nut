
function onSetState_RandomShoot(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local state = obj.sq_GetState();
	local substate = obj.sq_GetVectorData(datas, 0);
	local level = sq_GetSkillLevel(obj, 16);
	if(level >=1 && substate == 15)
	{
		sq_IntVectorClear(sq_GetGlobalIntVector());
		sq_IntVectorPush(sq_GetGlobalIntVector(),5);
		sq_AddSetStatePacketActiveObject(obj,STATE_RandomShoot, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
	}
}

function onSetState_NewRandomShoot(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local state = obj.sq_GetState();
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	local hitd = sq_getRandomUnique(true, 0, 2)
	switch(substate)
	{
		case 0:
			obj.sq_PlaySound("CHAIN_POWDER_GC_012");
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RandomShoot1)
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATGUNNER_RandomShootEX);

			local attackBonusRate = obj.sq_GetBonusRateWithPassive(9, 24, 3, 5.0);
			local attackInfo = sq_GetCurrentAttackInfo(obj);
			sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
			 
			obj.getVar("hit").clear_vector();
			obj.getVar("hit").push_vector(0);
			local currAtk = obj.getVar("atkCount").get_vector(0);
			obj.getVar("atkCount").set_vector(0, currAtk + 1);
			break;
		case 1:		
			obj.sq_PlaySound("CHAIN_POWDER_GC_012");
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RandomShoot2)
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATGUNNER_RandomShootEX);

			local attackBonusRate = obj.sq_GetBonusRateWithPassive(9, 24, 3, 5.0);
			local attackInfo = sq_GetCurrentAttackInfo(obj);
			sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
			sq_SetCurrentAttackDirection(attackInfo, hitd); 

			obj.getVar("hit").clear_vector();
			obj.getVar("hit").push_vector(0);
			local currAtk = obj.getVar("atkCount").get_vector(0);
			obj.getVar("atkCount").set_vector(0, currAtk + 1);
			break;
		case 2:		
			obj.sq_PlaySound("CHAIN_POWDER_GC_012");
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RandomShoot3)
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATGUNNER_RandomShootEX);


			local attackBonusRate = obj.sq_GetBonusRateWithPassive(9, 24, 3, 5.0);
			local attackInfo = sq_GetCurrentAttackInfo(obj);
			sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
			sq_SetCurrentAttackDirection(attackInfo, hitd); 

			obj.getVar("hit").clear_vector();
			obj.getVar("hit").push_vector(0);
			local currAtk = obj.getVar("atkCount").get_vector(0);
			obj.getVar("atkCount").set_vector(0, currAtk + 1);
			break;
		case 3:		
			obj.sq_PlaySound("CHAIN_POWDER_GC_012");
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_RandomShoot4)
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATGUNNER_RandomShootEX);

			local attackBonusRate = obj.sq_GetBonusRateWithPassive(9, 24, 3, 5.0);
			local attackInfo = sq_GetCurrentAttackInfo(obj);
			sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
			sq_SetCurrentAttackDirection(attackInfo, hitd); 

			obj.getVar("hit").clear_vector();
			obj.getVar("hit").push_vector(0);
			local currAtk = obj.getVar("atkCount").get_vector(0);
			obj.getVar("atkCount").set_vector(0, currAtk + 1);
			break;
		case 5:	
			obj.sq_SetCurrentAnimation(15)
			local Level = sq_GetSkillLevel(obj, 9);
			local Max = sq_GetLevelData(obj, 9, 2, Level)/2;

			obj.getVar("atkCount").clear_vector();
			obj.getVar("atkCount").push_vector(0);
			obj.getVar("atkCount").push_vector(Max);

			sq_IntVectorClear(sq_GetGlobalIntVector());
			sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
			sq_AddSetStatePacketActiveObject(obj, STATE_RandomShoot, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
			break;
	}
	local maxAniSpeed = 600;
	local minAniSpeed = 100;
	local maxCount = 3;
	local cCount = 0;

	obj.getVar().clear_vector();
	local objVar = obj.getVar();
	objVar.push_vector(maxAniSpeed);
	objVar.push_vector(minAniSpeed);
	objVar.push_vector(maxCount);
	objVar.push_vector(cCount);

	local atk = sq_GetCurrentAttackInfo(obj)
	sq_SetCurrentAttackeDamageAct(atk, 1);
	sq_SetCurrentAttacknUpForce(atk, 50);

	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 2.0, 2.0);
}

function onAttack_NewRandomShoot(obj, damager, boundingBox, isStuck)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();

	/*	local atk = sq_GetCurrentAttackInfo(obj)
		local level = sq_GetSkillLevel(obj, 9);
		local blood_proc = sq_GetLevelData(obj, 9, 4, level)/10;
		local blood_level = sq_GetLevelData(obj, 9, 5, level);
		local blood_time = sq_GetLevelData(obj, 9, 6, level);
		local blood_attackRate = sq_GetLevelData(obj, 9, 7, level);
		sq_SetChangeStatusIntoAttackInfo(atk, 0, ACTIVESTATUS_BLEEDING, blood_proc, blood_level, blood_time,blood_attackRate);*/

		local randNum = sq_getRandom(0, 100);
		local level = sq_GetSkillLevel(obj, 9);
		local randrate = sq_GetLevelData(obj, 9, 4, level)/10;
		local damage = sq_GetLevelData(obj, 9, 7, level)*3;
		
		if(randrate.tointeger() >= randNum)
		{
			obj.sq_PlaySound("KATANAC_HIT_01");
			obj.sq_PlaySound("SQUARESWDC_HIT_02");
			sq_EffectLayerAppendage(damager,sq_RGB(255,0,0),185,0,0,240);	
			local Group = sq_GetGroup(damager);
			local Unique = sq_GetUniqueId(damager);
			obj.sq_StartWrite();
			obj.sq_WriteDword(1);
			obj.sq_WriteDword(Group);
			obj.sq_WriteDword(Unique);
			obj.sq_WriteDword(damage.tointeger());
			obj.sq_SendCreatePassiveObjectPacket(24391, 0, 0, 0, 0);
		}
}

function onKeyFrameFlag_NewRandomShoot(obj, flagIndex)
{
	if(!obj) return;
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local hit = obj.getVar("hit").get_vector(0);
	switch (substate)
	{
	case 0:
		if(flagIndex == 1 && hit == 0)  
		{
			obj.resetHitObjectList();
			obj.getVar("hit").set_vector(0, 1);
		}
		break;
    case 1:

		if(flagIndex == 1 && hit == 0) 
		{
			obj.resetHitObjectList();
			obj.getVar("hit").set_vector(0, 1);
		}
		break;     
	case 2:

		if(flagIndex == 1 && hit == 0) 
		{
			obj.resetHitObjectList();
			obj.getVar("hit").set_vector(0, 1);
		}		
		break;
	case 3:

		if(flagIndex == 1 && hit == 0) 
		{
			obj.resetHitObjectList();
			obj.getVar("hit").set_vector(0, 1);
		}		
		break;
	}
}

function onProcCon_NewRandomShoot(obj)
{
	if(!obj) return;
	if(!obj) return;
	local state = obj.sq_GetState();
	local substate = obj.getSkillSubState();
	local objVar = obj.getVar();
	sq_SetKeyxEnable(obj, E_JUMP_COMMAND, true);
	if (sq_IsEnterCommand(obj, E_JUMP_COMMAND))
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		return;
	}
	sq_SetKeyxEnable(obj, E_ATTACK_COMMAND, true);
	obj.setSkillCommandEnable(24, true);
	if (sq_IsEnterCommand(obj, E_ATTACK_COMMAND) || obj.sq_IsEnterSkill(24) != -1)
	{
		local cCount = objVar.get_vector(3);
		local maxCount = objVar.get_vector(2);
		if (cCount < maxCount)
		{
			cCount += 1;
			objVar.set_vector(3, cCount);
			local cAniSpeed = sq_GetUniformVelocity(objVar.get_vector(1), objVar.get_vector(0), cCount, maxCount);
					
			
			sq_BinaryStartWrite();
			sq_BinaryWriteDword(cAniSpeed);
			sq_SendChangeSkillEffectPacket(obj, STATE_RandomShoot);
		}
	}
}

function onChangeSkillEffect_NewRandomShoot(obj, skillIndex, reciveData)
{
	if (!obj) return;
		if (skillIndex != STATE_RandomShoot)
			return;
			local cAniSpeed = (reciveData.readDword()).tofloat() / 100.0;
			obj.sq_SetStaticSpeedInfo(0, 0, SPEED_VALUE_DEFAULT, (SPEED_VALUE_DEFAULT * cAniSpeed).tointeger(), 2.0, 2.0);
}

function onEndCurrentAni_NewRandomShoot(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	switch (substate)
	{
	case 0:
		if (obj.getVar("atkCount").get_vector(0) < obj.getVar("atkCount").get_vector(1))
        {
			local ramdom = sq_getRandom(1,3)
			sq_IntVectorClear(sq_GetGlobalIntVector());
			sq_IntVectorPush(sq_GetGlobalIntVector(), ramdom);
			sq_AddSetStatePacketActiveObject(obj, STATE_RandomShoot, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
		}else
		{
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
		break;
	case 1:
		if (obj.getVar("atkCount").get_vector(0) < obj.getVar("atkCount").get_vector(1))
        {
			local ramdom = sq_getRandom(2,3)
			sq_IntVectorClear(sq_GetGlobalIntVector());
			sq_IntVectorPush(sq_GetGlobalIntVector(), ramdom);
			sq_AddSetStatePacketActiveObject(obj, STATE_RandomShoot, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
		}else
		{
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
		break;
    case 2:
		if (obj.getVar("atkCount").get_vector(0) < obj.getVar("atkCount").get_vector(1))
        {
			local ramdom = sq_getRandom(0,1)
			sq_IntVectorClear(sq_GetGlobalIntVector());
			sq_IntVectorPush(sq_GetGlobalIntVector(), ramdom);
			sq_AddSetStatePacketActiveObject(obj, STATE_RandomShoot, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
		}else
		{
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
		break;
    case 3:
		if (obj.getVar("atkCount").get_vector(0) < obj.getVar("atkCount").get_vector(1))
        {
			local ramdom = sq_getRandom(0,2)
			sq_IntVectorClear(sq_GetGlobalIntVector());
			sq_IntVectorPush(sq_GetGlobalIntVector(), ramdom);
			sq_AddSetStatePacketActiveObject(obj, STATE_RandomShoot, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
		}else
		{
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
		break;
	}
}

function Common_Image_Gunner(obj,aniFilename, disX, disY, disZ, imgangle, imgRate, Parent, SpeedRate)
{
	local angle = imgangle;
	local ani = sq_CreateAnimation("",aniFilename);
	sq_SetfRotateAngle(ani, sq_ToRadian(-angle.tofloat()));
	local sizeRate = imgRate;
	local size = sizeRate.tofloat() / 100.0;
	ani.setImageRateFromOriginal(size, size);
	ani.setAutoLayerWorkAnimationAddSizeRate(size);
	local setSpeedRateF = 100 * SpeedRate;
	ani.setSpeedRate(setSpeedRateF.tofloat()); 
	local pooledObj = sq_CreatePooledObject(ani,true);

	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	if (Parent == 0) 
	{
		sq_moveWithParent(obj, pooledObj);
	}
		sq_AddObject(obj,pooledObj,2,false);
}
