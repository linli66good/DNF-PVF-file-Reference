





 
function checkExecutableSkill_atgunner_pistolcarbine(obj)
{
 if(!obj) return false; 
 local isUse = obj.sq_IsUseSkill(241); 
 if(isUse) 
 {
 local state = obj.getState(); 
 switch(state)
 {
 case 6:
 case 7:
 obj.sq_IntVectClear();
 obj.sq_IntVectPush(3); 
 obj.sq_AddSetStatePacket(241, STATE_PRIORITY_USER, true); 
 break;
 default:
 obj.sq_IntVectClear();
 obj.sq_IntVectPush(0); 
 obj.sq_AddSetStatePacket(241, STATE_PRIORITY_USER, true); 
 break;
 }
 return true; 
 }
 return false; 
} ;

 
function checkCommandEnable_atgunner_pistolcarbine(obj)
{
 if(!obj) return false; 
 local state = obj.sq_GetState(); 
 if(state == STATE_STAND) 
 return true; 
 if(state == STATE_ATTACK) 
 {
 return obj.sq_IsCommandEnable(241); 
 }
 return true; 
} ;

 
function onSetState_atgunner_pistolcarbine(obj, state, datas, isResetTimer)
{
 if(!obj) return; 
 obj.sq_StopMove(); 
 obj.sq_ZStop(); 
 local subState = obj.sq_GetVectorData(datas, 0); 
 obj.setSkillSubState(subState); 
 switch(subState)
 {
 case 0:
 case 3:
 obj.getVar().clear_vector(); 
 local sq_var = obj.getVar(); 
 sq_var.push_vector(0); 
 sq_var.push_vector(3); 
 obj.getVar("aniobj").clear_obj_vector(); 
 onAddPooledObj_atgunner_pistolcarbine(obj, "passiveobject/script_sqr_nut_qq506807329/atgunner/animation/pistolcarbine/duststart_1.ani", obj.getXPos(), obj.getYPos());
 break;
 case 1:
 case 4:
 if(obj.getVar("aniobj").get_obj_vector_size() <= 0)
 {
 local ani = onAddPooledObj_atgunner_pistolcarbine(obj, "passiveobject/script_sqr_nut_qq506807329/atgunner/animation/pistolcarbine/dustloop_1.ani", obj.getXPos(), obj.getYPos());
 obj.getVar("aniobj").push_obj_vector(ani); 
 }
 
 obj.getVar().set_vector(0, obj.getVar().get_vector(0) + 1);
 break;
 case 2:
 case 5:
 RemoveAllAni(obj); 
 onAddPooledObj_atgunner_pistolcarbine(obj, "passiveobject/script_sqr_nut_qq506807329/atgunner/animation/pistolcarbine/dustend_1.ani", obj.getXPos(), obj.getYPos());
 break;
 }
 switch(subState)
 {
 case 0:
 obj.sq_SetCurrentAnimation(127);
 local skill_level = sq_GetSkillLevel(obj, 242);
	if(skill_level >0)
 {
 obj.sq_StartWrite();
 obj.sq_WriteDword(242); 
 obj.sq_WriteDword(1); 
 obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(242, 242, 0, 1.0)); 
 obj.sq_WriteDword(obj.sq_GetLevelData(242, 1, sq_GetSkillLevel(obj, 242))); 
 sq_SendCreatePassiveObjectPacketPos(obj, 24376, 0,
 sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 400), obj.getYPos(), 0);
 }
 break;
 case 1:
 obj.sq_SetCurrentAnimation(128);
 break;
 case 2:
 obj.sq_SetCurrentAnimation(129);
 break;
 case 3:
 obj.sq_SetCurrentAnimation(130);
 local skill_level1 = sq_GetSkillLevel(obj, 242);
	if(skill_level1 >0)
 {
 obj.sq_StartWrite();
 obj.sq_WriteDword(242); 
 obj.sq_WriteDword(1); 
 obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(242, 242, 0, 1.0)); 
 obj.sq_WriteDword(obj.sq_GetLevelData(242, 1, sq_GetSkillLevel(obj, 242))); 
 sq_SendCreatePassiveObjectPacketPos(obj, 24376, 0,
 sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 400), obj.getYPos(), 0);
 }
 break;
 case 4:
 obj.sq_SetCurrentAnimation(131);
 break;
 case 5:
 obj.sq_SetCurrentAnimation(132);
 break;
 }
 obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0); 
} ;

function onEndState_atgunner_pistolcarbine(obj, new_state)
{
 if(!obj) return;
 if(new_state != 241)
 RemoveAllAni(obj); 
} ;

function onKeyFrameFlag_atgunner_pistolcarbine(obj, flagIndex)
{
 if(!obj) return false;
 local subState = obj.getSkillSubState(); 
 if(obj.sq_IsMyControlObject())
 switch(flagIndex)
 {
 case 0:
 case 1:
 local aYy8BVmrtlqIiP4qa3G0 = 1; 
 local OocrHLC687xf3Md = 70; 
 local DAoZpZ37el4bBUdxbsnfAC74 = 100; 
 local u6aUarSOeWpv75Dyg0f = ENUM_ELEMENT_NONE; 
 if(subState > 2)
 {
 aYy8BVmrtlqIiP4qa3G0 = 2;
 switch(flagIndex)
 {
 case 0:OocrHLC687xf3Md = 58; DAoZpZ37el4bBUdxbsnfAC74 = 45; break;
 case 1:OocrHLC687xf3Md = 45; DAoZpZ37el4bBUdxbsnfAC74 = 45; break;
 }
 }
 else if(flagIndex == 1)
 DAoZpZ37el4bBUdxbsnfAC74 = 80;
 
 local x9lD0KPk_tHRttwFPlZta = obj.sq_GetDefaultAttackInfo(0); 
 for(local F53NhuD8dCAouNYmYxcpPB = ENUM_ELEMENT_FIRE; F53NhuD8dCAouNYmYxcpPB < ENUM_ELEMENT_NONE; F53NhuD8dCAouNYmYxcpPB++)
 if(x9lD0KPk_tHRttwFPlZta.isValidElement(F53NhuD8dCAouNYmYxcpPB)) 
 {
 u6aUarSOeWpv75Dyg0f = F53NhuD8dCAouNYmYxcpPB; 
 break;
 }
 obj.sq_StartWrite();
 obj.sq_WriteDword(241); 
 obj.sq_WriteDword(1); 
 obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(241, 241, 0, 1.0)); 
 obj.sq_WriteDword(aYy8BVmrtlqIiP4qa3G0); 
 obj.sq_WriteDword(u6aUarSOeWpv75Dyg0f); 
 obj.sq_SendCreatePassiveObjectPacket(24376, 0, OocrHLC687xf3Md, -1, DAoZpZ37el4bBUdxbsnfAC74);
 break;
 }
 
 if(subState > 2 && (flagIndex == 0 || flagIndex == 1))
 {
 local AoXX_vB88lQhfP3klYLLX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -1); 
 if(obj.isMovablePos(AoXX_vB88lQhfP3klYLLX, obj.getYPos()))
 sq_setCurrentAxisPos(obj, 0, AoXX_vB88lQhfP3klYLLX); 
 sq_setCurrentAxisPos(obj, 2, obj.getZPos() + 1); 
 }
 return true;
} ;

 
function onEndCurrentAni_atgunner_pistolcarbine(obj)
{
 if(!obj) return;
 if(!obj.sq_IsMyControlObject()) return;
 local subState = obj.getSkillSubState(); 
 switch(subState)
 {
 case 1:
 case 4:
 if(obj.getVar().get_vector(0) < obj.getVar().get_vector(1)) 
 {
 obj.sq_IntVectClear();
 obj.sq_IntVectPush(subState); 
 obj.sq_AddSetStatePacket(241, STATE_PRIORITY_USER, true); 
 }
 else
 {
 obj.sq_IntVectClear();
 obj.sq_IntVectPush(subState + 1); 
 obj.sq_AddSetStatePacket(241, STATE_PRIORITY_USER, true); 
 }
 break;
 case 2:
 obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 case 5:
 obj.sq_IntVectClear();
 obj.sq_IntVectPush(1);
 obj.sq_IntVectPush(0);
 obj.sq_IntVectPush(1);
 obj.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
 break;
 default:
 obj.sq_IntVectClear();
 obj.sq_IntVectPush(subState + 1); 
 obj.sq_AddSetStatePacket(241, STATE_PRIORITY_USER, true); 
 break;
 }
} ;

function onAddPooledObj_atgunner_pistolcarbine(dDH0Lq8zKJJKtG9Vqx, BSgBPPI1OT, mCWImYtOVr_HZ_RkXoxwyaCl, LH5iq9jHXsVubtxIlmKVVx)
{
 local yoFArzIq08LPK9kD3Q__YOwd = sq_CreateAnimation("", BSgBPPI1OT); 
 local qxGD3bXdZN = sq_CreatePooledObject(yoFArzIq08LPK9kD3Q__YOwd, true); 
 sq_SetCurrentDirection(qxGD3bXdZN, dDH0Lq8zKJJKtG9Vqx.getDirection()); 
 qxGD3bXdZN.setCurrentPos(mCWImYtOVr_HZ_RkXoxwyaCl, LH5iq9jHXsVubtxIlmKVVx, 0); 
 qxGD3bXdZN = sq_SetEnumDrawLayer(qxGD3bXdZN, ENUM_DRAWLAYER_NORMAL); 
 sq_AddObject(dDH0Lq8zKJJKtG9Vqx, qxGD3bXdZN, OBJECTTYPE_DRAWONLY, false); 
 return qxGD3bXdZN;
} ;


