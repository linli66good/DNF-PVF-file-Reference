function checkExecutableSkill_photobilizer(obj)
{
	if(!obj) return false;
	local isUse = obj.sq_IsUseSkill(SKILL_photobilizer);
	if(isUse)
	{
		obj.sq_IntVectClear();
		obj.sq_AddSetStatePacket(STATE_photobilizer, STATE_PRIORITY_USER, true);
		return true;
	}
	return false;
}

function checkCommandEnable_photobilizer(obj)
{
	if(!obj) return false;
	return true;
}

function onSetState_photobilizer(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	obj.sq_ZStop();
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
		SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
	obj.sq_SetCurrentAnimation(CUSTOM_ANI_atphotobilizer_body);
	local pAni = obj.sq_GetCurrentAni();
	local delay = pAni.getDelaySum(0, 2);
	local count = 10;
	obj.setTimeEvent(0,	delay / count, count, true);
	obj.getVar("flag").clear_vector();
	obj.getVar("flag").push_vector(0);
	obj.getVar("flag").push_vector(count / 2);
	obj.getVar("delay").clear_vector();
	obj.getVar("delay").push_vector(delay);
	obj.sq_PlaySound("RG_FG_PHOTOBILIZER_01");
}


function onProc_photobilizer(obj)
{
	if(!obj) return false;
	local subState = obj.getSkillSubState();
	local ani = obj.getCurrentAnimation();
	local currentT = sq_GetCurrentTime(ani);
	local frameindex = sq_GetAnimationFrameIndex(ani);
	if(frameindex >= 9 && obj.getVar("flag").get_vector(0) == 0)
	{
		obj.sq_StartWrite();
		obj.sq_WriteDword(3);
		obj.sq_SendCreatePassiveObjectPacket(24350, 0, 120, 1, 10);
		obj.getVar("flag").set_vector(0, 1);
	}
}

photobilizerx <-[40,64,86,108,118,120,107,85,63,41]
photobilizery <-[0,0,0,0,0,1,1,1,1,1]
photobilizerz <-[50,40,30,20,10,0,-10,-20,-30,-40]
function onTimeEvent_photobilizer(obj, timeEventIndex, timeEventCount)
{	
	if(!obj) return true;
	obj.sq_StartWrite();
	obj.sq_WriteDword(4);
	obj.sq_WriteDword(photobilizerx[timeEventCount - 1]);
	obj.sq_WriteDword(photobilizery[timeEventCount - 1]);
	obj.sq_WriteDword(photobilizerz[timeEventCount - 1]);
	local y = -1;
	if(timeEventCount >= obj.getVar("flag").get_vector(1))
		y = 1;
	obj.sq_SendCreatePassiveObjectPacket(24350, 0, -0, y, 65);
}

function onEndCurrentAni_photobilizer(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;
	local subState = obj.getSkillSubState();
	if (obj.sq_IsMyControlObject())
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_IntVectPush(0);
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
	}
}
