






if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onProcCon_atgunner_punisher2(aKHrNpw48Ku1GOC_ss5)
{
 if (!aKHrNpw48Ku1GOC_ss5) return;
 onProcIsSub_My_atgunner_stylish(aKHrNpw48Ku1GOC_ss5);
} 
