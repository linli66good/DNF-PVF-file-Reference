






function onProcCon_atgunner_punisher1(INxmmdsNiiDzwE8YxKz)
{
 if (!INxmmdsNiiDzwE8YxKz) return;
 onProcIsSub_My_atgunner_stylish(INxmmdsNiiDzwE8YxKz);
} 
