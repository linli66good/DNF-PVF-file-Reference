function setCustomData_po_atgunner_skill(obj, receiveData)
{
	local Re_Data = receiveData;
	local Id = receiveData.readDword();

	local pChrOBJ = obj.getTopCharacter();
	pChrOBJ = sq_GetCNRDObjectToSQRCharacter(pChrOBJ);

	obj.getVar("po_skill_Id").clear_vector();
	obj.getVar("po_skill_Id").push_vector(Id);

	switch(Id)
	{
		case 1:
		local Ani = obj.getCustomAnimation(2);
		obj.setCurrentAnimation(Ani);
		local Group = Re_Data.readDword();
		local Unique = Re_Data.readDword();
		local attackInfo = sq_GetCustomAttackInfo(obj,0);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		local damager = sq_GetObject(obj, Group, Unique);
		if(damager)
		damager = sq_GetCNRDObjectToActiveObject(damager);
		local Xrandom = sq_getRandom(-50, 50);
		local zpos = damager.getObjectHeight()/4;
		local random = sq_getRandom(0, 80);
		local Yrandom = sq_getRandom(-20, 20);
		Common_Image_Gunner(damager,"character/gunner/effect/animation/randomshoot/sub_00.ani",
		Xrandom, Yrandom, zpos+random, 0, 85, 1, 1.00)
		Common_Image_Gunner(damager,"character/gunner/effect/animation/randomshoot/sub_01.ani",
		Xrandom, Yrandom, zpos+random, 0, 75, 1, 1.00)
		Common_Image_Gunner(damager,"character/gunner/effect/animation/randomshoot/sub_02.ani",
		Xrandom, Yrandom, zpos+random, 45, 85, 1, 1.00)
		Common_Image_Gunner(damager,"character/gunner/effect/animation/randomshoot/sub_03.ani",
		Xrandom, Yrandom, zpos+random, -45, 70, 1, 1.00)
		Common_Image_Gunner(damager,"character/gunner/effect/animation/randomshoot/sub_03.ani",
		Xrandom, Yrandom, zpos+random, -45, -70, 1, 1.00)
		local attackInfo = sq_GetCustomAttackInfo(obj,0);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		local atk = sq_GetCurrentAttackInfo(obj);
		
		local damage = Re_Data.readDword();
		if(atk) 
		{
			sq_SetCurrentAttackBonusRate(atk, damage.tointeger());
		}
		sq_SendHitObjectPacket(obj,damager,0,0,zpos);
			break;
	}
}

function onEndCurrentAni_po_atgunner_skill(obj)
{
	local Id = obj.getVar("po_skill_Id").get_vector(0);
	if(Id == 1)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
}
