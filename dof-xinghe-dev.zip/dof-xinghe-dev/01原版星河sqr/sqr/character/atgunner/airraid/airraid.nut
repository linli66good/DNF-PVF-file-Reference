

function onSetState_airraid(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	if(substate == 0)
	{
			obj.sq_SetCurrentAnimation(187);
			obj.sq_SetCurrentAttackInfo(43);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(35, -1, 2, 3.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ndelay = ani.getDelaySum(false);
			local speed = delay.tofloat() / ndelay.tofloat();
			gunner_als(obj, "character/gunner/effect/animation/atairraid/atchainenlighten/chainenlighten_attack1_01.ani", 0, 0, 0, 0, 100, 1, 1, speed, 0);
			gunner_als(obj, "character/gunner/effect/animation/atairraid/atchainenlighten/chainenlighten_dust_front1_10.ani", 0, 0, 0, 0, 100, 0, 1, speed, 0);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(obj.getXPos());
	}
	if(substate == 1)
	{
			obj.sq_SetCurrentAnimation(188);
			obj.setDirection(sq_GetOppositeDirection(obj.getDirection()));
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local sizemove = sq_GetIntData(obj, 35, 7)-100;
			obj.sq_StartWrite();
			obj.sq_WriteDword(303);
			obj.sq_SendCreatePassiveObjectPacket(24334, 0, 0-sizemove, 0, 0-sizemove);
	}
}

function onEndCurrentAni_airraid(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_AddSetStatePacket(152, STATE_PRIORITY_USER, true);
	}
	if(substate == 1)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}

function onAttack_airraid(obj, damager, boundingBox, isStuck)
{
	if (!obj) return;
	local subState = obj.getSkillSubState();
	MagicswordupOccur(obj, damager, boundingBox, isStuck);
	if (subState == 0)
	{
		local x = sq_GetCenterXPos(boundingBox) - sq_GetXPos(damager);
		local z = sq_GetCenterZPos(boundingBox) - sq_GetZPos(damager);
		Common_Image_Als(damager,"character/gunner/effect/animation/atairraid/atchainenlighten/hiteffect_08.ani", x, 0, z, 0, 100, 1, 1.0);
	}
}

function onProc_airraid(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local Ani = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(Ani);
	local frameindex = sq_GetCurrentFrameIndex(obj);
	if (substate == 0)
	{
			local ani = obj.getCurrentAnimation();
			local currentT = sq_GetCurrentTime(ani);
			local fireT = ani.getDelaySum(false);
			local objVar = obj.getVar();
			local startX = objVar.get_vector(0);
			if(startX != 0)
			{
				local dstX = sq_GetDistancePos(startX, obj.getDirection(), sq_GetUniformVelocity(0, 300, currentT, fireT/2));
				if(obj.isMovablePos(dstX, obj.getYPos()))
					sq_setCurrentAxisPos(obj, 0, dstX);
				
				else
					objVar.set_vector(0,0);
			}
	}

}


