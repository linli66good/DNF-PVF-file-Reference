mechadroppointmarkXspeed <- 600
mechadroppointmarkYspeed <- 600


function onSetState_atgunner_skill_new(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();
	switch (subState)
	{
		case 0:
			obj.sq_PlaySound("DROPSHIP_RADIO_01");
			local ani = obj.sq_GetThrowChargeAni(1);
			obj.setCurrentAnimation(ani);
			obj.getVar("flag").clear_vector();
			obj.getVar("flag").push_vector(0);
			obj.getVar("mechadroppointmark").clear_vector();
			obj.getVar("mechadroppointmark").push_vector(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 180));
			obj.getVar("mechadroppointmark").push_vector(obj.getYPos());
		break;
		case 1:
			local ani = obj.sq_GetThrowShootAni(1);
			obj.setCurrentAnimation(ani);
			if(obj.sq_IsMyControlObject())
			{
				obj.sq_StartWrite();
				obj.sq_WriteDword(2);
				sq_SendCreatePassiveObjectPacketPos(obj, 24334, 0, obj.getVar("mechadroppointmark").get_vector(0), obj.getVar("mechadroppointmark").get_vector(1) - 1, 0);
			}
		break;
		case 2:
			local ani = obj.sq_GetThrowChargeAni(3);
			obj.setCurrentAnimation(ani);
			local skillLevel = sq_GetSkillLevel(obj, 83);
			local castTime = sq_GetCastTime(obj, 83, skillLevel);
			local animation = sq_GetCurrentAnimation(obj);
			sq_SetFrameDelayTime(animation, 0, castTime);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			sq_StartDrawCastGauge(obj, castTime, true);
		break;
		case 3:
			local ani = obj.sq_GetThrowShootAni(3);
			obj.setCurrentAnimation(ani);
			if(obj.sq_IsMyControlObject())
			{
				obj.sq_StartWrite();
				obj.sq_WriteDword(4);
				obj.sq_SendCreatePassiveObjectPacket(24334, 0, 150, 1, 0);
			}
		break;
	}
}

function onProcCon_atgunner_skill_new(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local pAni = obj.getCurrentAnimation();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local currentT = sq_GetCurrentTime(pAni);
	switch (substate)
	{
		case 0:
			if(obj.isDownSkillLastKey() && frmIndex >= 2 && obj.getVar("flag").get_vector(0) == 0)
			{
				local posX = obj.getXPos();
				local posY = obj.getYPos();
				local offsetX = 180;
				offsetX = obj.sq_GetDistancePos(posX, obj.sq_GetDirection(), offsetX);
				local vx = mechadroppointmarkXspeed;
				local vy = mechadroppointmarkYspeed;
				obj.sq_AddAimPointMark(offsetX, posY, vx.tointeger(), vy.tointeger());
				obj.getVar("flag").set_vector(0, 1);
			}
			if(!obj.isDownSkillLastKey() && frmIndex >= 2 || obj.getVar("flag").get_vector(0) == 1 && currentT >= 900)
			{
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1);
				obj.sq_AddSetStatePacket(120, STATE_PRIORITY_USER, true);
			}
		break;
	}
}

function onEndState_atgunner_skill_new(obj, new_state)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	switch (substate)
	{
		case 0:
			if(obj.getVar("flag").get_vector(0) == 1)
			{
				local posX = obj.getXPos();
				local posY = obj.getYPos();
				local aimPosX = obj.sq_GetAimPosX(posX, posY, false);
				local aimPosY = obj.sq_GetAimPosY(posX, posY, false);
				obj.getVar("mechadroppointmark").set_vector(0, aimPosX);
				obj.getVar("mechadroppointmark").set_vector(1, aimPosY);
				GunnerTargetWarning(obj, obj.getVar("mechadroppointmark").get_vector(0), obj.getVar("mechadroppointmark").get_vector(1), 2.5);
				obj.sq_RemoveAimPointMark();
			}
		break;
		case 2:
			sq_EndDrawCastGauge(obj);
		break;
	}
}

function onEndCurrentAni_atgunner_skill_new(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch (subState)
	{
		case 1:
		case 3:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(120, STATE_PRIORITY_USER, true);
		break;
	}
}


