






 
function checkExecutableSkill_atgunner_bloodnchain(BzDHEac6CCjA3RK)
{
 if(!BzDHEac6CCjA3RK) return false; 
 local mpZoI7Lhla4YR8jXB = BzDHEac6CCjA3RK.sq_IsUseSkill(239); 
 if(mpZoI7Lhla4YR8jXB) 
 {
 BzDHEac6CCjA3RK.sq_IntVectClear();
 BzDHEac6CCjA3RK.sq_IntVectPush(0); 
 BzDHEac6CCjA3RK.sq_AddSetStatePacket(239, STATE_PRIORITY_USER, true); 
 
 return true; 
 }
 return false;
} 

 

if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function checkCommandEnable_atgunner_bloodnchain(UTw2Wcb5GOCAgHLrhA4jE)
{
 if(!UTw2Wcb5GOCAgHLrhA4jE) return false; 
 local nMA5_5v2Radcgoxd4naQV2 = UTw2Wcb5GOCAgHLrhA4jE.sq_GetState(); 
 if(nMA5_5v2Radcgoxd4naQV2 == STATE_STAND) 
 return true; 
 if(nMA5_5v2Radcgoxd4naQV2 == STATE_ATTACK) 
 {
 return UTw2Wcb5GOCAgHLrhA4jE.sq_IsCommandEnable(239); 
 }
 return true; 
} 

 
function onSetState_atgunner_bloodnchain(UTw2Wcb5GOCAgHLrhA4jE, nMA5_5v2Radcgoxd4naQV2, TUhl3TGOt8F, sovvlmD4QgXj)
{
 
 
 
 
 
 
 if(!UTw2Wcb5GOCAgHLrhA4jE) return; 
 local D3Ub62CjXwhWRlgHR7 = UTw2Wcb5GOCAgHLrhA4jE.sq_GetVectorData(TUhl3TGOt8F, 0); 
 UTw2Wcb5GOCAgHLrhA4jE.setSkillSubState(D3Ub62CjXwhWRlgHR7); 
 switch(D3Ub62CjXwhWRlgHR7)
 {
 case 0:
 if(UTw2Wcb5GOCAgHLrhA4jE.isMyControlObject()) 
 CNSquirrelAppendage.sq_AppendAppendage(UTw2Wcb5GOCAgHLrhA4jE, UTw2Wcb5GOCAgHLrhA4jE, 239, true, "character/atgunner/appendage/ap_cutin_ani.nut", true); 
 UTw2Wcb5GOCAgHLrhA4jE.sq_StopMove(); 
 UTw2Wcb5GOCAgHLrhA4jE.getVar().clear_vector(); 
 UTw2Wcb5GOCAgHLrhA4jE.getVar().clear_obj_vector(); 
 UTw2Wcb5GOCAgHLrhA4jE.sq_SetCurrentAnimation(124);
 UTw2Wcb5GOCAgHLrhA4jE.sq_SetCurrentAttackInfo(33);
 UTw2Wcb5GOCAgHLrhA4jE.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0); 
 break;
 }
} 

function onAttack_atgunner_bloodnchain(w8gHOr3BsSE3watvO9, vpdIkgMitWQQdAA2POVW3x9, BiUCLkGhOStoYkBjPBH, GwualivHFmJV8AA)
{
 if(!w8gHOr3BsSE3watvO9) return;
 local D4jFGqLWclgi = w8gHOr3BsSE3watvO9.getSkillSubState();
 switch(D4jFGqLWclgi)
 {
 case 0:
 if(GwualivHFmJV8AA || !vpdIkgMitWQQdAA2POVW3x9.isObjectType(OBJECTTYPE_ACTIVE)) return; 
 local QL7YHKD1slQVME9Vp9CID = sq_GetCurrentFrameIndex(w8gHOr3BsSE3watvO9); 
 
 if(!CNSquirrelAppendage.sq_IsAppendAppendage(vpdIkgMitWQQdAA2POVW3x9, "character/atgunner/bloodnchain/ap_bloodnchain.nut"))
 {
 if(sq_IsHoldable(w8gHOr3BsSE3watvO9, vpdIkgMitWQQdAA2POVW3x9)) 
 {
 local Ov2nWpYH0Xt3iIOuaZ_8 = CNSquirrelAppendage.sq_AppendAppendage(vpdIkgMitWQQdAA2POVW3x9, w8gHOr3BsSE3watvO9, 239, true, "character/atgunner/bloodnchain/ap_bloodnchain.nut", true);
 sq_HoldAndDelayDie(vpdIkgMitWQQdAA2POVW3x9, w8gHOr3BsSE3watvO9, true, true, false, 0, 0, ENUM_DIRECTION_NEUTRAL, Ov2nWpYH0Xt3iIOuaZ_8);
 if(QL7YHKD1slQVME9Vp9CID >= 19 && !sq_IsFixture(vpdIkgMitWQQdAA2POVW3x9) && sq_IsGrabable(w8gHOr3BsSE3watvO9, vpdIkgMitWQQdAA2POVW3x9))
 {
 Ov2nWpYH0Xt3iIOuaZ_8.getVar().setBool(0, true); 
 sq_MoveToAppendage(vpdIkgMitWQQdAA2POVW3x9, w8gHOr3BsSE3watvO9, w8gHOr3BsSE3watvO9, 265, -20, 0, 100, true, Ov2nWpYH0Xt3iIOuaZ_8); 
 }
 w8gHOr3BsSE3watvO9.getVar().push_obj_vector(vpdIkgMitWQQdAA2POVW3x9); 
 }
 }
 
 local UJLHnPUeozWMGrQ = sq_GetXPos(vpdIkgMitWQQdAA2POVW3x9); 
 local guzdvlIIVslr2H1ITa2 = sq_GetYPos(vpdIkgMitWQQdAA2POVW3x9) + 1; 
 local pA2Q_ROjT4xx7T4RbDKq = sq_GetZPos(vpdIkgMitWQQdAA2POVW3x9); 
 local pZrulqxkXszq = sq_GetHeightObject(vpdIkgMitWQQdAA2POVW3x9); 
 if(QL7YHKD1slQVME9Vp9CID < 16)
 onAddHitEff_atgunner_bloodnchain(w8gHOr3BsSE3watvO9, "character/gunner/effect/animation/atbloodnchain/hit/bloodattc05.ani", UJLHnPUeozWMGrQ, guzdvlIIVslr2H1ITa2, pA2Q_ROjT4xx7T4RbDKq + pZrulqxkXszq / 2, false);
 else if(QL7YHKD1slQVME9Vp9CID < 23)
 onAddHitEff_atgunner_bloodnchain(w8gHOr3BsSE3watvO9, "character/gunner/effect/animation/atbloodnchain/hit/bloodattc05.ani", UJLHnPUeozWMGrQ, guzdvlIIVslr2H1ITa2, pA2Q_ROjT4xx7T4RbDKq + pZrulqxkXszq / 2, (pZrulqxkXszq / 120.0).tofloat());
 else
 onAddHitEff_atgunner_bloodnchain(w8gHOr3BsSE3watvO9, "character/gunner/effect/animation/atbloodnchain/hit/bloodattc05.ani", UJLHnPUeozWMGrQ, guzdvlIIVslr2H1ITa2, pA2Q_ROjT4xx7T4RbDKq + pZrulqxkXszq / 2, false);
 break;
 }
} 

function onKeyFrameFlag_atgunner_bloodnchain(uG_GG7WDDWHfa1WnV_ZbX, WxaRxFm1SHcmggJteK6)
{
 if(!uG_GG7WDDWHfa1WnV_ZbX) return false;
 local uoQrgXbhfy4kZvivxqRHrSJ = sq_IsMyControlObject(uG_GG7WDDWHfa1WnV_ZbX); 
 local ZSRePIG2k0zyX7tWyqTvS4UL = uG_GG7WDDWHfa1WnV_ZbX.getSkillSubState(); 
 switch(ZSRePIG2k0zyX7tWyqTvS4UL)
 {
 case 0:
 switch(WxaRxFm1SHcmggJteK6)
 {
 case 1:
 if(uoQrgXbhfy4kZvivxqRHrSJ) sq_SetMyShake(uG_GG7WDDWHfa1WnV_ZbX, 2, 100); 
 break;
 case 2:
 if(uoQrgXbhfy4kZvivxqRHrSJ) sq_SetMyShake(uG_GG7WDDWHfa1WnV_ZbX, 7, 200); 
 break;
 case 3:
 if(uoQrgXbhfy4kZvivxqRHrSJ)
 {
 sq_SetMyShake(uG_GG7WDDWHfa1WnV_ZbX, 5, 300); 
 sq_flashScreen(uG_GG7WDDWHfa1WnV_ZbX, 50, 100, 150, 178, sq_RGB(128, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM); 
 }
 uG_GG7WDDWHfa1WnV_ZbX.resetHitObjectList(); 
 break;
 case 4:
 if(uoQrgXbhfy4kZvivxqRHrSJ) sq_SetMyShake(uG_GG7WDDWHfa1WnV_ZbX, 2, 100); 
 break;
 case 5:
 local jS1tiUfkQdR = uG_GG7WDDWHfa1WnV_ZbX.getVar().get_obj_vector_size(); 
 if(jS1tiUfkQdR <= 0)break;
 local lUUk20L22RfV1 = uG_GG7WDDWHfa1WnV_ZbX.getVar(); 
 for(local e6syF4D4hBDG9a6GpA = 0; e6syF4D4hBDG9a6GpA < jS1tiUfkQdR; e6syF4D4hBDG9a6GpA++)
 {
 local kCxN4O4HJ5Ig6rPRu5 = lUUk20L22RfV1.get_obj_vector(e6syF4D4hBDG9a6GpA); 
 if(!kCxN4O4HJ5Ig6rPRu5) continue; 
 local TmcuuAUyKbBtpEa = CNSquirrelAppendage.sq_GetAppendage(kCxN4O4HJ5Ig6rPRu5, "character/atgunner/bloodnchain/ap_bloodnchain.nut"); 
 if(!TmcuuAUyKbBtpEa || TmcuuAUyKbBtpEa.getVar().getBool(0) == true)continue; 
 if(!sq_IsFixture(kCxN4O4HJ5Ig6rPRu5) && sq_IsGrabable(uG_GG7WDDWHfa1WnV_ZbX, kCxN4O4HJ5Ig6rPRu5)) 
 {
 TmcuuAUyKbBtpEa.getVar().setBool(0, true); 
 sq_MoveToAppendage(kCxN4O4HJ5Ig6rPRu5, uG_GG7WDDWHfa1WnV_ZbX, uG_GG7WDDWHfa1WnV_ZbX, 265, -20, 0, 100, true, TmcuuAUyKbBtpEa); 
 }
 }
 break;
 case 6:
 if(uoQrgXbhfy4kZvivxqRHrSJ) sq_SetMyShake(uG_GG7WDDWHfa1WnV_ZbX, 10, 200); 
 uG_GG7WDDWHfa1WnV_ZbX.resetHitObjectList(); 
 
 local kCxN4O4HJ5Ig6rPRu5 = uG_GG7WDDWHfa1WnV_ZbX.getVar().get_obj_vector(0); 
 if(kCxN4O4HJ5Ig6rPRu5)
 {
 local OrtgzriZKfDDv437HGKomu = sq_GetXPos(kCxN4O4HJ5Ig6rPRu5); 
 local p0TjJ7bskoK0dCZ4vM = sq_GetYPos(kCxN4O4HJ5Ig6rPRu5) + 1; 
 local isFX4dTOZq = sq_GetZPos(kCxN4O4HJ5Ig6rPRu5); 
 local FifU2gHFkDa2szU = sq_GetHeightObject(kCxN4O4HJ5Ig6rPRu5); 
 onAddHitEff_atgunner_bloodnchain(uG_GG7WDDWHfa1WnV_ZbX, "character/gunner/effect/animation/atbloodnchain/hit/bloodattc05.ani", OrtgzriZKfDDv437HGKomu, p0TjJ7bskoK0dCZ4vM, isFX4dTOZq + FifU2gHFkDa2szU / 2, (FifU2gHFkDa2szU / 120.0).tofloat());
 onAddHitEff_atgunner_bloodnchain(uG_GG7WDDWHfa1WnV_ZbX, "character/gunner/effect/animation/atbloodnchain/hit/bloodfinishhitattach_1.ani", OrtgzriZKfDDv437HGKomu, p0TjJ7bskoK0dCZ4vM, isFX4dTOZq + FifU2gHFkDa2szU / 2, (FifU2gHFkDa2szU / 120.0).tofloat());
 }
 break;
 case 7:
 break;
 case 8:
 if(uoQrgXbhfy4kZvivxqRHrSJ)
 {
 sq_SetMyShake(uG_GG7WDDWHfa1WnV_ZbX, 3, 150); 
 sq_flashScreen(uG_GG7WDDWHfa1WnV_ZbX, 50, 100, 50, 178, sq_RGB(128, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM); 
 }
 
 local kCxN4O4HJ5Ig6rPRu5 = uG_GG7WDDWHfa1WnV_ZbX.getVar().get_obj_vector(0); 
 if(kCxN4O4HJ5Ig6rPRu5)
 {
 local OrtgzriZKfDDv437HGKomu = sq_GetXPos(kCxN4O4HJ5Ig6rPRu5); 
 local p0TjJ7bskoK0dCZ4vM = sq_GetYPos(kCxN4O4HJ5Ig6rPRu5) + 1; 
 local isFX4dTOZq = sq_GetZPos(kCxN4O4HJ5Ig6rPRu5); 
 local FifU2gHFkDa2szU = sq_GetHeightObject(kCxN4O4HJ5Ig6rPRu5); 
 onAddHitEff_atgunner_bloodnchain(uG_GG7WDDWHfa1WnV_ZbX, "character/gunner/effect/animation/atbloodnchain/hit/bloodhitattach_1.ani", OrtgzriZKfDDv437HGKomu, p0TjJ7bskoK0dCZ4vM, isFX4dTOZq + FifU2gHFkDa2szU / 2, (FifU2gHFkDa2szU / 120.0).tofloat());
 }
 break;
 case 9:
 if(uoQrgXbhfy4kZvivxqRHrSJ) sq_SetMyShake(uG_GG7WDDWHfa1WnV_ZbX, 5, 50); 
 break;
 case 10:
 if(uoQrgXbhfy4kZvivxqRHrSJ) sq_flashScreen(uG_GG7WDDWHfa1WnV_ZbX, 500, 500, 1000, 204, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM); 
 break;
 case 11:
 onDeleteAllAp_atgunner_bloodnchain(uG_GG7WDDWHfa1WnV_ZbX); 
 if(uoQrgXbhfy4kZvivxqRHrSJ)
 {
 sq_SetMyShake(uG_GG7WDDWHfa1WnV_ZbX, 20, 500); 
 sq_flashScreen(uG_GG7WDDWHfa1WnV_ZbX, 50, 50, 150, 178, sq_RGB(128, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM); 
 local ivNgUvBWOW3N1k_99Ha3G8tl = 140; 
 uG_GG7WDDWHfa1WnV_ZbX.sq_StartWrite();
 uG_GG7WDDWHfa1WnV_ZbX.sq_WriteDword(239); 
 uG_GG7WDDWHfa1WnV_ZbX.sq_WriteDword(1); 
 uG_GG7WDDWHfa1WnV_ZbX.sq_WriteDword(uG_GG7WDDWHfa1WnV_ZbX.sq_GetBonusRateWithPassive(239, 239, 0, 1.0)); 
 uG_GG7WDDWHfa1WnV_ZbX.sq_WriteDword(ivNgUvBWOW3N1k_99Ha3G8tl); 
 uG_GG7WDDWHfa1WnV_ZbX.sq_SendCreatePassiveObjectPacket(24376, 0, 106, 0, 91);
 }
 break;
 }
 break;
 }
 return true;
} 

 
function onEndCurrentAni_atgunner_bloodnchain(Sv3yBtShkKe_tHo3ebi1Mxd)
{
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return;
 if(!sq_IsMyControlObject(Sv3yBtShkKe_tHo3ebi1Mxd)) return;
 local HlASuPcRLgluXam1rUDJ = Sv3yBtShkKe_tHo3ebi1Mxd.getSkillSubState(); 
 switch(HlASuPcRLgluXam1rUDJ)
 {
 case 0:
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 }
} 

function getScrollBasisPos_atgunner_bloodnchain(Sv3yBtShkKe_tHo3ebi1Mxd)
{
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return;
 if(!Sv3yBtShkKe_tHo3ebi1Mxd.isMyControlObject())return;
 local HlASuPcRLgluXam1rUDJ = Sv3yBtShkKe_tHo3ebi1Mxd.getSkillSubState();
 switch(HlASuPcRLgluXam1rUDJ)
 {
 case 0:
 local aL4NaAntuVr9flx = Sv3yBtShkKe_tHo3ebi1Mxd.getCurrentAnimation(); 
 local q8OsQ7Jd2qZMuGoPv = sq_GetCurrentTime(aL4NaAntuVr9flx); 
 local YQYFBMNhEly7vK = sq_GetCurrentFrameIndex(Sv3yBtShkKe_tHo3ebi1Mxd);
 if(YQYFBMNhEly7vK < 38)
 {
 local Web3cF41PV9 = aL4NaAntuVr9flx.getDelaySum(0, 5); 
 local YNlRxR2LCJreAgwvg6CY0Z = sq_GetDistancePos(Sv3yBtShkKe_tHo3ebi1Mxd.getXPos(), Sv3yBtShkKe_tHo3ebi1Mxd.getDirection(), sq_GetUniformVelocity(0, 300, q8OsQ7Jd2qZMuGoPv, Web3cF41PV9)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_SetCameraScrollPosition(YNlRxR2LCJreAgwvg6CY0Z, Sv3yBtShkKe_tHo3ebi1Mxd.getYPos(), 0);
 return true;
 }
 else if(YQYFBMNhEly7vK < 41)
 {
 q8OsQ7Jd2qZMuGoPv -= aL4NaAntuVr9flx.getDelaySum(0, 37); 
 local Web3cF41PV9 = aL4NaAntuVr9flx.getDelaySum(38, 40); 
 local la7WmTE0cKIrKZHExddXdhE1 = Sv3yBtShkKe_tHo3ebi1Mxd.getXPos(); 
 local YNlRxR2LCJreAgwvg6CY0Z = sq_GetUniformVelocity(sq_GetDistancePos(la7WmTE0cKIrKZHExddXdhE1, Sv3yBtShkKe_tHo3ebi1Mxd.getDirection(), 300), la7WmTE0cKIrKZHExddXdhE1, q8OsQ7Jd2qZMuGoPv, Web3cF41PV9); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_SetCameraScrollPosition(YNlRxR2LCJreAgwvg6CY0Z, Sv3yBtShkKe_tHo3ebi1Mxd.getYPos(), 0);
 return true;
 }
 break;
 }
 return false;
} 

function onDeleteAllAp_atgunner_bloodnchain(JwUy27pyLIh)
{
 if(!JwUy27pyLIh) return;
 local lvY5jfo9QPePP6 = JwUy27pyLIh.getVar().get_obj_vector_size(); 
 if(lvY5jfo9QPePP6 <= 0)return;
 local jtqU5TeGB1TqHJjieYAd63VO = sq_GetXPos(JwUy27pyLIh); 
 local Ezv4MBvVw00 = JwUy27pyLIh.getVar(); 
 for(local qpY9OO4Fezpql04MSJup = 0; qpY9OO4Fezpql04MSJup < lvY5jfo9QPePP6; qpY9OO4Fezpql04MSJup++)
 {
 local YnqIAN47tTJhQws5 = Ezv4MBvVw00.get_obj_vector(qpY9OO4Fezpql04MSJup); 
 if(!YnqIAN47tTJhQws5) continue; 
 
 if(CNSquirrelAppendage.sq_IsAppendAppendage(YnqIAN47tTJhQws5, "character/atgunner/bloodnchain/ap_bloodnchain.nut"))
 CNSquirrelAppendage.sq_RemoveAppendage(YnqIAN47tTJhQws5, "character/atgunner/bloodnchain/ap_bloodnchain.nut");
 }
 JwUy27pyLIh.getVar().clear_obj_vector(); 
} 

function onAddHitEff_atgunner_bloodnchain(md5z0osrDxXoUPTG, JxickFo1LKA74Zv, JceCfy6im5, FwEUqFVOGUB3QGl9kE6, YfyZrlXNng_Vs9nJywma, pPfKkE7V6YYl)
{
 if(!md5z0osrDxXoUPTG) return;
 local efVPlPZN9jU1Ojy = sq_CreateAnimation("", JxickFo1LKA74Zv); 
 if(pPfKkE7V6YYl != false)
 {
 efVPlPZN9jU1Ojy.setImageRateFromOriginal(pPfKkE7V6YYl, pPfKkE7V6YYl); 
 efVPlPZN9jU1Ojy.setAutoLayerWorkAnimationAddSizeRate(pPfKkE7V6YYl); 
 }
 local Cy2DnjTZ2FJD2lPazN7 = sq_CreatePooledObject(efVPlPZN9jU1Ojy, true); 
 sq_SetCurrentDirection(Cy2DnjTZ2FJD2lPazN7, md5z0osrDxXoUPTG.getDirection()); 
 Cy2DnjTZ2FJD2lPazN7.setCurrentPos(JceCfy6im5, FwEUqFVOGUB3QGl9kE6, YfyZrlXNng_Vs9nJywma); 
 Cy2DnjTZ2FJD2lPazN7 = sq_SetEnumDrawLayer(Cy2DnjTZ2FJD2lPazN7, ENUM_DRAWLAYER_NORMAL); 
 sq_AddObject(md5z0osrDxXoUPTG, Cy2DnjTZ2FJD2lPazN7, OBJECTTYPE_DRAWONLY, false); 
} 


