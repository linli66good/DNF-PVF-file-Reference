



function sq_AddFunctionName(appendage)
{
    appendage.sq_AddFunctionName("proc", "proc_appendage_atgunner_bloodnchain")
    appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_atgunner_bloodnchain")
}


function proc_appendage_atgunner_bloodnchain(iEAWniCoQoPkEPvPs2U3qw)
{
 if(!iEAWniCoQoPkEPvPs2U3qw) return;
 local JrCNUDD2_DcY6nmo = iEAWniCoQoPkEPvPs2U3qw.getParent();
 local KbGHW8Iy7Ay1 = iEAWniCoQoPkEPvPs2U3qw.getSource(); 
 if(!JrCNUDD2_DcY6nmo || !KbGHW8Iy7Ay1|| KbGHW8Iy7Ay1.getState()!= 239)
 {
 iEAWniCoQoPkEPvPs2U3qw.setValid(false);
 return;
 }
} 


