
function onCreateObject_ATWalkShoot(obj, createObject)
{
	if(!obj) return;
	local WeaponSubType = obj.getWeaponSubType();
	local level = sq_GetSkillLevel(obj, 16);
	local size = sq_GetIntData(obj, 15, 10);
	if(level > 0 && WeaponSubType == 0)
	{
		local Object = sq_GetCNRDObjectToCollisionObject(createObject); 
		if(Object && Object.getCollisionObjectIndex() == 22001)
		{
			if(Object.isMyControlObject())
			{
				local particleCreater = null;
				particleCreater = obj.getVar().GetparticleCreaterMap("W", "character/gunner/particle/walkshootex.ptl", obj);
				particleCreater.Restart(0);
				particleCreater.SetPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(),25),obj.getYPos(), obj.getZPos()+90);
				sq_AddParticleObject(obj, particleCreater);
				obj.sq_PlaySound("R_CHAIN_POWDER_MOVE_SHOOT");
				local ani = obj.getCurrentAnimation();
				createHeadShotDown(obj, "passiveobject/skillre/gunner/animation/walkshoot/110lvequipmenteffect/110lvepicweaponaworkshot_00.ani",50, sq_getRandom(1, 5), 100,ENUM_DRAWLAYER_NORMAL,true,0,true,size,"")
			}
		}
	}
}



function onProcCon_ATWalkShoot(obj)
{
	if(!obj) return;
	local state = obj.sq_GetState();
	local SubState0 = obj.getVar("substate").get_vector(0);
	local SubState1 = obj.getVar("substate").get_vector(1);
	local SubState2 = obj.getVar("substate").get_vector(2);
	local WeaponSubType = obj.getWeaponSubType();
	local level = sq_GetSkillLevel(obj, 16);
	if(level > 0 && WeaponSubType == 0)
	{
		local Count = obj.getMyPassiveObjectCount(22001);
		for(local i=0;i<Count;++i)
		{
			local object = obj.getMyPassiveObject(22001, i);
			if(object)
			{
				sq_SendDestroyPacketPassiveObject(object);
				local objectattackInfo = sq_GetCurrentAttackInfo(object);
				local Count = obj.getMyPassiveObjectCount(22010);
				for(local i=0;i<Count;++i)
				{
					local Baopo = obj.getMyPassiveObject(22010,i);
					if(Baopo)
					{
						local size = sq_GetIntData(obj, 15, 10);
						local sizeRate = size.tofloat() / 100.0;
						local ani = sq_GetCurrentAnimation(Baopo);
						sq_SetAnimationFrameIndex(ani, 1);
						local attackBonusRate = obj.sq_GetBonusRateWithPassive(15, -1, 0, 3.0);
						local attackInfo = sq_GetCurrentAttackInfo(Baopo);
						sq_SetCurrentAttacknUpForce(attackInfo, 70);
						sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
						sq_SetCurrentAttackeHitStunTime(attackInfo, 200); 
						sq_SetAttackBoundingBoxSizeRate(ani, sizeRate, sizeRate, sizeRate);
					}
				}
			}
		}
	}
}

