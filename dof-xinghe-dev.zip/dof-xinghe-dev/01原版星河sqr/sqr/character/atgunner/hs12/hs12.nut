






 
function checkExecutableSkill_atgunner_hs12(md5z0osrDxXoUPTG)
{
 if(!md5z0osrDxXoUPTG) return false; 
 local JxickFo1LKA74Zv = md5z0osrDxXoUPTG.sq_IsUseSkill(245); 
 if(JxickFo1LKA74Zv) 
 {
 md5z0osrDxXoUPTG.sq_IntVectClear();
 md5z0osrDxXoUPTG.sq_IntVectPush(0); 
 md5z0osrDxXoUPTG.sq_AddSetStatePacket(245, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_hs12(md5z0osrDxXoUPTG)
{
 if(!md5z0osrDxXoUPTG) return false; 
 local JxickFo1LKA74Zv = md5z0osrDxXoUPTG.sq_GetState(); 
 if(JxickFo1LKA74Zv == STATE_STAND) 
 return true; 
 if(JxickFo1LKA74Zv == STATE_ATTACK) 
 {
 return md5z0osrDxXoUPTG.sq_IsCommandEnable(245); 
 }
 return true; 
} 

 
function onSetState_atgunner_hs12(pnvI_lfeYugo_CTnuyUgj8, ZpED90M6NkfwlH7, xPPX3JRKtiT8s3L, eqTggIreIqkKEPw)
{
 
 
 
 
 
 if(!pnvI_lfeYugo_CTnuyUgj8) return; 
 pnvI_lfeYugo_CTnuyUgj8.sq_StopMove(); 
 local iXoUOyp1USbLdKDXm_8i = pnvI_lfeYugo_CTnuyUgj8.sq_GetVectorData(xPPX3JRKtiT8s3L, 0); 
 pnvI_lfeYugo_CTnuyUgj8.setSkillSubState(iXoUOyp1USbLdKDXm_8i); 
 switch(iXoUOyp1USbLdKDXm_8i)
 {
 case 0:
 pnvI_lfeYugo_CTnuyUgj8.getVar().clear_vector(); 
 pnvI_lfeYugo_CTnuyUgj8.sq_SetCurrentAnimation(133);
 local DNIcbrXhFtc5 = sq_GetSkillLevel(pnvI_lfeYugo_CTnuyUgj8, 245); 
 local _kDeUGLEOR9sJJhbiRQCnhV = sq_GetCastTime(pnvI_lfeYugo_CTnuyUgj8, 245, DNIcbrXhFtc5); 
 local pw1hRXv2DkLa8fasjm1 = sq_GetCurrentAnimation(pnvI_lfeYugo_CTnuyUgj8); 
 local E9IfcZcEVwfQxq = sq_GetFrameStartTime(pw1hRXv2DkLa8fasjm1, 3); 
 local QDl_G67QgN = E9IfcZcEVwfQxq.tofloat() / _kDeUGLEOR9sJJhbiRQCnhV.tofloat(); 
 pnvI_lfeYugo_CTnuyUgj8.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED,
 SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, QDl_G67QgN, QDl_G67QgN);
 sq_StartDrawCastGauge(pnvI_lfeYugo_CTnuyUgj8, E9IfcZcEVwfQxq, true);
 
 sq_AddDrawOnlyAniFromParent(pnvI_lfeYugo_CTnuyUgj8, "character/gunner/effect/animation/aths-12/targeting_00.ani", 205, 0, 75);
 break;
 case 1:
 pnvI_lfeYugo_CTnuyUgj8.sq_SetCurrentAnimation(134);
 
 sq_AddDrawOnlyAniFromParent(pnvI_lfeYugo_CTnuyUgj8, "character/gunner/effect/animation/aths-12/hs-12apear_00.ani", -110, 0, 125);
 if(pnvI_lfeYugo_CTnuyUgj8.sq_IsMyControlObject())
 {
 local DNIcbrXhFtc5 = sq_GetSkillLevel(pnvI_lfeYugo_CTnuyUgj8, 245); 
 pnvI_lfeYugo_CTnuyUgj8.sq_StartWrite();
 pnvI_lfeYugo_CTnuyUgj8.sq_WriteDword(245); 
 pnvI_lfeYugo_CTnuyUgj8.sq_WriteDword(1); 
 pnvI_lfeYugo_CTnuyUgj8.sq_WriteDword(pnvI_lfeYugo_CTnuyUgj8.sq_GetBonusRateWithPassive(245, 245, 0, 1.0)); 
 pnvI_lfeYugo_CTnuyUgj8.sq_WriteDword(pnvI_lfeYugo_CTnuyUgj8.sq_GetLevelData(245, 1, DNIcbrXhFtc5)); 
 
 pnvI_lfeYugo_CTnuyUgj8.sq_WriteDword(sq_GetDistancePos(pnvI_lfeYugo_CTnuyUgj8.getXPos(), pnvI_lfeYugo_CTnuyUgj8.getDirection(), 205)); 
 pnvI_lfeYugo_CTnuyUgj8.sq_WriteDword(pnvI_lfeYugo_CTnuyUgj8.getZPos() + 75); 
 pnvI_lfeYugo_CTnuyUgj8.sq_SendCreatePassiveObjectPacket(24376, 0, -110, 0, 125);
 }
 pnvI_lfeYugo_CTnuyUgj8.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
 break;
 }
} 

 
function onEndCurrentAni_atgunner_hs12(MhnC4vB0_X5ElHM)
{
 if(!MhnC4vB0_X5ElHM) return;
 if(!MhnC4vB0_X5ElHM.sq_IsMyControlObject()) return;
 local cvZTN5Fzb1X8Ka = MhnC4vB0_X5ElHM.getSkillSubState(); 
 switch(cvZTN5Fzb1X8Ka)
 {
 case 0:
 MhnC4vB0_X5ElHM.sq_IntVectClear();
 MhnC4vB0_X5ElHM.sq_IntVectPush(1); 
 MhnC4vB0_X5ElHM.sq_AddSetStatePacket(245, STATE_PRIORITY_USER, true); 
 break;
 case 1:
 MhnC4vB0_X5ElHM.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 }
} 

function onEndState_atgunner_hs12(MhnC4vB0_X5ElHM, cvZTN5Fzb1X8Ka)
{
 if(!MhnC4vB0_X5ElHM) return;
 if(cvZTN5Fzb1X8Ka != 245)
 sq_EndDrawCastGauge(MhnC4vB0_X5ElHM); 
} 


