





 
function checkExecutableSkill_atgunner_mecabolt(h1LzJvtnXF)
{
 if(!h1LzJvtnXF) return false; 
 local PjpVSX8x2oN7r8nkW = h1LzJvtnXF.sq_IsUseSkill(249); 
 if(PjpVSX8x2oN7r8nkW) 
 {
 h1LzJvtnXF.sq_IntVectClear();
 h1LzJvtnXF.sq_IntVectPush(0); 
 h1LzJvtnXF.sq_AddSetStatePacket(249, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_mecabolt(h1LzJvtnXF)
{
 if(!h1LzJvtnXF) return false; 
 local PjpVSX8x2oN7r8nkW = h1LzJvtnXF.sq_GetState(); 
 if(PjpVSX8x2oN7r8nkW == STATE_STAND) 
 return true; 
 if(PjpVSX8x2oN7r8nkW == STATE_ATTACK) 
 {
 return h1LzJvtnXF.sq_IsCommandEnable(249); 
 }
 return true; 
} 

 
function onSetState_atgunner_mecabolt(Sv3yBtShkKe_tHo3ebi1Mxd, HlASuPcRLgluXam1rUDJ, aL4NaAntuVr9flx, q8OsQ7Jd2qZMuGoPv)
{
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return; 
 local YQYFBMNhEly7vK = Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetVectorData(aL4NaAntuVr9flx, 0); 
 Sv3yBtShkKe_tHo3ebi1Mxd.setSkillSubState(YQYFBMNhEly7vK); 
 switch(YQYFBMNhEly7vK)
 {
 case 0:
 Sv3yBtShkKe_tHo3ebi1Mxd.getVar().clear_vector(); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_StopMove(); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_SetCurrentAnimation(139);
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_PlaySound("FG_BOLT_MX"); 
 if(Sv3yBtShkKe_tHo3ebi1Mxd.sq_IsMyControlObject())
 {
 local Web3cF41PV9 = sq_GetSkillLevel(Sv3yBtShkKe_tHo3ebi1Mxd, 249); 
 local YNlRxR2LCJreAgwvg6CY0Z = Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetLevelData(249, 0, Web3cF41PV9); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_StartWrite();
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(249); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(1); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetBonusRateWithPassive(249, 249, 6, 1.0)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetBonusRateWithPassive(249, 249, 7, 1.0)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetBonusRateWithPassive(249, 249, 8, 1.0)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetBonusRateWithPassive(249, 249, 9, 1.0)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetBonusRateWithPassive(249, 249, 2, 1.0)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetBonusRateWithPassive(249, 249, 5, 1.0)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetLevelData(249, 3, Web3cF41PV9)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetLevelData(249, 4, Web3cF41PV9)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_WriteDword(Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetLevelData(249, 1, Web3cF41PV9)); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_SendCreatePassiveObjectPacket(24376, 0, YNlRxR2LCJreAgwvg6CY0Z, 0, 0);
 }
 break;
 }
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 

 
function onEndCurrentAni_atgunner_mecabolt(JwUy27pyLIh)
{
 if(!JwUy27pyLIh) return;
 if(!JwUy27pyLIh.sq_IsMyControlObject()) return;
 JwUy27pyLIh.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
} 

