function onAfterSetState_atgunner_throw(obj, state, datas, UUNqBfRayvGuPY73hwFActR)
{
     local Ir5tOn2b07qHOBW = obj.getThrowIndex(); 
     local AKQ1_mLzQwPn = obj.getThrowState(); 
     if(AKQ1_mLzQwPn == 1)
     switch(Ir5tOn2b07qHOBW)
     {
         case 79:
         case 80:
         case 81:
             local hdf2mbAigEIzuyWx = onGetMyPassiveObject_My(obj, 24376, 247, 1); 
             if(!hdf2mbAigEIzuyWx) break;
             if(hdf2mbAigEIzuyWx.isMyControlObject())
             {
                 local lzQW3YYEg4sETv = Ir5tOn2b07qHOBW - 79 + 10; 
                 local m4PSFF9hZCiyZnPpuMoJyN = hdf2mbAigEIzuyWx.getState(); 
                 if(lzQW3YYEg4sETv != m4PSFF9hZCiyZnPpuMoJyN)
                 {
                     local dOPjqzgUA5K_evJOcr4OIDh = -1; 
                     switch(m4PSFF9hZCiyZnPpuMoJyN)
                     {
                         case 10:dOPjqzgUA5K_evJOcr4OIDh = 5; break;
                         case 11:dOPjqzgUA5K_evJOcr4OIDh = 4; break;
                         case 12:dOPjqzgUA5K_evJOcr4OIDh = 5; break;
                     }
                     local rYS5TdIWvwc33dMBxtb92 = sq_GetGlobalIntVector(); 
                     sq_IntVectorClear(rYS5TdIWvwc33dMBxtb92); 
                     sq_IntVectorPush(rYS5TdIWvwc33dMBxtb92, dOPjqzgUA5K_evJOcr4OIDh); 
                     sq_IntVectorPush(rYS5TdIWvwc33dMBxtb92, lzQW3YYEg4sETv); 
                     hdf2mbAigEIzuyWx.addSetStatePacket(m4PSFF9hZCiyZnPpuMoJyN, rYS5TdIWvwc33dMBxtb92, STATE_PRIORITY_AUTO, false, ""); 
                }
            }
        break;
     }
    local index = obj.getThrowIndex();
    local throwState = obj.getThrowState();
    switch (index)
    {
        case 59:
            local level = sq_GetSkillLevel(obj, 170);
            if (level > 0)
            {
                obj.sq_IsEnterSkillLastKeyUnits(59);
                sq_IntVectorClear(sq_GetGlobalIntVector());
                sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
                sq_AddSetStatePacketActiveObject(obj, 120, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
            }
        break;
        case 83:
            local level = sq_GetSkillLevel(obj, 170);
            if (level > 0)
            {
                sq_IntVectorClear(sq_GetGlobalIntVector());
                sq_IntVectorPush(sq_GetGlobalIntVector(), 2);
                sq_AddSetStatePacketActiveObject(obj, 120, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
            }
        break;
    }
}

function onSetState_atgunner_throw(obj, state, datas, UUNqBfRayvGuPY73hwFActR)
{
     if(!obj) return; 
    local index = obj.getThrowIndex();
    local throwState = obj.getThrowState();
    local subState0 = obj.sq_GetVectorData(datas, 0);
    local subState1 = obj.sq_GetVectorData(datas, 1);
    local subState2 = obj.sq_GetVectorData(datas, 2);
    obj.getVar("substate").clear_vector();
    obj.getVar("substate").push_vector(subState0);
    obj.getVar("substate").push_vector(subState1);
    obj.getVar("substate").push_vector(subState2);
    switch (index)
    {
        case 45:
            if(throwState == 0)
            {
                obj.getVar("exppointmark45").clear_vector();
                obj.getVar("exppointmark45").push_vector(0);
                obj.getVar("exppointmark45").push_vector(0);
                obj.getVar("exppointmark45").push_vector(0);
            }
        break;
    }
}

function onCreateObject_grenade(obj, createObject)
{
	if(!obj) return;
	local object = sq_GetCNRDObjectToCollisionObject(createObject);
	if(!object) return;
	if(sq_GetSkillLevel(obj, SKILL_NITROMOTOR) > 0)
	{
		local objectindex = object.getCollisionObjectIndex();
		if(object && (objectindex == 22219 || objectindex == 22220 || objectindex == 22221))
		{
			local type = 0;
			local size = 100;
			local power = 0;
			local level1 = sq_GetSkillLevel(obj, 56);
			local level2 = sq_GetSkillLevel(obj, 57);
			local level3 = sq_GetSkillLevel(obj, 58);
			if(objectindex == 22219)
			{
				type = 10;
				size = sq_GetLevelData(obj, 56, 1, level1)/4;
				power = obj.sq_GetPowerWithPassive(56, 42, 0, -1, 4.0);
			}
			if(objectindex == 22220)
			{
				type = 20;
				size = sq_GetLevelData(obj, 57, 1, level2)/4;
				power = obj.sq_GetPowerWithPassive(57, 42, 0, -1, 0.5);
			}
			if(objectindex == 22221)
			{
				type = 30;
				size = sq_GetLevelData(obj, 58, 1, level3)/4;
				power = obj.sq_GetPowerWithPassive(58, 42, 0, -1, 0.5);
			}
			local ptl = 1;
			if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) ptl = 2;
			obj.sq_StartWrite();
			obj.sq_WriteDword(2);
			obj.sq_WriteDword(type);
			obj.sq_WriteDword(power);
			obj.sq_WriteDword(size);
			obj.sq_WriteDword(ptl);
			obj.sq_SendCreatePassiveObjectPacket(24350, 0, 30, 1, 65);
			object.sendDestroyPacket(true);
		}
	}
}

function onCreateObject_atgunner_throw(obj, createObject)
{
	if(!obj) return;
	local object = sq_GetCNRDObjectToCollisionObject(createObject);
	if(!object) return;
	local index = obj.getThrowIndex();
	if(sq_GetSkillLevel(obj, 112)> 0 && index == 45)
	{
		local objectindex = object.getCollisionObjectIndex();
		if(objectindex == 48012)
		{
			obj.sq_PlaySound("STINGER_SHOT_FALL_TP");
			object.sendDestroyPacket(true);
		}
	}
	if(sq_GetSkillLevel(obj, SKILL_NITROMOTOR) > 0)
	{
		local objectindex = object.getCollisionObjectIndex();
		if(object && (objectindex == 22219 || objectindex == 22220 || objectindex == 22221))
		{
			local type = 0;
			local size = 100;
			local power = 0;
			local level1 = sq_GetSkillLevel(obj, 56);
			local level2 = sq_GetSkillLevel(obj, 57);
			local level3 = sq_GetSkillLevel(obj, 58);
			if(objectindex == 22219)
			{
				type = 10;
				size = sq_GetLevelData(obj, 56, 1, level1)/4;
				power = obj.sq_GetPowerWithPassive(56, 42, 0, -1, 4.0);
			}
			if(objectindex == 22220)
			{
				type = 20;
				size = sq_GetLevelData(obj, 57, 1, level2)/4;
				power = obj.sq_GetPowerWithPassive(57, 13, 0, -1, 0.5);
			}
			if(objectindex == 22221)
			{
				type = 30;
				size = sq_GetLevelData(obj, 58, 1, level3)/4;
				power = obj.sq_GetPowerWithPassive(58, 13, 0, -1, 0.5);
			}
			local ptl = 0;
			if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) ptl = 2;
			obj.sq_StartWrite();
			obj.sq_WriteDword(2);
			obj.sq_WriteDword(type);
			obj.sq_WriteDword(power);
			obj.sq_WriteDword(size);
			obj.sq_WriteDword(ptl);
			obj.sq_SendCreatePassiveObjectPacket(24350, 0, 30, 1, 80);
			object.sendDestroyPacket(true);
		}
	}
}

function onProc_atgunner_throw(obj)
{
	if (!obj) return;
	local index = obj.getThrowIndex();
	local throwState = obj.getThrowState();
	switch (index)
	{
		case 45:
			if(obj.sq_GetSkillLevel(112) > 0)
			{
				local Object = obj.getMyPassiveObject(48012, obj.getMyPassiveObjectCount(48012)-1);
				if(Object)
				{
					local posX = Object.getXPos();
					local posY = Object.getYPos();
					if(Object.getXPos() > obj.getXPos())
						sq_SetCurrentDirection(Object, 0);
					else if(Object.getXPos() < obj.getXPos())
						sq_SetCurrentDirection(Object, 1);
					if(obj.getVar("exppointmark45").get_vector(2) == 0)
					{
						local count = sq_GetIntData(obj, 45, 7);
						for (local i = 0; i < count; i++)
						{
							if (obj.isMyControlObject())
							{
								obj.sq_StartWrite();
								obj.sq_WriteDword(0);
								obj.sq_WriteDword(-15);
								obj.sq_WriteWord(600 + i * 30 + sq_getRandom(30, 65) * i);
								obj.sq_WriteWord(400 + sq_getRandom(-180, 180));
								obj.sq_WriteWord(posY + sq_getRandom(-50, 50));
								sq_SendCreatePassiveObjectPacketPos(obj, 24201, 0, sq_GetDistancePos(posX, obj.getDirection(), -400) + sq_getRandom(-50, 50), posY + sq_getRandom(-50, 50), 400);
							}
						}
						obj.getVar("exppointmark45").set_vector(2, 1);
					}
				}
			}
		break;
	}
}

function onEndState_grenade(obj, new_state)
{
    if(!obj) return;
    if(new_state == 6)
    {
        sq_IntVectorClear(sq_GetGlobalIntVector());
        sq_IntVectorPush(sq_GetGlobalIntVector(), 1);
        sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
        sq_IntVectorPush(sq_GetGlobalIntVector(), 50);
        sq_AddSetStatePacketActiveObject(obj, 6, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
    }
}
