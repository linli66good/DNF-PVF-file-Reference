





function onAfterSetState_atgunner_aerialknee(BzDHEac6CCjA3RK, mpZoI7Lhla4YR8jXB, S2QE_uZj7WM7jJsekwl1IGW, zouJxFcvF9VJCLa)
{
 if (!BzDHEac6CCjA3RK) return;
 local vi0ujaXyakOtlVrXkry = BzDHEac6CCjA3RK.sq_GetVectorData(S2QE_uZj7WM7jJsekwl1IGW, 0); 
 BzDHEac6CCjA3RK.getVar().clear_vector(); 
 BzDHEac6CCjA3RK.getVar().push_vector(vi0ujaXyakOtlVrXkry); 
} 




if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onProcCon_atgunner_aerialknee(BzDHEac6CCjA3RK)
{
 if (!BzDHEac6CCjA3RK) return;
 local mpZoI7Lhla4YR8jXB = BzDHEac6CCjA3RK.getVar().get_vector(0);
 if (mpZoI7Lhla4YR8jXB == 4) 
 onProcIsSub_My_atgunner_stylish(BzDHEac6CCjA3RK)
} 
