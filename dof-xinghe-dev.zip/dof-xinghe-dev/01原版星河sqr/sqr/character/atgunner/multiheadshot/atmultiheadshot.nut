function onGetMyPassiveObject_My(E4bfx7uQzohHz9o2AtmldE,BdUS7iApQxJ,T88mtZZDWBF11K, QOvjxC_E1Gd8o)
{
 local MHsELPXEUamxKcMQYPu0t = E4bfx7uQzohHz9o2AtmldE.getMyPassiveObjectCount(BdUS7iApQxJ); 
 for (local r3ffQb7DLAQ1E7kj98d = 0; r3ffQb7DLAQ1E7kj98d < MHsELPXEUamxKcMQYPu0t; r3ffQb7DLAQ1E7kj98d++)
 {
 local weK03cRk9RLovfSiyc8fxCl = E4bfx7uQzohHz9o2AtmldE.getMyPassiveObject(BdUS7iApQxJ, r3ffQb7DLAQ1E7kj98d); 
 if(!weK03cRk9RLovfSiyc8fxCl) continue; 
 if (weK03cRk9RLovfSiyc8fxCl.getVar("skill").get_vector(0) == T88mtZZDWBF11K)
 {
 if (QOvjxC_E1Gd8o)
 {
 if(QOvjxC_E1Gd8o == weK03cRk9RLovfSiyc8fxCl.getVar("subType").get_vector(0))
 return weK03cRk9RLovfSiyc8fxCl;
 }
 else
 return weK03cRk9RLovfSiyc8fxCl;
 }
 }
 return null;
}










function onSetState_ATMultiHeadShot(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local WeaponSubType = obj.getWeaponSubType();
	if (WeaponSubType == 0 && sq_GetSkillLevel(obj, 16) > 0)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(101, STATE_PRIORITY_USER, true);
	}
}


function onSetState_NewATMultiHeadShot(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();
	local skill_level = sq_GetSkillLevel(obj, 72);
	local Rate = sq_GetIntData(obj, 72, 1)/2;
	switch(subState)
	{
		case 0:
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, 72, false, "character/gunner/multiheadshot/ap_multiheadshot.nut", true);
			onDeleteAllAp_NewATMultiHeadShot(obj)
			obj.sq_SetCurrentAnimation(42);
			als_ani(obj, "character/gunner/effect/animation/multiheadshot/range.ani", 0, -1, 0, 90, Rate-50, 0, 0, 1.0);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(43);
			als_ani(obj, "character/gunner/effect/animation/multiheadshot/range.ani", 0, -1, 0, 0, Rate-50, 0, 0, 1.0);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(41);
			als_ani(obj, "character/gunner/effect/animation/multiheadshot/range.ani", 0, -1, 0, -90, Rate-50, 0, 0, 1.0);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(44);
			als_ani(obj, "character/gunner/effect/animation/multiheadshot/range.ani", 0, -1, 0, 180, Rate-50, 0, 0, 1.0);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(42);
			als_ani(obj, "character/gunner/effect/animation/multiheadshot/range.ani", 0, -1, 0, 90, Rate-50, 0, 0, 1.0);
			break;
		case 5:
			obj.sq_PlaySound("GN_MULTIHEAD_FIN");
			obj.sq_SetCurrentAnimation(43);
			als_ani(obj, "character/gunner/effect/animation/multiheadshot/shoot.ani", 0, -1, 110, -90, 100, 0, 0, 1.0);
			local particleCreater = obj.getVar("NewMultiHeadShot").GetparticleCreaterMap("NewMultiHeadShot", "character/gunner/particle/newmultiheadshot.ptl", obj);
			particleCreater.Restart(0);
			particleCreater.SetPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(),50),obj.getYPos()-1, obj.getZPos()+1110);
			sq_AddParticleObject(obj, particleCreater);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_NewATMultiHeadShot(obj)
{
	if(!obj) return false;
	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 4:
			local objvar = obj.getVar("addshotE").get_obj_vector_size()
			if (objvar == 0)
			{
				obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
			}else
			{
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(5);
				obj.sq_AddSetStatePacket(101, STATE_PRIORITY_USER, true);
			}
			break;
		case 5:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
			break;
	}
}

function onProc_NewATMultiHeadShot(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	switch (substate)
	{
		case 0:
		case 1:
		case 2:
		case 3:
			local pAni = obj.getCurrentAnimation();
			local frameIndex = sq_GetAnimationFrameIndex(pAni);
			if (frameIndex >= 3)
			{
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(substate + 1);
				obj.sq_AddSetStatePacket(101, STATE_PRIORITY_USER, true);
			}
		break;
	}
}

function onCreateObject_NewATMultiHeadShot(obj, createObject)
{
	if(!obj) return;
	local WeaponSubType = obj.getWeaponSubType();
	local state = obj.sq_GetState();
	if(WeaponSubType == 0 && state == 101)
	{
		local Object = sq_GetCNRDObjectToCollisionObject(createObject);
		if(Object && Object.getCollisionObjectIndex() == 22001)
		{
			obj.getVar("NewMultiHeadShot").push_obj_vector(Object);
		}
	}
}

function onDeleteAllAp_NewATMultiHeadShot(obj)
{
	if(!obj) return;
	local count = obj.getVar("addshotE").get_obj_vector_size();
	if(count <= 0)return;
	local objAtkVar = obj.getVar("addshotE");
	for(local i = 0; i < count; i++)
	{
		local damager = objAtkVar.get_obj_vector(i);
		if(!damager) continue;
		
			
	}
	obj.getVar("addshotE").clear_obj_vector();
	obj.getVar("addshote").clear_obj_vector();
}

function onEndState_NewATMultiHeadShot(obj, new_state)
{
	local state = obj.sq_GetState();
	if (new_state != 101)
	{
		CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/gunner/multiheadshot/ap_multiheadshot.nut");
		onDeleteAllAp_NewATMultiHeadShot(obj)
	}
}

function onSendAttack_NewATMultiHeadShot(obj, damager,passiveObject)
{
	local targetObj = sq_GetCNRDObjectToActiveObject(damager);
	if(passiveObject && targetObj)
		if(!targetObj.isDead())
		{
			sq_SetCurrentAttackBonusRate(sq_GetCurrentAttackInfo(passiveObject), obj.sq_GetBonusRateWithPassive(72, 37, 0, 20.0));
			if(passiveObject.isMyControlObject())
				sq_SendHitObjectPacket(passiveObject, targetObj, 0, 0, sq_GetHeightObject(targetObj) / 2);
		}
}

function onProcCon_NewATMultiHeadShot(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local XRate = sq_GetIntData(obj, 72, 1) / 2;
	sq_SetKeyxEnable(obj, E_ATTACK_COMMAND, true);
	if (substate != 4)
	{
		obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 2.0, 2.0);
	}
	switch (substate)
	{
		case 0:
		case 1:
		case 2:
		case 3:
		
				local objectManager = obj.getObjectManager();
				for(local i=0; i<objectManager.getCollisionObjectNumber(); ++i)
				{
					local object = objectManager.getCollisionObject(i);
					local dis = sq_GetDistanceObject(object, obj, false);
					if(object
					&& obj.isEnemy(object)
					&& object.isObjectType(OBJECTTYPE_ACTIVE)
					&& object.isInDamagableState(obj)
					&& !obj.getVar("addshotE").is_obj_vector(object)
					&& dis <= XRate)
					{
						local activeObj = sq_GetCNRDObjectToActiveObject(object);
						if(!activeObj.isDead())
						{
							obj.getVar("addshotE").push_obj_vector(object);
							local zpos = object.getObjectHeight();
							als_ani(object, "character/gunner/effect/animation/multiheadshot/target.ani", 0, 1, zpos, 180, 100, 1, 0, 1.0);
						}
					}
				}
		break;
		case 5:
			local Count = obj.getMyPassiveObjectCount(22001);
			for(local i=0;i<Count;++i)
			{
				local object = obj.getMyPassiveObject(22001, i);
				local objecttt = obj.getVar("NewMultiHeadShot").is_obj_vector(object);
				if(object && objecttt)
				{
					setCurrentAnimationFromCutomIndex(object, 15);
					local attackInfo = sq_GetCurrentAttackInfo(object);
					local attackdelay = sq_GetAttackInfoHitDelayRateDamager(attackInfo)
					local delayrate = sq_GetLevelData(obj, 72, 2, sq_GetSkillLevel(obj, 72));
					sq_SetCurrentAttackeHitStunTime(attackInfo, delayrate*2);

					local objectManager = obj.getObjectManager();
					for(local i = 0; i < objectManager.getCollisionObjectNumber(); i++)
					{
						local Enemy = objectManager.getCollisionObject(i);
						if(Enemy
						&& obj.isEnemy(Enemy)
						&& Enemy.isObjectType(OBJECTTYPE_ACTIVE)
						&& Enemy.isInDamagableState(obj)
						&& obj.getVar("addshotE").is_obj_vector(Enemy)
						&& !obj.getVar("addshote").is_obj_vector(Enemy))
						{
							onSendAttack_NewATMultiHeadShot(obj, Enemy, object)
							obj.getVar("addshote").push_obj_vector(Enemy);
						}
					}
				}
			}
		break;
	}
}
