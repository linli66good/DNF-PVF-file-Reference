

function onProc_athouzuoli(obj){
	if(sq_GetSkillLevel(obj, 112) < 1) return;
	local skillindex = obj.getCurrentSkillIndex();
	if(skillindex == 40 || skillindex == 39){
		local movx = obj.getVar("movex").get_vector(0);
		if(obj.getXPos()!=movx){
			sq_SetVelocity(obj,0,6.0);
		}
		local stateTimer=obj.sq_GetStateTimer();
		if(stateTimer>250){
			obj.sq_StopMove();
		}
	}
}

function onSetState_athouzuoli(obj, state, datas, isResetTimer){
	obj.getVar("movex").clear_vector();
	obj.getVar("movex").push_vector(obj.getXPos());
}


