






 
function checkExecutableSkill_atgunner_g96thermobaricgranade(pnvI_lfeYugo_CTnuyUgj8)
{
 if(!pnvI_lfeYugo_CTnuyUgj8) return false; 
 local ZpED90M6NkfwlH7 = pnvI_lfeYugo_CTnuyUgj8.sq_IsUseSkill(243); 
 if(ZpED90M6NkfwlH7) 
 {
 local xPPX3JRKtiT8s3L = pnvI_lfeYugo_CTnuyUgj8.getZPos(); 
 local eqTggIreIqkKEPw = pnvI_lfeYugo_CTnuyUgj8.getState(); 
 if(xPPX3JRKtiT8s3L > 0 && (eqTggIreIqkKEPw == 6 || eqTggIreIqkKEPw == 7)) 
 {
 pnvI_lfeYugo_CTnuyUgj8.sq_IntVectClear();
 pnvI_lfeYugo_CTnuyUgj8.sq_IntVectPush(1); 
 pnvI_lfeYugo_CTnuyUgj8.sq_AddSetStatePacket(243, STATE_PRIORITY_USER, true); 
 }
 else
 {
 pnvI_lfeYugo_CTnuyUgj8.sq_IntVectClear();
 pnvI_lfeYugo_CTnuyUgj8.sq_IntVectPush(0); 
 pnvI_lfeYugo_CTnuyUgj8.sq_AddSetStatePacket(243, STATE_PRIORITY_USER, true); 
 }
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_g96thermobaricgranade(Y1Oz6wX3ep6EGj0KmTx)
{
 if(!Y1Oz6wX3ep6EGj0KmTx) return false; 
 local yUEsNv3o5v3_HEJ = Y1Oz6wX3ep6EGj0KmTx.sq_GetState(); 
 if(yUEsNv3o5v3_HEJ == STATE_STAND) 
 return true; 
 if(yUEsNv3o5v3_HEJ == STATE_ATTACK) 
 {
 return Y1Oz6wX3ep6EGj0KmTx.sq_IsCommandEnable(243); 
 }
 return true; 
} 

 
function onSetState_atgunner_g96thermobaricgranade(Y1Oz6wX3ep6EGj0KmTx, yUEsNv3o5v3_HEJ, eIKXZpWM3A5IugXy7ZbCjfc, uWMUu6FwQ8GZFWcG4R)
{
 
 
 
 
 
 
 if(!Y1Oz6wX3ep6EGj0KmTx) return; 
 Y1Oz6wX3ep6EGj0KmTx.getVar().clear_vector(); 
 Y1Oz6wX3ep6EGj0KmTx.sq_StopMove(); 
 local sjf1ORHZB5VlUw = Y1Oz6wX3ep6EGj0KmTx.sq_GetVectorData(eIKXZpWM3A5IugXy7ZbCjfc, 0); 
 Y1Oz6wX3ep6EGj0KmTx.setSkillSubState(sjf1ORHZB5VlUw); 
 switch(sjf1ORHZB5VlUw)
 {
 case 0:
 Y1Oz6wX3ep6EGj0KmTx.sq_SetCurrentAnimation(125);
 break;
 case 1:
 Y1Oz6wX3ep6EGj0KmTx.sq_ZStop(); 
 Y1Oz6wX3ep6EGj0KmTx.sq_SetCurrentAnimation(61);
 break;
 }
 Y1Oz6wX3ep6EGj0KmTx.sq_PlaySound("FG_THERMOBARIC"); 
 Y1Oz6wX3ep6EGj0KmTx.sq_SetSuperArmor(POD_VAR_SUPERARMOR); 
 Y1Oz6wX3ep6EGj0KmTx.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 

function onKeyFrameFlag_atgunner_g96thermobaricgranade(gr7I5sC266, U7E_Qx5Uv1feXyuMOB)
{
 if(!gr7I5sC266) return false;
 if(!gr7I5sC266.sq_IsMyControlObject())return true;
 local gjreb7BjBwalhh8w = gr7I5sC266.getSkillSubState(); 
 if(U7E_Qx5Uv1feXyuMOB == 1)
 {
 
 
 
 
 local ffy6Lf5MX0tkHfe = 1; 
 switch(gjreb7BjBwalhh8w)
 {
 case 0:
 if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) 
 ffy6Lf5MX0tkHfe = 3; 
 else if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL)) 
 ffy6Lf5MX0tkHfe = 4; 
 break;
 case 1:
 ffy6Lf5MX0tkHfe = 2; 
 break;
 }
 local PJqgV5LR38 = 100; 
 
 gr7I5sC266.sq_StartWrite();
 gr7I5sC266.sq_WriteDword(243); 
 gr7I5sC266.sq_WriteDword(1); 
 gr7I5sC266.sq_WriteDword(gr7I5sC266.sq_GetBonusRateWithPassive(243, 243, 0, 1.0)); 
 gr7I5sC266.sq_WriteDword(ffy6Lf5MX0tkHfe); 
 gr7I5sC266.sq_WriteDword(PJqgV5LR38); 
 if(gjreb7BjBwalhh8w == 1)
 gr7I5sC266.sq_SendCreatePassiveObjectPacket(24376, 0, 35, 0, 68);
 else
 gr7I5sC266.sq_SendCreatePassiveObjectPacket(24376, 0, 48, 0, 76);
 }
 return true;
} 

 
function onEndCurrentAni_atgunner_g96thermobaricgranade(MhnC4vB0_X5ElHM)
{
 if(!MhnC4vB0_X5ElHM) return;
 if(!MhnC4vB0_X5ElHM.sq_IsMyControlObject()) return;
 local cvZTN5Fzb1X8Ka = MhnC4vB0_X5ElHM.getSkillSubState(); 
 switch(cvZTN5Fzb1X8Ka)
 {
 case 0:
 MhnC4vB0_X5ElHM.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 case 1:
 MhnC4vB0_X5ElHM.sq_IntVectClear();
 MhnC4vB0_X5ElHM.sq_IntVectPush(1);
 MhnC4vB0_X5ElHM.sq_IntVectPush(0);
 MhnC4vB0_X5ElHM.sq_IntVectPush(250);
 MhnC4vB0_X5ElHM.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
 break;
 }
} 

function onEndState_atgunner_g96thermobaricgranade(zZAIwtzLbBGX, jdEOCIRTE2BwC)
{
 if(!zZAIwtzLbBGX) return;
 zZAIwtzLbBGX.sq_RemoveSuperArmor(POD_VAR_SUPERARMOR); 
} 



