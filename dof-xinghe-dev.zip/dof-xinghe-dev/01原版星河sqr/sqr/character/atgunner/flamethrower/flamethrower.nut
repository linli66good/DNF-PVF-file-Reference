function checkExecutableSkill_FlameThrower(obj)
{
	if(!obj) return false;
	local skill_level = sq_GetSkillLevel(obj, 112);
	if(skill_level > 0)
	{
		local isUse = obj.sq_IsUseSkill(13);
		if(isUse)
		{
			sq_IntVectorClear(sq_GetGlobalIntVector());
			sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
			sq_AddSetStatePacketActiveObject(obj, 122, sq_GetGlobalIntVector(), STATE_PRIORITY_IGNORE_FORCE);
			return true;
		}
	}
	return false;
}

function checkCommandEnable_FlameThrower(obj)
{
	if(!obj) return false;
	return true;
}

function onSetState_FlameThrower(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	local pAni = obj.sq_GetCurrentAni();
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	switch (substate)
	{
		case 0:
			print(substate)
			obj.sq_IsEnterSkillLastKeyUnits(13);
			obj.sq_SetCurrentAnimation(flamethrower_compressedflamestart);
			local pAni = obj.getCurrentAnimation();
			sq_ClearAttackBox(pAni);
			sq_AddAttackBox(pAni, -10, -10, 70, 50, 20, 70);
		break;
		case 1:
			obj.sq_SetCurrentAnimation(flamethrower_compressedflameloop);
		break;
		case 2:
			obj.sq_SetCurrentAnimation(flamethrower_compressedflameend);
			obj.sq_StartWrite();
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(-11);
			obj.sq_SendCreatePassiveObjectPacket(24201, 0, 120, 1, 60);
		break;
	}
}

function onProcCon_FlameThrower(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;
	local subState = obj.getSkillSubState();
	local ani = obj.getCurrentAnimation();
	local currentT = sq_GetCurrentTime(ani);
	local frameindex = sq_GetCurrentFrameIndex(obj);
	if(subState == 0)
	{
		switch (frameindex)
		{
			case 2:
				sq_ClearAttackBox(ani);
				sq_AddAttackBox(ani, 10, -10, 70, 150, 20, 70);
			break;
			case 4:
				sq_ClearAttackBox(ani);
			break;
		}
	}
	if(subState == 1)
	{
		if(currentT >= 70 && !obj.isDownSkillLastKey())
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(122, STATE_PRIORITY_USER, true);
		}
	}
}

function onEndCurrentAni_FlameThrower(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(subState + 1);
			obj.sq_AddSetStatePacket(122, STATE_PRIORITY_USER, true);
		break;
		case 2:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		break;
	}
}




















function checkExecutableSkill_FlameThrowerBoost(obj)
{
	if(!obj) return false;
	local skill_level = sq_GetSkillLevel(obj, 112);
	if(skill_level > 0)
	{
		local isUse = obj.sq_IsUseSkill(36);
		if(isUse)
		{
			sq_IntVectorClear(sq_GetGlobalIntVector());
			sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
			sq_AddSetStatePacketActiveObject(obj, 123, sq_GetGlobalIntVector(), STATE_PRIORITY_IGNORE_FORCE);
			return true;
		}
	}
	return false;
}

function checkCommandEnable_FlameThrowerBoost(obj)
{
	if(!obj) return false;
	return true;
}

function onSetState_FlameThrowerBoost(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	local pAni = obj.sq_GetCurrentAni();
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	switch (substate)
	{
		case 0:
			print(substate)
			obj.sq_IsEnterSkillLastKeyUnits(13);
			obj.sq_SetCurrentAnimation(flamethrowerboost_compressedflamestart_body);
			local pAni = obj.getCurrentAnimation();
			sq_ClearAttackBox(pAni);
			sq_AddAttackBox(pAni, -10, -10, 70, 50, 20, 70);
		break;
		case 1:
			obj.sq_SetCurrentAnimation(flamethrowerboost_compressedflameloop_body);
		break;
		case 2:
			obj.sq_SetCurrentAnimation(flamethrowerboost_compressedflameend_body);
			obj.sq_StartWrite();
			obj.sq_WriteDword(0);
			obj.sq_WriteDword(-12);
			obj.sq_SendCreatePassiveObjectPacket(24201, 0, 120, 1, 60);
		break;
	}
}

function onProcCon_FlameThrowerBoost(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;
	local subState = obj.getSkillSubState();
	local ani = obj.getCurrentAnimation();
	local currentT = sq_GetCurrentTime(ani);
	local frameindex = sq_GetCurrentFrameIndex(obj);
	if(subState == 0)
	{
		switch (frameindex)
		{
			case 2:
				sq_ClearAttackBox(ani);
				sq_AddAttackBox(ani, 10, -10, 70, 150, 20, 70);
			break;
			case 4:
				sq_ClearAttackBox(ani);
			break;
		}
	}
	if(subState == 1)
	{
		if(currentT >= 70 && !obj.isDownSkillLastKey())
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(123, STATE_PRIORITY_USER, true);
		}
	}
}

function onEndCurrentAni_FlameThrowerBoost(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(subState + 1);
			obj.sq_AddSetStatePacket(123, STATE_PRIORITY_USER, true);
		break;
		case 2:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		break;
	}
}
