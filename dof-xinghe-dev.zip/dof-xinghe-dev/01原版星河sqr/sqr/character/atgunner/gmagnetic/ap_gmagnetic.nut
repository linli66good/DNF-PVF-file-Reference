function sq_AddFunctionName(appendage)
{
	appendage.sq_AddFunctionName("proc", "proc_appendage_gmagnetic")
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_gmagnetic")
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_gmagnetic")
}

function proc_appendage_gmagnetic(appendage)
{
	if(!appendage) {
		return;		
	}

	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();
				
	if(!sourceObj || !parentObj) {
		appendage.setValid(false);
		return;
	}
}

function onStart_appendage_gmagnetic(appendage)
{
	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();
				
	if(!sourceObj || !parentObj) {
		appendage.setValid(false);
		return;
	}
	Aniadd_var(parentObj, "character/gunner/effect/animation/atg_magnetic/hold/02_loop/atg_magnetic_shot01_loop.ani", 0, 1, 65, 0, 100, 1, 1, 1.0, "magnetic");
}



function onEnd_appendage_gmagnetic(appendage)
{
	if(!appendage) {
		return;		
	}
	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();
				
	if(!sourceObj || !parentObj) {
		appendage.setValid(false);
		return;
	}
	Removeani(parentObj, "magnetic");
}
