function checkExecutableSkill_GMagnetic(obj)
{
	local G1 = obj.getMyPassiveObject(22247, obj.getMyPassiveObjectCount(22247)-1);
	local G2 = obj.getMyPassiveObject(22249, obj.getMyPassiveObjectCount(22249)-1);
	local G3 = obj.getMyPassiveObject(22251, obj.getMyPassiveObjectCount(22251)-1);
	if(G2 || G3) obj.setSkillCommandEnable(SKILL_GMagnetic, false);
	if(!obj || G2 || G3) return false;
	local isUse = obj.sq_IsUseSkill(SKILL_GMagnetic);
	local x = sq_GetXPos(G1);
	local y = sq_GetYPos(G1);
	local z = sq_GetZPos(G1);
	local dis = 200;
	if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection()== ENUM_DIRECTION_LEFT
		||sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection()== ENUM_DIRECTION_RIGHT)
		dis = 400;
	if(isUse)
	{
		if(G1)
		{
			local pIntVec = sq_GetGlobalIntVector();
			sq_IntVectorClear(pIntVec);
			G1.addSetStatePacket(3, pIntVec, STATE_PRIORITY_AUTO, false, "");
			gunner_als(G1, "passiveobject/skillre/gunner/animation/gmagnetic/atg_01.ani", 0, 1, 0, 0, 100, 0, 1, 1.0, 0);
			gunner_als(G1, "passiveobject/skillre/gunner/animation/gmagnetic/atg_02.ani", 0, 1, 0, 0, 100, 0, 1, 1.0, 0);
			gunner_als(G1, "passiveobject/skillre/gunner/animation/gmagnetic/atg_03.ani", 0, 1, 0, 0, 100, 0, 1, 1.0, 0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(6);
			obj.sq_WriteDword(dis);
			sq_SendCreatePassiveObjectPacketPos(obj, 24334, 0, x, y, z);
		}else 
		if(!G1 && !G2 && !G3)
		{
			if(sq_GetSkill(obj, 79).isInCoolTime())
				 return false;
			obj.sq_StartWrite();
			obj.sq_WriteDword(6);
			obj.sq_WriteDword(dis);
			obj.sq_SendCreatePassiveObjectPacket(24334, 0, -60, 1, 65);
			gunner_als(obj, "passiveobject/skillre/gunner/animation/gmagnetic/atg_01.ani", -60, 1, 65, 0, 100, 0, 1, 1.0, 0);
			gunner_als(obj, "passiveobject/skillre/gunner/animation/gmagnetic/atg_02.ani", -60, 1, 65, 0, 100, 0, 1, 1.0, 0);
			gunner_als(obj, "passiveobject/skillre/gunner/animation/gmagnetic/atg_03.ani", -60, 1, 65, 0, 100, 0, 1, 1.0, 0);
			if(obj.sq_IsUseSkill(79))
			{
				sq_IntVectorClear(sq_GetGlobalIntVector());
				sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
				sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
				sq_IntVectorPush(sq_GetGlobalIntVector(), 79);
				sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
				sq_IntVectorPush(sq_GetGlobalIntVector(), 0);
				sq_IntVectorPush(sq_GetGlobalIntVector(), 1);
				sq_IntVectorPush(sq_GetGlobalIntVector(), 14);
				sq_IntVectorPush(sq_GetGlobalIntVector(), 14);
				sq_AddSetStatePacketActiveObject(obj, 13, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
			}
		}
		return true;
	}
	return false;
}

function checkCommandEnable_GMagnetic(obj)
{
	local G1 = obj.getMyPassiveObject(22247, obj.getMyPassiveObjectCount(22247)-1);
	local G2 = obj.getMyPassiveObject(22249, obj.getMyPassiveObjectCount(22249)-1);
	local G3 = obj.getMyPassiveObject(22251, obj.getMyPassiveObjectCount(22251)-1);
	if(!obj || G2 || G3 || !G1 && sq_GetSkill(obj, 79).isInCoolTime()) return false;
	local state = obj.sq_GetState();
	return true;
}
