





 
function checkExecutableSkill_atgunner_fsc_7(Sv3yBtShkKe_tHo3ebi1Mxd)
{
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return false; 
 local HlASuPcRLgluXam1rUDJ = Sv3yBtShkKe_tHo3ebi1Mxd.sq_IsUseSkill(233); 
 if(HlASuPcRLgluXam1rUDJ) 
 {
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_AddSetStatePacket(233, STATE_PRIORITY_USER, false); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_fsc_7(Sv3yBtShkKe_tHo3ebi1Mxd)
{
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return false; 
 local HlASuPcRLgluXam1rUDJ = Sv3yBtShkKe_tHo3ebi1Mxd.sq_GetState(); 
 if(HlASuPcRLgluXam1rUDJ == STATE_STAND) 
 return true; 
 if(HlASuPcRLgluXam1rUDJ == STATE_ATTACK) 
 {
 return Sv3yBtShkKe_tHo3ebi1Mxd.sq_IsCommandEnable(233); 
 }
 return true; 
} 

 
function onSetState_atgunner_fsc_7(Sv3yBtShkKe_tHo3ebi1Mxd, HlASuPcRLgluXam1rUDJ, aL4NaAntuVr9flx, q8OsQ7Jd2qZMuGoPv)
{
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return; 
 Sv3yBtShkKe_tHo3ebi1Mxd.getVar().clear_vector(); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_StopMove(); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_SetCurrentAnimation(106);
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 

function onKeyFrameFlag_atgunner_fsc_7(xIxzVhFgaTI_b, hF7Nx9XeNu)
{
 if(!xIxzVhFgaTI_b) return false;
 if(hF7Nx9XeNu == 1)
 {
 xIxzVhFgaTI_b.getVar().clear_vector(); 
 xIxzVhFgaTI_b.getVar().push_vector(xIxzVhFgaTI_b.getXPos()); 
 xIxzVhFgaTI_b.getVar().push_vector(-20); 
 if(xIxzVhFgaTI_b.isMyControlObject())
 {
 xIxzVhFgaTI_b.sq_StartWrite();
 xIxzVhFgaTI_b.sq_WriteDword(233); 
 xIxzVhFgaTI_b.sq_WriteDword(xIxzVhFgaTI_b.sq_GetBonusRateWithPassive(233, 233, 0, 1.0)); 
 xIxzVhFgaTI_b.sq_WriteDword(xIxzVhFgaTI_b.sq_GetBonusRateWithPassive(233, 233, 1, 1.0)); 
 xIxzVhFgaTI_b.sq_WriteDword(xIxzVhFgaTI_b.sq_GetLevelData(233, 2, sq_GetSkillLevel(xIxzVhFgaTI_b, 233))); 
 xIxzVhFgaTI_b.sq_SendCreatePassiveObjectPacket(24376, 0, 139, 0, 84);
 sq_SetMyShake(xIxzVhFgaTI_b, 5, 150); 
 }
 }
 return true;
} 


if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onProc_atgunner_fsc_7(JwUy27pyLIh)
{
 if(!JwUy27pyLIh) return;
 if(JwUy27pyLIh.getVar().size_vector() <= 0) return;
 local lvY5jfo9QPePP6 = JwUy27pyLIh.getCurrentAnimation(); 
 local jtqU5TeGB1TqHJjieYAd63VO = sq_GetCurrentTime(lvY5jfo9QPePP6) - lvY5jfo9QPePP6.getDelaySum(0, 8); 
 local Ezv4MBvVw00 = lvY5jfo9QPePP6.getDelaySum(8, 10); 
 local qpY9OO4Fezpql04MSJup = JwUy27pyLIh.getVar().get_vector(1); 
 local YnqIAN47tTJhQws5 = sq_GetDistancePos(JwUy27pyLIh.getVar().get_vector(0),
 JwUy27pyLIh.getDirection(),
 sq_GetAccel(0, qpY9OO4Fezpql04MSJup, jtqU5TeGB1TqHJjieYAd63VO, Ezv4MBvVw00, true)); 
 if(JwUy27pyLIh.isMovablePos(YnqIAN47tTJhQws5, JwUy27pyLIh.getYPos())) 
 sq_setCurrentAxisPos(JwUy27pyLIh, 0, YnqIAN47tTJhQws5); 
 else
 {
 local xsKVZ49dEMZbw = sq_Abs(YnqIAN47tTJhQws5 - JwUy27pyLIh.getXPos());
 if(xsKVZ49dEMZbw != 0)
 JwUy27pyLIh.getVar().set_vector(1, (qpY9OO4Fezpql04MSJup > 0) ? qpY9OO4Fezpql04MSJup - xsKVZ49dEMZbw : qpY9OO4Fezpql04MSJup + xsKVZ49dEMZbw);
 }
} 

 
function onEndCurrentAni_atgunner_fsc_7(JwUy27pyLIh)
{
 if(!JwUy27pyLIh) return;
 if(!JwUy27pyLIh.sq_IsMyControlObject()) return;
 JwUy27pyLIh.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
} 


