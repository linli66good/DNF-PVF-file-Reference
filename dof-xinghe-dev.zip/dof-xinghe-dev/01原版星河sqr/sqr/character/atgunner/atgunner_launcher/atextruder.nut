function onSetState_atextruder(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	if(substate == 0)
	{
			obj.sq_SetCurrentAnimation(174);

	}
	if(substate == 1)
	{
			obj.sq_SetCurrentAnimation(172);
			local sizemove = obj.sq_GetIntData(71, 9)-100;
			obj.sq_StartWrite();
			obj.sq_WriteDword(112);
			obj.sq_SendCreatePassiveObjectPacket(24334, 0, -170-sizemove, 0, -35-sizemove/4);
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
	SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}

function onEndCurrentAni_atextruder(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_IntVectClear()
		obj.sq_IntVectPush(1)
		obj.sq_AddSetStatePacket(150, STATE_PRIORITY_IGNORE_FORCE, true)
	}
	if(substate == 1)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}
