


function onCreateObject_atstingerex(obj, createObject)
{
	if(!obj) return;
	local object = sq_GetCNRDObjectToCollisionObject(createObject);
	if(!object) return;
	local objectindex = object.getCollisionObjectIndex();
	local level = sq_GetSkillLevel(obj, 112);
	if (level > 0)
	{
		if(objectindex == 22260)
		{
			object.sendDestroyPacket(true);
			obj.sq_StartWrite();
			obj.sq_WriteDword(100);
			obj.sq_SendCreatePassiveObjectPacket(24334, 0, 123, 0, 170);
		}
		if(objectindex == 22289)
		{
			object.sendDestroyPacket(true);
			obj.sq_StartWrite();
			obj.sq_WriteDword(103);
			obj.sq_SendCreatePassiveObjectPacket(24334, 0, 123, 0, 170);
		}
	}
}
