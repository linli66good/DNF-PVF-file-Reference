function sq_AddFunctionName(appendage)
{
	appendage.sq_AddFunctionName("proc", "proc_appendage_tg6")
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_tg6")
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_tg6")
}

function sq_AddEffect(appendage)
{
}

function onStart_appendage_tg6(appendage)
{
	if(!appendage) return;
	local obj = appendage.getParent();
}

function proc_appendage_tg6(appendage)
{
	if(!appendage) return;
	local obj = appendage.getParent();
}

function onEnd_appendage_tg6(appendage)
{
	if(!appendage) return;
	local parentObj = appendage.getParent();
	if(!parentObj) 
	{
		appendage.setValid(false);
		return;
	}
}
