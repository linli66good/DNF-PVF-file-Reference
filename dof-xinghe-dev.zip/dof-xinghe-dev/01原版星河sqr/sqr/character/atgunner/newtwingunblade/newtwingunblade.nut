
function onSetState_newtwingunblade(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local currentT = sq_GetCurrentTime(pAni);

	obj.getVar("len").clear_vector();
	obj.getVar("len").push_vector(obj.getXPos());
	obj.getVar("len").push_vector(200);
	obj.getVar("len").push_vector(500);

	obj.setSkillSubState(substate);
	switch (substate)
	{
	case 0:
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_RushBlade_ABody);
		local atk = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackeHitStunTime(atk, 0);
	
	

		break;
	case 1:
		obj.sq_PlaySound("SLIDING");
		obj.sq_PlaySound("BRI_CUT_01");
		obj.sq_PlaySound("FG_TWINGUN_SWORD_DASH");

		obj.sq_SetCurrentAnimation(CUSTOM_ANI_RushBlade_BBody);
		obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATGUNNER_GunBladeRushBlade);
		local atk = sq_GetCurrentAttackInfo(obj);
		local skill_level = sq_GetSkillLevel(obj, SKILL_newtwingunblade);
		local rate = sq_GetLevelData(obj, SKILL_newtwingunblade, 0, skill_level)*0.01;
		local attackRate = obj.sq_GetBonusRateWithPassive(174, -1, 0, rate);
		sq_SetCurrentAttackBonusRate(atk, attackRate);
		
		
		

		break;
	case 2:;
		obj.sq_StopMove();
		obj.sq_ZStop();
		
		
		
		
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_RainbowShot);


		obj.getVar("1").clear_vector();
		obj.getVar("1").push_vector(0);
		obj.getVar("2").clear_vector();
		obj.getVar("2").push_vector(0);
		obj.getVar("0").clear_vector();
		obj.getVar("0").push_vector(0);

		break;
	case 3:
		obj.sq_PlaySound("FG_JUMP");
		obj.sq_PlaySound("JUMP_START");
		obj.sq_PlaySound("DARKCROSS_02");

		obj.sq_SetCurrentAnimation(CUSTOM_ANI_AirBlade_ABody);
		obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATGUNNER_GunBladeAirBlade);
		local atk = sq_GetCurrentAttackInfo(obj);
		local skill_level = sq_GetSkillLevel(obj, SKILL_newtwingunblade);
		local rate = sq_GetLevelData(obj, SKILL_newtwingunblade, 2, skill_level)*0.01;
		local attackRate = obj.sq_GetBonusRateWithPassive(174, -1, 0, rate);
		sq_SetCurrentAttackBonusRate(atk, attackRate);

		sq_SetZVelocity(obj, -650, 0);
		obj.sq_SetStaticMoveInfo(0, 1500, 50, false);
		obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);

		break;
	case 4:
		obj.sq_PlaySound("FG_TWINGUN_SWORD_JUMP");
		
		obj.sq_StopMove();
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_AirBlade_BBody);

		break;
	case 5:;
		obj.sq_PlaySound("MUSSANG_SPIN");
		obj.sq_PlaySound("FG_TWINGUN_RKICK");
		obj.sq_StopMove();
		obj.sq_ZStop();

		obj.sq_SetCurrentAnimation(CUSTOM_ANI_RainbowKick_ABody);
		obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATGUNNER_GunBladeRainbowKick);
		local atk = sq_GetCurrentAttackInfo(obj);
		local skill_level = sq_GetSkillLevel(obj, SKILL_newtwingunblade);
		local rate = sq_GetLevelData(obj, SKILL_newtwingunblade, 3, skill_level)*0.01;
		local attackRate = obj.sq_GetBonusRateWithPassive(174, -1, 0, rate);
		sq_SetCurrentAttackBonusRate(atk, attackRate);
		sq_SetCurrentAttacknUpForce(atk, 350); 
		sq_SetCurrentAttackeHitStunTime(atk, 0);
		break;
	}
}

function onAttack_newtwingunblade(obj, damager, boundingBox, isStuck)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local level = sq_GetSkillLevel(obj, 94);
		if (level > 0)
		{
			local blood_proc = sq_GetLevelData(obj, 94, 0, level)/10;
			local blood_level = sq_GetLevelData(obj, 94, 1, level);
			local blood_time = sq_GetLevelData(obj, 94, 2, level);
			local blood_attackRate = sq_GetLevelData(obj, 94, 3, level);
			local atk = sq_GetCurrentAttackInfo(obj)
			sq_SetChangeStatusIntoAttackInfo(atk, 0, ACTIVESTATUS_BLEEDING, blood_proc, blood_level, blood_time,blood_attackRate);
		}
}

function onProcCon_newtwingunblade(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	switch (substate)
	{
		case 1:
			local pAni = obj.sq_GetCurrentAni();
			local currentT = sq_GetCurrentTime(pAni);
			local startX = obj.getVar("len").get_vector(0);
			local FrontX = obj.getVar("len").get_vector(1);
			local maxX = obj.getVar("len").get_vector(2);
			if (currentT < maxX)
			{
				local X = sq_GetAccel(0, FrontX, currentT,maxX, true);
				local dstX = sq_GetDistancePos(startX, obj.getDirection(), X);
				if(obj.isMovablePos(dstX, obj.getYPos() ))
				{
					sq_setCurrentAxisPos(obj, 0, dstX);
				}
			}
			local isCooling = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/newtwingunblade/ap_rainbowkick_cool.nut");
			if(!isCooling)
			{
				sq_SetKeyxEnable(obj, E_JUMP_COMMAND, true)
				if (sq_IsEnterCommand(obj, E_JUMP_COMMAND))
				{
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(5);
					obj.sq_AddSetStatePacket(250, STATE_PRIORITY_USER, true);

					local coolTime = sq_GetIntData(obj, SKILL_newtwingunblade, 3);
					local cool = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, SKILL_newtwingunblade, false, "character/atgunner/newtwingunblade/ap_rainbowkick_cool.nut", false);
					cool.sq_SetValidTime(coolTime);
					CNSquirrelAppendage.sq_Append(cool, obj, obj);
				}
			}
			break;
		case 3:
		local Zpos = obj.getZPos()
			if (Zpos == 0)
			{
				sq_IntVectorClear(sq_GetGlobalIntVector());
				sq_IntVectorPush(sq_GetGlobalIntVector(), 4);
				sq_AddSetStatePacketActiveObject(obj, 250, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
			}
			break;
		case 2:
				local Count = obj.getMyPassiveObjectCount(22002);
				for(local i=0;i<Count;++i)
				{
					local hurricane = obj.getMyPassiveObject(22002,i);
					if(hurricane)
					{
						local skill_level = sq_GetSkillLevel(obj, SKILL_newtwingunblade);
						local rate = sq_GetLevelData(obj, SKILL_newtwingunblade, 1, skill_level)*0.01;
						local attackBonusRate = obj.sq_GetBonusRateWithPassive(174, -1, 0, rate);
						local attackInfo = sq_GetCurrentAttackInfo(hurricane);
						sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
					}
				}
				local pAni = obj.sq_GetCurrentAni();
				local currentT = sq_GetCurrentTime(pAni);
				local startX = obj.getVar("len").get_vector(0);
				local FrontX = obj.getVar("len").get_vector(1);
				local maxX = obj.getVar("len").get_vector(2);
				local posZ = obj.getZPos();
				if (currentT < maxX)
				{
					local X = sq_GetAccel(0, FrontX+30, currentT,maxX, true);
					local Z = sq_GetAccel(posZ, FrontX, currentT, 2000, true);
					local dstX = sq_GetDistancePos(startX, obj.getDirection(), X);
					if(obj.isMovablePos(dstX, obj.getYPos() ))
					{
						sq_setCurrentAxisPos(obj, 0, dstX);
					}
					sq_setCurrentAxisPos(obj, 2, Z);	
				}
			break;
		case 5:
				local pAni = obj.getCurrentAnimation();
				local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
				if (frmIndex > 0)
				{
					sq_SetZVelocity(obj, 370, 0);			
				}
			break;
	}
}

function onKeyFrameFlag_newtwingunblade(obj, flagIndex)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	if(substate == 2)
	{
		local countr0 = obj.getVar("0").get_vector(0);
		if(flagIndex == 0 && countr0 == 0) 
			{
				local particleCreater = null;
				particleCreater = obj.getVar().GetparticleCreaterMap("1", "character/gunner/particle/newtwingunbladeattack2.ptl", obj);
				particleCreater.Restart(0);
				particleCreater.SetPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(),20),obj.getYPos(), obj.getZPos()+100);
				sq_AddParticleObject(obj, particleCreater);
				
				local particleCreater1 = null;
				particleCreater1 = obj.getVar().GetparticleCreaterMap("2", "character/gunner/particle/newtwingunbladeattack2.ptl", obj);
				particleCreater1.Restart(0);
				particleCreater1.SetPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(),25),obj.getYPos(), obj.getZPos()+100);
				sq_AddParticleObject(obj, particleCreater1);

				obj.sq_PlaySound("G_MREVOLVERB");
				obj.sq_PlaySound("R_DIFFUSION_GUNA_HIT");
				createHeadShotDown(obj, "character/gunner/effect/animation/atgunblade/rainbowkick/rainbowkick_headshotdown.ani",-15, 0, -20,ENUM_DRAWLAYER_NORMAL,true,0,true,100,"")
				createHeadShotDown(obj, "character/gunner/effect/animation/atgunblade/rainbowkick/rainbowkick_headshotdown.ani",-10, 0, -20,ENUM_DRAWLAYER_NORMAL,true,0,true,100,"")
				obj.getVar("0").set_vector(0, 1);
			}
		local countr1 = obj.getVar("1").get_vector(0);
		if(flagIndex == 1 && countr1 == 0) 
			{

				local particleCreater = null;
				particleCreater = obj.getVar().GetparticleCreaterMap("3", "character/gunner/particle/newtwingunbladeattack1.ptl", obj);
				particleCreater.Restart(0);
				particleCreater.SetPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(),-10),obj.getYPos(), obj.getZPos()+80);
				sq_AddParticleObject(obj, particleCreater);
				
				local particleCreater1 = null;
				particleCreater1 = obj.getVar().GetparticleCreaterMap("4", "character/gunner/particle/newtwingunbladeattack1.ptl", obj);
				particleCreater1.Restart(0);
				particleCreater1.SetPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(),15),obj.getYPos(), obj.getZPos()+80);
				sq_AddParticleObject(obj, particleCreater1);

				obj.sq_PlaySound("G_MREVOLVERB");
				obj.sq_PlaySound("R_DIFFUSION_GUNA_HIT");
				createHeadShotDown(obj, "character/gunner/effect/animation/atgunblade/rainbowkick/rainbowkick_headshotdown.ani",-30, 0, -30,ENUM_DRAWLAYER_NORMAL,true,-20,true,100,"")
				createHeadShotDown(obj, "character/gunner/effect/animation/atgunblade/rainbowkick/rainbowkick_headshotdown.ani",-65, 0, -30,ENUM_DRAWLAYER_NORMAL,true,-20,true,100,"")
				obj.getVar("1").set_vector(0, 1);
			}
		local countr2 = obj.getVar("2").get_vector(0);
		if(flagIndex == 2 && countr2 == 0) 
			{
				local particleCreater = null;
				particleCreater = obj.getVar().GetparticleCreaterMap("5", "character/gunner/particle/newtwingunbladeattack3.ptl", obj);
				particleCreater.Restart(0);
				particleCreater.SetPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(),5),obj.getYPos(), obj.getZPos()+60);
				sq_AddParticleObject(obj, particleCreater);
				
				local particleCreater1 = null;
				particleCreater1 = obj.getVar().GetparticleCreaterMap("6", "character/gunner/particle/newtwingunbladeattack3.ptl", obj);
				particleCreater1.Restart(0);
				particleCreater1.SetPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(),10),obj.getYPos(), obj.getZPos()+60);
				sq_AddParticleObject(obj, particleCreater1);

				obj.sq_PlaySound("G_MREVOLVERB");
				obj.sq_PlaySound("R_DIFFUSION_GUNA_HIT");
				createHeadShotDown(obj, "character/gunner/effect/animation/atgunblade/rainbowkick/rainbowkick_headshotdown.ani",-60, 0, 0,ENUM_DRAWLAYER_NORMAL,true,-45,true,100,"")
				createHeadShotDown(obj, "character/gunner/effect/animation/atgunblade/rainbowkick/rainbowkick_headshotdown.ani",-95, 0, 0,ENUM_DRAWLAYER_NORMAL,true,-45,true,100,"")
				obj.getVar("2").set_vector(0, 1);
			}
	}
}
    
function onEndCurrentAni_newtwingunblade(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	switch (substate)
	{
	case 0:
			sq_IntVectorClear(sq_GetGlobalIntVector());
			sq_IntVectorPush(sq_GetGlobalIntVector(), 1);
			sq_AddSetStatePacketActiveObject(obj, 250, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
		break;
	case 1:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		break;
	case 2:
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_IntVectPush(0);
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(6, STATE_PRIORITY_USER, true);
		break;
	case 4:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		break;
	case 5:
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_IntVectPush(0);
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(6, STATE_PRIORITY_USER, true);
		break;
	}
 }
 

 function createHeadShotDown(obj, aniFilename,Xpos, Ypos, Zpos,DRAWLAYER,trueImage,angle,bool,Size,Push_obj)
{
	if(!obj) return
	local image = sq_CreateDrawOnlyObject(obj,aniFilename,DRAWLAYER,trueImage);
	if(bool == true)
	{
		local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), Xpos);
		image.setCurrentPos(posX,obj.getYPos() + Ypos,obj.getZPos() + Zpos);
	}
	else
	{
		image.setCurrentPos(Xpos,Ypos,Zpos);
	}
	local rotate = angle.tointeger() * 0.017453;
	image.setCustomRotate(true,rotate);
	local imageAni = image.getCurrentAnimation();
	local SizeFloat = Size.tofloat() / 100.0;
	imageAni.Proc();
	imageAni.setImageRateFromOriginal(SizeFloat, SizeFloat);
	imageAni.setAutoLayerWorkAnimationAddSizeRate(SizeFloat);
	obj.getVar(Push_obj).push_obj_vector(image);
}

function onSetState_TwinGunblade(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local state = obj.sq_GetState();
	local SubState0 = obj.getVar("substate").get_vector(0);
	local SubState1 = obj.getVar("substate").get_vector(1);
	local SubState2 = obj.getVar("substate").get_vector(2);
	local skill_level = sq_GetSkillLevel(obj, 100);
	if(skill_level >= 3)
	{
		if(SubState0 < 3)
		{
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, 100, false,"character/atgunner/newtwingunblade/ap_tg3.nut", false);
			
			CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, 250, true);
			appendage = obj.GetSquirrelAppendage("character/atgunner/newtwingunblade/ap_tg3.nut");
			if(appendage)
			{
				local attackrate = 10;
				local change_appendage = appendage.sq_getChangeStatus("LV3");
				if(!change_appendage)
				{
					change_appendage = appendage.sq_AddChangeStatusAppendageID(obj, obj, 0, 
					CHANGE_STATUS_TYPE_PHYSICAL_ATTACK_BONUS, 
					false, 0, APID_COMMON)
				}
				if(change_appendage) 
				{
					change_appendage.clearParameter();
					change_appendage.addParameter(CHANGE_STATUS_TYPE_PHYSICAL_ATTACK_BONUS, true, attackrate.tofloat());
				}
			}
		}
	}
	if(skill_level >= 6)
	{
		if(SubState0 == 3)
		{
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, 100, false,"character/atgunner/newtwingunblade/ap_tg6.nut", false);
			
			CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, 251, true);
			appendage = obj.GetSquirrelAppendage("character/atgunner/newtwingunblade/ap_tg6.nut");
			if(appendage)
			{
				local attackrate = 10;
				local change_appendage = appendage.sq_getChangeStatus("LV6");
				if(!change_appendage)
				{
					change_appendage = appendage.sq_AddChangeStatusAppendageID(obj, obj, 0, 
					CHANGE_STATUS_TYPE_PHYSICAL_ATTACK_BONUS, 
					true, 0, APID_COMMON)
				}
				if(change_appendage) 
				{
					change_appendage.clearParameter();
					change_appendage.addParameter(CHANGE_STATUS_TYPE_PHYSICAL_ATTACK_BONUS, true, attackrate.tofloat());
				}
			}
		}
	}
	if(skill_level >= 9)
	{
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, 100, false,"character/atgunner/newtwingunblade/ap_tg9.nut", false);
			
			CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, 252, true);
			appendage = obj.GetSquirrelAppendage("character/atgunner/newtwingunblade/ap_tg9.nut");
			if(appendage)
			{
				local attackrate = 10;
				local change_appendage = appendage.sq_getChangeStatus("LV9");
				if(!change_appendage)
				{
					change_appendage = appendage.sq_AddChangeStatusAppendageID(obj, obj, 0, 
					CHANGE_STATUS_TYPE_PHYSICAL_ATTACK_BONUS, 
					true, 0, APID_COMMON)
				}
				if(change_appendage) 
				{
					change_appendage.clearParameter();
					change_appendage.addParameter(CHANGE_STATUS_TYPE_PHYSICAL_ATTACK_BONUS, true, attackrate.tofloat());
				}
			}
	}
}

function onEndState_TwinGunblade(obj, new_state)
{
	if(!obj) return;
	local state = obj.sq_GetState();
	local SubState0 = obj.getVar("substate").get_vector(0);
	local SubState1 = obj.getVar("substate").get_vector(1);
	local SubState2 = obj.getVar("substate").get_vector(2);
	if (SubState0 ==3)
		{
			CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/atgunner/newtwingunblade/ap_tg3.nut");		
		}
	if (SubState0 !=3)
		{
			CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/atgunner/newtwingunblade/ap_tg6.nut");		
		}
	if (new_state !=55)
		{
			CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/atgunner/newtwingunblade/ap_tg9.nut");
		}
}
