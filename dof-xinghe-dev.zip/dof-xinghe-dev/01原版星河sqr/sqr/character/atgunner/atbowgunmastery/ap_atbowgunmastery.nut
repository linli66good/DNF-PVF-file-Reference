function sq_AddFunctionName(appendage)
{
	appendage.sq_AddFunctionName("proc", "proc_appendage_atbowgunmastery")
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_atbowgunmastery")
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_atbowgunmastery")
}

function sq_AddEffect(appendage)
{
}

function proc_appendage_atbowgunmastery(appendage)
{
	if(!appendage) return;
	local obj = appendage.getParent();
}

function onStart_appendage_atbowgunmastery(appendage)
{
	if(!appendage) return;
	local obj = appendage.getParent();
	local sqrChr = sq_GetCNRDObjectToSQRCharacter(obj);
	if(sqrChr.getWeaponSubType() == 4)
	{
		local skillLevel = sqrChr.sq_GetSkillLevel(85);
		local magicalAttackBonus = sq_GetLevelData(sqrChr, 85, 2, skillLevel);
		local attackSpeed = sq_GetLevelData(sqrChr, 85, 7, skillLevel);
		local magicalcrittcal = sq_GetLevelData(sqrChr, 85, 0, skillLevel);
		local change_appendage = appendage.sq_getChangeStatus("atbowgunmastery");
		if(!change_appendage)
		{
			change_appendage = appendage.sq_AddChangeStatus("atbowgunmastery",obj, obj, 0, CHANGE_STATUS_TYPE_MAGICAL_ATTACK_BONUS, true, magicalAttackBonus);
		}
		if(change_appendage)
		{
			change_appendage.clearParameter();
			change_appendage.addParameter(CHANGE_STATUS_TYPE_MAGICAL_ATTACK_BONUS, true, magicalAttackBonus.tofloat());
			change_appendage.addParameter(CHANGE_STATUS_TYPE_ATTACK_SPEED, false, attackSpeed.tofloat());
			change_appendage.addParameter(CHANGE_STATUS_TYPE_MAGICAL_CRITICAL_HIT_RATE, false, magicalcrittcal.tofloat());
		}
	}
}

function onEnd_appendage_atbowgunmastery(appendage)
{
	if(!appendage) return;
	local obj = appendage.getParent();
}
