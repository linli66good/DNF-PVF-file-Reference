





 
function checkExecutableSkill_atgunner_suppressingfire(JwUy27pyLIh)
{
 if(!JwUy27pyLIh) return false; 
 local lvY5jfo9QPePP6 = JwUy27pyLIh.sq_IsUseSkill(236); 
 if(lvY5jfo9QPePP6) 
 {
 JwUy27pyLIh.sq_IntVectClear();
 JwUy27pyLIh.sq_IntVectPush(0); 
 JwUy27pyLIh.sq_AddSetStatePacket(236, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_suppressingfire(JwUy27pyLIh)
{
 if(!JwUy27pyLIh) return false; 
 local lvY5jfo9QPePP6 = JwUy27pyLIh.sq_GetState(); 
 if(lvY5jfo9QPePP6 == STATE_STAND) 
 return true; 
 if(lvY5jfo9QPePP6 == STATE_ATTACK) 
 {
 return JwUy27pyLIh.sq_IsCommandEnable(236); 
 }
 return true; 
} 

 
function onSetState_atgunner_suppressingfire(md5z0osrDxXoUPTG, JxickFo1LKA74Zv, JceCfy6im5, FwEUqFVOGUB3QGl9kE6)
{
 if(!md5z0osrDxXoUPTG) return; 
 md5z0osrDxXoUPTG.sq_StopMove(); 
 local YfyZrlXNng_Vs9nJywma = md5z0osrDxXoUPTG.sq_GetVectorData(JceCfy6im5, 0); 
 md5z0osrDxXoUPTG.setSkillSubState(YfyZrlXNng_Vs9nJywma); 
 switch(YfyZrlXNng_Vs9nJywma)
 {
 case 0:
 md5z0osrDxXoUPTG.getVar().clear_vector(); 
 md5z0osrDxXoUPTG.sq_SetCurrentAnimation(115);
 md5z0osrDxXoUPTG.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0); 
 break;
 case 1:
 md5z0osrDxXoUPTG.sq_SetCurrentAnimation(116);
 md5z0osrDxXoUPTG.sq_SetCurrentAttackInfo(26); 
 local pPfKkE7V6YYl = md5z0osrDxXoUPTG.sq_GetBonusRateWithPassive(236, 236, 0, 1.0); 
 md5z0osrDxXoUPTG.sq_SetCurrentAttackBonusRate(pPfKkE7V6YYl); 
 local efVPlPZN9jU1Ojy = sq_GetSkillLevel(md5z0osrDxXoUPTG, 236); 
 local Cy2DnjTZ2FJD2lPazN7 = md5z0osrDxXoUPTG.sq_GetLevelData(236, 3, efVPlPZN9jU1Ojy); 
 md5z0osrDxXoUPTG.getVar().clear_timer_vector();
 md5z0osrDxXoUPTG.getVar().push_timer_vector();
 local CbAKle1pIJAe = md5z0osrDxXoUPTG.getVar().get_timer_vector(0);
 CbAKle1pIJAe.setParameter(Cy2DnjTZ2FJD2lPazN7, -1); 
 CbAKle1pIJAe.resetInstant(0);
 local jejRIKRP3IUZ6COOsnSo4Pf = md5z0osrDxXoUPTG.sq_GetLevelData(236, 2, efVPlPZN9jU1Ojy); 
 local apsgswr3TXAuoOD6x = md5z0osrDxXoUPTG.sq_GetLevelData(236, 4, efVPlPZN9jU1Ojy); 
 local LJ4MdipEdiMXGQHX = 280; 
 local xctfLxEyewkhRFTF = 100; 
 local XbktN44AJV4A69lgogW = 3; 
 local rMdlP96ZePca5 = 0; 
 md5z0osrDxXoUPTG.getVar().clear_vector();
 local Sixejk9T2nnx = md5z0osrDxXoUPTG.getVar(); 
 Sixejk9T2nnx.push_vector(jejRIKRP3IUZ6COOsnSo4Pf);
 Sixejk9T2nnx.push_vector(Cy2DnjTZ2FJD2lPazN7);
 Sixejk9T2nnx.push_vector(apsgswr3TXAuoOD6x);
 Sixejk9T2nnx.push_vector(LJ4MdipEdiMXGQHX);
 Sixejk9T2nnx.push_vector(xctfLxEyewkhRFTF);
 Sixejk9T2nnx.push_vector(XbktN44AJV4A69lgogW);
 Sixejk9T2nnx.push_vector(rMdlP96ZePca5);
 break;
 case 2:
 md5z0osrDxXoUPTG.sq_SetCurrentAnimation(117);
 md5z0osrDxXoUPTG.sq_SetCurrentAttackInfo(27); 
 local pPfKkE7V6YYl = md5z0osrDxXoUPTG.sq_GetBonusRateWithPassive(236, 236, 1, 1.0); 
 md5z0osrDxXoUPTG.sq_SetCurrentAttackBonusRate(pPfKkE7V6YYl); 
 sq_AddDrawOnlyAniFromParent(md5z0osrDxXoUPTG, "character/gunner/effect/animation/atsuppressingfire/03_finish/dust/suppressingfire_finish_dust01.ani", 0, 0, 0); 
 sq_AddDrawOnlyAniFromParent(md5z0osrDxXoUPTG, "character/gunner/effect/animation/atsuppressingfire/03_finish/front/suppressingfire_finish_front.ani", 0, 30, 0); 
 break;
 }
} 

function onProc_atgunner_suppressingfire(gr7I5sC266)
{
 if(!gr7I5sC266) return;
 local U7E_Qx5Uv1feXyuMOB = gr7I5sC266.getSkillSubState(); 
 if(U7E_Qx5Uv1feXyuMOB == 1)
 {
 local gjreb7BjBwalhh8w = gr7I5sC266.getVar().get_timer_vector(0);
 if(gjreb7BjBwalhh8w)
 {
 if(gjreb7BjBwalhh8w.isOnEvent(gr7I5sC266.sq_GetStateTimer()) == true) 
 gr7I5sC266.resetHitObjectList(); 
 }
 }
} 

function onProcCon_atgunner_suppressingfire(gr7I5sC266)
{
 if(!gr7I5sC266) return;
 local U7E_Qx5Uv1feXyuMOB = gr7I5sC266.getSkillSubState(); 
 if(U7E_Qx5Uv1feXyuMOB == 1)
 {
 local gjreb7BjBwalhh8w = gr7I5sC266.getVar(); 
 
 if(gr7I5sC266.sq_GetStateTimer() >= gjreb7BjBwalhh8w.get_vector(0))
 {
 gr7I5sC266.sq_IntVectClear();
 gr7I5sC266.sq_IntVectPush(2); 
 gr7I5sC266.sq_AddSetStatePacket(236, STATE_PRIORITY_USER, true); 
 return;
 }
 sq_SetKeyxEnable(gr7I5sC266, E_JUMP_COMMAND, true); 
 if(sq_IsEnterCommand(gr7I5sC266, E_JUMP_COMMAND)) 
 {
 gr7I5sC266.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 return;
 }
 sq_SetKeyxEnable(gr7I5sC266, E_ATTACK_COMMAND, true); 
 gr7I5sC266.setSkillCommandEnable(236, true); 
 if(sq_IsEnterCommand(gr7I5sC266, E_ATTACK_COMMAND) || gr7I5sC266.sq_IsEnterSkill(236) != -1)
 {
 local ffy6Lf5MX0tkHfe = gjreb7BjBwalhh8w.get_vector(6); 
 local PJqgV5LR38 = gjreb7BjBwalhh8w.get_vector(5); 
 if(ffy6Lf5MX0tkHfe < PJqgV5LR38) 
 {
 ffy6Lf5MX0tkHfe += 1; 
 gjreb7BjBwalhh8w.set_vector(6, ffy6Lf5MX0tkHfe); 
 local pmMGD4VPsPah38tR7 = sq_GetUniformVelocity(gjreb7BjBwalhh8w.get_vector(1), gjreb7BjBwalhh8w.get_vector(2), ffy6Lf5MX0tkHfe, PJqgV5LR38); 
 local _7H7gAQMFjwcE2PZXhVr = sq_GetUniformVelocity(gjreb7BjBwalhh8w.get_vector(4), gjreb7BjBwalhh8w.get_vector(3), ffy6Lf5MX0tkHfe, PJqgV5LR38); 
 
 sq_BinaryStartWrite();
 sq_BinaryWriteDword(pmMGD4VPsPah38tR7);
 sq_BinaryWriteDword(_7H7gAQMFjwcE2PZXhVr);
 sq_SendChangeSkillEffectPacket(gr7I5sC266, 236); 
 }
 }
 }
} 

function onChangeSkillEffect_atgunner_suppressingfire(zZAIwtzLbBGX, jdEOCIRTE2BwC, gVLkX_1ZG4Ab)
{
 if(!zZAIwtzLbBGX) return;
 if(jdEOCIRTE2BwC != 236)return;
 local NeCSkPJoxK4hIomSKGcu3eVT = zZAIwtzLbBGX.getSkillSubState();
 if(NeCSkPJoxK4hIomSKGcu3eVT == 1)
 {
 local CCtknbMfOIkOicz5Z = gVLkX_1ZG4Ab.readDword(); 
 local tF2eOz7NitiVSuyybGWKC = (gVLkX_1ZG4Ab.readDword()).tofloat() / 100.0; 
 local y1_W73mo2q9hKK = zZAIwtzLbBGX.getVar().get_timer_vector(0); 
 if(y1_W73mo2q9hKK)
 y1_W73mo2q9hKK.setEventTerm(CCtknbMfOIkOicz5Z); 
 zZAIwtzLbBGX.sq_SetStaticSpeedInfo(0, 0, SPEED_VALUE_DEFAULT, (SPEED_VALUE_DEFAULT * tF2eOz7NitiVSuyybGWKC).tointeger(), 1.0, 1.0); 
 }
} 

 
function onEndCurrentAni_atgunner_suppressingfire(r49CqhcKjPoCQvdaRs)
{
 if(!r49CqhcKjPoCQvdaRs) return;
 if(!r49CqhcKjPoCQvdaRs.sq_IsMyControlObject()) return;
 local GmaRvxU6IHDTahEm3MzRugs = r49CqhcKjPoCQvdaRs.getSkillSubState(); 
 if(GmaRvxU6IHDTahEm3MzRugs != 2)
 {
 r49CqhcKjPoCQvdaRs.sq_IntVectClear();
 r49CqhcKjPoCQvdaRs.sq_IntVectPush(GmaRvxU6IHDTahEm3MzRugs + 1); 
 r49CqhcKjPoCQvdaRs.sq_AddSetStatePacket(236, STATE_PRIORITY_USER, true); 
 }
 else
 r49CqhcKjPoCQvdaRs.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
} 

function onAttack_atgunner_suppressingfire(r49CqhcKjPoCQvdaRs, GmaRvxU6IHDTahEm3MzRugs, pbq4KWOo1Bx_SkTkxpG1, tNvNBod9PEfrWkMpWy6)
{
 if(!r49CqhcKjPoCQvdaRs) return;
 if(tNvNBod9PEfrWkMpWy6 || !GmaRvxU6IHDTahEm3MzRugs.isObjectType(OBJECTTYPE_ACTIVE)) return;
 local mRfCRHEa28B = r49CqhcKjPoCQvdaRs.getSkillSubState(); 
 
 switch(mRfCRHEa28B)
 {
 case 1:
 local k46mY7Cod8ps7F90U7 = sq_CreateAnimation("", "character/gunner/effect/animation/hiteffect/updefault.ani"); 
 k46mY7Cod8ps7F90U7.setImageRateFromOriginal(-1.0, 1.0);
 k46mY7Cod8ps7F90U7.addLayerAnimation(1, sq_CreateAnimation("", "character/gunner/effect/animation/atsuppressingfire/suppressingfire_blow001.ani"), true); 
 local rOCqlWEs7U16QYFXbajYxsF = sq_GetCenterZPos(pbq4KWOo1Bx_SkTkxpG1); 
 local la2FJYEYVuXZhXTM2DFRa = sq_CreatePooledObject(k46mY7Cod8ps7F90U7, true); 
 sq_SetCurrentDirection(la2FJYEYVuXZhXTM2DFRa, r49CqhcKjPoCQvdaRs.getDirection()); 
 la2FJYEYVuXZhXTM2DFRa.setCurrentPos(GmaRvxU6IHDTahEm3MzRugs.getXPos(), GmaRvxU6IHDTahEm3MzRugs.getYPos() + 1, GmaRvxU6IHDTahEm3MzRugs.getZPos() + rOCqlWEs7U16QYFXbajYxsF + sq_getRandom(rOCqlWEs7U16QYFXbajYxsF / 2 / -1, rOCqlWEs7U16QYFXbajYxsF / 2)); 
 la2FJYEYVuXZhXTM2DFRa = sq_SetEnumDrawLayer(la2FJYEYVuXZhXTM2DFRa, ENUM_DRAWLAYER_NORMAL); 
 sq_AddObject(r49CqhcKjPoCQvdaRs, la2FJYEYVuXZhXTM2DFRa, OBJECTTYPE_DRAWONLY, false); 
 break;
 }
} 


