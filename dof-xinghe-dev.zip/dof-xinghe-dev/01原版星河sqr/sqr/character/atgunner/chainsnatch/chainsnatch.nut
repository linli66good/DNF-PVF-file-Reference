function checkExecutableSkill_chainsnatch(obj)  
{
	if (!obj) return false;
		local isUseSkill = obj.sq_IsUseSkill(24);
		if (isUseSkill)
		{
		obj.sq_IntVectClear()
		obj.sq_IntVectPush(0)
		obj.sq_AddSetStatePacket(153, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
		}
		return false;
}

function checkCommandEnable_chainsnatch(obj)
{
	if(!obj) return false;

	local state = obj.sq_GetState();

	if(state == STATE_STAND)
		return true;

	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(24);
	}


	return true;

}

function onSetState_chainsnatch(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	if(substate == 0)
	{
			obj.sq_SetCurrentAnimation(189);
			obj.sq_SetCurrentAttackInfo(38);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(24, -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);

	}
	if(substate == 1)
	{
			obj.sq_SetCurrentAnimation(190);
			obj.sq_SetCurrentAttackInfo(39);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(24, -1, 1, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
	}
	if(substate == 2)
	{
			obj.sq_SetCurrentAnimation(191);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local sizemove = sq_GetIntData(obj, 24, 0)-100;
			obj.sq_StartWrite();
			obj.sq_WriteDword(304);
			obj.sq_SendCreatePassiveObjectPacket(24334, 0, 0-sizemove, 0, 0-sizemove);
	}
}



function onEndCurrentAni_chainsnatch(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_IntVectClear()
		obj.sq_IntVectPush(1)
		obj.sq_AddSetStatePacket(153, STATE_PRIORITY_IGNORE_FORCE, true)
	}
	if(substate == 1)
	{
		obj.sq_IntVectClear()
		obj.sq_IntVectPush(2)
		obj.sq_AddSetStatePacket(153, STATE_PRIORITY_IGNORE_FORCE, true)
	}
	if(substate == 2)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


