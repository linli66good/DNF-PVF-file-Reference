






 
function checkExecutableSkill_atgunner_operationraze(mndUu71ONF_tg0O)
{
 if(!mndUu71ONF_tg0O) return false; 
 local VSISyKLM7QgJXpWdDKr = mndUu71ONF_tg0O.sq_IsUseSkill(235); 
 if(VSISyKLM7QgJXpWdDKr) 
 {
 mndUu71ONF_tg0O.sq_IntVectClear();
 mndUu71ONF_tg0O.sq_IntVectPush(0); 
 mndUu71ONF_tg0O.sq_AddSetStatePacket(235, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_operationraze(mndUu71ONF_tg0O)
{
 if(!mndUu71ONF_tg0O) return false; 
 local VSISyKLM7QgJXpWdDKr = mndUu71ONF_tg0O.sq_GetState(); 
 if(VSISyKLM7QgJXpWdDKr == STATE_STAND) 
 return true; 
 if(VSISyKLM7QgJXpWdDKr == STATE_ATTACK) 
 {
 return mndUu71ONF_tg0O.sq_IsCommandEnable(235); 
 }
 return true; 
} 

 
function onSetState_atgunner_operationraze(oADXyo3ILmxtOrOdKeZZq, bnjapuFrHFwkCA6Ft3, ttbJPmZIpu, gOQEitxV_FXTSI3uoN)
{
 if(!oADXyo3ILmxtOrOdKeZZq) return; 
 local rNHZ5aVPODjmz = oADXyo3ILmxtOrOdKeZZq.sq_GetVectorData(ttbJPmZIpu, 0); 
 oADXyo3ILmxtOrOdKeZZq.setSkillSubState(rNHZ5aVPODjmz); 
 switch(rNHZ5aVPODjmz)
 {
 case 0:
 oADXyo3ILmxtOrOdKeZZq.getVar().clear_vector(); 
 oADXyo3ILmxtOrOdKeZZq.getVar().setBool(0, false); 
 oADXyo3ILmxtOrOdKeZZq.getVar().setBool(1, false); 
 oADXyo3ILmxtOrOdKeZZq.sq_StopMove(); 
 oADXyo3ILmxtOrOdKeZZq.sq_SetCurrentAnimation(111);
 
 sq_AddDrawOnlyAniFromParent(oADXyo3ILmxtOrOdKeZZq, "character/gunner/effect/animation/atoperationraze/start/startbackoperation_02.ani", -40, -1, 0);
 
 sq_AddDrawOnlyAniFromParent(oADXyo3ILmxtOrOdKeZZq, "character/gunner/effect/animation/atoperationraze/start/startfront1_02.ani", -40, -1, 0);
 
 sq_AddDrawOnlyAniFromParent(oADXyo3ILmxtOrOdKeZZq, "character/gunner/effect/animation/atoperationraze/start/startfront2_01.ani", -40, 0, 0);
 break;
 case 1:
 oADXyo3ILmxtOrOdKeZZq.sq_SetCurrentAnimation(112);
 break;
 case 2:
 oADXyo3ILmxtOrOdKeZZq.sq_SetCurrentAnimation(114);
 sq_CreateParticle("passiveobject/script_sqr_nut_qq506807329/atgunner/particle/atoperationrazeattack1.ptl", oADXyo3ILmxtOrOdKeZZq, 0, 0, 0, true, 80, 0, 999); 
 sq_CreateParticle("passiveobject/script_sqr_nut_qq506807329/atgunner/particle/atoperationrazeattack4.ptl", oADXyo3ILmxtOrOdKeZZq, 0, 0, 0, true, 80, 0, 999); 
 sq_CreateParticle("passiveobject/script_sqr_nut_qq506807329/atgunner/particle/atoperationrazeattack4.ptl", oADXyo3ILmxtOrOdKeZZq, 0, 0, 15, true, 80, 0, 999); 
 oADXyo3ILmxtOrOdKeZZq.setTimeEvent(0, 100, -1, false); 
 oADXyo3ILmxtOrOdKeZZq.getVar().clear_vector(); 
 oADXyo3ILmxtOrOdKeZZq.getVar().push_vector(2); 
 oADXyo3ILmxtOrOdKeZZq.getVar().push_vector(2); 
 oADXyo3ILmxtOrOdKeZZq.sq_PlaySound("FG_OPERATION_RAZE_02"); 
 if(oADXyo3ILmxtOrOdKeZZq.sq_IsMyControlObject())
 {
 
 oADXyo3ILmxtOrOdKeZZq.sq_StartWrite();
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(235); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(5); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(oADXyo3ILmxtOrOdKeZZq.sq_GetBonusRateWithPassive(235, 235, 5, 1.0)); 
 oADXyo3ILmxtOrOdKeZZq.sq_SendCreatePassiveObjectPacket(24376, 0, 0, 0, 0);
 
 oADXyo3ILmxtOrOdKeZZq.sq_StartWrite();
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(235); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(8); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(oADXyo3ILmxtOrOdKeZZq.sq_GetBonusRateWithPassive(235, 235, 2, 1.0)); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(100); 
 oADXyo3ILmxtOrOdKeZZq.sq_SendCreatePassiveObjectPacket(24376, 0, 0, 0, 0);
 
 oADXyo3ILmxtOrOdKeZZq.sq_StartWrite();
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(235); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(9); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(oADXyo3ILmxtOrOdKeZZq.sq_GetBonusRateWithPassive(235, 235, 3, 1.0)); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(80); 
 oADXyo3ILmxtOrOdKeZZq.sq_SendCreatePassiveObjectPacket(24376, 0, 0, 0, 0);
 }
 break;
 case 3:
 oADXyo3ILmxtOrOdKeZZq.sq_SetCurrentAnimation(113);
 local fvxKplZop4rwWD8YoQP2eWlH = oADXyo3ILmxtOrOdKeZZq.getVar().GetparticleCreaterMap("operationrazedestroy", "passiveobject/script_sqr_nut_qq506807329/atgunner/particle/operationrazedestroy.ptl", oADXyo3ILmxtOrOdKeZZq); 
 fvxKplZop4rwWD8YoQP2eWlH.Restart(0); 
 fvxKplZop4rwWD8YoQP2eWlH.SetPos(sq_GetDistancePos(oADXyo3ILmxtOrOdKeZZq.getXPos(), oADXyo3ILmxtOrOdKeZZq.getDirection(), -10), oADXyo3ILmxtOrOdKeZZq.getYPos(), oADXyo3ILmxtOrOdKeZZq.getZPos() + 80); 
 sq_AddParticleObject(oADXyo3ILmxtOrOdKeZZq, fvxKplZop4rwWD8YoQP2eWlH); 
 if(oADXyo3ILmxtOrOdKeZZq.sq_IsMyControlObject())
 {
 local gdvF9mtjUcwQh_vfS = oADXyo3ILmxtOrOdKeZZq.sq_GetBonusRateWithPassive(235, 235, 6, 1.0); 
 
 oADXyo3ILmxtOrOdKeZZq.sq_StartWrite();
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(235); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(7); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(gdvF9mtjUcwQh_vfS); 
 oADXyo3ILmxtOrOdKeZZq.sq_SendCreatePassiveObjectPacket(24376, 0, 350, 0, 600);
 
 oADXyo3ILmxtOrOdKeZZq.sq_StartWrite();
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(235); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(7); 
 oADXyo3ILmxtOrOdKeZZq.sq_WriteDword(gdvF9mtjUcwQh_vfS); 
 oADXyo3ILmxtOrOdKeZZq.sq_SendCreatePassiveObjectPacket(24376, 0, 500, 0, 600);
 }
 break;
 }
 
} 

function onEndState_atgunner_operationraze(ODrspvYx5MUbxp3KXXi, IezPVcsYvxh7A)
{
 if(!ODrspvYx5MUbxp3KXXi) return;
 sq_RemoveParticle("passiveobject/script_sqr_nut_qq506807329/atgunner/particle/atoperationrazeattack1.ptl", ODrspvYx5MUbxp3KXXi); 
 sq_RemoveParticle("passiveobject/script_sqr_nut_qq506807329/atgunner/particle/atoperationrazeattack4.ptl", ODrspvYx5MUbxp3KXXi); 
} 


if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onTimeEvent_atgunner_operationraze(ODrspvYx5MUbxp3KXXi, IezPVcsYvxh7A, OV2Q0jc8dSp9n20E)
{
 if(!ODrspvYx5MUbxp3KXXi) return false;
 switch(IezPVcsYvxh7A)
 {
 case 0:
 if(ODrspvYx5MUbxp3KXXi.sq_IsMyControlObject())
 {
 
 ODrspvYx5MUbxp3KXXi.sq_StartWrite();
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(235); 
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(4); 
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(ODrspvYx5MUbxp3KXXi.sq_GetBonusRateWithPassive(235, 235, 4, 1.0)); 
 ODrspvYx5MUbxp3KXXi.sq_SendCreatePassiveObjectPacket(24376, 0, 110, 0, 35);
 }
 break;
 }
 return false;
} 

function onKeyFrameFlag_atgunner_operationraze(euj7jywsR2gKoHj9e, typAOeQgTGE0d9)
{
 if(!euj7jywsR2gKoHj9e) return false;
 local Posu8vBUP3T = euj7jywsR2gKoHj9e.getSkillSubState(); 
 switch(Posu8vBUP3T)
 {
 case 0:
 if(typAOeQgTGE0d9 == 1)
 {
 
 local fFc_djy9pepntb1Ef = euj7jywsR2gKoHj9e.getVar().GetparticleCreaterMap("operationrazestart", "passiveobject/script_sqr_nut_qq506807329/atgunner/particle/operationrazestart.ptl", euj7jywsR2gKoHj9e); 
 fFc_djy9pepntb1Ef.Restart(0); 
 fFc_djy9pepntb1Ef.SetPos(euj7jywsR2gKoHj9e.getXPos(), euj7jywsR2gKoHj9e.getYPos(), euj7jywsR2gKoHj9e.getZPos()); 
 sq_AddParticleObject(euj7jywsR2gKoHj9e, fFc_djy9pepntb1Ef); 
 sq_SetMyShake(euj7jywsR2gKoHj9e, 10, 500); 
 if(euj7jywsR2gKoHj9e.sq_IsMyControlObject())
 {
 euj7jywsR2gKoHj9e.sq_StartWrite();
 euj7jywsR2gKoHj9e.sq_WriteDword(235); 
 euj7jywsR2gKoHj9e.sq_WriteDword(1); 
 euj7jywsR2gKoHj9e.sq_SendCreatePassiveObjectPacket(24376, 0, 0, 0, 0);
 }
 }
 break;
 case 2:
 switch(typAOeQgTGE0d9)
 {
 case 1:
 if(euj7jywsR2gKoHj9e.sq_IsMyControlObject())
 {
 
 euj7jywsR2gKoHj9e.sq_StartWrite();
 euj7jywsR2gKoHj9e.sq_WriteDword(235); 
 euj7jywsR2gKoHj9e.sq_WriteDword(2); 
 euj7jywsR2gKoHj9e.sq_WriteDword(euj7jywsR2gKoHj9e.sq_GetBonusRateWithPassive(235, 235, 0, 1.0)); 
 euj7jywsR2gKoHj9e.sq_SendCreatePassiveObjectPacket(24376, 0, 0, 0, 0);
 
 euj7jywsR2gKoHj9e.sq_StartWrite();
 euj7jywsR2gKoHj9e.sq_WriteDword(235); 
 euj7jywsR2gKoHj9e.sq_WriteDword(3); 
 euj7jywsR2gKoHj9e.sq_WriteDword(euj7jywsR2gKoHj9e.sq_GetBonusRateWithPassive(235, 235, 1, 1.0)); 
 euj7jywsR2gKoHj9e.sq_SendCreatePassiveObjectPacket(24376, 0, 0, 0, 0);
 }
 local UUtPEv4Z3F9mWI2UaE8F = euj7jywsR2gKoHj9e.getVar().get_vector(1); 
 if(UUtPEv4Z3F9mWI2UaE8F > 0) 
 {
 euj7jywsR2gKoHj9e.getVar().set_vector(1, UUtPEv4Z3F9mWI2UaE8F - 1); 
 local Y7_HxMF2ExsoM = UUtPEv4Z3F9mWI2UaE8F % 2; 
 local _obwMVxdl0SERvme = onGetMyPassiveObject_My(euj7jywsR2gKoHj9e, 24376, 235, 5); 
 if(_obwMVxdl0SERvme && _obwMVxdl0SERvme.isMyControlObject())
 {
 local mQx0mtX8biKloHiW = [-38, -9]; 
 
 sq_BinaryStartWrite();
 sq_BinaryWriteDword(235); 
 sq_BinaryWriteDword(6); 
 sq_SendCreatePassiveObjectPacket(_obwMVxdl0SERvme, 24376, 0, mQx0mtX8biKloHiW[Y7_HxMF2ExsoM], 0, 105, euj7jywsR2gKoHj9e.getDirection());
 }
 switch(Y7_HxMF2ExsoM)
 {
 case 0:
 if(euj7jywsR2gKoHj9e.getVar().getBool(1) == false)
 {
 euj7jywsR2gKoHj9e.sq_AddStateLayerAnimation(-1, euj7jywsR2gKoHj9e.sq_CreateCNRDAnimation("effect/animation/atoperationraze/artillery/artillery2_01.ani"), 0, 0);
 euj7jywsR2gKoHj9e.getVar().setBool(1, true); 
 }
 break;
 case 1:
 if(euj7jywsR2gKoHj9e.getVar().getBool(0) == false)
 {
 euj7jywsR2gKoHj9e.sq_AddStateLayerAnimation(-1, euj7jywsR2gKoHj9e.sq_CreateCNRDAnimation("effect/animation/atoperationraze/artillery/artillery2_02.ani"), 0, 0);
 euj7jywsR2gKoHj9e.getVar().setBool(0, true); 
 }
 break;
 }
 }
 break;
 case 2:
 local rgGk9ZDyYM4Ls = euj7jywsR2gKoHj9e.getVar().get_vector(0) - 1; 
 if(rgGk9ZDyYM4Ls <= 0) 
 {
 if(euj7jywsR2gKoHj9e.sq_IsMyControlObject())
 {
 euj7jywsR2gKoHj9e.sq_IntVectClear();
 euj7jywsR2gKoHj9e.sq_IntVectPush(3); 
 euj7jywsR2gKoHj9e.sq_AddSetStatePacket(235, STATE_PRIORITY_USER, true); 
 }
 }
 else
 euj7jywsR2gKoHj9e.getVar().set_vector(0, rgGk9ZDyYM4Ls); 
 break;
 case 2001:
 euj7jywsR2gKoHj9e.sq_PlaySound("R_OPERATION_RAZE"); 
 break;
 }
 break;
 }
 return true;
} 

 
function onEndCurrentAni_atgunner_operationraze(EoLmzzF8Klm93CDR)
{
 if(!EoLmzzF8Klm93CDR) return;
 if(!EoLmzzF8Klm93CDR.sq_IsMyControlObject()) return;
 local qxESgOf6nUesu = EoLmzzF8Klm93CDR.getSkillSubState(); 
 if(qxESgOf6nUesu != 3)
 {
 EoLmzzF8Klm93CDR.sq_IntVectClear();
 EoLmzzF8Klm93CDR.sq_IntVectPush(qxESgOf6nUesu + 1); 
 EoLmzzF8Klm93CDR.sq_AddSetStatePacket(235, STATE_PRIORITY_USER, true); 
 }
 else
 EoLmzzF8Klm93CDR.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
} 

function getScrollBasisPos_atgunner_operationraze(EoLmzzF8Klm93CDR)
{
 if(!EoLmzzF8Klm93CDR) return;
 if(!EoLmzzF8Klm93CDR.sq_IsMyControlObject()) return;
 local qxESgOf6nUesu = EoLmzzF8Klm93CDR.getSkillSubState();
 switch(qxESgOf6nUesu)
 {
 case 2:
 local mOU1beVopwSwL_IDYaIG1_VT = EoLmzzF8Klm93CDR.sq_GetStateTimer(); 
 local TclCGQFQc4lg = 150; 
 local dksPqk_eJfjF1ZYzVcF1ZBI = EoLmzzF8Klm93CDR.getXPos(); 
 local zcWMEfCygD5yzpHcT = sq_GetUniformVelocity(dksPqk_eJfjF1ZYzVcF1ZBI, sq_GetDistancePos(dksPqk_eJfjF1ZYzVcF1ZBI, EoLmzzF8Klm93CDR.getDirection(), 300), mOU1beVopwSwL_IDYaIG1_VT, TclCGQFQc4lg);
 EoLmzzF8Klm93CDR.sq_SetCameraScrollPosition(zcWMEfCygD5yzpHcT, EoLmzzF8Klm93CDR.getYPos(), 0);
 return true;
 case 3:
 local F828FO87mQUf0iALsUK1Wllq = EoLmzzF8Klm93CDR.getCurrentAnimation(); 
 local mOU1beVopwSwL_IDYaIG1_VT = sq_GetCurrentTime(F828FO87mQUf0iALsUK1Wllq); 
 local TclCGQFQc4lg = F828FO87mQUf0iALsUK1Wllq.getDelaySum(false); 
 local dksPqk_eJfjF1ZYzVcF1ZBI = EoLmzzF8Klm93CDR.getXPos(); 
 local zcWMEfCygD5yzpHcT = sq_GetUniformVelocity(sq_GetDistancePos(dksPqk_eJfjF1ZYzVcF1ZBI, EoLmzzF8Klm93CDR.getDirection(), 300), dksPqk_eJfjF1ZYzVcF1ZBI, mOU1beVopwSwL_IDYaIG1_VT, TclCGQFQc4lg);
 EoLmzzF8Klm93CDR.sq_SetCameraScrollPosition(zcWMEfCygD5yzpHcT, EoLmzzF8Klm93CDR.getYPos(), 0);
 return true;
 }
 return false;
} 



