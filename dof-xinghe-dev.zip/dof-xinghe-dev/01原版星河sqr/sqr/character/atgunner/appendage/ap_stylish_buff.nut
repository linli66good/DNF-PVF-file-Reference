



function sq_AddFunctionName(appendage)
{
    appendage.sq_AddFunctionName("proc", "proc_appendage_atgunner_stylish_buff")
}


function proc_appendage_atgunner_stylish_buff(h1LzJvtnXF)
{
 if(!h1LzJvtnXF) return;
 if(h1LzJvtnXF.getVar().size_vector() <= 0)return;
 local PjpVSX8x2oN7r8nkW = h1LzJvtnXF.getVar().get_timer_vector(0); 
 if(PjpVSX8x2oN7r8nkW)
 if(PjpVSX8x2oN7r8nkW.isOnEvent(h1LzJvtnXF.getTimer().Get()) == true)
 if(h1LzJvtnXF.getVar().get_vector(0) < h1LzJvtnXF.getVar().get_vector(1)) 
 h1LzJvtnXF.getVar().set_vector(0, h1LzJvtnXF.getVar().get_vector(0) + 1); 
 local pmWx9GJUS3c3 = h1LzJvtnXF.getParent();
 if(!pmWx9GJUS3c3)
 {
 h1LzJvtnXF.setValid(false);
 return;
 }
} 
