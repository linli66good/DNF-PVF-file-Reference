
function sq_AddFunctionName(appendage)
{
	appendage.sq_AddFunctionName("proc", "proc_appendage_atgunner_comminterrupt")
}


function sq_AddEffect(appendage)
{

}

function proc_appendage_atgunner_comminterrupt(appendage)
{
	if(!appendage) return;
	atgunner_comminterrupt(appendage);
}


function EnableSoften(obj,skillindex,state)
{
	if(obj.sq_GetState() == state)
		return false;
	obj.setSkillCommandEnable(skillindex ,true);
		return true;
}

function SetSkillState(obj,skillindex,state,Arr)
{
	local iEnterSkill = obj.sq_IsEnterSkill(skillindex);
	if(iEnterSkill == -1)
	return false;
	if(obj.sq_GetState() == state)				
		return false;
	if(obj.sq_IsUseSkill(skillindex))
	{
		obj.sq_IntVectClear();
		if(Arr.len() < 1)
		{
			obj.sq_AddSetStatePacket(state,STATE_PRIORITY_USER,true);
			return true;
		}
		else
		{
			foreach(sub in Arr)
			obj.sq_IntVectPush(sub);
			obj.sq_AddSetStatePacket(state,STATE_PRIORITY_USER,true);
			return true;
		}
	}


}


function atgunner_comminterrupt(appendage)
{

	local parentObj = appendage.getParent();
	local sourceObj = appendage.getSource();
	if(!sourceObj || !parentObj) 
	{
		appendage.setValid(false);
		return;
	}
	local obj = sq_GetCNRDObjectToSQRCharacter(parentObj);
	local type = sq_getGrowType(obj);

		local mystate = obj.sq_GetState();
		local isTower = sq_IsTowerDungeon();
		if(isTower) return;
		if(mystate == 3||mystate == 4||mystate == 5||mystate == 6||mystate == 9||mystate == 16) return;

	EnableSoften(obj,3,19);			
	SetSkillState(obj,3,19,[3]);
	EnableSoften(obj,47,8);				
	SetSkillState(obj,47,8,[1,47,0]);
	
	
	EnableSoften(obj,4,20);				
	SetSkillState(obj,4,20,[4]);
	EnableSoften(obj,5,8);			
	SetSkillState(obj,5,8,[1,5,0]);


	switch (type)
	{

		case 1:
		EnableSoften(obj,5,8);			
		 SetSkillState(obj,5,8,[1,5,0]);
		EnableSoften(obj,20,8);			
		 SetSkillState(obj,20,8,[1,20,0]);
		EnableSoften(obj,9,24);			
		 SetSkillState(obj,9,24,[15,2,0,100]);
		EnableSoften(obj,72,37);			
		 SetSkillState(obj,72,37,[0,0,1,2,3]);
		EnableSoften(obj,15,27);			
		 SetSkillState(obj,15,27,[15]);
		EnableSoften(obj,236,236);			
		 SetSkillState(obj,236,236,[0,1,2]);
		EnableSoften(obj,104,58);			
		 SetSkillState(obj,104,58,[1,97,98,0,5]);
		EnableSoften(obj,238,238);			
		 SetSkillState(obj,238,238,[0,1,2]);
		EnableSoften(obj,239,239);			
		 SetSkillState(obj,239,239,[0]);
		EnableSoften(obj,84,84);			
		 SetSkillState(obj,84,84,[0,1]);
		EnableSoften(obj,51,41);			
		 SetSkillState(obj,51,41,[0,1,2]);
		EnableSoften(obj,18,251);			
		 SetSkillState(obj,18,251,[0,2,4]);
		EnableSoften(obj,35,38);			
		 SetSkillState(obj,35,38,[]);
		EnableSoften(obj,101,56);			
		 SetSkillState(obj,101,56,[94,1,0,30]);
		break;

		case 2:
		EnableSoften(obj,39,26);			
		SetSkillState(obj,39,26,[39,0,1,600]);
		EnableSoften(obj,38,26);			
		SetSkillState(obj,38,26,[38,0,1]);
		EnableSoften(obj,40,26);			
		SetSkillState(obj,40,26,[40,0,0]);
		EnableSoften(obj,234,234);			
		SetSkillState(obj,234,234,[0,1]);
		EnableSoften(obj,233,233);			
		SetSkillState(obj,233,233,[0]);
		EnableSoften(obj,235,235);			
		SetSkillState(obj,235,235,[0,1,2]);
		EnableSoften(obj,108,26);			
		SetSkillState(obj,108,26,[108,0,1]);
		EnableSoften(obj,97,44);			
		SetSkillState(obj,97,44,[0,1]);
		EnableSoften(obj,71,36);			
		SetSkillState(obj,71,36,[0,2,0]);
		EnableSoften(obj,115,115);			
		SetSkillState(obj,115,115,[0,1,2]);
		EnableSoften(obj,232,232);			
		SetSkillState(obj,232,232,[0,1,2]);
		break;

		case 3:
		break;

		case 4:

		break;

	default:
		break;
	}

	return;
}




