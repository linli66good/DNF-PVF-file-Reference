



function sq_AddFunctionName(appendage)
{
 appendage.sq_AddFunctionName("proc", "proc_appendage_atgunner_stylish") 
 appendage.sq_AddFunctionName("onStart", "onStart_appendage_atgunner_stylish") 
 appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_atgunner_stylish") 
}


function proc_appendage_atgunner_stylish(KG9HvkBux5rj)
{
 if(!KG9HvkBux5rj) return;
 local VcluzZw5Z2dvUL6YIyjw5ddk = KG9HvkBux5rj.getParent()
 if(!VcluzZw5Z2dvUL6YIyjw5ddk)
 {
 KG9HvkBux5rj.setValid(false);
 return;
 }
 switch(VcluzZw5Z2dvUL6YIyjw5ddk.getState())
 {
 case STATE_STAND:
 case STATE_DIE:
 case STATE_HOLD:
 case STATE_JUMP:
 onEnd_appendage_atgunner_stylish(KG9HvkBux5rj);
 return;
 }
} 


function onStart_appendage_atgunner_stylish(didWRqz708)
{
 if(!didWRqz708) return;
 local FAjZSmZIqDjiJqmqyArelna = didWRqz708.getParent(); 
 if(!FAjZSmZIqDjiJqmqyArelna) {
 didWRqz708.setValid(false);
 return;
 }
 local HULXMkupqZ = didWRqz708.sq_GetOcularSpectrum("ocularSpectrum"); 
 if (!HULXMkupqZ) 
 {
 HULXMkupqZ = didWRqz708.sq_AddOcularSpectrum("ocularSpectrum", FAjZSmZIqDjiJqmqyArelna, FAjZSmZIqDjiJqmqyArelna, 100); 
 sq_SetParameterOcularSpectrum(HULXMkupqZ, 400, 50, true, sq_RGBA(0, 255, 0, 255), sq_RGBA(0, 255, 0, 0), 2, 2, 2); 
 }
} 

function onEnd_appendage_atgunner_stylish(BzDHEac6CCjA3RK)
{
 if(!BzDHEac6CCjA3RK) return;
 local mpZoI7Lhla4YR8jXB = BzDHEac6CCjA3RK.sq_GetOcularSpectrum("ocularSpectrum"); 
 if(mpZoI7Lhla4YR8jXB) 
 mpZoI7Lhla4YR8jXB.endCreateSpectrum(); 
} 


