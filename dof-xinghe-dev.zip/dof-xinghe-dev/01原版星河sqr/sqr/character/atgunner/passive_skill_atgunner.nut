function ProcPassiveSkill_ATGunner(obj, skill_index, skill_level)
{
 switch(skill_index)
 {
 case SKILL_NITROMOTOR:
	if(skill_level > 0)
	{
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skill_index, false, "character/atgunner/nitromotor/ap_nitromotor.nut", true);
	}
break;

 case 85:
	if(skill_level > 0)
	{
	
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skill_index, false, "character/atgunner/atbowgunmastery/ap_atbowgunmastery.nut", true);
	}
break;

case 174:
	if(skill_level > 0)
	{
	if(!obj || sq_isPVPMode()) return;
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skill_index, false, "character/atgunner/appendage/ap_atgunner_comminterrupt.nut", true);
	}
 break;

case 254:
	if(skill_level > 0)
	{
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skill_index, false, "character/gunner/latentability/ap_latentability.nut", true);
	}
 break;
 
 }
 return true;
};
