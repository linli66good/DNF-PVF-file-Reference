
function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_gunner_napalmbomb")
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_gunner_napalmbomb")
}

function onStart_appendage_gunner_napalmbomb(appendage)
{
	if(!appendage) {
		return;
	}
	
	local obj = appendage.getParent();
	local x = obj.getXPos();
    local y = obj.getYPos();
    if (obj.getDirection() == ENUM_DIRECTION_RIGHT) {
		x = x + 250;
	} else {
		x = x - 250;
	}
	sq_SendCreatePassiveObjectPacketPos( obj, 90010010, 0, x, y, 0);
}


function onEnd_appendage_gunner_napalmbomb(appendage)
{
	if(!appendage) return;
	local obj = appendage.getParent();
}
