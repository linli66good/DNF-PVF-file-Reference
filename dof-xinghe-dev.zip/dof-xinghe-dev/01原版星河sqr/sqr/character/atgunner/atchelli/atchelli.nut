function checkExecutableSkill_atchelli(obj)
{
	if(!obj) return false;

	local isUse = obj.sq_IsUseSkill(251);

	if(isUse)
	{
		local state = obj.getState();
		switch(state)
		{
			case 6:
			case 7:
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1); 
				obj.sq_AddSetStatePacket(251, STATE_PRIORITY_USER, true);
				obj.sq_PlaySound("R_FG_CHELLI");
				break;
			default:
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(0); 
				obj.sq_AddSetStatePacket(251, STATE_PRIORITY_USER, true);
				obj.sq_PlaySound("R_FG_CHELLI");
				break;
		}
		return true;
	}
	return false;
}

function checkCommandEnable_atchelli(obj)
{
	if(!obj) return false;

	local state = obj.sq_GetState();

	if(state == STATE_STAND)
		return true;

	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(251); 
	}


	return true;
}



function onSetState_atchelli(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	obj.sq_StopMove();
	obj.sq_ZStop();

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	switch(subState)
	{
		case 0:
			obj.sq_SetCurrentAnimation(184);
			break;
		case 1:
			obj.sq_SetCurrentAnimation(185);
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onKeyFrameFlag_atchelli(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		if (flagIndex == 0)
		{
			obj.sq_StartWrite();
			obj.sq_WriteDword(218);
			obj.sq_SendCreatePassiveObjectPacket(24334, 0, 200, 0, 0);
		}
	}
	if(substate == 1)
	{
		if (flagIndex == 10001)
		{
			obj.sq_StartWrite();
			obj.sq_WriteDword(217);
			obj.sq_SendCreatePassiveObjectPacket(24334, 0, 100, 0, 10);
		}
	}
	return true;
}


function onEndCurrentAni_atchelli(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;
	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 0:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
			break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
			break;
	}
}
