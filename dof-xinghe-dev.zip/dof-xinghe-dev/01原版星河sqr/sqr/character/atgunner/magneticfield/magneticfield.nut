






 
function checkExecutableSkill_atgunner_magneticfield(K_j1DiRSUgpd)
{
 if(!K_j1DiRSUgpd) return false; 
 local sQiKj5YJp72RghelVNu = K_j1DiRSUgpd.sq_IsUseSkill(248); 
 if(sQiKj5YJp72RghelVNu) 
 {
 K_j1DiRSUgpd.sq_IntVectClear();
 K_j1DiRSUgpd.sq_IntVectPush(0); 
 K_j1DiRSUgpd.sq_AddSetStatePacket(248, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_magneticfield(QqJuSlYAmqGdNjQ0S)
{
 if(!QqJuSlYAmqGdNjQ0S) return false; 
 local gFS0OEC9aRaJwIpADXTOdj = QqJuSlYAmqGdNjQ0S.sq_GetState(); 
 if(gFS0OEC9aRaJwIpADXTOdj == STATE_STAND) 
 return true; 
 if(gFS0OEC9aRaJwIpADXTOdj == STATE_ATTACK) 
 {
 return QqJuSlYAmqGdNjQ0S.sq_IsCommandEnable(248); 
 }
 return true; 
} 

 
function onSetState_atgunner_magneticfield(QqJuSlYAmqGdNjQ0S, gFS0OEC9aRaJwIpADXTOdj, aS9S6X1S7GcWKAczrsE82hAM, etTUd3cLGnu)
{
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 if(!QqJuSlYAmqGdNjQ0S) return; 
 local ZGyoLr2U6z_ikjfSoB = QqJuSlYAmqGdNjQ0S.sq_GetVectorData(aS9S6X1S7GcWKAczrsE82hAM, 0); 
 QqJuSlYAmqGdNjQ0S.setSkillSubState(ZGyoLr2U6z_ikjfSoB); 
 switch(ZGyoLr2U6z_ikjfSoB)
 {
 case 0:
 QqJuSlYAmqGdNjQ0S.sq_StopMove(); 
 QqJuSlYAmqGdNjQ0S.sq_SetCurrentAnimation(135);
 QqJuSlYAmqGdNjQ0S.sq_PlaySound("FG_LSHOT_03"); 
 break;
 case 1:
 QqJuSlYAmqGdNjQ0S.sq_SetCurrentAnimation(136);
 sq_SetMyShake(QqJuSlYAmqGdNjQ0S, 4, 100); 
 if(QqJuSlYAmqGdNjQ0S.sq_IsMyControlObject())
 {
 local qqT3Yf5SA0A3etCdbfJqwI = sq_GetSkillLevel(QqJuSlYAmqGdNjQ0S, 248); 
 QqJuSlYAmqGdNjQ0S.sq_StartWrite();
 QqJuSlYAmqGdNjQ0S.sq_WriteDword(248); 
 QqJuSlYAmqGdNjQ0S.sq_WriteDword(1); 
 QqJuSlYAmqGdNjQ0S.sq_WriteDword(QqJuSlYAmqGdNjQ0S.sq_GetBonusRateWithPassive(248, 248, 0, 1.0)); 
 QqJuSlYAmqGdNjQ0S.sq_WriteDword(QqJuSlYAmqGdNjQ0S.sq_GetLevelData(248, 1, qqT3Yf5SA0A3etCdbfJqwI)); 
 QqJuSlYAmqGdNjQ0S.sq_WriteDword(QqJuSlYAmqGdNjQ0S.sq_GetLevelData(248, 2, qqT3Yf5SA0A3etCdbfJqwI)); 
 QqJuSlYAmqGdNjQ0S.sq_WriteDword(QqJuSlYAmqGdNjQ0S.sq_GetLevelData(248, 3, qqT3Yf5SA0A3etCdbfJqwI)); 
 QqJuSlYAmqGdNjQ0S.sq_SendCreatePassiveObjectPacket(24376, 0, 60, -1, 88);
 }
 QqJuSlYAmqGdNjQ0S.getVar().clear_vector(); 
 local qWyftBISmJSyge = QqJuSlYAmqGdNjQ0S.getVar(); 
 qWyftBISmJSyge.push_vector(QqJuSlYAmqGdNjQ0S.getXPos()); 
 qWyftBISmJSyge.push_vector(-50); 
 break;
 }
 QqJuSlYAmqGdNjQ0S.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 

function onProc_atgunner_magneticfield(YJlyKsrm000U57V1MIiX)
{
 if(!YJlyKsrm000U57V1MIiX) return;
 local fbYKGbwoisq5m7Q = YJlyKsrm000U57V1MIiX.getSkillSubState(); 
 switch(fbYKGbwoisq5m7Q)
 {
 case 1:
 if(YJlyKsrm000U57V1MIiX.getVar().size_vector() <= 0)break;
 local qNrEBuc3Yg2LPD1C3sdpF = YJlyKsrm000U57V1MIiX.getCurrentAnimation(); 
 local eH1iPUKWb0duNA3o = sq_GetCurrentTime(qNrEBuc3Yg2LPD1C3sdpF); 
 local _2WehxaQvpy2tDiN = qNrEBuc3Yg2LPD1C3sdpF.getDelaySum(0, 2); 
 local VhQUbJr3K2clGoKSCdu = YJlyKsrm000U57V1MIiX.getVar().get_vector(0); 
 local aTsIIrdWnpy4o = YJlyKsrm000U57V1MIiX.getVar().get_vector(1); 
 local KYPSlef8mkH8O1g = sq_GetAccel(0, aTsIIrdWnpy4o, eH1iPUKWb0duNA3o, _2WehxaQvpy2tDiN, true);
 local jh0Dju4ZMpxEvv = sq_GetDistancePos(VhQUbJr3K2clGoKSCdu, YJlyKsrm000U57V1MIiX.getDirection(), KYPSlef8mkH8O1g); 
 if(YJlyKsrm000U57V1MIiX.isMovablePos(jh0Dju4ZMpxEvv, YJlyKsrm000U57V1MIiX.getYPos()))
 sq_setCurrentAxisPos(YJlyKsrm000U57V1MIiX, 0, jh0Dju4ZMpxEvv); 
 else
 YJlyKsrm000U57V1MIiX.getVar().clear_vector(); 
 break;
 }
} 

 
function onEndCurrentAni_atgunner_magneticfield(h1LzJvtnXF)
{
 if(!h1LzJvtnXF) return;
 if(!h1LzJvtnXF.sq_IsMyControlObject()) return;
 local PjpVSX8x2oN7r8nkW = h1LzJvtnXF.getSkillSubState(); 
 switch(PjpVSX8x2oN7r8nkW)
 {
 case 0:
 h1LzJvtnXF.sq_IntVectClear();
 h1LzJvtnXF.sq_IntVectPush(1); 
 h1LzJvtnXF.sq_AddSetStatePacket(248, STATE_PRIORITY_USER, true); 
 break;
 case 1:
 h1LzJvtnXF.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 }
} 


