






 
function checkExecutableSkill_atgunner_pt_15(fhgXswEvohIbJC4g31Z_DGiQ)
{
 if(!fhgXswEvohIbJC4g31Z_DGiQ) return false; 
 local _vHSYMuNuujt5JK = fhgXswEvohIbJC4g31Z_DGiQ.sq_IsUseSkill(234); 
 if(_vHSYMuNuujt5JK) 
 {
 fhgXswEvohIbJC4g31Z_DGiQ.sq_IntVectClear();
 fhgXswEvohIbJC4g31Z_DGiQ.sq_IntVectPush(0); 
 fhgXswEvohIbJC4g31Z_DGiQ.sq_AddSetStatePacket(234, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_pt_15(fhgXswEvohIbJC4g31Z_DGiQ)
{
 if(!fhgXswEvohIbJC4g31Z_DGiQ) return false; 
 local _vHSYMuNuujt5JK = fhgXswEvohIbJC4g31Z_DGiQ.sq_GetState(); 
 if(_vHSYMuNuujt5JK == STATE_STAND) 
 return true; 
 if(_vHSYMuNuujt5JK == STATE_ATTACK) 
 {
 return fhgXswEvohIbJC4g31Z_DGiQ.sq_IsCommandEnable(234); 
 }
 return true; 
} 

 
function onSetState_atgunner_pt_15(NQG7adRcwewb96, uMz57IcL9R, vyTmeIdKBU8JC93MnprOo, CDkPK6ElPYxQVgLR0)
{
 if(!NQG7adRcwewb96) return; 
 local ppqgM9nB4PBmVBkNs = NQG7adRcwewb96.sq_GetVectorData(vyTmeIdKBU8JC93MnprOo, 0); 
 NQG7adRcwewb96.setSkillSubState(ppqgM9nB4PBmVBkNs); 
 switch(ppqgM9nB4PBmVBkNs)
 {
 case 0:
 NQG7adRcwewb96.getVar().clear_vector(); 
 NQG7adRcwewb96.sq_StopMove(); 
 NQG7adRcwewb96.sq_SetCurrentAnimation(110);
 break;
 case 1:
 NQG7adRcwewb96.sq_SetCurrentAnimation(107);
 break;
 case 2:
 NQG7adRcwewb96.sq_SetCurrentAnimation(108);
 break;
 case 3:
 NQG7adRcwewb96.sq_SetCurrentAnimation(109);
 NQG7adRcwewb96.getVar().clear_vector(); 
 NQG7adRcwewb96.getVar().push_vector(NQG7adRcwewb96.getXPos()); 
 NQG7adRcwewb96.getVar().push_vector(NQG7adRcwewb96.getZPos()); 
 NQG7adRcwewb96.getVar().push_vector(155); 
 NQG7adRcwewb96.getVar().push_vector(200); 
 break;
 }
 NQG7adRcwewb96.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 

function onKeyFrameFlag_atgunner_pt_15(ODrspvYx5MUbxp3KXXi, IezPVcsYvxh7A)
{
 if(!ODrspvYx5MUbxp3KXXi) return false;
 if(!ODrspvYx5MUbxp3KXXi.sq_IsMyControlObject())return true;
 local OV2Q0jc8dSp9n20E = ODrspvYx5MUbxp3KXXi.getSkillSubState(); 
 switch(OV2Q0jc8dSp9n20E)
 {
 case 0:
 if(IezPVcsYvxh7A == 1)
 {
 local l6p2lpchHw_NEQnF2U8 = ODrspvYx5MUbxp3KXXi.getDirection(); 
 if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) 
 {
 
 ODrspvYx5MUbxp3KXXi.sq_IntVectClear();
 ODrspvYx5MUbxp3KXXi.sq_IntVectPush(3); 
 ODrspvYx5MUbxp3KXXi.sq_AddSetStatePacket(234, STATE_PRIORITY_USER, true); 
 }
 else if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL)
 || (l6p2lpchHw_NEQnF2U8 == ENUM_DIRECTION_LEFT && sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL))
 || (l6p2lpchHw_NEQnF2U8 == ENUM_DIRECTION_RIGHT && sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL)))
 {
 ODrspvYx5MUbxp3KXXi.getVar().push_vector(1);
 }
 else
 {
 ODrspvYx5MUbxp3KXXi.getVar().push_vector(2);
 }
 }
 break;
 case 1:
 if(IezPVcsYvxh7A == 1)
 {
 ODrspvYx5MUbxp3KXXi.sq_StartWrite();
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(234); 
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(1); 
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(ODrspvYx5MUbxp3KXXi.sq_GetBonusRateWithPassive(234, 234, 1, 1.0)); 
 ODrspvYx5MUbxp3KXXi.sq_SendCreatePassiveObjectPacket(24376, 0, 135, 1, 90);
 sq_SetMyShake(ODrspvYx5MUbxp3KXXi, 6, 240); 
 sq_flashScreen(ODrspvYx5MUbxp3KXXi, 0, 40, 0, 102, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM); 
 }
 break;
 case 2:
 if(IezPVcsYvxh7A == 1)
 sq_SetMyShake(ODrspvYx5MUbxp3KXXi, 6, 240); 
 else if(IezPVcsYvxh7A == 2)
 {
 ODrspvYx5MUbxp3KXXi.sq_StartWrite();
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(234); 
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(2); 
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(ODrspvYx5MUbxp3KXXi.sq_GetBonusRateWithPassive(234, 234, 0, 1.0)); 
 ODrspvYx5MUbxp3KXXi.sq_SendCreatePassiveObjectPacket(24376, 0, 50, 0, 91);
 }
 break;
 case 3:
 if(IezPVcsYvxh7A == 1)
 {
 ODrspvYx5MUbxp3KXXi.sq_StartWrite();
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(234); 
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(3); 
 ODrspvYx5MUbxp3KXXi.sq_WriteDword(ODrspvYx5MUbxp3KXXi.sq_GetBonusRateWithPassive(234, 234, 2, 1.0)); 
 sq_SendCreatePassiveObjectPacketPos(ODrspvYx5MUbxp3KXXi, 24376, 0, sq_GetDistancePos(ODrspvYx5MUbxp3KXXi.getXPos(), ODrspvYx5MUbxp3KXXi.getDirection(), 86), ODrspvYx5MUbxp3KXXi.getYPos(), 0);
 }
 break;
 }
 return true;
} 

function onProc_atgunner_pt_15(FkJshhrpvHZKE0jZ7Aiftk)
{
 if(!FkJshhrpvHZKE0jZ7Aiftk) return;
 local GZ9nrxVQWbu_Wq = FkJshhrpvHZKE0jZ7Aiftk.getSkillSubState(); 
 switch(GZ9nrxVQWbu_Wq)
 {
 case 3:
 local Yt7LL5EI237tRLjvRp94zyK = FkJshhrpvHZKE0jZ7Aiftk.getVar(); 
 local KWyips1HOy83ydQe9w6x6uoI = FkJshhrpvHZKE0jZ7Aiftk.getCurrentAnimation(); 
 local qRIl5jdd82uJ = sq_GetCurrentTime(KWyips1HOy83ydQe9w6x6uoI); 
 local xI2ovgAduiPBVi = KWyips1HOy83ydQe9w6x6uoI.getDelaySum(false); 
 local zZmpn7pOsdRH = Yt7LL5EI237tRLjvRp94zyK.get_vector(2); 
 local A7ppdJGjlHSCNHAdNcq7e = sq_GetDistancePos(Yt7LL5EI237tRLjvRp94zyK.get_vector(0),
 FkJshhrpvHZKE0jZ7Aiftk.getDirection(),
 sq_GetAccel(0, zZmpn7pOsdRH, qRIl5jdd82uJ, xI2ovgAduiPBVi, true)); 
 if(FkJshhrpvHZKE0jZ7Aiftk.isMovablePos(A7ppdJGjlHSCNHAdNcq7e, FkJshhrpvHZKE0jZ7Aiftk.getYPos())) 
 sq_setCurrentAxisPos(FkJshhrpvHZKE0jZ7Aiftk, 0, A7ppdJGjlHSCNHAdNcq7e); 
 else
 {
 local fxNor4MOBXnNY9NjW6cPV4Gg = sq_Abs(A7ppdJGjlHSCNHAdNcq7e - FkJshhrpvHZKE0jZ7Aiftk.getXPos());
 if(fxNor4MOBXnNY9NjW6cPV4Gg != 0)
 Yt7LL5EI237tRLjvRp94zyK.set_vector(2, (zZmpn7pOsdRH > 0) ? zZmpn7pOsdRH - fxNor4MOBXnNY9NjW6cPV4Gg : zZmpn7pOsdRH + fxNor4MOBXnNY9NjW6cPV4Gg);
 }
 
 local jmdfKlOQOLJs3EPlAL = Yt7LL5EI237tRLjvRp94zyK.get_vector(1) + Yt7LL5EI237tRLjvRp94zyK.get_vector(3) * sq_SinTable(sq_GetAccel(0, 90, qRIl5jdd82uJ, xI2ovgAduiPBVi, true));
 sq_setCurrentAxisPos(FkJshhrpvHZKE0jZ7Aiftk, 2, jmdfKlOQOLJs3EPlAL.tointeger()); 
 if(qRIl5jdd82uJ >= xI2ovgAduiPBVi) 
 if(FkJshhrpvHZKE0jZ7Aiftk.sq_IsMyControlObject()) 
 {
 FkJshhrpvHZKE0jZ7Aiftk.sq_IntVectClear();
 FkJshhrpvHZKE0jZ7Aiftk.sq_IntVectPush(1);
 FkJshhrpvHZKE0jZ7Aiftk.sq_IntVectPush(0);
 FkJshhrpvHZKE0jZ7Aiftk.sq_IntVectPush(1);
 FkJshhrpvHZKE0jZ7Aiftk.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
 }
 break;
 }
} 

 
function onEndCurrentAni_atgunner_pt_15(EoLmzzF8Klm93CDR)
{
 if(!EoLmzzF8Klm93CDR) return;
 if(!EoLmzzF8Klm93CDR.sq_IsMyControlObject()) return;
 local qxESgOf6nUesu = EoLmzzF8Klm93CDR.getSkillSubState(); 
 switch(qxESgOf6nUesu)
 {
 case 0:
 switch(EoLmzzF8Klm93CDR.getVar().get_vector(0))
 {
 case 1: 
 EoLmzzF8Klm93CDR.sq_IntVectClear();
 EoLmzzF8Klm93CDR.sq_IntVectPush(2); 
 EoLmzzF8Klm93CDR.sq_AddSetStatePacket(234, STATE_PRIORITY_USER, true); 
 break;
 case 2: 
 EoLmzzF8Klm93CDR.sq_IntVectClear();
 EoLmzzF8Klm93CDR.sq_IntVectPush(1); 
 EoLmzzF8Klm93CDR.sq_AddSetStatePacket(234, STATE_PRIORITY_USER, true); 
 break;
 }
 break;
 case 1:
 case 2:
 EoLmzzF8Klm93CDR.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 }
} 


