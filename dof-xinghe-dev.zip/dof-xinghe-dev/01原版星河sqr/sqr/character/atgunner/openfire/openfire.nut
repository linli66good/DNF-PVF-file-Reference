






 
function checkExecutableSkill_atgunner_openfire(MhnC4vB0_X5ElHM)
{
 if(!MhnC4vB0_X5ElHM) return false; 
 local cvZTN5Fzb1X8Ka = MhnC4vB0_X5ElHM.sq_IsUseSkill(242); 
 if(cvZTN5Fzb1X8Ka) 
 {
 local ZRFtfKq1zFErKtRWG = MhnC4vB0_X5ElHM.getState(); 
 switch(ZRFtfKq1zFErKtRWG)
 {
 case 6:
 case 7:
 MhnC4vB0_X5ElHM.sq_IntVectClear();
 MhnC4vB0_X5ElHM.sq_IntVectPush(1); 
 MhnC4vB0_X5ElHM.sq_AddSetStatePacket(242, STATE_PRIORITY_USER, true); 
 break;
 default:
 MhnC4vB0_X5ElHM.sq_IntVectClear();
 MhnC4vB0_X5ElHM.sq_IntVectPush(0); 
 MhnC4vB0_X5ElHM.sq_AddSetStatePacket(242, STATE_PRIORITY_USER, true); 
 break;
 }
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_openfire(zZAIwtzLbBGX)
{
 if(!zZAIwtzLbBGX) return false; 
 local jdEOCIRTE2BwC = zZAIwtzLbBGX.sq_GetState(); 
 if(jdEOCIRTE2BwC == STATE_STAND) 
 return true; 
 if(jdEOCIRTE2BwC == STATE_ATTACK) 
 {
 return zZAIwtzLbBGX.sq_IsCommandEnable(242); 
 }
 return true; 
} 

 
function onSetState_atgunner_openfire(zZAIwtzLbBGX, jdEOCIRTE2BwC, gVLkX_1ZG4Ab, NeCSkPJoxK4hIomSKGcu3eVT)
{
 
 
 
 
 
 
 
 
 
 
 
 
 
 if(!zZAIwtzLbBGX) return; 
 zZAIwtzLbBGX.getVar().clear_vector(); 
 zZAIwtzLbBGX.sq_StopMove(); 
 zZAIwtzLbBGX.sq_ZStop(); 
 local CCtknbMfOIkOicz5Z = zZAIwtzLbBGX.sq_GetVectorData(gVLkX_1ZG4Ab, 0); 
 zZAIwtzLbBGX.setSkillSubState(CCtknbMfOIkOicz5Z); 
 switch(CCtknbMfOIkOicz5Z)
 {
 case 0:
 local tF2eOz7NitiVSuyybGWKC = zZAIwtzLbBGX.sq_GetJumpAni(); 
 zZAIwtzLbBGX.sq_Rewind(tF2eOz7NitiVSuyybGWKC); 
 zZAIwtzLbBGX.setCurrentAnimation(tF2eOz7NitiVSuyybGWKC); 
 local y1_W73mo2q9hKK = zZAIwtzLbBGX.getVar(); 
 y1_W73mo2q9hKK.push_vector(zZAIwtzLbBGX.getZPos()); 
 y1_W73mo2q9hKK.push_vector(120); 
 y1_W73mo2q9hKK.push_vector(0); 
 y1_W73mo2q9hKK.push_vector(2); 
 break;
 case 1:
 zZAIwtzLbBGX.sq_SetCurrentAnimation(126);
 break;
 }
 zZAIwtzLbBGX.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 


if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onKeyFrameFlag_atgunner_openfire(mndUu71ONF_tg0O, VSISyKLM7QgJXpWdDKr)
{
 if(!mndUu71ONF_tg0O) return false;
 local a29FmVj6AippQk2V0 = mndUu71ONF_tg0O.getSkillSubState(); 
 switch(a29FmVj6AippQk2V0)
 {
 case 1:
 if(VSISyKLM7QgJXpWdDKr == 1)
 {
 local iEIfnIAwGTwTlbFtj = mndUu71ONF_tg0O.getVar().GetparticleCreaterMap("openfiregrenade", "passiveobject/script_sqr_nut_qq506807329/atgunner/particle/openfiregrenade.ptl", mndUu71ONF_tg0O); 
 iEIfnIAwGTwTlbFtj.Restart(0); 
 iEIfnIAwGTwTlbFtj.SetPos(
 sq_GetDistancePos(mndUu71ONF_tg0O.getXPos(), mndUu71ONF_tg0O.getDirection(), 13),
 mndUu71ONF_tg0O.getYPos(),
 mndUu71ONF_tg0O.getZPos() + 53); 
 sq_AddParticleObject(mndUu71ONF_tg0O, iEIfnIAwGTwTlbFtj); 
 }
 else if(VSISyKLM7QgJXpWdDKr == 2)
 {
 if(mndUu71ONF_tg0O.sq_IsMyControlObject())
 {
 mndUu71ONF_tg0O.sq_StartWrite();
 mndUu71ONF_tg0O.sq_WriteDword(242); 
 mndUu71ONF_tg0O.sq_WriteDword(1); 
 mndUu71ONF_tg0O.sq_WriteDword(mndUu71ONF_tg0O.sq_GetBonusRateWithPassive(242, 242, 0, 1.0)); 
 mndUu71ONF_tg0O.sq_WriteDword(mndUu71ONF_tg0O.sq_GetLevelData(242, 1, sq_GetSkillLevel(mndUu71ONF_tg0O, 242))); 
 sq_SendCreatePassiveObjectPacketPos(mndUu71ONF_tg0O, 24376, 0,
 sq_GetDistancePos(mndUu71ONF_tg0O.getXPos(), mndUu71ONF_tg0O.getDirection(), 400),
 mndUu71ONF_tg0O.getYPos(),
 0);
 }
 }
 break;
 }
 return true;
} 

function onProc_atgunner_openfire(oADXyo3ILmxtOrOdKeZZq)
{
 if(!oADXyo3ILmxtOrOdKeZZq) return;
 local bnjapuFrHFwkCA6Ft3 = oADXyo3ILmxtOrOdKeZZq.getSkillSubState(); 
 switch(bnjapuFrHFwkCA6Ft3)
 {
 case 0:
 local ttbJPmZIpu = oADXyo3ILmxtOrOdKeZZq.getVar(); 
 local gOQEitxV_FXTSI3uoN = oADXyo3ILmxtOrOdKeZZq.getCurrentAnimation(); 
 local rNHZ5aVPODjmz = sq_GetCurrentTime(gOQEitxV_FXTSI3uoN); 
 local fvxKplZop4rwWD8YoQP2eWlH = gOQEitxV_FXTSI3uoN.getDelaySum(ttbJPmZIpu.get_vector(2), ttbJPmZIpu.get_vector(3)); 
 local gdvF9mtjUcwQh_vfS = ttbJPmZIpu.get_vector(0); 
 local FUXA9W2zKKkSY4Yd15f = ttbJPmZIpu.get_vector(1); 
 local iv_DCiN5ZQeUkBI9E = sq_GetAccel(0, FUXA9W2zKKkSY4Yd15f, rNHZ5aVPODjmz, fvxKplZop4rwWD8YoQP2eWlH, true); 
 sq_setCurrentAxisPos(oADXyo3ILmxtOrOdKeZZq, 2, gdvF9mtjUcwQh_vfS + iv_DCiN5ZQeUkBI9E); 
 if(oADXyo3ILmxtOrOdKeZZq.sq_IsMyControlObject()) 
 if(rNHZ5aVPODjmz >= fvxKplZop4rwWD8YoQP2eWlH) 
 {
 oADXyo3ILmxtOrOdKeZZq.sq_IntVectClear();
 oADXyo3ILmxtOrOdKeZZq.sq_IntVectPush(1); 
 oADXyo3ILmxtOrOdKeZZq.sq_AddSetStatePacket(242, STATE_PRIORITY_USER, true); 
 }
 break;
 }
} 

 
function onEndCurrentAni_atgunner_openfire(ZCw7tz4YSdN)
{
 if(!ZCw7tz4YSdN) return;
 if(!ZCw7tz4YSdN.sq_IsMyControlObject()) return;
 local whO5DR405u27I = ZCw7tz4YSdN.getSkillSubState(); 
 if(whO5DR405u27I == 1)
 {
 ZCw7tz4YSdN.sq_IntVectClear();
 ZCw7tz4YSdN.sq_IntVectPush(1);
 ZCw7tz4YSdN.sq_IntVectPush(0);
 ZCw7tz4YSdN.sq_IntVectPush(1);
 ZCw7tz4YSdN.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
 }
} 


