






function checkExecutableSkill_atgunner_gravitygrenade(UTw2Wcb5GOCAgHLrhA4jE)
{
 if(!UTw2Wcb5GOCAgHLrhA4jE) return false; 
 local nMA5_5v2Radcgoxd4naQV2 = UTw2Wcb5GOCAgHLrhA4jE.sq_IsUseSkill(240); 
 if(nMA5_5v2Radcgoxd4naQV2) 
 {
 local TUhl3TGOt8F = UTw2Wcb5GOCAgHLrhA4jE.getZPos(); 
 local sovvlmD4QgXj = UTw2Wcb5GOCAgHLrhA4jE.getState(); 
 if(TUhl3TGOt8F > 0 && (sovvlmD4QgXj == 6 || sovvlmD4QgXj == 7)) 
 {
 UTw2Wcb5GOCAgHLrhA4jE.sq_IntVectClear();
 UTw2Wcb5GOCAgHLrhA4jE.sq_IntVectPush(1); 
 UTw2Wcb5GOCAgHLrhA4jE.sq_AddSetStatePacket(240, STATE_PRIORITY_USER, true); 
 }
 else
 {
 UTw2Wcb5GOCAgHLrhA4jE.sq_IntVectClear();
 UTw2Wcb5GOCAgHLrhA4jE.sq_IntVectPush(0); 
 UTw2Wcb5GOCAgHLrhA4jE.sq_AddSetStatePacket(240, STATE_PRIORITY_USER, true); 
 }
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_gravitygrenade(UTw2Wcb5GOCAgHLrhA4jE)
{
 if(!UTw2Wcb5GOCAgHLrhA4jE) return false; 
 local nMA5_5v2Radcgoxd4naQV2 = UTw2Wcb5GOCAgHLrhA4jE.sq_GetState(); 
 if(nMA5_5v2Radcgoxd4naQV2 == STATE_STAND) 
 return true; 
 if(nMA5_5v2Radcgoxd4naQV2 == STATE_ATTACK) 
 {
 return UTw2Wcb5GOCAgHLrhA4jE.sq_IsCommandEnable(240); 
 }
 return true; 
} 

 
function onSetState_atgunner_gravitygrenade(w8gHOr3BsSE3watvO9, vpdIkgMitWQQdAA2POVW3x9, BiUCLkGhOStoYkBjPBH, GwualivHFmJV8AA)
{
 if(!w8gHOr3BsSE3watvO9) return; 
 w8gHOr3BsSE3watvO9.getVar().clear_vector(); 
 w8gHOr3BsSE3watvO9.sq_StopMove(); 
 local D4jFGqLWclgi = w8gHOr3BsSE3watvO9.sq_GetVectorData(BiUCLkGhOStoYkBjPBH, 0); 
 w8gHOr3BsSE3watvO9.setSkillSubState(D4jFGqLWclgi); 
 switch(D4jFGqLWclgi)
 {
 case 0:
 w8gHOr3BsSE3watvO9.sq_SetCurrentAnimation(125);
 break;
 case 1:
 w8gHOr3BsSE3watvO9.sq_ZStop(); 
 w8gHOr3BsSE3watvO9.sq_SetCurrentAnimation(61);
 break;
 }
 w8gHOr3BsSE3watvO9.sq_PlaySound("FG_GRENADE"); 
 w8gHOr3BsSE3watvO9.sq_SetSuperArmor(POD_VAR_SUPERARMOR); 
 w8gHOr3BsSE3watvO9.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 

function onKeyFrameFlag_atgunner_gravitygrenade(SaG2Ig4Cyn63vvryRQ4nt4o0, DeTxxGF8aAMEYUsVpkfd)
{
 if(!SaG2Ig4Cyn63vvryRQ4nt4o0) return false;
 if(!SaG2Ig4Cyn63vvryRQ4nt4o0.sq_IsMyControlObject())return true;
 local ojnYEs1kPT2 = SaG2Ig4Cyn63vvryRQ4nt4o0.getSkillSubState(); 
 if(DeTxxGF8aAMEYUsVpkfd == 1)
 {
 
 
 
 
 local lBekkSSpVeFyTNCAECTCR = 1; 
 switch(ojnYEs1kPT2)
 {
 case 0:
 if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)) 
 lBekkSSpVeFyTNCAECTCR = 3; 
 else if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL)) 
 lBekkSSpVeFyTNCAECTCR = 4; 
 break;
 case 1:
 lBekkSSpVeFyTNCAECTCR = 2; 
 break;
 }
 local eeNTo1TkiJG079FfjsE = sq_GetSkillLevel(SaG2Ig4Cyn63vvryRQ4nt4o0, 240); 
 local TD5HLlDIW5BHpP9cZY = sq_GetLevelData(SaG2Ig4Cyn63vvryRQ4nt4o0, 240, 4, eeNTo1TkiJG079FfjsE); 
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_StartWrite();
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_WriteDword(240); 
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_WriteDword(1); 
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_WriteDword(SaG2Ig4Cyn63vvryRQ4nt4o0.sq_GetLevelData(240, 0, eeNTo1TkiJG079FfjsE)); 
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_WriteDword(SaG2Ig4Cyn63vvryRQ4nt4o0.sq_GetLevelData(240, 1, eeNTo1TkiJG079FfjsE)); 
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_WriteDword(SaG2Ig4Cyn63vvryRQ4nt4o0.sq_GetBonusRateWithPassive(240, 240, 2, 1.0)); 
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_WriteDword(SaG2Ig4Cyn63vvryRQ4nt4o0.sq_GetBonusRateWithPassive(240, 240, 3, 1.0)); 
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_WriteDword(lBekkSSpVeFyTNCAECTCR); 
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_WriteDword(TD5HLlDIW5BHpP9cZY); 
 if(ojnYEs1kPT2 == 1)
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_SendCreatePassiveObjectPacket(24376, 0, 35, 0, 68);
 else
 SaG2Ig4Cyn63vvryRQ4nt4o0.sq_SendCreatePassiveObjectPacket(24376, 0, 48, 0, 76);
 }
 return true;
} 

 
function onEndCurrentAni_atgunner_gravitygrenade(uG_GG7WDDWHfa1WnV_ZbX)
{
 if(!uG_GG7WDDWHfa1WnV_ZbX) return;
 if(!uG_GG7WDDWHfa1WnV_ZbX.sq_IsMyControlObject()) return;
 local WxaRxFm1SHcmggJteK6 = uG_GG7WDDWHfa1WnV_ZbX.getSkillSubState(); 
 switch(WxaRxFm1SHcmggJteK6)
 {
 case 0:
 uG_GG7WDDWHfa1WnV_ZbX.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
 break;
 case 1:
 uG_GG7WDDWHfa1WnV_ZbX.sq_IntVectClear();
 uG_GG7WDDWHfa1WnV_ZbX.sq_IntVectPush(1);
 uG_GG7WDDWHfa1WnV_ZbX.sq_IntVectPush(0);
 uG_GG7WDDWHfa1WnV_ZbX.sq_IntVectPush(250);
 uG_GG7WDDWHfa1WnV_ZbX.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
 break;
 }
} 

function onEndState_atgunner_gravitygrenade(K_j1DiRSUgpd, sQiKj5YJp72RghelVNu)
{
 if(!K_j1DiRSUgpd) return;
 K_j1DiRSUgpd.sq_RemoveSuperArmor(POD_VAR_SUPERARMOR); 
} 



