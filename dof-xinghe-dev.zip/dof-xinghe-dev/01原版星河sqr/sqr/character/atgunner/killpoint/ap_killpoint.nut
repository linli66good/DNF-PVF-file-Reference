



function sq_AddFunctionName(appendage)
{
    appendage.sq_AddFunctionName("onStart", "onStart_appendage_atgunner_killpoint")
    appendage.sq_AddFunctionName("proc", "proc_appendage_atgunner_killpoint")
 appendage.sq_AddFunctionName("onDamageParent", "onDamageParent_appendage_atgunner_killpoint")
 appendage.sq_AddFunctionName("drawAppend", "drawAppend_appendage_atgunner_killpoint")
 appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_atgunner_killpoint")
}




function onStart_appendage_atgunner_killpoint(YJlyKsrm000U57V1MIiX)
{
 if(!YJlyKsrm000U57V1MIiX) return;
 local fbYKGbwoisq5m7Q = YJlyKsrm000U57V1MIiX.getParent();
 local qNrEBuc3Yg2LPD1C3sdpF = YJlyKsrm000U57V1MIiX.getSource();
 if(!qNrEBuc3Yg2LPD1C3sdpF || !fbYKGbwoisq5m7Q)
 {
 YJlyKsrm000U57V1MIiX.setValid(false);
 return;
 }
 YJlyKsrm000U57V1MIiX.getVar("state").clear_vector(); 
 YJlyKsrm000U57V1MIiX.getVar("state").push_vector(0); 
 local eH1iPUKWb0duNA3o = sq_GetDirection(qNrEBuc3Yg2LPD1C3sdpF); 
 local _2WehxaQvpy2tDiN = sq_GetXPos(qNrEBuc3Yg2LPD1C3sdpF); 
 local VhQUbJr3K2clGoKSCdu = sq_GetYPos(qNrEBuc3Yg2LPD1C3sdpF); 
 local aTsIIrdWnpy4o = sq_GetZPos(qNrEBuc3Yg2LPD1C3sdpF) + 83; 
 
 local KYPSlef8mkH8O1g = sq_CreateAnimation("", "character/gunner/effect/animation/atkillpoint/anionly_killpoint_spinchain.ani"); 
 local jh0Dju4ZMpxEvv = sq_CreatePooledObject(KYPSlef8mkH8O1g, true); 
 sq_SetCurrentDirection(jh0Dju4ZMpxEvv, eH1iPUKWb0duNA3o); 
 jh0Dju4ZMpxEvv.setCurrentPos(_2WehxaQvpy2tDiN, VhQUbJr3K2clGoKSCdu, aTsIIrdWnpy4o); 
 jh0Dju4ZMpxEvv = sq_SetEnumDrawLayer(jh0Dju4ZMpxEvv, ENUM_DRAWLAYER_NORMAL); 
 sq_AddObject(qNrEBuc3Yg2LPD1C3sdpF, jh0Dju4ZMpxEvv, OBJECTTYPE_DRAWONLY, false); 
 YJlyKsrm000U57V1MIiX.getVar("aniobj").clear_obj_vector(); 
 YJlyKsrm000U57V1MIiX.getVar("aniobj").push_obj_vector(jh0Dju4ZMpxEvv); 
 YJlyKsrm000U57V1MIiX.getVar("direction").clear_vector(); 
 YJlyKsrm000U57V1MIiX.getVar("direction").push_vector(eH1iPUKWb0duNA3o); 
 YJlyKsrm000U57V1MIiX.getVar("move").clear_vector(); 
 local v9lze1qX4H44XZmvaeu0J4 = YJlyKsrm000U57V1MIiX.getVar("move"); 
 v9lze1qX4H44XZmvaeu0J4.push_vector(_2WehxaQvpy2tDiN); 
 v9lze1qX4H44XZmvaeu0J4.push_vector(VhQUbJr3K2clGoKSCdu); 
 v9lze1qX4H44XZmvaeu0J4.push_vector(aTsIIrdWnpy4o); 
} 

function proc_appendage_atgunner_killpoint(Sv3yBtShkKe_tHo3ebi1Mxd)
{
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return;
 local HlASuPcRLgluXam1rUDJ = Sv3yBtShkKe_tHo3ebi1Mxd.getParent();
 local aL4NaAntuVr9flx = Sv3yBtShkKe_tHo3ebi1Mxd.getSource();
 if(!aL4NaAntuVr9flx || !HlASuPcRLgluXam1rUDJ)
 {
 Sv3yBtShkKe_tHo3ebi1Mxd.setValid(false);
 return;
 }
 if(Sv3yBtShkKe_tHo3ebi1Mxd.getVar().size_vector() > 0)
 {
 local q8OsQ7Jd2qZMuGoPv = Sv3yBtShkKe_tHo3ebi1Mxd.getVar().get_vector(4); 
 if(q8OsQ7Jd2qZMuGoPv > 0 && Sv3yBtShkKe_tHo3ebi1Mxd.getTimer().Get() >= q8OsQ7Jd2qZMuGoPv)
 {
 Sv3yBtShkKe_tHo3ebi1Mxd.setValid(false);
 return;
 }
 }
 local YQYFBMNhEly7vK = Sv3yBtShkKe_tHo3ebi1Mxd.getVar("state").get_vector(0); 
 switch(YQYFBMNhEly7vK)
 {
 case 0:
 local Web3cF41PV9 = Sv3yBtShkKe_tHo3ebi1Mxd.getVar("aniobj").get_obj_vector(0); 
 if(!Web3cF41PV9) break; 
 local YNlRxR2LCJreAgwvg6CY0Z = Sv3yBtShkKe_tHo3ebi1Mxd.getVar("move"); 
 local YSU0nvnBLG7fk9HDxx0qU = sq_GetObjectTime(Web3cF41PV9); 
 local la7WmTE0cKIrKZHExddXdhE1 = 100; 
 local zmsjw0A3EjsXNNCaLpuUr = YNlRxR2LCJreAgwvg6CY0Z.get_vector(0); 
 local NBZ_TGFTBO5Ke5 = YNlRxR2LCJreAgwvg6CY0Z.get_vector(1); 
 local TpKN9tzzObhlmx = sq_GetXPos(HlASuPcRLgluXam1rUDJ); 
 local lsv3EgnwdVi = sq_GetYPos(HlASuPcRLgluXam1rUDJ); 
 local nTG6SH3i_jP44xzqzysr9KdA = sq_GetUniformVelocity(zmsjw0A3EjsXNNCaLpuUr, TpKN9tzzObhlmx, YSU0nvnBLG7fk9HDxx0qU, la7WmTE0cKIrKZHExddXdhE1);
 local izL27x1Ly_JCjTR = sq_GetUniformVelocity(NBZ_TGFTBO5Ke5, lsv3EgnwdVi, YSU0nvnBLG7fk9HDxx0qU, la7WmTE0cKIrKZHExddXdhE1);
 sq_setCurrentAxisPos(Web3cF41PV9, 0, nTG6SH3i_jP44xzqzysr9KdA); 
 sq_setCurrentAxisPos(Web3cF41PV9, 1, izL27x1Ly_JCjTR); 
 if(YSU0nvnBLG7fk9HDxx0qU >= 100)
 {
 Web3cF41PV9.setValid(false); 
 sq_setCurrentAxisPos(HlASuPcRLgluXam1rUDJ, 2, 0); 
 
 sq_sendSetActiveStatusPacket(HlASuPcRLgluXam1rUDJ, aL4NaAntuVr9flx, ACTIVESTATUS_BLEEDING, (Sv3yBtShkKe_tHo3ebi1Mxd.getVar().get_vector(3)).tofloat(), Sv3yBtShkKe_tHo3ebi1Mxd.getVar().get_vector(0), false, Sv3yBtShkKe_tHo3ebi1Mxd.getVar().get_vector(1), Sv3yBtShkKe_tHo3ebi1Mxd.getVar().get_vector(2));
 local s6BRkM8VfP7Q4JRi3 = izL27x1Ly_JCjTR;
 if(NBZ_TGFTBO5Ke5 < s6BRkM8VfP7Q4JRi3) s6BRkM8VfP7Q4JRi3 -= 10;
 else s6BRkM8VfP7Q4JRi3 += 10;
 local IsetLVIeHxTu2EOOBAj7Z = sq_GetDistancePos(nTG6SH3i_jP44xzqzysr9KdA, Sv3yBtShkKe_tHo3ebi1Mxd.getVar("direction").get_vector(0), 20);
 Sv3yBtShkKe_tHo3ebi1Mxd.getVar("move").clear_vector();
 Sv3yBtShkKe_tHo3ebi1Mxd.getVar("move").push_vector(nTG6SH3i_jP44xzqzysr9KdA);
 Sv3yBtShkKe_tHo3ebi1Mxd.getVar("move").push_vector(izL27x1Ly_JCjTR);
 Sv3yBtShkKe_tHo3ebi1Mxd.getVar("move").push_vector(IsetLVIeHxTu2EOOBAj7Z);
 Sv3yBtShkKe_tHo3ebi1Mxd.getVar("move").push_vector(s6BRkM8VfP7Q4JRi3);
 
 sq_SetMyShake(aL4NaAntuVr9flx, 2, 100);
 Sv3yBtShkKe_tHo3ebi1Mxd.getVar("state").set_vector(0, 1); 
 }
 break;
 case 1:
 break;
 }
} 

function onDamageParent_appendage_atgunner_killpoint(md5z0osrDxXoUPTG, JxickFo1LKA74Zv, JceCfy6im5, FwEUqFVOGUB3QGl9kE6)
{
 if(!md5z0osrDxXoUPTG) return;
 local YfyZrlXNng_Vs9nJywma = md5z0osrDxXoUPTG.getParent();
 local pPfKkE7V6YYl = md5z0osrDxXoUPTG.getSource();
 if(!pPfKkE7V6YYl || !YfyZrlXNng_Vs9nJywma)
 {
 md5z0osrDxXoUPTG.setValid(false);
 return;
 }
 if(md5z0osrDxXoUPTG.getVar().size_vector() > 0)
 {
 local efVPlPZN9jU1Ojy = md5z0osrDxXoUPTG.getVar().get_vector(4); 
 if(efVPlPZN9jU1Ojy > 0 && isSameObject(pPfKkE7V6YYl, JxickFo1LKA74Zv) && JxickFo1LKA74Zv.getState() == 237)
 {
 md5z0osrDxXoUPTG.getVar().set_vector(4, 0); 
 }
 }
} 


function drawAppend_appendage_atgunner_killpoint(pnvI_lfeYugo_CTnuyUgj8, ZpED90M6NkfwlH7, xPPX3JRKtiT8s3L, eqTggIreIqkKEPw, iXoUOyp1USbLdKDXm_8i)
{
 if(!pnvI_lfeYugo_CTnuyUgj8) return;
 local DNIcbrXhFtc5 = pnvI_lfeYugo_CTnuyUgj8.getParent();
 local _kDeUGLEOR9sJJhbiRQCnhV = pnvI_lfeYugo_CTnuyUgj8.getSource();
 if(!_kDeUGLEOR9sJJhbiRQCnhV || !DNIcbrXhFtc5)
 {
 pnvI_lfeYugo_CTnuyUgj8.setValid(false);
 return;
 }
 if(!ZpED90M6NkfwlH7)return;
 local pw1hRXv2DkLa8fasjm1 = pnvI_lfeYugo_CTnuyUgj8.getVar().getBool(0); 
 local E9IfcZcEVwfQxq = pnvI_lfeYugo_CTnuyUgj8.getVar("state").get_vector(0); 
 switch(E9IfcZcEVwfQxq)
 {
 case 1:
 if(pw1hRXv2DkLa8fasjm1)
 {
 local QDl_G67QgN = pnvI_lfeYugo_CTnuyUgj8.getVar().GetAnimationMap("killpointchaina_chain", "character/gunner/effect/animation/atkillpoint/killpointchaina_chain.ani");
 local cCoycMgE31x = sq_GetCurrentTime(QDl_G67QgN); 
 local VAhX7W4oJMsHmNmrtjQ = 100; 
 if(cCoycMgE31x >= QDl_G67QgN.getDelaySum(false))
 {
 pnvI_lfeYugo_CTnuyUgj8.getVar("state").set_vector(0, 2); 
 return;
 }
 local xjzWaUUgeZ6017 = pnvI_lfeYugo_CTnuyUgj8.getVar("move"); 
 local fhe0MaIykmxIbjqgRk = xjzWaUUgeZ6017.get_vector(0); 
 local gxiHQkVU5NLs = xjzWaUUgeZ6017.get_vector(1); 
 local bjpH1jEMIw21J_8M1xzmH = xjzWaUUgeZ6017.get_vector(2); 
 local rMWEm2YWimtIy67ddrJeQo = xjzWaUUgeZ6017.get_vector(3); 
 local HSlFI4zgDNWfa = sq_GetUniformVelocity(fhe0MaIykmxIbjqgRk, bjpH1jEMIw21J_8M1xzmH, cCoycMgE31x, VAhX7W4oJMsHmNmrtjQ);
 local cKma5XzG9S2LU = sq_GetUniformVelocity(gxiHQkVU5NLs, rMWEm2YWimtIy67ddrJeQo, cCoycMgE31x, VAhX7W4oJMsHmNmrtjQ);
 if(DNIcbrXhFtc5.isMovablePos(HSlFI4zgDNWfa, cKma5XzG9S2LU))
 {
 sq_setCurrentAxisPos(DNIcbrXhFtc5, 0, HSlFI4zgDNWfa); 
 sq_setCurrentAxisPos(DNIcbrXhFtc5, 1, cKma5XzG9S2LU); 
 }
 else if(DNIcbrXhFtc5.isMovablePos(HSlFI4zgDNWfa, gxiHQkVU5NLs))
 sq_setCurrentAxisPos(DNIcbrXhFtc5, 0, HSlFI4zgDNWfa); 
 else if(DNIcbrXhFtc5.isMovablePos(fhe0MaIykmxIbjqgRk, cKma5XzG9S2LU))
 sq_setCurrentAxisPos(DNIcbrXhFtc5, 1, cKma5XzG9S2LU); 
 if(sq_GetDirection(DNIcbrXhFtc5) == ENUM_DIRECTION_RIGHT)
 QDl_G67QgN.setImageRateFromOriginal(-1.0, 1.0);
 else
 QDl_G67QgN.setImageRateFromOriginal(1.0, 1.0);
 sq_AnimationProc(QDl_G67QgN);
 sq_drawCurrentFrame(QDl_G67QgN, xPPX3JRKtiT8s3L, eqTggIreIqkKEPw, false);
 }
 else
 {
 local fARuSSHL7uB = pnvI_lfeYugo_CTnuyUgj8.getVar().GetAnimationMap("killpointchainnoholda_chain", "character/gunner/effect/animation/atkillpoint/killpointchainnoholda_chain.ani");
 if(sq_IsEnd(fARuSSHL7uB))
 {
 pnvI_lfeYugo_CTnuyUgj8.getVar("state").set_vector(0, 2); 
 return;
 }
 local KwlPTAF8NduZxhS_WI = pnvI_lfeYugo_CTnuyUgj8.getVar().GetAnimationMap("killpointchainnoholda_hit_eff_b", "character/gunner/effect/animation/atkillpoint/killpointchainnoholda_hit_eff_b.ani");
 if(sq_GetDirection(DNIcbrXhFtc5) == ENUM_DIRECTION_RIGHT)
 {
 fARuSSHL7uB.setImageRateFromOriginal(-1.0, 1.0);
 KwlPTAF8NduZxhS_WI.setImageRateFromOriginal(-1.0, 1.0);
 }
 sq_AnimationProc(fARuSSHL7uB);
 sq_drawCurrentFrame(fARuSSHL7uB, xPPX3JRKtiT8s3L, eqTggIreIqkKEPw - 14, false);
 sq_AnimationProc(KwlPTAF8NduZxhS_WI);
 sq_drawCurrentFrame(KwlPTAF8NduZxhS_WI, xPPX3JRKtiT8s3L, eqTggIreIqkKEPw - sq_GetHeightObject(DNIcbrXhFtc5) / 2, false);
 }
 break;
 case 2:
 local QDl_G67QgN = (pw1hRXv2DkLa8fasjm1)
 ? pnvI_lfeYugo_CTnuyUgj8.getVar().GetAnimationMap("killpointchainb_chain", "character/gunner/effect/animation/atkillpoint/killpointchainb_chain.ani")
 : pnvI_lfeYugo_CTnuyUgj8.getVar().GetAnimationMap("killpointchainnoholdb_chain", "character/gunner/effect/animation/atkillpoint/killpointchainnoholdb_chain.ani");
 if(QDl_G67QgN)
 {
 if(sq_GetDirection(DNIcbrXhFtc5) == ENUM_DIRECTION_RIGHT)
 QDl_G67QgN.setImageRateFromOriginal(-1.0, 1.0);
 else
 QDl_G67QgN.setImageRateFromOriginal(1.0, 1.0);
 sq_AnimationProc(QDl_G67QgN);
 sq_drawCurrentFrame(QDl_G67QgN, xPPX3JRKtiT8s3L, eqTggIreIqkKEPw, false);
 }
 break;
 }
} 

function onEnd_appendage_atgunner_killpoint(zZAIwtzLbBGX)
{
 if(!zZAIwtzLbBGX) return;
 local jdEOCIRTE2BwC = zZAIwtzLbBGX.getParent();
 local gVLkX_1ZG4Ab = zZAIwtzLbBGX.getSource();
 if(!gVLkX_1ZG4Ab || !jdEOCIRTE2BwC)
 {
 zZAIwtzLbBGX.setValid(false);
 return;
 }
 local NeCSkPJoxK4hIomSKGcu3eVT = zZAIwtzLbBGX.getVar("aniobj").get_obj_vector(0); 
 if(NeCSkPJoxK4hIomSKGcu3eVT) NeCSkPJoxK4hIomSKGcu3eVT.setValid(false); 
 local CCtknbMfOIkOicz5Z = zZAIwtzLbBGX.getVar("state").get_vector(0); 
 switch(CCtknbMfOIkOicz5Z)
 {
 case 2: 
 local tF2eOz7NitiVSuyybGWKC = sq_GetDirection(jdEOCIRTE2BwC); 
 local y1_W73mo2q9hKK = (zZAIwtzLbBGX.getVar().getBool(0))
 ? sq_CreateAnimation("", "character/gunner/effect/animation/atkillpoint/killpointchainc_chain.ani")
 : sq_CreateAnimation("", "character/gunner/effect/animation/atkillpoint/killpointchainnoholdc_chain.ani"); 
 local SrSaWuA5FBwl2MYx2 = sq_CreatePooledObject(y1_W73mo2q9hKK, true); 
 sq_SetCurrentDirection(SrSaWuA5FBwl2MYx2, sq_GetOppositeDirection(tF2eOz7NitiVSuyybGWKC)); 
 SrSaWuA5FBwl2MYx2.setCurrentPos(sq_GetXPos(jdEOCIRTE2BwC), sq_GetYPos(jdEOCIRTE2BwC), sq_GetZPos(jdEOCIRTE2BwC)); 
 SrSaWuA5FBwl2MYx2 = sq_SetEnumDrawLayer(SrSaWuA5FBwl2MYx2, ENUM_DRAWLAYER_NORMAL); 
 sq_AddObject(gVLkX_1ZG4Ab, SrSaWuA5FBwl2MYx2, OBJECTTYPE_DRAWONLY, false); 
 break;
 }
} 


