





 
function checkExecutableSkill_atgunner_killpoint(zZAIwtzLbBGX)
{
 if(!zZAIwtzLbBGX) return false; 
 local jdEOCIRTE2BwC = -1; 
 local gVLkX_1ZG4Ab = zZAIwtzLbBGX.getDirection(); 
 local NeCSkPJoxK4hIomSKGcu3eVT = sq_GetXPos(zZAIwtzLbBGX); 
 local CCtknbMfOIkOicz5Z = []; 
 local tF2eOz7NitiVSuyybGWKC = zZAIwtzLbBGX.getObjectManager(); 
 local y1_W73mo2q9hKK = tF2eOz7NitiVSuyybGWKC.getCollisionObjectNumber(); 
 for(local SrSaWuA5FBwl2MYx2 = 0; SrSaWuA5FBwl2MYx2 < y1_W73mo2q9hKK; SrSaWuA5FBwl2MYx2++)
 {
 local HI0r6s3gMe7DdjgDJWKba3f = tF2eOz7NitiVSuyybGWKC.getCollisionObject(SrSaWuA5FBwl2MYx2); 
 
 if(!zZAIwtzLbBGX.isEnemy(HI0r6s3gMe7DdjgDJWKba3f) || !HI0r6s3gMe7DdjgDJWKba3f.isObjectType(OBJECTTYPE_ACTIVE)) continue;
 local sYBEbagU6v4wzc6huribM0Q = CNSquirrelAppendage.sq_GetAppendage(HI0r6s3gMe7DdjgDJWKba3f, "character/atgunner/killpoint/ap_killpoint.nut");
 if(sYBEbagU6v4wzc6huribM0Q && isSameObject(zZAIwtzLbBGX, sYBEbagU6v4wzc6huribM0Q.getSource()) && sYBEbagU6v4wzc6huribM0Q.isValid())
 {
 local ru83TvnPp50lhlLTHkYJs = (NeCSkPJoxK4hIomSKGcu3eVT > sq_GetXPos(HI0r6s3gMe7DdjgDJWKba3f)) ? ENUM_DIRECTION_LEFT : ENUM_DIRECTION_RIGHT; 
 if(jdEOCIRTE2BwC == -1) 
 jdEOCIRTE2BwC = ru83TvnPp50lhlLTHkYJs; 
 
 if(jdEOCIRTE2BwC != -1 && jdEOCIRTE2BwC == ru83TvnPp50lhlLTHkYJs)
 CCtknbMfOIkOicz5Z.push(1); 
 else 
 CCtknbMfOIkOicz5Z.push(2); 
 CCtknbMfOIkOicz5Z.push(sq_GetGroup(HI0r6s3gMe7DdjgDJWKba3f)); 
 CCtknbMfOIkOicz5Z.push(sq_GetUniqueId(HI0r6s3gMe7DdjgDJWKba3f)); 
 }
 }
 if(CCtknbMfOIkOicz5Z.len() > 0 && jdEOCIRTE2BwC != -1) 
 {
 zZAIwtzLbBGX.sq_IntVectClear();
 zZAIwtzLbBGX.sq_IntVectPush(1);
 zZAIwtzLbBGX.sq_IntVectPush(sq_getRandom(0, 1)); 
 zZAIwtzLbBGX.sq_IntVectPush(jdEOCIRTE2BwC); 
 zZAIwtzLbBGX.sq_IntVectPush(CCtknbMfOIkOicz5Z.len()); 
 foreach(val in CCtknbMfOIkOicz5Z)
 zZAIwtzLbBGX.sq_IntVectPush(val); 
 zZAIwtzLbBGX.sq_AddSetStatePacket(237, STATE_PRIORITY_USER, true); 
 return true; 
 }
 local jscku7FKBe4wb = zZAIwtzLbBGX.sq_IsUseSkill(237); 
 if(jscku7FKBe4wb) 
 {
 zZAIwtzLbBGX.sq_IntVectClear();
 zZAIwtzLbBGX.sq_IntVectPush(0); 
 zZAIwtzLbBGX.sq_AddSetStatePacket(237, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false;
} 

 
function checkCommandEnable_atgunner_killpoint(oADXyo3ILmxtOrOdKeZZq)
{
 if(!oADXyo3ILmxtOrOdKeZZq) return false; 
 local bnjapuFrHFwkCA6Ft3 = oADXyo3ILmxtOrOdKeZZq.sq_GetState(); 
 if(bnjapuFrHFwkCA6Ft3 == STATE_STAND) 
 return true; 
 if(bnjapuFrHFwkCA6Ft3 == STATE_ATTACK) 
 {
 return oADXyo3ILmxtOrOdKeZZq.sq_IsCommandEnable(237); 
 }
 return true; 
} 

 
function onSetState_atgunner_killpoint(oADXyo3ILmxtOrOdKeZZq, bnjapuFrHFwkCA6Ft3, ttbJPmZIpu, gOQEitxV_FXTSI3uoN)
{
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 if(!oADXyo3ILmxtOrOdKeZZq) return; 
 oADXyo3ILmxtOrOdKeZZq.sq_StopMove(); 
 oADXyo3ILmxtOrOdKeZZq.getVar().clear_vector(); 
 local rNHZ5aVPODjmz = oADXyo3ILmxtOrOdKeZZq.sq_GetVectorData(ttbJPmZIpu, 0); 
 oADXyo3ILmxtOrOdKeZZq.setSkillSubState(rNHZ5aVPODjmz); 
 switch(rNHZ5aVPODjmz)
 {
 case 0:
 oADXyo3ILmxtOrOdKeZZq.sq_SetCurrentAnimation(121);
 local fvxKplZop4rwWD8YoQP2eWlH = sq_GetSkillLevel(oADXyo3ILmxtOrOdKeZZq, 237); 
 oADXyo3ILmxtOrOdKeZZq.getVar().push_vector(oADXyo3ILmxtOrOdKeZZq.sq_GetLevelData(237, 0, fvxKplZop4rwWD8YoQP2eWlH)); 
 break;
 case 1:
 
 
 
 
 oADXyo3ILmxtOrOdKeZZq.sq_SetCurrentAnimation(122);
 oADXyo3ILmxtOrOdKeZZq.setDirection(oADXyo3ILmxtOrOdKeZZq.sq_GetVectorData(ttbJPmZIpu, 2)); 
 local gdvF9mtjUcwQh_vfS = oADXyo3ILmxtOrOdKeZZq.getVar(); 
 local FUXA9W2zKKkSY4Yd15f = oADXyo3ILmxtOrOdKeZZq.sq_GetVectorData(ttbJPmZIpu, 3); 
 for(local iv_DCiN5ZQeUkBI9E = 0; iv_DCiN5ZQeUkBI9E < FUXA9W2zKKkSY4Yd15f; iv_DCiN5ZQeUkBI9E += 3)
 {
 local sCSIPfMCJ6C3Mj0uvt = oADXyo3ILmxtOrOdKeZZq.sq_GetVectorData(ttbJPmZIpu, 4 + iv_DCiN5ZQeUkBI9E); 
 local uHLRBQuYDaPgcAxZlSlF = oADXyo3ILmxtOrOdKeZZq.sq_GetVectorData(ttbJPmZIpu, 4 + iv_DCiN5ZQeUkBI9E + 1); 
 local J_lLqJEDYwjlzcPdoG7 = oADXyo3ILmxtOrOdKeZZq.sq_GetVectorData(ttbJPmZIpu, 4 + iv_DCiN5ZQeUkBI9E + 2); 
 local SrW6Ojpxnnc3l4aH = sq_GetObject(oADXyo3ILmxtOrOdKeZZq, uHLRBQuYDaPgcAxZlSlF, J_lLqJEDYwjlzcPdoG7); 
 if(SrW6Ojpxnnc3l4aH)
 {
 local HDATZ69oV1ySvqBs = CNSquirrelAppendage.sq_GetAppendage(SrW6Ojpxnnc3l4aH, "character/atgunner/killpoint/ap_killpoint.nut");
 if(HDATZ69oV1ySvqBs && HDATZ69oV1ySvqBs.isValid())
 {
 switch(sCSIPfMCJ6C3Mj0uvt)
 {
 case 1: 
 if(HDATZ69oV1ySvqBs.getVar().size_vector() > 0)
 {
 local CQhs9Sv8r6Uf0hq = HDATZ69oV1ySvqBs.getVar().get_vector(4); 
 if(CQhs9Sv8r6Uf0hq > 0)
 HDATZ69oV1ySvqBs.getVar().set_vector(4, 0); 
 }
 gdvF9mtjUcwQh_vfS.push_vector(uHLRBQuYDaPgcAxZlSlF); 
 gdvF9mtjUcwQh_vfS.push_vector(J_lLqJEDYwjlzcPdoG7); 
 break;
 case 2: 
 HDATZ69oV1ySvqBs.setValid(false);
 break;
 }
 }
 }
 }
 break;
 }
 local Bv2fHH6lHFh4A1gnO7qAk5E = oADXyo3ILmxtOrOdKeZZq.sq_GetDelaySum(); 
 oADXyo3ILmxtOrOdKeZZq.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0); 
 local dvU_zVVE4K = oADXyo3ILmxtOrOdKeZZq.sq_GetDelaySum(); 
 local OCMv4xNvddlheP8YXt = Bv2fHH6lHFh4A1gnO7qAk5E.tofloat() / dvU_zVVE4K.tofloat() * 100.0; 
 switch(rNHZ5aVPODjmz)
 {
 case 1:
 oADXyo3ILmxtOrOdKeZZq.sq_SetCurrentAttackInfo(31);
 local nKZ08o97MXLF0LkP = oADXyo3ILmxtOrOdKeZZq.sq_GetBonusRateWithPassive(237, 237, 2, 1.0); 
 oADXyo3ILmxtOrOdKeZZq.sq_SetCurrentAttackBonusRate(nKZ08o97MXLF0LkP); 
 CreateAniRate(oADXyo3ILmxtOrOdKeZZq, "character/gunner/effect/animation/atkillpoint/finish/killpointfinishd_bullet_c.ani", ENUM_DRAWLAYER_NORMAL, oADXyo3ILmxtOrOdKeZZq.getXPos(), oADXyo3ILmxtOrOdKeZZq.getYPos(), oADXyo3ILmxtOrOdKeZZq.getZPos(), false, OCMv4xNvddlheP8YXt); 
 break;
 }
} 

function onKeyFrameFlag_atgunner_killpoint(ODrspvYx5MUbxp3KXXi, IezPVcsYvxh7A)
{
 if(!ODrspvYx5MUbxp3KXXi) return false;
 local OV2Q0jc8dSp9n20E = ODrspvYx5MUbxp3KXXi.getSkillSubState(); 
 switch(OV2Q0jc8dSp9n20E)
 {
 case 0:
 if(IezPVcsYvxh7A == 1)
 {
 local l6p2lpchHw_NEQnF2U8 = ODrspvYx5MUbxp3KXXi.getVar().get_vector(0); 
 local kXKAxKOjFBpTXH41kheEnq = sq_GetSkillLevel(ODrspvYx5MUbxp3KXXi, 237); 
 local dvwSqSfcfZHp = ODrspvYx5MUbxp3KXXi.sq_GetLevelData(237, 1, kXKAxKOjFBpTXH41kheEnq); 
 local fmnWW5RLZd3FcbsT = ODrspvYx5MUbxp3KXXi.sq_GetLevelData(237, 4, kXKAxKOjFBpTXH41kheEnq) / -1; 
 local WuqOEtp6nYjkBS5cE = ODrspvYx5MUbxp3KXXi.sq_GetLevelData(237, 5, kXKAxKOjFBpTXH41kheEnq); 
 local XKW1lbpf97NYt1LXdn9AR = ODrspvYx5MUbxp3KXXi.sq_GetLevelData(237, 6, kXKAxKOjFBpTXH41kheEnq); 
 local dc3kekVWMoZSzF = ODrspvYx5MUbxp3KXXi.sq_GetLevelData(237, 7, kXKAxKOjFBpTXH41kheEnq); 
 local QGRgt5w8ZjgQ2hbdZ8nE5N1 = ODrspvYx5MUbxp3KXXi.sq_GetLevelData(237, 8, kXKAxKOjFBpTXH41kheEnq); 
 local Xkm9UFxm41LSvs = ODrspvYx5MUbxp3KXXi.getDirection(); 
 local f3fw0HLXekB0RVwD = ODrspvYx5MUbxp3KXXi.getXPos(); 
 local HovGv2z6BHv1bFJbPo = ODrspvYx5MUbxp3KXXi.getYPos(); 
 local DF0v1ndPADKTZyaNrH = ODrspvYx5MUbxp3KXXi.getZPos(); 
 local D1X54_dZYY6zCTR3SFD = 450; 
 local fqpAa5wRDrHEO7mnH = 100; 
 local BvUUO3RpB0uemwksdmOq = 140; 
 local MGP6lJcSF44r3JuHQlu60 = ODrspvYx5MUbxp3KXXi.getObjectManager(); 
 local pdQTTqdD0KYC = MGP6lJcSF44r3JuHQlu60.getCollisionObjectNumber(); 
 for(local SBmut7n9VeMcsqbD6l3SHRdv = 0; SBmut7n9VeMcsqbD6l3SHRdv < pdQTTqdD0KYC; SBmut7n9VeMcsqbD6l3SHRdv++)
 {
 local aah14tm7LnZ1e1Mz0yqW9 = MGP6lJcSF44r3JuHQlu60.getCollisionObject(SBmut7n9VeMcsqbD6l3SHRdv); 
 
 if(!ODrspvYx5MUbxp3KXXi.isEnemy(aah14tm7LnZ1e1Mz0yqW9) || !aah14tm7LnZ1e1Mz0yqW9.isObjectType(OBJECTTYPE_ACTIVE) || !aah14tm7LnZ1e1Mz0yqW9.isInDamagableState(ODrspvYx5MUbxp3KXXi)
 || sq_GetCNRDObjectToActiveObject(aah14tm7LnZ1e1Mz0yqW9).isDead()) continue;
 local qJ_XhWw95Q2l2F = sq_GetXPos(aah14tm7LnZ1e1Mz0yqW9); 
 
 if(Xkm9UFxm41LSvs == ENUM_DIRECTION_LEFT && qJ_XhWw95Q2l2F > f3fw0HLXekB0RVwD
 || Xkm9UFxm41LSvs == ENUM_DIRECTION_RIGHT && qJ_XhWw95Q2l2F < f3fw0HLXekB0RVwD)continue;
 local uLNjfzETSXj4 = sq_GetYPos(aah14tm7LnZ1e1Mz0yqW9); 
 local KfeVYXam2qJNBO = sq_GetZPos(aah14tm7LnZ1e1Mz0yqW9); 
 if(sq_Abs(f3fw0HLXekB0RVwD - qJ_XhWw95Q2l2F) <= D1X54_dZYY6zCTR3SFD
 && sq_Abs(HovGv2z6BHv1bFJbPo - uLNjfzETSXj4) <= fqpAa5wRDrHEO7mnH
 && sq_Abs(DF0v1ndPADKTZyaNrH - KfeVYXam2qJNBO) <= BvUUO3RpB0uemwksdmOq) 
 {
 if(l6p2lpchHw_NEQnF2U8 <= 0) break;
 else l6p2lpchHw_NEQnF2U8 -= 1; 
 local hMS_waZgewDJgwyM = CNSquirrelAppendage.sq_AppendAppendage(aah14tm7LnZ1e1Mz0yqW9, ODrspvYx5MUbxp3KXXi, 237, true, "character/atgunner/killpoint/ap_killpoint.nut", true);
 hMS_waZgewDJgwyM.getVar().clear_vector();
 local WCaPg6G9zW5I8zkS9dD9kZNC = hMS_waZgewDJgwyM.getVar(); 
 WCaPg6G9zW5I8zkS9dD9kZNC.push_vector(WuqOEtp6nYjkBS5cE);
 WCaPg6G9zW5I8zkS9dD9kZNC.push_vector(XKW1lbpf97NYt1LXdn9AR);
 WCaPg6G9zW5I8zkS9dD9kZNC.push_vector(dc3kekVWMoZSzF);
 WCaPg6G9zW5I8zkS9dD9kZNC.push_vector(QGRgt5w8ZjgQ2hbdZ8nE5N1);
 WCaPg6G9zW5I8zkS9dD9kZNC.push_vector(dvwSqSfcfZHp); 
 if(sq_IsHoldable(ODrspvYx5MUbxp3KXXi, aah14tm7LnZ1e1Mz0yqW9))
 {
 sq_HoldAndDelayDie(aah14tm7LnZ1e1Mz0yqW9, ODrspvYx5MUbxp3KXXi, true, true, false, 0, 0, ENUM_DIRECTION_NEUTRAL, hMS_waZgewDJgwyM); 
 WCaPg6G9zW5I8zkS9dD9kZNC.setBool(0, true); 
 }
 else
 {
 sq_sendSetActiveStatusPacket(aah14tm7LnZ1e1Mz0yqW9, ODrspvYx5MUbxp3KXXi, ACTIVESTATUS_SLOW, 100.0, WuqOEtp6nYjkBS5cE, false, dvwSqSfcfZHp, 0, fmnWW5RLZd3FcbsT); 
 WCaPg6G9zW5I8zkS9dD9kZNC.setBool(0, false); 
 }
 }
 }
 }
 break;
 case 1:
 if(IezPVcsYvxh7A == 2)
 {
 ODrspvYx5MUbxp3KXXi.sq_SetCurrentAttackInfo(32);
 local _SZ3VfFwKj1gAXZBKPAGO4Oa = ODrspvYx5MUbxp3KXXi.sq_GetBonusRateWithPassive(237, 237, 3, 1.0); 
 ODrspvYx5MUbxp3KXXi.sq_SetCurrentAttackBonusRate(_SZ3VfFwKj1gAXZBKPAGO4Oa); 
 }
 local l6p2lpchHw_NEQnF2U8 = ODrspvYx5MUbxp3KXXi.getVar().size_vector(); 
 if(l6p2lpchHw_NEQnF2U8 > 0)
 {
 local tbrpvo2hdhlXeWqt8iC2nMU = ODrspvYx5MUbxp3KXXi.getVar(); 
 for(local SBmut7n9VeMcsqbD6l3SHRdv = 0; SBmut7n9VeMcsqbD6l3SHRdv < l6p2lpchHw_NEQnF2U8; SBmut7n9VeMcsqbD6l3SHRdv += 2)
 {
 local LfWTNzPuzxpd6KI0w_ya = sq_GetCNRDObjectToActiveObject(sq_GetObject(ODrspvYx5MUbxp3KXXi, tbrpvo2hdhlXeWqt8iC2nMU.get_vector(SBmut7n9VeMcsqbD6l3SHRdv), tbrpvo2hdhlXeWqt8iC2nMU.get_vector(SBmut7n9VeMcsqbD6l3SHRdv + 1))); 
 if(LfWTNzPuzxpd6KI0w_ya && !LfWTNzPuzxpd6KI0w_ya.isDead()) 
 {
 local cNfwJ_OT48fRyK9 = false; 
 local AsasAb0rYYsJc0FjWfkh = sq_GetHeightObject(LfWTNzPuzxpd6KI0w_ya); 
 switch(IezPVcsYvxh7A)
 {
 case 1:
 if(CNSquirrelAppendage.sq_IsAppendAppendage(LfWTNzPuzxpd6KI0w_ya, "character/atgunner/killpoint/ap_killpoint.nut"))
 {
 AsasAb0rYYsJc0FjWfkh = AsasAb0rYYsJc0FjWfkh / 2 + sq_getRandom(0, (AsasAb0rYYsJc0FjWfkh * 0.25).tointeger()); 
 if(ODrspvYx5MUbxp3KXXi.sq_IsMyControlObject())
 sq_SendHitObjectPacketWithNoStuck(ODrspvYx5MUbxp3KXXi, LfWTNzPuzxpd6KI0w_ya, 0, 0, AsasAb0rYYsJc0FjWfkh); 
 cNfwJ_OT48fRyK9 = true; 
 }
 break;
 case 2:
 if(CNSquirrelAppendage.sq_IsAppendAppendage(LfWTNzPuzxpd6KI0w_ya, "character/atgunner/killpoint/ap_killpoint.nut"))
 CNSquirrelAppendage.sq_RemoveAppendage(LfWTNzPuzxpd6KI0w_ya, "character/atgunner/killpoint/ap_killpoint.nut"); 
 break;
 case 3:
 if(ODrspvYx5MUbxp3KXXi.sq_IsMyControlObject())
 sq_SendHitObjectPacketWithNoStuck(ODrspvYx5MUbxp3KXXi, LfWTNzPuzxpd6KI0w_ya, 0, 0, AsasAb0rYYsJc0FjWfkh); 
 cNfwJ_OT48fRyK9 = true; 
 break;
 }
 if(!cNfwJ_OT48fRyK9) continue; 
 sq_SetMyShake(ODrspvYx5MUbxp3KXXi, 2, 100); 
 local n8x1RgsBAK_vi = sq_ToRadian(sq_getRandom(0, 360).tofloat());
 local OV_ELB9vwTZ94dB2L = sq_CreateAnimation("", "character/gunner/effect/animation/atkillpoint/hiteffect/killpointatkeff_b.ani"); 
 sq_SetfRotateAngle(OV_ELB9vwTZ94dB2L, n8x1RgsBAK_vi); 
 local FcrrKa79UiVGsprc = ODrspvYx5MUbxp3KXXi.sq_GetAutoLayerWorkAnimation(OV_ELB9vwTZ94dB2L, "A"); 
 if(FcrrKa79UiVGsprc) sq_SetfRotateAngle(FcrrKa79UiVGsprc, n8x1RgsBAK_vi); 
 OV_ELB9vwTZ94dB2L.addLayerAnimation(1, sq_CreateAnimation("", "character/gunner/effect/animation/atkillpoint/hiteffect/hiteffect_1.ani"), true); 
 local QEDQz4NBJ8z = sq_getRandom(20, 100).tofloat() / 100.0;
 OV_ELB9vwTZ94dB2L.setImageRateFromOriginal(QEDQz4NBJ8z, QEDQz4NBJ8z); 
 OV_ELB9vwTZ94dB2L.setAutoLayerWorkAnimationAddSizeRate(QEDQz4NBJ8z); 
 local __IMQFFok5YxPi = sq_CreatePooledObject(OV_ELB9vwTZ94dB2L, true); 
 sq_SetCurrentDirection(__IMQFFok5YxPi, ODrspvYx5MUbxp3KXXi.getDirection()); 
 __IMQFFok5YxPi.setCurrentPos(sq_GetXPos(LfWTNzPuzxpd6KI0w_ya), sq_GetYPos(LfWTNzPuzxpd6KI0w_ya) + 1, sq_GetZPos(LfWTNzPuzxpd6KI0w_ya) + AsasAb0rYYsJc0FjWfkh); 
 __IMQFFok5YxPi = sq_SetEnumDrawLayer(__IMQFFok5YxPi, ENUM_DRAWLAYER_NORMAL); 
 sq_AddObject(ODrspvYx5MUbxp3KXXi, __IMQFFok5YxPi, OBJECTTYPE_DRAWONLY, false); 
 }
 }
 }
 break;
 }
 return true;
} 

 
function onEndCurrentAni_atgunner_killpoint(KoPnA8lR9Nw5l0KPVbxMQ6ez)
{
 if(!KoPnA8lR9Nw5l0KPVbxMQ6ez) return;
 if(!KoPnA8lR9Nw5l0KPVbxMQ6ez.sq_IsMyControlObject()) return;
 KoPnA8lR9Nw5l0KPVbxMQ6ez.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
} 

function onEndState_atgunner_killpoint(KoPnA8lR9Nw5l0KPVbxMQ6ez, WoXyElZ293mQK5O0MOXXatP)
{
 if(!KoPnA8lR9Nw5l0KPVbxMQ6ez) return;
 if(WoXyElZ293mQK5O0MOXXatP != 237)
 {
 local mPEBnjP6yRtKngnvo3o = KoPnA8lR9Nw5l0KPVbxMQ6ez.getVar().size_vector(); 
 if(mPEBnjP6yRtKngnvo3o > 0)
 {
 local g94kFNEgoQWiniSZJBxPszst = KoPnA8lR9Nw5l0KPVbxMQ6ez.getVar(); 
 for(local ZlQqgEiVFssYw9WHaGY2Bo = 0; ZlQqgEiVFssYw9WHaGY2Bo < mPEBnjP6yRtKngnvo3o; ZlQqgEiVFssYw9WHaGY2Bo += 2)
 {
 local OYUsmQEGHJmVc1 = sq_GetObject(KoPnA8lR9Nw5l0KPVbxMQ6ez, g94kFNEgoQWiniSZJBxPszst.get_vector(ZlQqgEiVFssYw9WHaGY2Bo), g94kFNEgoQWiniSZJBxPszst.get_vector(ZlQqgEiVFssYw9WHaGY2Bo + 1)); 
 if(!OYUsmQEGHJmVc1) continue;
 if(CNSquirrelAppendage.sq_IsAppendAppendage(OYUsmQEGHJmVc1, "character/atgunner/killpoint/ap_killpoint.nut"))
 CNSquirrelAppendage.sq_RemoveAppendage(OYUsmQEGHJmVc1, "character/atgunner/killpoint/ap_killpoint.nut"); 
 }
 }
 }
} 


