function checkExecutableSkill_atovercharge(obj)
{
	if (!obj) return false;
	local b_useskill = obj.sq_IsUseSkill(252);
	if (b_useskill)
	{
		obj.getVar("atgunner_charge").setBool(0, true);
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(56);
		obj.sq_AddSetStatePacket(32, STATE_PRIORITY_USER, true);
		return true;
	}
	return false;
}

function checkCommandEnable_atovercharge(obj)
{
	if (!obj) return false;
	return true;
}

function onEndState_atovercharge(obj, new_state)
{
	if (!obj) return;
	local pooledObj = obj.getVar("atgunner_element").get_obj_vector(0);
	if(pooledObj)
	{
		pooledObj.setValid(false);
	}
	sq_EndDrawCastGauge(obj);
}

function onSetState_atovercharge(obj, state, datas, isResetTimer)
{
	if (!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	local catsT = obj.sq_GetVectorData(datas, 1);
	obj.setSkillSubState(substate);

	switch (substate)
	{
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("OVERCHARGE_READY");
			local Ani = obj.sq_GetBuffAni();
			obj.setCurrentAnimation(Ani);
			local T = sq_GetFrameStartTime(Ani, 5);
			local Rat = T.tofloat() / catsT.tofloat();
			obj.sq_SetStaticSpeedInfo(4, 4, 1000, 1000, Rat, Rat);
			sq_StartDrawCastGauge(obj, T, true);
			local posX = obj.getXPos();
			local posY = obj.getYPos();
			local ani = sq_CreateAnimation("", "sqr/character/atgunner/overcharge/overchange.ani");
			ani.setSpeedRate(100.0);
			ani.setImageRateFromOriginal(1.0, 1.0);
			sq_SetfRotateAngle(ani, sq_ToRadian(0.0));
			local pooledObj = sq_CreatePooledObject(ani, false);
			pooledObj.setCurrentPos(posX, posY + 50, 0);
			sq_moveWithParent(obj, pooledObj);
			sq_AddObject(obj, pooledObj, OBJECTTYPE_DRAWONLY, false);
			obj.getVar("atgunner_element").clear_obj_vector();
			obj.getVar("atgunner_element").push_obj_vector(pooledObj);
			obj.getVar("flag").clear_vector();
			obj.getVar("flag").push_vector(T);
			obj.getVar("flag").push_vector(0);
			obj.getVar("overcharge").setInt(0, -1);
		break;
	}
}

function onProcCon_atovercharge(obj)
{
	if (!obj) return;
	local substate = obj.getSkillSubState();
	local pAni = sq_GetCurrentAnimation(obj);
	local currentT = sq_GetCurrentTime(pAni);
	local Uparrow = sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL);
	local Leftarrow = sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL);
	local Downarrow = sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL);
	local Rightarrow = sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL);
	local element = -1;
	if(Uparrow) element = 1;
	if(Downarrow) element = 3;
	if(Leftarrow) element = 0;
	if(Rightarrow) element = 4;
	if(currentT >= obj.getVar("flag").get_vector(0))
	{
		if((Uparrow || Leftarrow || Downarrow || Rightarrow) && obj.getVar("flag").get_vector(1) == 0)
		{
			obj.getVar("overcharge").setInt(0, element);
			obj.getVar("flag").set_vector(1, 1);
		}
		local isDownKey = sq_IsKey(7, ENUM_SUBKEY_TYPE_ALL);
		if (isDownKey && obj.getVar("flag").get_vector(1) == 0) 
		{
			obj.getVar("overcharge").setInt(0, -1);
			if(CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atgunner/overcharge/ap_overcharge.nut"))
				CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/atgunner/overcharge/ap_overcharge.nut");
			obj.getVar("flag").set_vector(1, 2);
		}
		if(obj.getVar("flag").get_vector(1) != 0)
		{
			if(obj.getVar("flag").get_vector(1) == 1)
			{
				local T = obj.sq_GetLevelData(252, 0, sq_GetSkillLevel(obj, 252));
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, "character/atgunner/overcharge/ap_overcharge.nut", false);
				appendage.sq_SetValidTime(T);
				appendage.setEnableIsBuff(true);
				appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 252, sq_GetSkillLevel(obj, 252));
				CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
				appendage.setBuffIconImage(116);
			}
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
	}
}


function onSetState_atgunner_charge(obj, state, datas, isResetTimer)
{
	if (!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	if (obj.getVar("atgunner_charge").getBool(0))
	{
		obj.sq_SetStaticSpeedInfo(2, 2, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 100.0, 100.0);
	}
}

function onEndState_atgunner_charge(obj, newState)
{
	if (!obj) return;
	local SubState = obj.getSkillSubState();
	switch (SubState)
	{
		case 56:
			if (!obj.getVar("atgunner_charge").getBool(0) && newState == 0) break;
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(57);
			obj.sq_AddSetStatePacket(32, STATE_PRIORITY_USER, true);
		break;
		case 57:
			if (!obj.getVar("atgunner_charge").getBool(0) && newState == 0) break;
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(58);
			obj.sq_AddSetStatePacket(32, STATE_PRIORITY_USER, true);
		break;
		case 58:
			if (!obj.getVar("atgunner_charge").getBool(0) && newState == 0) break;
			local skillLevel = sq_GetSkillLevel(obj, 252);
			local T = sq_GetCastTime(obj, 252, skillLevel);
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(T);
			obj.sq_AddSetStatePacket(252, STATE_PRIORITY_USER, true);
		break;
	}
}
