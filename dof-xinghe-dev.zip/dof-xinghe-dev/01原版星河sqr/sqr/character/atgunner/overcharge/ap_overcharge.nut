function sq_AddFunctionName(appendage)
{
	appendage.sq_AddFunctionName("proc", "proc_appendage_overcharge")
	appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_overcharge")
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_overcharge")
}

function sq_AddEffect(appendage)
{
	if(!appendage)
		return;

}

function onAttackParent_appendage_overcharge(appendage, realAttacker, damager, boundingBox, isStuck)
{
	if(!appendage) return;
	local obj = appendage.getParent();
	local sourceObj = appendage.getSource();
	if(!sourceObj || !obj)
	{
		appendage.setValid(false);
		return;
	}
	local gunner = sq_ObjectToSQRCharacter(obj);
	local element = gunner.getVar("overcharge").getInt(0);
	for(local i = 22001;i < 22016;i+=1)
	{
		local count = gunner.getMyPassiveObjectCount(i);
		if(count > 0)
		{
			for(local countIndex = 0;countIndex < count;countIndex+=1)
			{
				local bullet = gunner.getMyPassiveObject(i,countIndex);
				local id = sq_GetObjectId(realAttacker);
				local bulletid = sq_GetObjectId(bullet);
				if(id == bulletid)
				{
					local centerX = sq_GetCenterXPos(boundingBox);
					local centerZ = sq_GetCenterZPos(boundingBox);
					local posY = damager.getYPos();
					local attackBonus = gunner.sq_GetBonusRateWithPassive(252, -1, 1, 1.0);
					gunner.sq_StartWrite();
					gunner.sq_WriteDword(6);
					gunner.sq_WriteDword(attackBonus);
					gunner.sq_WriteDword(0);
					if(i != 22001 && i != 22004 && i != 22007 && i != 22010 && i != 22013)
					{
						gunner.sq_WriteDword(1);
					}
					else
					{
						gunner.sq_WriteDword(0);
					}
					sq_SendCreatePassiveObjectPacketPos(gunner, 24350, 0, centerX, posY, centerZ);
				}
			}
		}
	}
}

function proc_appendage_overcharge(appendage)
{

	if(!appendage) return;
	local obj = appendage.getParent();
	local sourceObj = appendage.getSource();
	if(!sourceObj || !obj)
	{
		appendage.setValid(false);
		return;
	}
	local gunner = sq_ObjectToSQRCharacter(obj);
	if(gunner)
	{
		for(local i = 22001;i < 22016;i+=1)
		{
			local count = gunner.getMyPassiveObjectCount(i);
			for(local countIndex = 0;countIndex < count;countIndex+=1)
			{
				local bullet = gunner.getMyPassiveObject(i,countIndex);
				local pobullet = sq_GetCNRDObjectToCollisionObject(bullet);
				if(bullet.getZPos() <= 8)
				{
					local attackBonus = gunner.sq_GetBonusRateWithPassive(252, -1, 1, 1.0);
					gunner.sq_StartWrite();
					gunner.sq_WriteDword(6);
					gunner.sq_WriteDword(attackBonus);
					gunner.sq_WriteDword(0);
					if(i != 22001 && i != 22004 && i != 22007 && i != 22010 && i != 22013)
					{
						gunner.sq_WriteDword(1);
					}
					else
					{
						gunner.sq_WriteDword(0);
					}
					sq_SendCreatePassiveObjectPacketPos(gunner, 24350, 0, bullet.getXPos(), bullet.getYPos(), 0);
					sq_SendDestroyPacketPassiveObject(bullet);
				}
			}
		}
	}
}

function onEnd_appendage_overcharge(appendage)
{
	if(!appendage) 
		return;
}
