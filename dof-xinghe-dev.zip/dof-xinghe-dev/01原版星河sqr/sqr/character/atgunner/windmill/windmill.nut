






if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onAfterSetState_atgunner_windmill(mndUu71ONF_tg0O, VSISyKLM7QgJXpWdDKr, a29FmVj6AippQk2V0, iEIfnIAwGTwTlbFtj)
{
 if (!mndUu71ONF_tg0O) return;
 local UCepkDyKu4uluUsiOWGHxl2 = mndUu71ONF_tg0O.sq_GetVectorData(a29FmVj6AippQk2V0, 0); 
 mndUu71ONF_tg0O.getVar().clear_vector(); 
 mndUu71ONF_tg0O.getVar().push_vector(UCepkDyKu4uluUsiOWGHxl2); 
 local uDC6HFvs0qp6oJw = sq_GetSkillLevel(mndUu71ONF_tg0O, 250); 
 if(uDC6HFvs0qp6oJw > 0)
 {
 local iOkYVsgvoqHwkEgqLHwYK92 = mndUu71ONF_tg0O.sq_GetLevelData(250, 0, uDC6HFvs0qp6oJw);
 local RVl6dyMLjZIF0glFg = mndUu71ONF_tg0O.sq_GetLevelData(250, 1, uDC6HFvs0qp6oJw);
 mndUu71ONF_tg0O.sq_SetStaticMoveInfo(0, iOkYVsgvoqHwkEgqLHwYK92, iOkYVsgvoqHwkEgqLHwYK92, true);
 mndUu71ONF_tg0O.sq_SetStaticMoveInfo(1, RVl6dyMLjZIF0glFg, RVl6dyMLjZIF0glFg, true);
 mndUu71ONF_tg0O.sq_SetMoveDirection(mndUu71ONF_tg0O.getDirection(), ENUM_DIRECTION_NEUTRAL); 
 }
} 



function onProcCon_atgunner_windmill(oADXyo3ILmxtOrOdKeZZq)
{
 if (!oADXyo3ILmxtOrOdKeZZq) return;
 local bnjapuFrHFwkCA6Ft3 = oADXyo3ILmxtOrOdKeZZq.getVar().get_vector(0);
 if (bnjapuFrHFwkCA6Ft3 == 3) 
 onProcIsSub_My_atgunner_stylish(oADXyo3ILmxtOrOdKeZZq);
} 
