



function sq_AddFunctionName(appendage)
{
    appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_atgunner_plasmaboost")
    appendage.sq_AddFunctionName("proc", "proc_appendage_atgunner_plasmaboost")
 appendage.sq_AddFunctionName("onDamageParent", "onDamageParent_appendage_atgunner_plasmaboost")
    appendage.sq_AddFunctionName("onStart", "onStart_appendage_atgunner_plasmaboost")
}




function onStart_appendage_atgunner_plasmaboost(Sv3yBtShkKe_tHo3ebi1Mxd)
{
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return;
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_DeleteEffectFront(); 
 Sv3yBtShkKe_tHo3ebi1Mxd.sq_AddEffectFront("character/gunner/effect/animation/plasmaboost/monster/hit_loop.ani"); 
} 

function onDamageParent_appendage_atgunner_plasmaboost(Sv3yBtShkKe_tHo3ebi1Mxd, HlASuPcRLgluXam1rUDJ, aL4NaAntuVr9flx, q8OsQ7Jd2qZMuGoPv)
{
 if(!Sv3yBtShkKe_tHo3ebi1Mxd) return;
 local YQYFBMNhEly7vK = Sv3yBtShkKe_tHo3ebi1Mxd.getSource(); 
 if(!YQYFBMNhEly7vK) return;
 local Web3cF41PV9 = Sv3yBtShkKe_tHo3ebi1Mxd.getParent();
 if(!Web3cF41PV9)
 {
 Sv3yBtShkKe_tHo3ebi1Mxd.setValid(false);
 return;
 }
 if(isSameObject(YQYFBMNhEly7vK, HlASuPcRLgluXam1rUDJ)) 
 {
 local YNlRxR2LCJreAgwvg6CY0Z = Sv3yBtShkKe_tHo3ebi1Mxd.getTimer(); 
 if(YNlRxR2LCJreAgwvg6CY0Z)
 {
 YNlRxR2LCJreAgwvg6CY0Z.Reset(); 
 YNlRxR2LCJreAgwvg6CY0Z.Start(10000, 0); 
 }
 }
} 

function proc_appendage_atgunner_plasmaboost(xIxzVhFgaTI_b)
{
 if(!xIxzVhFgaTI_b) return;
 local hF7Nx9XeNu = xIxzVhFgaTI_b.getParent();
 if(!hF7Nx9XeNu)
 {
 xIxzVhFgaTI_b.setValid(false);
 return;
 }
 if(xIxzVhFgaTI_b.getVar().size_vector() > 0)
 if(xIxzVhFgaTI_b.getTimer().Get() >= xIxzVhFgaTI_b.getVar().get_vector(0)) 
 {
 xIxzVhFgaTI_b.setValid(false);
 return;
 }
} 

function onEnd_appendage_atgunner_plasmaboost(xIxzVhFgaTI_b)
{
 if(!xIxzVhFgaTI_b) return;
 local hF7Nx9XeNu = xIxzVhFgaTI_b.getParent();
 if(!hF7Nx9XeNu)
 {
 xIxzVhFgaTI_b.setValid(false);
 return;
 }
 local aTq9RP3uN9c = sq_CreateAnimation("", "character/gunner/effect/animation/plasmaboost/monster/hit_end.ani"); 
 local rYoYJQilT7T4wBwxzdeAr = sq_CreatePooledObject(aTq9RP3uN9c, true); 
 sq_SetCurrentDirection(rYoYJQilT7T4wBwxzdeAr, sq_GetDirection(hF7Nx9XeNu)); 
 rYoYJQilT7T4wBwxzdeAr.setCurrentPos(sq_GetXPos(hF7Nx9XeNu), sq_GetYPos(hF7Nx9XeNu) + 1, sq_GetZPos(hF7Nx9XeNu)); 
 rYoYJQilT7T4wBwxzdeAr = sq_SetEnumDrawLayer(rYoYJQilT7T4wBwxzdeAr, ENUM_DRAWLAYER_NORMAL); 
 sq_AddObject(hF7Nx9XeNu, rYoYJQilT7T4wBwxzdeAr, OBJECTTYPE_DRAWONLY, false); 
 sq_moveWithParent(hF7Nx9XeNu, rYoYJQilT7T4wBwxzdeAr); 
} 

