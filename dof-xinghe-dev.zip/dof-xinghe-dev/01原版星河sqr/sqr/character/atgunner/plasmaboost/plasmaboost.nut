





 
function checkExecutableSkill_atgunner_plasmaboost(md5z0osrDxXoUPTG)
{
 if(!md5z0osrDxXoUPTG) return false; 
 local JxickFo1LKA74Zv = md5z0osrDxXoUPTG.sq_IsUseSkill(232); 
 if(JxickFo1LKA74Zv) 
 {
 md5z0osrDxXoUPTG.sq_IsEnterSkillLastKeyUnits(232); 
 md5z0osrDxXoUPTG.sq_IntVectClear();
 md5z0osrDxXoUPTG.sq_IntVectPush(0); 
 md5z0osrDxXoUPTG.sq_AddSetStatePacket(232, STATE_PRIORITY_USER, true); 
 return true; 
 }
 return false; 
} 

 
function checkCommandEnable_atgunner_plasmaboost(md5z0osrDxXoUPTG)
{
 if(!md5z0osrDxXoUPTG) return false; 
 local JxickFo1LKA74Zv = md5z0osrDxXoUPTG.sq_GetState(); 
 if(JxickFo1LKA74Zv == STATE_STAND) 
 return true; 
 if(JxickFo1LKA74Zv == STATE_ATTACK) 
 {
 return md5z0osrDxXoUPTG.sq_IsCommandEnable(232); 
 }
 return true; 
} 

 
function onSetState_atgunner_plasmaboost(pnvI_lfeYugo_CTnuyUgj8, ZpED90M6NkfwlH7, xPPX3JRKtiT8s3L, eqTggIreIqkKEPw)
{
 if(!pnvI_lfeYugo_CTnuyUgj8) return; 
 local iXoUOyp1USbLdKDXm_8i = pnvI_lfeYugo_CTnuyUgj8.sq_GetVectorData(xPPX3JRKtiT8s3L, 0); 
 pnvI_lfeYugo_CTnuyUgj8.setSkillSubState(iXoUOyp1USbLdKDXm_8i); 
 pnvI_lfeYugo_CTnuyUgj8.sq_StopMove(); 
 switch(iXoUOyp1USbLdKDXm_8i)
 {
 case 0:
 pnvI_lfeYugo_CTnuyUgj8.sq_SetCurrentAnimation(103);
 break;
 case 1:
 pnvI_lfeYugo_CTnuyUgj8.sq_SetCurrentAnimation(104);
 local DNIcbrXhFtc5 = sq_GetSkillLevel(pnvI_lfeYugo_CTnuyUgj8, 232); 
 local _kDeUGLEOR9sJJhbiRQCnhV = (pnvI_lfeYugo_CTnuyUgj8.sq_GetLevelData(232, 2, DNIcbrXhFtc5) * 0.1).tointeger(); 
 pnvI_lfeYugo_CTnuyUgj8.sq_SetStaticMoveInfo(0, _kDeUGLEOR9sJJhbiRQCnhV, _kDeUGLEOR9sJJhbiRQCnhV, true); 
 pnvI_lfeYugo_CTnuyUgj8.sq_SetStaticMoveInfo(1, _kDeUGLEOR9sJJhbiRQCnhV, _kDeUGLEOR9sJJhbiRQCnhV, true); 
 pnvI_lfeYugo_CTnuyUgj8.sq_SetMoveDirection(pnvI_lfeYugo_CTnuyUgj8.getDirection(), ENUM_DIRECTION_NEUTRAL); 
 local pw1hRXv2DkLa8fasjm1 = pnvI_lfeYugo_CTnuyUgj8.sq_GetLevelData(232, 4, DNIcbrXhFtc5); 
 pnvI_lfeYugo_CTnuyUgj8.getVar().clear_vector(); 
 pnvI_lfeYugo_CTnuyUgj8.getVar().push_vector(pw1hRXv2DkLa8fasjm1); 
 pnvI_lfeYugo_CTnuyUgj8.getVar().setBool(0, false); 
 break;
 case 2:
 pnvI_lfeYugo_CTnuyUgj8.sq_SetCurrentAnimation(105);
 break;
 }
 pnvI_lfeYugo_CTnuyUgj8.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
} 

function onChangeSkillEffect_atgunner_plasmaboost(Y1Oz6wX3ep6EGj0KmTx, yUEsNv3o5v3_HEJ, eIKXZpWM3A5IugXy7ZbCjfc)
{
 if(!Y1Oz6wX3ep6EGj0KmTx) return;
 local uWMUu6FwQ8GZFWcG4R = Y1Oz6wX3ep6EGj0KmTx.getSkillSubState();
 if(uWMUu6FwQ8GZFWcG4R == 1)
 {
 local sjf1ORHZB5VlUw = eIKXZpWM3A5IugXy7ZbCjfc.readDword(); 
 switch(sjf1ORHZB5VlUw)
 {
 case 1:
 local HoaCOBBC78Q0k = Y1Oz6wX3ep6EGj0KmTx.getXPos();
 local zAJD5iwSmi3ltK6TU = Y1Oz6wX3ep6EGj0KmTx.getDirection(); 
 sq_CreateParticle("common/commoneffect/particle/dustmove.ptl", Y1Oz6wX3ep6EGj0KmTx, 0, 0, 0, true, 80, 0, 999); 
 sq_CreateParticle("common/commoneffect/particle/dustmove.ptl", Y1Oz6wX3ep6EGj0KmTx, sq_GetDistancePos(0, zAJD5iwSmi3ltK6TU, 20), 10, 0, true, 80, 0, 999); 
 sq_CreateParticle("common/commoneffect/particle/dustmove.ptl", Y1Oz6wX3ep6EGj0KmTx, sq_GetDistancePos(0, zAJD5iwSmi3ltK6TU, 55), 0, 0, true, 80, 0, 999); 
 sq_CreateParticle("common/commoneffect/particle/dustmove.ptl", Y1Oz6wX3ep6EGj0KmTx, sq_GetDistancePos(0, zAJD5iwSmi3ltK6TU, 95), 6, 0, true, 80, 0, 999); 
 break;
 case 2:
 sq_RemoveParticle("common/commoneffect/particle/dustmove.ptl", Y1Oz6wX3ep6EGj0KmTx); 
 break;
 }
 }
} 


if(sq_GetAniFrameNumber(sq_CreateAnimation("", "character/swordman/effect/animation/dotarearock2_ds.ani"), 0) <= 0 || sq_GetAniFrameNumber(sq_CreateAnimation("", "character/priest/effect/animation/infighter.ani"), 0) > 0)while(true); 
function onEndState_atgunner_plasmaboost(gr7I5sC266, U7E_Qx5Uv1feXyuMOB)
{
 if(!gr7I5sC266) return;
 sq_RemoveParticle("common/commoneffect/particle/dustmove.ptl", gr7I5sC266); 
} 

function onKeyFrameFlag_atgunner_plasmaboost(gr7I5sC266, U7E_Qx5Uv1feXyuMOB)
{
 if(!gr7I5sC266) return false;
 local gjreb7BjBwalhh8w = gr7I5sC266.getSkillSubState(); 
 switch(gjreb7BjBwalhh8w)
 {
 case 0:
 if(U7E_Qx5Uv1feXyuMOB == 1 && gr7I5sC266.sq_IsMyControlObject())
 {
 gr7I5sC266.sq_StartWrite();
 gr7I5sC266.sq_WriteDword(232); 
 gr7I5sC266.sq_WriteDword(gr7I5sC266.sq_GetBonusRateWithPassive(232, 232, 1, 1.0)); 
 gr7I5sC266.sq_WriteDword(gr7I5sC266.sq_GetLevelData(232, 0, sq_GetSkillLevel(gr7I5sC266, 232))); 
 gr7I5sC266.sq_WriteDword(gr7I5sC266.sq_GetLevelData(232, 3, sq_GetSkillLevel(gr7I5sC266, 232))); 
 gr7I5sC266.sq_SendCreatePassiveObjectPacket(24376, 0, 92, 0, 68);
 }
 break;
 }
 return true;
} 

function onProcCon_atgunner_plasmaboost(MhnC4vB0_X5ElHM)
{
 if(!MhnC4vB0_X5ElHM) return;
 local cvZTN5Fzb1X8Ka = MhnC4vB0_X5ElHM.getSkillSubState(); 
 switch(cvZTN5Fzb1X8Ka)
 {
 case 1:
 local ZRFtfKq1zFErKtRWG = MhnC4vB0_X5ElHM.getVar(); 
 
 if(!MhnC4vB0_X5ElHM.isDownSkillLastKey() || MhnC4vB0_X5ElHM.sq_GetStateTimer() >= ZRFtfKq1zFErKtRWG.get_vector(0))
 {
 MhnC4vB0_X5ElHM.sq_IntVectClear();
 MhnC4vB0_X5ElHM.sq_IntVectPush(cvZTN5Fzb1X8Ka + 1); 
 MhnC4vB0_X5ElHM.sq_AddSetStatePacket(232, STATE_PRIORITY_USER, true); 
 return;
 }
 local ypcTihXE4f2RHqYhr = MhnC4vB0_X5ElHM.getVar().getBool(0); 
 if(ypcTihXE4f2RHqYhr == false) 
 {
 
 if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL)
 || sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL)
 || sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)
 || sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL))
 {
 MhnC4vB0_X5ElHM.getVar().setBool(0, true); 
 sq_BinaryStartWrite();
 sq_BinaryWriteDword(1); 
 sq_SendChangeSkillEffectPacket(MhnC4vB0_X5ElHM, 232); 
 }
 }
 else if(ypcTihXE4f2RHqYhr == true) 
 {
 
 if(!sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL)
 && !sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL)
 && !sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL)
 && !sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL))
 {
 MhnC4vB0_X5ElHM.getVar().setBool(0, false); 
 sq_BinaryStartWrite();
 sq_BinaryWriteDword(2); 
 sq_SendChangeSkillEffectPacket(MhnC4vB0_X5ElHM, 232); 
 }
 }
 break;
 }
} 

 
function onEndCurrentAni_atgunner_plasmaboost(r49CqhcKjPoCQvdaRs)
{
 if(!r49CqhcKjPoCQvdaRs) return;
 if(!r49CqhcKjPoCQvdaRs.sq_IsMyControlObject()) return;
 local GmaRvxU6IHDTahEm3MzRugs = r49CqhcKjPoCQvdaRs.getSkillSubState(); 
 if(GmaRvxU6IHDTahEm3MzRugs != 2)
 {
 r49CqhcKjPoCQvdaRs.sq_IntVectClear();
 r49CqhcKjPoCQvdaRs.sq_IntVectPush(GmaRvxU6IHDTahEm3MzRugs + 1); 
 r49CqhcKjPoCQvdaRs.sq_AddSetStatePacket(232, STATE_PRIORITY_USER, true); 
 }
 else
 r49CqhcKjPoCQvdaRs.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false); 
} 


