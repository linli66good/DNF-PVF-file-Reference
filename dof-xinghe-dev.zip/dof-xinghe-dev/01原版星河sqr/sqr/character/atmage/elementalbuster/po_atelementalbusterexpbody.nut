

/************************************************
************************************************

************************************************
************************************************/
function setPower_po_ATElementalBuster(obj, power)
{
	local attackInfo = sq_GetCurrentAttackInfo(obj);
	if (attackInfo)
		sq_SetCurrentAttackBonusRate(attackInfo, power);
		
	
}

function setSizeRate_po_ATElementalBuster(obj, sizeRate)
{
	local animation = sq_GetCurrentAnimation(obj);
	if (!animation) return;
	
	local sizeRate = sizeRate.tofloat() / 100.0;
	animation.setImageRateFromOriginal(sizeRate, sizeRate);
	animation.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	sq_SetAttackBoundingBoxSizeRate(animation, sizeRate, sizeRate, sizeRate);
}

function setCustomData_po_ATElementalBusterExpBodyFire(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpBodyWater(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpBodyLight(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpBodyDark(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function onEndCurrentAni_po_ATElementalBuster(obj)
{
	if (!obj) return;	
	if (obj.isMyControlObject()) {
		sq_SendDestroyPacketPassiveObject(obj);
	}
}

function onEndCurrentAni_po_ATElementalBusterExpBodyFire(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}
function onEndCurrentAni_po_ATElementalBusterExpBodyWater(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}
function onEndCurrentAni_po_ATElementalBusterExpBodyLight(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}
function onEndCurrentAni_po_ATElementalBusterExpBodyDark(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}



/************************************************
************************************************

************************************************
************************************************/
function setCustomData_po_ATElementalBusterExpBigFire(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpBigWater(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpBigLight(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpBigDark(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function onEndCurrentAni_po_ATElementalBusterExpBigFire(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}

function onEndCurrentAni_po_ATElementalBusterExpBigWater(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}

function onEndCurrentAni_po_ATElementalBusterExpBigLight(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}

function onEndCurrentAni_po_ATElementalBusterExpBigDark(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}






/************************************************
************************************************

************************************************
************************************************/
function setCustomData_po_ATElementalBusterExpSmallFire(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpSmallWater(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpSmallLight(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function setCustomData_po_ATElementalBusterExpSmallDark(obj, receiveData)
{	
	if (!obj) return;
	local power = receiveData.readDword();
	setPower_po_ATElementalBuster(obj, power);
	
	local sizeRate = receiveData.readWord();
	setSizeRate_po_ATElementalBuster(obj, sizeRate);
}

function onEndCurrentAni_po_ATElementalBusterExpSmallFire(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}

function onEndCurrentAni_po_ATElementalBusterExpSmallWater(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}

function onEndCurrentAni_po_ATElementalBusterExpSmallLight(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}

function onEndCurrentAni_po_ATElementalBusterExpSmallDark(obj)
{	
	onEndCurrentAni_po_ATElementalBuster(obj);
}

