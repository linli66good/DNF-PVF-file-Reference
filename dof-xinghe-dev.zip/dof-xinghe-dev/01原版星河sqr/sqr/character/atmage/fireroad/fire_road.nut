
function checkExecutableSkill_FireRoad(obj)
{
	if (!obj) return false;

	local isUseSkill = obj.sq_IsUseSkill(SKILL_FIRE_ROAD);
	if (isUseSkill) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);	
		obj.sq_AddSetStatePacket(STATE_FIRE_ROAD, STATE_PRIORITY_USER, true);
		return true;
	}
	return false;

}

function checkCommandEnable_FireRoad(obj)
{
	if(!obj)
		return false;
	local state = obj.sq_GetState();
		
	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(SKILL_FIRE_ROAD); 
	}
		
	return true;
}

function onEndState_FireRoad(obj, state)
{
	
	sq_EndDrawCastGauge(obj);
}


function onSetState_FireRoad(obj, state, datas, isResetTimer)
{
	if (!obj) return;

	obj.sq_StopMove();
	
	
	local subState = obj.sq_GetVectorData(datas, 0);	
	obj.sq_SetSkillSubState(obj, subState);
	
	if (subState == 0)
	{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_FIRE_ROAD_CAST1);
		obj.sq_PlaySound("MW_FIREROAD");
		
		
		
		
		local skillLevel = sq_GetSkillLevel(obj, SKILL_FIRE_ROAD);
		local castTime = sq_GetCastTime(obj, SKILL_FIRE_ROAD, skillLevel);
		local animation = sq_GetCurrentAnimation(obj);
		obj.sq_Rewind(animation);
		sq_SetFrameDelayTime(animation, 0, castTime);
		obj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED,
			SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
		sq_StartDrawCastGauge(obj, castTime, true);
		
		addElementalChain_ATMage(obj, ENUM_ELEMENT_FIRE);
	}
	else if (subState == 1)
	{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_FIRE_ROAD_CAST2);
	}
}




function prepareDraw_FireRoad(obj)
{
	if (!obj) return;
}




function onEndCurrentAni_FireRoad(obj)
{
	if (!obj) return;
	
	
	if (obj.sq_GetSkillSubState(obj) == 0) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);	
		obj.sq_AddSetStatePacket(STATE_FIRE_ROAD, STATE_PRIORITY_USER, true);
	}
	else if (obj.sq_GetSkillSubState(obj) == 1) {
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}





function onKeyFrameFlag_FireRoad(obj, flagIndex)
{
	if (!obj) return true;

	local skillSubState = obj.sq_GetSkillSubState(obj);

	if (skillSubState == 0) {

		local skillLevel = obj.sq_GetSkillLevel(SKILL_FIRE_ROAD);	
		local pauseTime = obj.sq_GetIntData(SKILL_FIRE_ROAD, 0);	
		local xPos = obj.sq_GetIntData(SKILL_FIRE_ROAD, 1);			
		local xOffset = obj.sq_GetIntData(SKILL_FIRE_ROAD, 2);		
		local maxHit = obj.sq_GetIntData(SKILL_FIRE_ROAD, 3);		
		local sizeRate = obj.sq_GetIntData(SKILL_FIRE_ROAD, 5);		

		
		local createCount = obj.sq_GetLevelData(SKILL_FIRE_ROAD, 0, skillLevel);
		local damage1 = obj.sq_GetBonusRateWithPassive(SKILL_FIRE_ROAD, STATE_FIRE_ROAD, 1, 1.0);	
		local damage2 = obj.sq_GetBonusRateWithPassive(SKILL_FIRE_ROAD, STATE_FIRE_ROAD, 2, 1.0);	
	
		printc("createCount " + createCount);
		
		
		local rowNumber = obj.sq_GetIntData(SKILL_FIRE_ROAD, 4);
		local yAxisDistance = 55;
		
		for (local i = 0; i < createCount; i++)
		{
			if (obj.isMyControlObject())
			{
				obj.sq_StartWrite();
				obj.sq_WriteWord(pauseTime * i);
				obj.sq_WriteDword(damage1);		
				obj.sq_WriteDword(damage2);		
				obj.sq_WriteByte(maxHit);		
				obj.sq_WriteByte(i);			
				obj.sq_WriteWord(sizeRate);		
				
				printc("number " +i);
				
				local passiveObjectIndex = 24212 + i % 2;
				obj.sq_SendCreatePassiveObjectPacket(passiveObjectIndex, 0, xPos + xOffset * i, 1, 0);
				
				
				
				if (rowNumber > 0)
				{
					for (local j = 0; j < rowNumber; j+=1)
					{
						local row = (j + 2) / 2;
						row = row.tointeger();
	
						if ((j % 2) == 0)
						{	
							local y = row * yAxisDistance;
							obj.sq_SendCreatePassiveObjectPacket(passiveObjectIndex, 0, xPos + xOffset * i, -y, 0);
						}
						else
						{	
							local y = row * yAxisDistance;
							obj.sq_SendCreatePassiveObjectPacket(passiveObjectIndex, 0, xPos + xOffset * i, y, 0);
						}
					}
				}
			}
		}
	}

	return true;

}


