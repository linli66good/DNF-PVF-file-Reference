
function sq_AddFunctionName(appendage)
{
	appendage.sq_AddFunctionName("proc", "proc_appendage_atmage_iceroad")
	appendage.sq_AddFunctionName("prepareDraw", "prepareDraw_appendage_atmage_iceroad")
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_atmage_iceroad")
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_atmage_iceroad")
	appendage.sq_AddFunctionName("isEnd", "isEnd_appendage_atmage_iceroad")
}


function sq_AddEffect(appendage)
{
	if(!appendage)
		return;
	appendage.sq_AddEffectFront("Character/Mage/Effect/Animation/ATIceRoad/loop/00_icebottom_dodge.ani")
}




function proc_appendage_atmage_iceroad(appendage)
{
	if(!appendage) {
		return;
	}
	
	local obj = appendage.getParent();
	
	local currentT = appendage.getTimer().Get();
	local t = appendage.sq_var.get_timer_vector(0);
	
	
		
			
				
			
				
					
					
					
						
						
					
					
					
						
						
						
					
				
				
			
		
	
	
	local state = sq_GetState(obj);
	
	local term = -1;
	
	if(state == STATE_DASH) {
		term = 400;
	}
	else if(state == STATE_STAND) {
		if(!obj.isStay()) {
			term = 800;
		}
	}
	
	if(t.getEventTerm() != term) {
		t.setParameter(term, -1);
		t.resetInstant(0);
	}
	
	
}

function onStart_appendage_atmage_iceroad(appendage)
{
	if(!appendage) {
		return;
	}
	
	local obj = appendage.getParent();		


	appendage.sq_var.clear_timer_vector();
	appendage.sq_var.push_timer_vector();
	appendage.sq_var.push_timer_vector();
			
	local t = appendage.sq_var.get_timer_vector(0);
	t.setParameter(400, -1);
	t.resetInstant(0);

	local t2 = appendage.sq_var.get_timer_vector(1);
	t2.setParameter(500, -1);
	t2.resetInstant(0);
	
	
	
	
	
	local obj = appendage.getParent();	
	if(obj)
		obj.sq_PlaySound("ICEROAD_LOOP", 7578);
	

}


function onEnd_appendage_atmage_iceroad(appendage)
{
	if(!appendage) {
		return;
	}
	
	local obj = appendage.getParent();
	if(obj)
		obj.stopSound(7578);
	
}

function prepareDraw_appendage_atmage_iceroad(appendage)
{
	if(!appendage) {
		return;
	}
	
	local obj = appendage.getParent();	
}




function isEnd_appendage_atmage_iceroad(appendage)
{
	if(!appendage)
		return false;
	local T = appendage.getTimer().Get();	
	
	return false;
}
