
function sq_AddFunctionName(appendage)
{
	appendage.sq_AddFunctionName("proc", "proc_appendage_heteropupil")
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_heteropupil")
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_heteropupil")
}

function sq_AddEffect(appendage)
{

}

function proc_appendage_heteropupil(appendage)
{
	if(!appendage) {
		return;
	}

}



function onStart_appendage_heteropupil(appendage)
{
	if(!appendage) {
		return;
	}
	
	local obj = appendage.getParent();	
	
	
}

function onEnd_appendage_heteropupil(appendage)
{
	if(!appendage) return;
	local parentObj = appendage.getParent();
	if(!parentObj) 
	{
		appendage.setValid(false);
		return;
	}
}
