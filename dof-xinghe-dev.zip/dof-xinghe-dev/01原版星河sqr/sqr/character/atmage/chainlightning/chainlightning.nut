
SUB_STATE_ATCHAINLIGHTNING_0	<- 0
SUB_STATE_ATCHAINLIGHTNING_1	<- 1
SUB_STATE_ATCHAINLIGHTNING_2	<- 2
SUB_STATE_ATCHAINLIGHTNING_3	<- 3
SUB_STATE_ATCHAINLIGHTNING_4	<- 4

SKL_CL_SD_0 <- 0 
SKL_CL_SD_1 <- 1 
SKL_CL_SD_2 <- 2 
SKL_CL_SD_3 <- 3 
SKL_CL_SD_4 <- 4 
SKL_CL_SD_5 <- 5 
SKL_CL_SD_6 <- 6 


SKL_CL_LI_0 <- 0 
SKL_CL_LI_1 <- 1 
SKL_CL_LI_2 <- 2 
SKL_CL_LI_3 <- 3 
SKL_CL_LI_4 <- 4 

function checkExecutableSkill_ChainLightning(obj)
{

	if(!obj) return false;

	local b_useskill = obj.sq_IsUseSkill(SKILL_ATCHAINLIGHTNING);
	
	print("b_useskill : %d" + b_useskill);

	if(b_useskill) {
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(SUB_STATE_ATCHAINLIGHTNING_0); 
		obj.sq_AddSetStatePacket(STATE_CHAINLIGHTNING, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}	

	return false;

}

function checkCommandEnable_ChainLightning(obj)
{

	if(!obj) return false;

	local state = obj.sq_GetState();
	
	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(SKILL_ATCHAINLIGHTNING); 
	}

	return true;

}

function onSetState_ChainLightning(obj, state, datas, isResetTimer)
{

	if(!obj) return;

	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();

	local posX = obj.getXPos();
	local posY = obj.getYPos();
	local posZ = obj.getZPos();
	
	obj.getVar().clear_vector();
	obj.getVar().push_vector(0);

	if(substate == SUB_STATE_ATCHAINLIGHTNING_0) {

		obj.sq_SetCurrentAnimation(CUSTOM_ANI_CHAINLIGHTNING_CAST);
		local pAni = obj.sq_GetCurrentAni();
		
		
		
		
		local skillLevel = sq_GetSkillLevel(obj, SKILL_ATCHAINLIGHTNING);
		
		local castTime = sq_GetCastTime(obj, SKILL_ATCHAINLIGHTNING, skillLevel);
		local animation = sq_GetCurrentAnimation(obj);
		local startTime = sq_GetFrameStartTime(animation, 16);
		local speedRate = startTime.tofloat() / castTime.tofloat();
		obj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED,
			SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, speedRate, speedRate);

		sq_StartDrawCastGauge(obj, startTime, true);
		addElementalChain_ATMage(obj, ENUM_ELEMENT_LIGHT);
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_1) {
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_CHAINLIGHTNING);		
		obj.sq_PlaySound("MW_CHAINLIGHT");

		if(obj.isMyControlObject()) {
			
			local firstTargetYRange = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_SD_0); 
			local firstTargetXStartRange = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_LI_1); 
			local firstTargetXEndRange = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_SD_2); 
			local nextTargetRange = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_SD_3); 
			local targetMaxHeight = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_SD_4); 
			local isChoroset = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_SD_5); 
			local chorosetTime = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_SD_6); 

			local skill_level = obj.sq_GetSkillLevel(SKILL_ATCHAINLIGHTNING);
			
			local link_num = obj.sq_GetLevelData(SKILL_ATCHAINLIGHTNING, SKL_CL_LI_0, skill_level); 
			local attack_time = obj.sq_GetLevelData(SKILL_ATCHAINLIGHTNING, SKL_CL_LI_1, skill_level);	
			local firstAttackRate = obj.sq_GetBonusRateWithPassive(SKILL_ATCHAINLIGHTNING, STATE_CHAINLIGHTNING, SKL_CL_LI_2, 1.0); 
			local multi_hit_num = obj.sq_GetLevelData(SKILL_ATCHAINLIGHTNING, SKL_CL_LI_3, skill_level);	
			
			
			sq_BinaryStartWrite();
			sq_BinaryWriteWord(firstTargetYRange);
			sq_BinaryWriteWord(firstTargetXStartRange);
			sq_BinaryWriteWord(firstTargetXEndRange);
			sq_BinaryWriteWord(nextTargetRange);
			sq_BinaryWriteWord(targetMaxHeight);
			sq_BinaryWriteWord(isChoroset);
			sq_BinaryWriteWord(chorosetTime);
    		
			sq_BinaryWriteWord(link_num);
			sq_BinaryWriteWord(attack_time);
			sq_BinaryWriteDword(firstAttackRate);
			sq_BinaryWriteWord(multi_hit_num);
			
			
			
    		
    		local distanceL = 50;
    		local h = 88;
    		obj.sq_SendCreatePassiveObjectPacket(24241, 0, distanceL, 0, h);
    		
    		obj.sq_PlaySound("CHAINLIGHT_ELEC_LOOP", 7576);
    	}
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_2) {
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_CHAINLIGHTNING_END);
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_3) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_4) {
		
	}
	

}

function prepareDraw_ChainLightning(obj)
{

	if(!obj) return;

	local substate = obj.getSkillSubState();

	if(substate == SUB_STATE_ATCHAINLIGHTNING_0) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_1) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_2) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_3) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_4) {
		
	}
	

}

function onProc_ChainLightning(obj)
{

	if(!obj) return;

	local substate = obj.getSkillSubState();

	local pAni = obj.sq_GetCurrentAni();
	local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);
	local currentT = sq_GetCurrentTime(pAni);

	if(substate == SUB_STATE_ATCHAINLIGHTNING_0) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_1) {
		
		if(obj.isMyControlObject()) {
			
			
			local skill_level = obj.sq_GetSkillLevel(SKILL_ATCHAINLIGHTNING);
			local attack_time = obj.sq_GetLevelData(SKILL_ATCHAINLIGHTNING, SKL_CL_LI_1, skill_level);	
			
			
			local isChoroset = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_SD_5);
			if (isChoroset == 1)
			{
				attack_time = obj.sq_GetIntData(SKILL_ATCHAINLIGHTNING, SKL_CL_SD_6);
			}

			
			local passiveobj_cl = obj.sq_GetPassiveObject(24241);
			
			
			if(passiveobj_cl) {
				local flag = passiveobj_cl.getVar("nograb").get_vector(0);
				
				if(flag)
				{
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(SUB_STATE_ATCHAINLIGHTNING_2);
					obj.sq_AddSetStatePacket(STATE_CHAINLIGHTNING, STATE_PRIORITY_USER, true);
					return;
				}
				else
				{
					if(obj.getVar().get_vector(0) == 0) {
						obj.sq_SetShake(obj,1,attack_time);
						obj.getVar().set_vector(0, 1);
					}
				}
				
			}
			
			if(currentT > attack_time) {
				
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(SUB_STATE_ATCHAINLIGHTNING_2);
				obj.sq_AddSetStatePacket(STATE_CHAINLIGHTNING, STATE_PRIORITY_USER, true);
			}
		}
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_2) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_3) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_4) {
		
	}
	

}

function onProcCon_ChainLightning(obj)
{

	if(!obj) return;

	local substate = obj.getSkillSubState();

	if(substate == SUB_STATE_ATCHAINLIGHTNING_0) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_1) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_2) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_3) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_4) {
		
	}
	

}

function onEndCurrentAni_ChainLightning(obj)
{

	if(!obj) return;
	
	

	local substate = obj.getSkillSubState();

	if(substate == SUB_STATE_ATCHAINLIGHTNING_0) {
		if(obj.isMyControlObject()) {
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(SUB_STATE_ATCHAINLIGHTNING_1);
			obj.sq_AddSetStatePacket(STATE_CHAINLIGHTNING, STATE_PRIORITY_USER, true);
		}
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_1) {
		
		
			
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_2) {
		if(obj.isMyControlObject()) {
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_3) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_4) {
		
	}
	

}

function onKeyFrameFlag_ChainLightning(obj, flagIndex)
{

	if(!obj) return false;

	local substate = obj.getSkillSubState();

	if(substate == SUB_STATE_ATCHAINLIGHTNING_0) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_1) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_2) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_3) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_4) {
		
	}
	

	return false;

}

function onEndState_ChainLightning(obj, new_state)
{

	if(!obj) return;

	local substate = obj.getSkillSubState();

	if(substate == SUB_STATE_ATCHAINLIGHTNING_0) {
		
		
		sq_EndDrawCastGauge(obj);
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_1) {
		
		
		obj.stopSound(7576);
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_2) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_3) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_4) {
		
	}
	
	
}

function onAfterSetState_ChainLightning(obj, state, datas, isResetTimer)
{

	if(!obj) return;

	local substate = obj.getSkillSubState();

	if(substate == SUB_STATE_ATCHAINLIGHTNING_0) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_1) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_2) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_3) {
		
	}
	else if(substate == SUB_STATE_ATCHAINLIGHTNING_4) {
		
	}
	

}

