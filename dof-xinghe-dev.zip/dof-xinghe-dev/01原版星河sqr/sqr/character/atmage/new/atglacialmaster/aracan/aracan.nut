function checkExecutableSkill_Aracan(obj)  
{
	if (!obj) return false;
	
	local isUse = obj.sq_IsUseSkill(SKILL_ARACAN);

	if (isUse)
	{
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(0);
		obj.sq_AddSetStatePacket(STATE_ARACAN, STATE_PRIORITY_USER, false);
		return true;
	}
	return false;
}

function checkCommandEnable_Aracan(obj)
{
	return true;
}

function onSetState_Aracan(obj, state, datas, isResetTimer)
{	
	local state = obj.getVar("state").get_vector(0);
	
	obj.sq_StopMove();

	if (state == 0)
	{
		local objectManager = obj.getObjectManager();
		local xPos = objectManager.getFieldXPos(400, ENUM_DRAWLAYER_NORMAL);
		local yPos = objectManager.getFieldYPos(400, 0, ENUM_DRAWLAYER_NORMAL);
		obj.sq_SetCurrentPos(obj, xPos, yPos, 0);
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATARACAN_START_BODY);
	}
	if (state == 1)
	{
		local zPos = 800;
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), zPos);
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATARACAN_BODY);
		obj.sq_ZStop();
		
		createAracanBody(obj);
	}
	if (state == 2)
	{
		obj.sq_SetCurrentPos(obj, obj.getXPos(), obj.getYPos(), 0);
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATARACAN_END_BODY);
	}
}

function onTimeEvent_Aracan(obj, timeEventIndex, timeEventCount)
{
	local state = obj.getVar("state").get_vector(0);
	
	if(state == 1)
	{
		if (timeEventIndex == 0)
		{
			createAracanTempestAttack(obj);
		}
	}
}

function onEndCurrentAni_Aracan(obj)
{
	local state = obj.getVar("state").get_vector(0);
	
	if (state == 0)
	{
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(1);
		obj.sq_AddSetStatePacket(STATE_ARACAN, STATE_PRIORITY_USER, false);
	}
	if (state == 1)
	{
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(2);
		obj.sq_AddSetStatePacket(STATE_ARACAN, STATE_PRIORITY_USER, false);
	}
	if (state == 2)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}

function onKeyFrameFlag_Aracan(obj, flagIndex)
{
	local state = obj.getVar("state").get_vector(0);
	
	if (state == 0)
	{
		if (flagIndex == 0)
		{
			createAracanStart_Back00(obj);
			createAracanStart_Front00(obj);
			createAracanStart_Bottom00(obj);
			createAracanStart_BackGround00(obj);
		}
	}
	if (state == 1)
	{
		if (flagIndex == 0)
		{
			obj.sq_PlaySound("ARACAN_CAST");
			sq_SetMyShake(obj,12,250);
			
			createAracanAscendingAttack(obj);
		
		}
		if (flagIndex == 1)
		{
			createAracanScene1_Back00(obj);
			createAracanScene1_Front00(obj);
			createAracanScene1_BackZero(obj);
		}
		if (flagIndex == 2)
		{
			create_Atmage_SwiftMaster_Neo(obj);
		}
		if (flagIndex == 3)
		{
			sq_SetMyShake(obj,6,120);
		}
		if (flagIndex == 4)
		{
			sq_SetMyShake(obj,10,150);
		}
		if (flagIndex == 5)
		{
			sq_SetMyShake(obj,35,300);
			createAracanScene2_Back00(obj);
			createAracanScene2_Front00(obj);
			createAracanScene2_Cover00(obj);
			createAracanScene2_Bottom00(obj);
			createAracanScene2_BackGround00(obj);
			createAracanKickAttack(obj);
		}	
		if (flagIndex == 8)
		{
			sq_SetMyShake(obj,13,300);
			
			local attT = obj.sq_GetIntData(SKILL_ARACAN, 3);
			obj.setTimeEvent(0, 1250 / attT, attT, true);
		}
		if (flagIndex == 9)
		{
			sq_SetMyShake(obj,22,1200);
		}
		if (flagIndex == 10)
		{
			sq_flashScreen(obj,100,300,100,204, sq_RGB(255,255,255), GRAPHICEFFECT_LINEARDODGE, ENUM_DRAWLAYER_CLOSEBACK);
		}
	}
	if (state == 2)
	{
		if (flagIndex == 0)
		{
			createAracanEnd_Back00(obj);
			createAracanEnd_Cover00(obj);
		}
	}
	return true;
}

function createAracanAscendingAttack(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_ARACAN, STATE_ARACAN, 0, 1.0);
	sq_createAttackObjectWithPath(obj, 
	"passiveobject/actionobject/new/atmage/atglacialmaster/animation/ataracan/ascendingattackbox.ani",
	"passiveobject/actionobject/new/atmage/atglacialmaster/attackinfo/aracanascending.atk",true,atk,100,0,0,-800);		
}

function createAracanKickAttack(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_ARACAN, STATE_ARACAN, 1, 1.0);
	sq_createAttackObjectWithPath(obj, 
	"passiveobject/actionobject/new/atmage/atglacialmaster/animation/ataracan/kickattackbox.ani",
	"passiveobject/actionobject/new/atmage/atglacialmaster/attackinfo/aracankick.atk",true,atk,100,0,0,-800);		
}

function createAracanTempestAttack(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_ARACAN, STATE_ARACAN, 2, 1.0);
	sq_createAttackObjectWithPath(obj, 
	"passiveobject/actionobject/new/atmage/atglacialmaster/animation/ataracan/tempestattackbox.ani",
	"passiveobject/actionobject/new/atmage/atglacialmaster/attackinfo/aracantempest.atk",true,atk,100,0,0,-800);		
}

function createAracanBody(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/ataracan/body/ataracan_body.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanStart_Back00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/start/start_back_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanStart_Front00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/start/start_front_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanStart_Bottom00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/start/start_bottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanStart_BackGround00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/start/start_background_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CLOSEBACK);
	pooledObj.setCurrentPos(obj.getXPos(),obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanScene1_Back00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/scene1/scene1_back_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CONTACT);
	pooledObj.setCurrentPos(obj.getXPos(), obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}

function createAracanScene1_BackZero(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/scene1/scene1_back_zero.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	pooledObj.setCurrentPos(obj.getXPos(), obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,2,false);
}

function createAracanScene1_Front00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/scene1/scene1_front_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanScene2_Back00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/scene2/scene2_back_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanScene2_Front00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/scene2/scene2_front_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanScene2_Cover00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/scene2/scene2_cover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanScene2_Bottom00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/scene2/scene2_bottom_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanScene2_BackGround00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/scene2/scene2_background_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_CLOSEBACK);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanEnd_Back00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/end/end_back_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function createAracanEnd_Cover00(obj)
{
	local ani = sq_CreateAnimation("","character/mage/effect/animation/atAracan/end/end_cover_00.ani");
	local pooledObj = sq_CreatePooledObject(ani,true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	pooledObj.setCurrentPos(obj.getXPos() ,obj.getYPos(), 0);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj,pooledObj,0,false);
}

function create_Atmage_SwiftMaster_Neo(obj)
{
	local ani = sq_CreateAnimation("","passiveobject/actionobject/new/atmage/atglacialmaster/animation/ataracan/atmage_swiftmaster_neo.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_COVER);
	local objectManager = obj.getObjectManager();
	local xPos = objectManager.getFieldXPos(0, ENUM_DRAWLAYER_COVER);
	local yPos = objectManager.getFieldYPos(0, 0, ENUM_DRAWLAYER_COVER);
	pooledObj.setCurrentPos(xPos ,yPos, 0);
	pooledObj.setCurrentDirection(ENUM_DIRECTION_RIGHT);
	sq_AddObject(obj, pooledObj, 0, false);
}
