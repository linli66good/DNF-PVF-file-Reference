function checkExecutableSkill_BloodStinger(obj)  
{
	if (!obj) return false;
	
	local isUse = obj.sq_IsUseSkill(SKILL_BLOODSTINGER);

	if (isUse)
	{
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(0);
		obj.sq_AddSetStatePacket(STATE_BLOODSTINGER, STATE_PRIORITY_USER, false);
		return true;
	}
	return false;
}

function checkCommandEnable_BloodStinger(obj)
{
	return true;
}

function onSetState_BloodStinger(obj, state, datas, isResetTimer)
{	
	local state = obj.getVar("state").get_vector(0);
	
	obj.sq_StopMove();

	if (state == 0)
	{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATBLOODSTINGE_BODY);
		createBloodStingerFront01(obj, 0, 0, 0);
		createBloodStingerFront01_Hit(obj);
		createBloodStingerBottom01(obj, 0, 0, 0);
	}
}

function onEndCurrentAni_BloodStinger(obj)
{
	local state = obj.getVar("state").get_vector(0);
	
	if (state == 0)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}

function onKeyFrameFlag_BloodStinger(obj, flagIndex)
{
	local state = obj.getVar("state").get_vector(0);
	
	if (state == 0)
	{
		if (flagIndex == 0)
		{
			obj.sq_PlaySound("BLOODSTINGE_CAST");
		}
		if (flagIndex == 1)
		{
			sq_SetMyShake(obj,30,250);
			sq_flashScreen(obj,240,360,150,255, sq_RGB(0,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
		if (flagIndex == 2)
		{
			sq_SetMyShake(obj,7,40);
			sq_flashScreen(obj,0,80,280,127, sq_RGB(255,0,0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
		if (flagIndex == 3)
		{
			createBloodStingerFront03(obj, 0, 0, 0);
			createBloodStingerBack22(obj, 0, 0, 0);
		}
	}
	return true;
}

function createBloodStingerFront01_Hit(obj)
{
	local atk = obj.sq_GetBonusRateWithPassive(SKILL_BLOODSTINGER, STATE_BLOODSTINGER, 0, 1.0);
	sq_createAttackObjectWithPath(obj, 
	"passiveobject/actionobject/new/atmage/atglacialmaster/animation/atbloodstinger/atbloodstingefront_01atkbox.ani",
	"passiveobject/actionobject/new/atmage/atglacialmaster/attackinfo/atbloodstinger.atk",true,atk,100,0,0,0);		
}

function createBloodStingerBack22(obj, disX, disY, disZ)
{
	local ani = sq_CreateAnimation("", "character/mage/effect/animation/atbloodstinger/atbloodstingeback_22.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj, pooledObj, 0, false);
}

function createBloodStingerFront01(obj, disX, disY, disZ)
{
	local ani = sq_CreateAnimation("", "passiveobject/actionobject/new/atmage/atglacialmaster/animation/atbloodstinger/atbloodstingefront_01.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj, pooledObj, 0, false);
}

function createBloodStingerFront03(obj, disX, disY, disZ)
{
	local ani = sq_CreateAnimation("", "passiveobject/actionobject/new/atmage/atglacialmaster/animation/atbloodstinger/atbloodstingefront_03.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj, pooledObj, 0, false);
}

function createBloodStingerBottom01(obj, disX, disY, disZ)
{
	local ani = sq_CreateAnimation("", "passiveobject/actionobject/new/atmage/atglacialmaster/animation/atbloodstinger/atbloodstingebottom_01.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj, pooledObj, 0, false);
}

