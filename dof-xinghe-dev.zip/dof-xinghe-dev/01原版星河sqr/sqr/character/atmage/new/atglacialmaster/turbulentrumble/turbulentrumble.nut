function checkExecutableSkill_TurbulentRumble(obj)  
{
	if (!obj) return false;
	
	local isUse = obj.sq_IsUseSkill(SKILL_TURBULENTRUMBLE);

	if (isUse)
	{
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(0);
		obj.sq_AddSetStatePacket(STATE_TURBULENTRUMBLE, STATE_PRIORITY_USER, false);
		return true;
	}
	return false;
}

function checkCommandEnable_TurbulentRumble(obj)
{
	return true;
}

function onSetState_TurbulentRumble(obj, state, datas, isResetTimer)
{	
	local state = obj.getVar("state").get_vector(0);
	
	obj.sq_StopMove();

	if (state == 0)
	{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_TURBULENTRUMBLECAST_BODY);
	}
	if (state == 1)
	{
		obj.sq_SetCurrentAnimation(CUSTOM_ANI_TURBULENTRUMBLESTART_BODY);
	}
}

function onEndCurrentAni_TurbulentRumble(obj)
{
	local state = obj.getVar("state").get_vector(0);
	
	if (state == 0)
	{
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(1);
		obj.sq_AddSetStatePacket(STATE_TURBULENTRUMBLE, STATE_PRIORITY_USER, false);
	}
	if (state == 1)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}

function onKeyFrameFlag_TurbulentRumble(obj, flagIndex)
{
	local state = obj.getVar("state").get_vector(0);
	
	local id = sq_GetObjectId(obj);
	
	if (state == 0)
	{
		if (flagIndex == 0)
		{
			obj.sq_PlaySound("TURBULENTRUMBLE_CAST");
		}
		if (flagIndex == 1)
		{
			sq_SetMyShake(obj,8,100);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_TURBULENTRUMBLE, STATE_TURBULENTRUMBLE, 0, 1.0);
		
			obj.sq_StartWrite();
			obj.sq_WriteDword(7);
			obj.sq_WriteDword(id);
			obj.sq_WriteDword(attackBonusRate);
			obj.sq_SendCreatePassiveObjectPacket(24337, 0, 0, 0, 0);
		}
		if (flagIndex == 2)
		{
			sq_SetMyShake(obj,12,180);
		}
	}
	if (state == 1)
	{
		if (flagIndex == 0)
		{
			sq_SetMyShake(obj,7,300);
		}
	}
	return true;
}

function createTurbulentRumbleBoomDust_00(obj, disX, disY, disZ)
{
	local ani = sq_CreateAnimation("", "passiveobject/actionobject/new/atmage/atglacialmaster/animation/atturbulentrumble/turbulentrumbleexlposion/boomdust_00.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj, pooledObj, 0, false);
}

function createTurbulentRumbleBoomFront_00(obj, disX, disY, disZ)
{
	local ani = sq_CreateAnimation("", "passiveobject/actionobject/new/atmage/atglacialmaster/animation/atturbulentrumble/turbulentrumbleexlposion/tornadoboomfront_00.ani");
	local pooledObj = sq_CreatePooledObject(ani, true);
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_NORMAL);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	sq_AddObject(obj, pooledObj, 0, false);
}
