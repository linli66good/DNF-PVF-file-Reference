function setCustomData_po_ATGlacialMaster(obj, receiveData)
{
	local id = receiveData.readDword();
	local targetid = receiveData.readDword();
	
	obj.getVar("id").clear_vector();
	obj.getVar("id").push_vector(id);
	
	local atmage = obj.getTopCharacter();
	if (!atmage)
		return;
	
	if (id == 7)
	{
		local attackBonusRate = receiveData.readDword();
		
		local ani = obj.getVar().GetAnimationMap("7", "passiveobject/actionobject/new/atmage/atglacialmaster/animation/atturbulentrumble/turbulentrumbleturbulentair/tornadoup_04.ani");
		obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);
		
		local attackInfo = sq_GetCustomAttackInfo(obj, 0);	
		sq_SetCurrentAttackInfo(obj, attackInfo);
		
		local attackInfo = sq_GetCurrentAttackInfo(obj, attackInfo);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		
		obj.setTimeEvent(0, 140, 0, true);
	}
	if (id == 8)
	{
		local attackBonusRate = receiveData.readDword();
		
		local ani = obj.getVar().GetAnimationMap("8", "passiveobject/actionobject/new/atmage/atglacialmaster/animation/atturbulentrumble/turbulentrumblelandspout/tornadodownfront_00.ani");
		obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);
		
		local attackInfo = sq_GetCustomAttackInfo(obj, 1);	
		sq_SetCurrentAttackInfo(obj, attackInfo);
		
		local attackInfo = sq_GetCurrentAttackInfo(obj, attackInfo);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		
		local skill = sq_GetSkill(atmage, SKILL_TURBULENTRUMBLE);
		local skillLevel = sq_GetSkillLevel(atmage, SKILL_TURBULENTRUMBLE);
		attackBonusRate = sq_GetBonusRateWithPassive(atmage, SKILL_TURBULENTRUMBLE, STATE_TURBULENTRUMBLE, 1, 1.0);
		sq_SetCurrentAttackBonusRate(sq_GetCurrentAttackInfo(obj), attackBonusRate);
		
		obj.setTimeEvent(0, 100, 0, true);
	}
	if (id == 9)
	{
		local attackBonusRate = receiveData.readDword();
		
		local ani = obj.getVar().GetAnimationMap("9", "passiveobject/actionobject/new/atmage/atglacialmaster/animation/atturbulentrumble/turbulentrumbleexlposion/tornadoboom_08.ani");
		obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);
		
		local attackInfo = sq_GetCustomAttackInfo(obj, 2);	
		sq_SetCurrentAttackInfo(obj, attackInfo);
		
		local attackInfo = sq_GetCurrentAttackInfo(obj, attackInfo);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		
		local skill = sq_GetSkill(atmage, SKILL_TURBULENTRUMBLE);
		local skillLevel = sq_GetSkillLevel(atmage, SKILL_TURBULENTRUMBLE);
		attackBonusRate = sq_GetBonusRateWithPassive(atmage, SKILL_TURBULENTRUMBLE, STATE_TURBULENTRUMBLE, 2, 1.0);
		sq_SetCurrentAttackBonusRate(sq_GetCurrentAttackInfo(obj), attackBonusRate);
		
		createTurbulentRumbleBoomDust_00(obj, 0, 0, 0);
		createTurbulentRumbleBoomFront_00(obj, 0, 0, 0);
	}
}

function onTimeEvent_po_ATGlacialMaster(obj, timeEventIndex, timeEventCount)
{
	local id = obj.getVar("id").get_vector(0);
	
	if (obj.getVar("id").get_vector(0) == 7)
    {
		if (timeEventIndex == 0)
		{
			if (timeEventCount <= 7)
			{
				obj.resetHitObjectList();
			}
		}
	}
	if (obj.getVar("id").get_vector(0) == 8)
    {
		if (timeEventIndex == 0)
		{
			if (timeEventCount <= 4)
			{
				obj.resetHitObjectList();
			}
		}
	}
}

function onEndCurrentAni_po_ATGlacialMaster(obj)
{
   local id = obj.getVar("id").get_vector(0);
	
	if (obj.getVar("id").get_vector(0) == 7)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	if (obj.getVar("id").get_vector(0) == 8)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
	if (obj.getVar("id").get_vector(0) == 9)
	{
		sq_SendDestroyPacketPassiveObject(obj);
	}
}

function onKeyFrameFlag_po_ATGlacialMaster(obj, flagIndex)
{
	local id = obj.getVar("id").get_vector(0);
	
	if (obj.getVar("id").get_vector(0) == 7)
    {
		if (flagIndex == 3)
		{
			sq_BinaryStartWrite();
			sq_BinaryWriteDword(8);
			sq_SendCreatePassiveObjectPacketPos(obj, 24337, 0, obj.getXPos(), obj.getYPos(), obj.getZPos());
		}
		if (flagIndex == 4)
		{
			sq_BinaryStartWrite();
			sq_BinaryWriteDword(9);
			sq_SendCreatePassiveObjectPacketPos(obj, 24337, 0, obj.getXPos(), obj.getYPos() + 5, obj.getZPos() + 180);
		}
	}
	if (obj.getVar("id").get_vector(0) == 9)
    {
		if (flagIndex == 0)
		{
			sq_SetMyShake(obj, 15, 160);
			sq_flashScreen(obj,0,40,0,63, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
		}
	}
	return true;
}
