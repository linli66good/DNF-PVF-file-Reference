luoxuannianqichang_shijian <- 1000
luoxuannianqichang_juli <- 600

function setCustomData_po_ATWindStrike(obj, receiveData)
{
	if(!obj) return;
	local attackBonusRate = receiveData.readDword();
	local power = receiveData.readDword();
	local parentObj = obj.getTopCharacter();
	parentObj = sq_ObjectToSQRCharacter(parentObj);
	obj.getVar("power").clear_vector();
	obj.getVar("power").push_vector(power);
	if(power == -20)
	{
		sq_SetMyShake(obj,7,800);
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/character/mage/animation/heatingfurnace/heatburst/mk2heatburstfront_01.ani"));
		obj.getVar("flag").clear_vector();
		obj.getVar("flag").push_vector(0);
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 11);
		sq_SetCurrentAttackeHitStunTime(sq_GetCurrentAttackInfo(obj), 0);
		local power = parentObj.sq_GetPowerWithPassive(106, -1, 4, -1, 1.0);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, power);
		local size = sq_GetIntData(parentObj, 106, 20);
		local sizeRate = size.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setImageRateFromOriginal(sizeRate, sizeRate);
		currentAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
		locakonhit(obj, "passiveobject/character/mage/animation/heatingfurnace/heatburst/mk2heatburstback_01.ani", 0, -1, 0, 0, size, 0, 1, 1.0, 0);
		return;
	}else
	if(power == -19)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/character/mage/animation/heatingfurnace/fail_new/heatingfurnacenewnew_39.ani"));
		obj.getVar("flag").clear_vector();
		obj.getVar("flag").push_vector(0);
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 10);
		sq_SetCurrentAttackeHitStunTime(sq_GetCurrentAttackInfo(obj), 0);
		local power = parentObj.sq_GetPowerWithPassive(106, -1, 1, -1, 1.0);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, power);
		local size = sq_GetIntData(parentObj, 106, 20);
		local sizeRate = size.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		
		
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
		locakonhit(obj, "passiveobject/character/mage/animation/heatingfurnace/fail_new/heatingfurnacenewnew_33.ani", 0, 0, 70, 0, 100, 0, 1, 1.0, 0);
		return;
	}else
	if(power == -18)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/character/mage/animation/megadrill/familiar/fail_n.ani"));
		locakonhit(obj, "passiveobject/character/mage/animation/megadrill/familiar/fail_d.ani", 0, 1, 0, 0, 100, 1, 1, 1.0, 0);
		locakonhit(obj, "passiveobject/character/mage/animation/megadrill/familiar/fail1.ani", 0, 1, 0, 0, 100, 1, 1, 1.0, 0);
		locakonhit(obj, "passiveobject/character/mage/animation/megadrill/familiar/fail2.ani", 0, 1, 0, 0, 100, 1, 1, 1.0, 0);
		return;
	}else
	if(power == -17)
	{
		obj.sq_PlaySound("MEGA_DRILL_ICEEXP");
		sq_SetMyShake(obj,6,300);
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/character/mage/animation/megadrill/fail/megadrillfailend_07.ani"));
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 9);
		locakonhit(obj, "passiveobject/character/mage/animation/megadrill/fail/megadrillfailendbttom_01.ani", 0, 1, 0, 0, sq_GetIntData(parentObj, 104, 28), 0, 2, 1.0, 0);
		local power = parentObj.sq_GetPowerWithPassive(104, -1, 2, -1, 1.0);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, power);
		local size = sq_GetIntData(parentObj, 104, 28);
		local sizeRate = size.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setImageRateFromOriginal(sizeRate, sizeRate);
		currentAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
		return;
	}else
	if(power == -16)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/character/mage/animation/megadrill/fail/megadrillfailstart_57.ani"));
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 8);
		locakonhit(obj, "passiveobject/character/mage/animation/megadrill/fail/megadrillfailstart_48.ani", 0, 1, 0, 0, sq_GetIntData(parentObj, 104, 28), 0, 1, 1.0, 0);
		obj.getVar("flag").clear_vector();
		obj.getVar("flag").push_vector(0);
		obj.getVar("flag").push_vector(0);
		obj.getVar("flag").push_vector(0);
		local power = parentObj.sq_GetPowerWithPassive(104, -1, 2, -1, 0.6);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, power);
		local size = sq_GetIntData(parentObj, 104, 28);
		local sizeRate = size.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
		return;
	}else
	if(power == -15)
	{
		obj.getVar("pauseTime").clear_vector();
		obj.getVar("pauseTime").push_vector(receiveData.readWord());
		obj.getVar("pos").clear_vector();
		obj.getVar("pos").push_vector(obj.getXPos());
		obj.getVar("pos").push_vector(obj.getYPos());
		obj.getVar("pos").push_vector(obj.getZPos());
		obj.getVar("pos").push_vector(receiveData.readWord());
		obj.getVar("pos").push_vector(receiveData.readWord());
		obj.getVar("pos").push_vector(1000 + sq_getRandom(-150, 150));
		obj.getVar("flag").clear_vector();
		obj.getVar("flag").push_vector(0);
		obj.getVar("flag").push_vector(0);
		return;
	}else
	if(power == -14)
	{
		local iceboomrate = receiveData.readDword();
		obj.getVar("power").push_vector(attackBonusRate);
		obj.getVar("power").push_vector(iceboomrate);
		local Maxcount = receiveData.readDword();
		local CurrentCount = receiveData.readDword();
		local disx = receiveData.readDword();
		local disy = receiveData.readDword();
		local size = receiveData.readDword();
		local maxT = receiveData.readDword();
		obj.getVar("icewave").clear_vector();
		obj.getVar("icewave").push_vector(iceboomrate);
		obj.getVar("icewave").push_vector(Maxcount);
		obj.getVar("icewave").push_vector(CurrentCount);
		obj.getVar("icewave").push_vector(disx);
		obj.getVar("icewave").push_vector(disy);
		obj.getVar("icewave").push_vector(size);
		obj.getVar("icewave").push_vector(maxT);
		obj.getVar("flag").clear_vector();
		obj.getVar("flag").push_vector(0);
		obj.sendStateOnlyPacket(100);
		obj.flushSetStatePacket();
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(100);
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 5);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, attackBonusRate);
		local burnProc = sq_GetLevelData(parentObj, 100, 4, sq_GetSkillLevel(parentObj, 100)) / 10;
		local burnLevel = sq_GetLevelData(parentObj, 100, 5, sq_GetSkillLevel(parentObj, 100));
		local burnTime = sq_GetLevelData(parentObj, 100, 6, sq_GetSkillLevel(parentObj, 100));
		sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,ACTIVESTATUS_FREEZE, burnProc, burnLevel, burnTime);
	}else
	if(power == -13)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/fighter/animation/hiddensting/lv95poisonspirit/hiddenstingfront_01.ani"));
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 4);
		local power = parentObj.sq_GetPowerWithPassive(75, -1, 0, -1, 10.0);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, power);
		obj.getVar("power").push_vector(0);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		local skill_level = sq_GetSkillLevel(parentObj, 75);
		local proc = sq_GetLevelData(parentObj, 75, 2, skill_level) / 10;
		local lv = sq_GetLevelData(parentObj, 75, 5, skill_level);
		local time = sq_GetLevelData(parentObj, 75, 3, skill_level);
		local damage = sq_GetLevelData(parentObj, 75, 4, skill_level) * 15;
		sq_SetChangeStatusIntoAttackInfoWithEtc(attackInfo, 0, 2, proc.tointeger(), lv, time, damage, 0);
		return;
	}else
	if(power == -11)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atflamethrower/compressedflameprojectilefront_01.ani"));
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 3);
		locakonhit(obj, "passiveobject/skillre/atgunner/animation/atflamethrower/compressedflameprojectileback_00.ani", 0, -1, 0, 0, 100, 1, 1, 1.0, 0);
		local skill_level = sq_GetSkillLevel(parentObj, 13);
		local maxtime = sq_GetLevelData(parentObj, 13, 1, skill_level);
		local interval = sq_GetLevelData(parentObj, 13, 2, skill_level);
		local maxcount = maxtime / interval;
		local pAni = obj.getCurrentAnimation();
		local delay = pAni.getDelaySum(0, 18);
		obj.setTimeEvent(1, 0, 999999, true);
		local attackBonusRate = parentObj.sq_GetBonusRateWithPassive(13, 26, 4, 1.0);
		local power = parentObj.sq_GetPowerWithPassive(13, 26, 0, 4, 1.0);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		sq_SetCurrentAttackPower(attackInfo, power);
		obj.sq_SetMaxHitCounterPerObject(maxcount);
		sq_SetMyShake(obj, 6, 400);
		return;
	}else
	if(power == -12)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/atflamethrowerboost/compressedstrongprojectilefront_16.ani"));
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 2);
		local skill_level = sq_GetSkillLevel(parentObj, 36);
		local maxtime = sq_GetLevelData(parentObj, 36, 1, skill_level);
		local interval = sq_GetLevelData(parentObj, 36, 2, skill_level);
		local maxcount = maxtime / interval;
		local pAni = obj.getCurrentAnimation();
		local delay = pAni.getDelaySum(0, 18);
		obj.setTimeEvent(1, 0, 999999, true);
		local attackBonusRate = parentObj.sq_GetBonusRateWithPassive(36, 26, 4, 1.0);
		local power = parentObj.sq_GetPowerWithPassive(36, 26, 0, 4, 1.0);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		sq_SetCurrentAttackPower(attackInfo, power);
		obj.sq_SetMaxHitCounterPerObject(maxcount);
		sq_SetMyShake(obj, 6, 500);
		return;
	}else
	if(power == -10)
	{
		obj.sendStateOnlyPacket(20);
		obj.flushSetStatePacket();
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(20);
		obj.getVar("attackBonusRate").clear_vector();
		obj.getVar("attackBonusRate").push_vector(attackBonusRate);
		obj.getVar("attackBonusRate").push_vector(receiveData.readWord());
		return;
	}else
	if(power >= 0)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/character/mage/animation/atwindstrike/00_wind_dodge.ani"));
		local upForce = receiveData.readWord();
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, attackBonusRate);
		sq_SetCurrentAttackPower(attackInfo, power);
		sq_SetCurrentAttacknUpForce(attackInfo, upForce);
	}
	if (sq_BinaryGetReadSize() < receiveData.getSize())
	{
		local type = receiveData.readDword();
		local count = receiveData.readDword();
		local sizerate = receiveData.readDword();
		local prob = receiveData.readDword();
		local lv = receiveData.readDword();
		local time = receiveData.readDword();
		if(type <= 0) return;
		obj.getVar("attackBonusRate").clear_vector();
		obj.getVar("attackBonusRate").push_vector(attackBonusRate);
		obj.getVar("Status").clear_vector();
		obj.getVar("Status").push_vector(prob);
		obj.getVar("Status").push_vector(lv);
		obj.getVar("Status").push_vector(time);
		obj.getVar("state").clear_vector();
		obj.getVar("state").push_vector(10);
		obj.getVar("state").push_vector(0);
		obj.getVar("state").push_vector(type);
		obj.getVar("count").clear_vector();
		obj.getVar("count").push_vector(count);
		obj.getVar("size").clear_vector();
		obj.getVar("size").push_vector(sizerate);
		local UniqueId = sq_GetUniqueId(obj);
		obj.getVar("count").push_vector(UniqueId);
		obj.sendStateOnlyPacket(10);
		obj.flushSetStatePacket();
		if(type == 1)
		{
			sq_setCurrentAxisPos(obj, 0, sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -90));
			sq_setCurrentAxisPos(obj, 2, 80);
		}
		if(type == 2)
		{
			sq_setCurrentAxisPos(obj, 0, sq_GetDistancePos(obj.getXPos(), obj.getDirection(), -90));
			sq_setCurrentAxisPos(obj, 2, receiveData.readDword() + 65);
		}
	}
}

function onAttack_po_ATWindStrike(obj, damager, boundingBox, isStuck)
{
	if (!obj) return;
	local parentObj = obj.getTopCharacter();
	parentObj = sq_ObjectToSQRCharacter(parentObj);
	local type = obj.getVar("power").get_vector(0);
	local state = obj.getVar("state").get_vector(0);
	if(state == 100 || state == 101)
	{
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, parentObj, -1, false, "character/swordman/wave/ap_icewavehold.nut", true);
		local currentAni = sq_GetCurrentAnimation(obj);
		local currentT = sq_GetCurrentTime(currentAni);
		local maxT =  obj.getVar("icewave").get_vector(6) - currentT;
		if(appendage)
		{
		appendage.sq_SetValidTime(maxT + 200);
		}
	}
}

function procAppend_po_ATWindStrike(obj)
{
	if (!obj) return;
	local parentObj = obj.getTopCharacter();
	parentObj = sq_ObjectToSQRCharacter(parentObj);
	local type = obj.getVar("power").get_vector(0);
	local state = obj.getVar("state").get_vector(0);
	local pAni = obj.getCurrentAnimation();
	local currentT = sq_GetCurrentTime(pAni);
	local frameindex = sq_GetAnimationFrameIndex(pAni);
	if(type == -13)
	{
		if(obj.getVar("power").get_vector(1) == 0 && frameindex >= 4)
		{
			locakonhit(obj, "passiveobject/skillre/fighter/animation/hiddensting/lv95poisonspirit/hiddenstingground_00.ani", 0, -1, 0, 0, 150, 1, 2, 1.0, 0);
			obj.getVar("power").set_vector(1, 1);
		}
	}
	if(type == -16)
	{
		if(obj.getVar("flag").get_vector(0) == 0)
		{
			if(frameindex >= 6)
			{
				locakonhit(obj, "passiveobject/character/mage/animation/megadrill/fail/megadrillfailstartbottom.ani", 0, 0, 0, 0, sq_GetIntData(parentObj, 104, 28), 0, 2, 1.0, 0);
				locakonhit(obj, "character/mage/effect/animation/megadrill/newmegadrilltwist_01.ani", 0, 1, 0, 0, sq_GetIntData(parentObj, 104, 28), 1, 2, 1.0, 0);
				obj.sq_PlaySound("MEGA_DRILL_DIG");
				local pAni = sq_GetCurrentAnimation(obj);
				local delay = pAni.getDelaySum(6, 17);
				local count = 10;
				obj.setTimeEvent(1, delay / count, count, false);
				local appendage = CNSquirrelAppendage.sq_AppendAppendage(parentObj, obj, 104, false, "Character/ATMage/DarknessMantle/ap_ATDarknessMantle_suck.nut", false);
				local suckVel = 450;
				local range = 250 * sq_GetIntData(parentObj, 104, 28) / 100;
				if(appendage)
				{
					CNSquirrelAppendage.sq_Append(appendage, parentObj, obj);
					local auraAppendage = appendage.sq_getAuraMaster("auraMaster");
					if(!auraAppendage)
						auraAppendage = appendage.sq_AddAuraMaster("auraMaster", parentObj, obj, 1200, 18, 5, 0);
					if(auraAppendage)
					{
						auraAppendage.setAttractionInfo(suckVel, suckVel, range, 100);
					}
				}
				obj.getVar("flag").set_vector(0, 1);
			}
		}
		if(obj.getVar("flag").get_vector(1) == 0)
		{
			if(frameindex >= 29)
			{
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(0);
				sq_BinaryWriteDword(-17);
				sq_SendCreatePassiveObjectPacket(obj, 24201, 0, 0, 1, 0, obj.getDirection());
				obj.getVar("flag").set_vector(1, 1);
			}
		}
	}
	if(type == -19)
	{
		if(obj.getVar("flag").get_vector(0) == 0)
		{
			if(frameindex >= 15)
			{
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(0);
				sq_BinaryWriteDword(-20);
				sq_SendCreatePassiveObjectPacket(obj, 24201, 0, 0, 1, 0, obj.getDirection());
				local pAni = sq_GetCurrentAnimation(obj);
				local delay = pAni.getDelaySum(15, 37);
				local count = sq_GetIntData(parentObj, 106, 18);
				obj.setTimeEvent(1, delay / count, count, false);
				obj.sq_SetMaxHitCounterPerObject(count);
				obj.getVar("flag").set_vector(0, 1);
			}
		}
	}
	if(type == -20)
	{
		if(obj.getVar("flag").get_vector(0) == 0)
		{
			if(frameindex >= 3)
			{
				local pAni = sq_GetCurrentAnimation(obj);
				local delay = pAni.getDelaySum(3, 15);
				local count = sq_GetIntData(parentObj, 106, 19);
				obj.setTimeEvent(1, delay / count, count, false);
				obj.sq_SetMaxHitCounterPerObject(count);
				obj.getVar("flag").set_vector(0, 1);
			}
		}
	}
	if(state == 21)
	{
		local maxT = luoxuannianqichang_shijian;
		local srcX = obj.getVar("dis").get_vector(0);
		local dis_x_len = obj.getVar("dis").get_vector(1);
		local v = sq_GetUniformVelocity(0, dis_x_len, currentT, maxT);
		local dstX = sq_GetDistancePos(srcX, obj.getDirection(), v);
		sq_setCurrentAxisPos(obj, 0, dstX);
		if(currentT >= maxT)
		{
			if(obj.isMyControlObject())
			{
				obj.sendStateOnlyPacket(22);
				obj.flushSetStatePacket();
			}
		}
	}
	if(state == 10 && obj.getZPos() <= 0)
	{
		local type = obj.getVar("state").get_vector(2);
		if(type == 1)
		{
			obj.sendStateOnlyPacket(11);
			obj.flushSetStatePacket();
		}
		if(type == 2)
		{
			obj.sendStateOnlyPacket(12);
			obj.flushSetStatePacket();
		}
	}
	if(state == 11)
	{
		local startX = obj.getVar("move").get_vector(0);
		local endX = obj.getVar("move").get_vector(1);
		if(currentT < 120)
		{
			local dstX = sq_GetAccel(startX, endX, currentT, 120 ,true);
			sq_setCurrentAxisPos(obj, 0, dstX);
		}
		else if(currentT >= 120)
		{
			obj.sendStateOnlyPacket(12);
			obj.flushSetStatePacket();
		}
	}
	if (state == 12 && obj.getVar("lockon").get_vector(0) == 1)
	{
		local maxT = 500;
		if(currentT <= maxT)
		{
			local objectManager = obj.getObjectManager();
			for(local i = 0; i < objectManager.getCollisionObjectNumber(); i++)
			{
				local Enemy = objectManager.getCollisionObject(i);
				local dis = sq_GetDistanceObject(obj, Enemy, false);
				local disrate = 320 * (obj.getVar("size").get_vector(0).tofloat() / 100);
				if(Enemy
					&& obj.isEnemy(Enemy)
					&& Enemy.isObjectType(OBJECTTYPE_ACTIVE)
					&& Enemy.isInDamagableState(obj))
				{
					if(dis <= disrate && !obj.getVar("lockon").is_obj_vector(Enemy))
					{
						obj.getVar("lockon").push_obj_vector(Enemy);
						LockOn(Enemy, obj, "passiveobject/skillre/atgunner/animation/lockonsupport/target/lockonsupport_targetmarka_start_eff01.ani", 0, 0, 78, 0, 100, 1, 1, 1.0);
						LockOn(Enemy, obj, "passiveobject/skillre/atgunner/animation/lockonsupport/target/lockonsupport_targetmarka_loop_eff01.ani", 0, 0, 78, 0, 100, 1, 1, 1.0);
						Enemy = sq_GetCNRDObjectToActiveObject(Enemy);
						Enemy.getVar("count" + obj.getVar("count").get_vector(1)).clear_vector();
						Enemy.getVar("count" + obj.getVar("count").get_vector(1)).push_vector(obj.getVar("count").get_vector(0));
					}
				}
			}
		}
		if(obj.getVar("lockon").get_obj_vector_size() > 0 && obj.getVar("lockon").get_vector(1) == 0 && currentT > maxT)
		{
			local count = obj.getVar("count").get_vector(0);
			local delay = pAni.getDelaySum(4, 10);
			obj.setTimeEvent(0, 10 / obj.getVar("lockon").get_obj_vector_size(), 999999999, true);
			obj.getVar("lockon").set_vector(1, 1);
			obj.getVar("state").set_vector(1, 1);
		}
		if(obj.getVar("lockon").get_obj_vector_size() <= 0 && obj.getVar("state").get_vector(1) == 1)
		{
			sq_SendDestroyPacketPassiveObject(obj);
		}
	}
	if(state == 100)
	{
		if(frameindex >= 2)
		{
			obj.sendStateOnlyPacket(101);
			obj.flushSetStatePacket();
		}
		local maxCount = obj.getVar("icewave").get_vector(1);
		local currCount =  obj.getVar("icewave").get_vector(2);
		local disx =  obj.getVar("icewave").get_vector(3);
		local disy =  obj.getVar("icewave").get_vector(4);
		local size =  obj.getVar("icewave").get_vector(5);
		local maxT =  obj.getVar("icewave").get_vector(6);
		local currentAni = sq_GetCurrentAnimation(obj);
		local currentT = sq_GetCurrentTime(currentAni);
		if(currentT >= sq_GetIntData(parentObj, 100, 0) && obj.getVar("flag").get_vector(0) == 0)
		{
			obj.getVar("flag").set_vector(0, 1);
			if (maxCount > currCount)
			{
				if(!obj.isMyControlObject()) return false;
				local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disx);
				sq_BinaryStartWrite();
				sq_BinaryWriteDword(obj.getVar("power").get_vector(1));
				sq_BinaryWriteDword(-14);
				sq_BinaryWriteDword(obj.getVar("power").get_vector(2));
				sq_BinaryWriteDword(maxCount);
				sq_BinaryWriteDword(currCount + 1);
				sq_BinaryWriteDword(disx);
				sq_BinaryWriteDword(disy);
				sq_BinaryWriteDword(size);
				sq_BinaryWriteDword(maxT);
				sq_SendCreatePassiveObjectPacketPos(obj,24201, 0, posX , obj.getYPos() + disy, obj.getZPos());
			}
		}
	}
	if(state == 101 && currentT >= obj.getVar("icewave").get_vector(6))
	{
		obj.sendStateOnlyPacket(102);
		obj.flushSetStatePacket();
	}
	if(type == -15)
	{
		if(sq_GetObjectTime(obj) > obj.getVar("pauseTime").get_vector(0) && !obj.getVar("state").get_vector(0))
		{
			obj.sendStateOnlyPacket(45);
			obj.flushSetStatePacket();
			obj.getVar("state").clear_vector();
			obj.getVar("state").push_vector(45);
		}
	}
	if(state == 45)
	{
		local startX = obj.getVar("pos").get_vector(0);
		local startY = obj.getVar("pos").get_vector(1);
		local startZ = obj.getVar("pos").get_vector(2);
		local endX = obj.getVar("pos").get_vector(3);
		local endY = obj.getVar("pos").get_vector(4);
		local time = obj.getVar("pos").get_vector(5);
		local v = sq_GetUniformVelocity(0, endX, currentT - obj.getVar("state").get_vector(1), time, false);
		local dstX = sq_GetDistancePos(startX, obj.getDirection(), v);
		sq_setCurrentAxisPos(obj, 0, dstX);
		local dstY = sq_GetUniformVelocity(startY, endY, currentT - obj.getVar("state").get_vector(1), time, false);
		sq_setCurrentAxisPos(obj, 1, dstY);
		local dstZ = sq_GetAccel(startZ, 0, currentT - obj.getVar("state").get_vector(1), time, false);
		sq_setCurrentAxisPos(obj, 2, dstZ);
		if(obj.getZPos() == 0)
		{
			obj.sendStateOnlyPacket(46);
			obj.flushSetStatePacket();
		}
	}
}

function onSendAttack_LockOn(obj, damager, passiveObject)
{
	local targetObj = sq_GetCNRDObjectToActiveObject(damager);
	if(passiveObject && targetObj)
	if(!targetObj.isDead())
	{
		sq_SetCurrentAttackBonusRate(sq_GetCurrentAttackInfo(passiveObject), obj.getVar("attackBonusRate").get_vector(0));
		if(passiveObject.isMyControlObject())
			sq_SendHitObjectPacket(passiveObject, targetObj, 0, 0, 78);
	}
}

function onTimeEvent_po_ATWindStrike(obj, timeEventIndex, timeEventCount)
{
	if(!obj) return;
	if(timeEventIndex == 0)
	{
		local count = obj.getVar("count").get_vector(0);
		for(local i = 0; i < obj.getVar("lockon").get_obj_vector_size(); i++)
		{
			local Enemy = sq_GetCNRDObjectToActiveObject(obj.getVar("lockon").get_obj_vector(sq_getRandom(0, obj.getVar("lockon").get_obj_vector_size())));
			if(Enemy)
			{
				local xPos = sq_GetXPos(Enemy);
				local yPos = sq_GetYPos(Enemy);
				local zPos = sq_GetZPos(Enemy);
				locakonhit(Enemy, "passiveobject/skillre/atgunner/animation/lockonsupport/lockonsupport_hit0"+ sq_getRandom(1, 5) +"_eff01.ani", 0, 1, 78, 0, 100, 1, 1, 1.0, sq_getRandom(0, 1));
				onSendAttack_LockOn(obj, Enemy, obj);
				obj.sq_PlaySound("SNIPING_SHOT");
				sq_SetMyShake(obj,5,150);
				Enemy.getVar("count" + obj.getVar("count").get_vector(1)).set_vector(0, Enemy.getVar("count" + obj.getVar("count").get_vector(1)).get_vector(0) - 1);
				if(Enemy.getVar("count" + obj.getVar("count").get_vector(1)).get_vector(0) == 0)
				{
					obj.getVar("lockon").remove_obj_vector(Enemy);
					RemovelockonAni(Enemy, obj);
					locakonhit(Enemy, "passiveobject/skillre/atgunner/animation/lockonsupport/target/lockonsupport_targetmarka_end_eff01.ani", 0, 1, 78, 0, 100, 1, 1, 1.0, 0);
				}
			}
		}
	}
	if(timeEventIndex == 1)
	{
		obj.resetHitObjectList();
	}
}

function setState_po_ATWindStrike(obj, state, datas)
{
	if(!obj) return;
	local parentObj = obj.getTopCharacter();
	parentObj = sq_ObjectToSQRCharacter(parentObj);
	obj.getVar("state").set_vector(0, state);
	local state = obj.getVar("state").get_vector(0);
	if(state == 10)
	{
		local type = obj.getVar("state").get_vector(2);
		if(type == 1)
			obj.sq_SetMoveParticle("particle/grenadecenter.ptl", 0.0, 0.0);
		if(type == 2)
			obj.sq_SetMoveParticle("particle/grenadejump.ptl", 0.0, 0.0);
		obj.sq_PlaySound("THROW_GRENADE_LOOP", 24201);
		obj.sq_PlaySound("D_DAY_READY");
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/lockonsupport/lockonsupport_grenade_lockonrolling01.ani"));
	}else if (state == 11)
	{
		obj.stopSound(24201);
		obj.sq_RemoveMoveParticle();
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/lockonsupport/lockonsupport_grenade_lockonrolling01.ani"));
		local endx = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 20);
		obj.getVar("move").clear_vector();
		obj.getVar("move").push_vector(obj.getXPos());
		obj.getVar("move").push_vector(endx);
	}else if (state == 12)
	{
		obj.stopSound(24201);
		local attackInfo = sq_GetCustomAttackInfo(obj, 0);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetChangeStatusIntoAttackInfo(attackInfo, 0, ACTIVESTATUS_STUN, obj.getVar("Status").get_vector(0), obj.getVar("Status").get_vector(1), obj.getVar("Status").get_vector(2));
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/atgunner/animation/lockonsupport/lockonsupport_readya_grenadb01.ani"));
		obj.getVar("lockon").clear_vector();
		obj.getVar("lockon").push_vector(0);
		obj.getVar("lockon").push_vector(0);
		obj.getVar("lockon").clear_obj_vector();
	}else if(state == 20)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/fighter/animation/energyfield.ani"));
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 1);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, obj.getVar("attackBonusRate").get_vector(0));
		local skill_level = sq_GetSkillLevel(parentObj, 16);
		local proc = sq_GetLevelData(parentObj, 16, 1, skill_level) / 10;
		local lv = sq_GetLevelData(parentObj, 16, 2, skill_level);
		local time = sq_GetLevelData(parentObj, 16, 5, skill_level);
		local damage = sq_GetLevelData(parentObj, 16, 6, skill_level);
		sq_SetChangeStatusIntoAttackInfo(attackInfo, 0, ACTIVESTATUS_LIGHTNING , proc, lv, time, damage);
		local sizeRate = obj.getVar("attackBonusRate").get_vector(1);
			sizeRate = sizeRate.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setImageRateFromOriginal(sizeRate, sizeRate);
		currentAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
	}else if(state == 21)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/fighter/animation/energyfieldtalismanloop_00.ani"));
		local x = sq_GetXPos(obj);
		obj.getVar("dis").clear_vector();
		obj.getVar("dis").push_vector(x);
		obj.getVar("dis").push_vector(luoxuannianqichang_juli);
		local sizeRate = obj.getVar("attackBonusRate").get_vector(1);
			sizeRate = sizeRate.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setImageRateFromOriginal(sizeRate, sizeRate);
		currentAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
		sq_SetMyShake(obj, 8, 300);
	}else if(state == 22)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/fighter/animation/energyfieldtalismanend_00.ani"));
		local sizeRate = obj.getVar("attackBonusRate").get_vector(1);
			sizeRate = sizeRate.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setImageRateFromOriginal(sizeRate, sizeRate);
		currentAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
	}else if(state == 100)
	{
		local type = obj.getVar("icewave").get_vector(2) % 6;
		type = type + 1;
		local ani = "null";
		ani = "passiveobject/skillre/swordman/animation/icewaveex/ice_dodge_middle"+type+".ani";
		obj.setCurrentAnimation(sq_CreateAnimation("", ani));
		locakonhit(obj, "passiveobject/skillre/swordman/animation/icewaveex/ice_dust1.ani", 0, -1, 0, 0, 100, 1, 1, 1.0, 0);
		locakonhit(obj, "passiveobject/skillre/swordman/animation/icewaveex/ice_dust2.ani", 0, -1, 0, 0, 100, 1, 1, 1.0, 0);
	}else if(state == 101)
	{
		local type = obj.getVar("icewave").get_vector(2) % 6;
		local ani = "null";
		type = type + 1;
		ani = "passiveobject/skillre/swordman/animation/icewaveex/icewaveex_icepowerup"+type+".ani";
		obj.setCurrentAnimation(sq_CreateAnimation("", ani));
		icewaveEX(obj, "passiveobject/skillre/swordman/animation/lightningpower/icewaveex/icewaveexlightning0"+type+"_icewaveexlightning"+type+"_"+type+".ani", 0, 1, 0, 0, 100, 1, 1, 1.0, "icewave");
		icewaveEX(obj, "passiveobject/skillre/swordman/animation/lightningpower/icewaveex/icewaveexlightning0"+type+"_icewaveexlightning"+type+".ani", 0, 1, 0, 0, 100, 1, 1, 1.0, "icewave");
	}else if(state == 102)
	{
		RemoveicewaveEX(obj, "icewave");
		obj.sq_PlaySound("R_SLASH_HIT");
		local ani = "passiveobject/character/swordman/animation/icewaveexiceexplosion.ani";
		obj.setCurrentAnimation(sq_CreateAnimation("", ani));
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 6);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackPower(attackInfo, obj.getVar("power").get_vector(2));
		local size = obj.getVar("icewave").get_vector(5);
		local sizeRate = size.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setImageRateFromOriginal(sizeRate, sizeRate);
		currentAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
		local zpos = 30;
		locakonhit(obj, "passiveobject/character/swordman/animation/icewaveexiceexplosionparticle1.ani", 0, 1, zpos, 0, size, 1, 1, 1.0, 0);
		locakonhit(obj, "passiveobject/character/swordman/animation/icewaveexiceexplosionparticle2.ani", 0, 1, zpos, 0, size, 1, 1, 1.0, 0);
		locakonhit(obj, "passiveobject/character/swordman/animation/icewaveexiceexplosionparticle3.ani", 0, 1, zpos, 0, size, 1, 1, 1.0, 0);
		locakonhit(obj, "passiveobject/character/swordman/animation/icewaveexiceexplosionparticle4.ani", 0, 1, zpos, 0, size, 1, 1, 1.0, 0);
		sq_SetMyShake(obj, 7, 100);
	}
	else if(state == 45)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/gunner/animation/uraniumbomb/biguraniumbomb/missile.ani"));
		local sizeRate = 100;
			sizeRate = sizeRate.tofloat() / 100.0 * 0.65;
		local currentAni = sq_GetCurrentAnimation(obj);
		currentAni.setImageRateFromOriginal(sizeRate, sizeRate);
	}
	else if(state == 46)
	{
		obj.setCurrentAnimation(sq_CreateAnimation("", "passiveobject/skillre/gunner/animation/uraniumbomb/minibomb/attackbox.ani"));
		sq_SetCurrentAttackInfoFromCustomIndex(obj, 7);
		obj.sq_PlaySound("R_BOMB");
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		local power = parentObj.sq_GetPowerWithPassive(45, -1, 0, -1, 0.15) + parentObj.sq_GetPowerWithPassive(45, -1, 6, -1, 0.15);
		sq_SetCurrentAttackPower(attackInfo, power);
		local skill_level = sq_GetSkillLevel(parentObj, 45);
		local proc = sq_GetLevelData(parentObj, 45, 1, skill_level) / 10;
		local lv = sq_GetLevelData(parentObj, 45, 2, skill_level);
		local time = sq_GetLevelData(parentObj, 45, 3, skill_level);
		local damage = sq_GetLevelData(parentObj, 45, 4, skill_level);
		sq_SetChangeStatusIntoAttackInfo(attackInfo, 0, 6 , proc, lv, time, damage);
		local size = sq_GetIntData(parentObj, 45, 8);
		local sizeRate = size.tofloat() / 100.0;
		local currentAni = sq_GetCurrentAnimation(obj);
		sq_SetAttackBoundingBoxSizeRate(currentAni, sizeRate, sizeRate, sizeRate);
		locakonhit(obj, "passiveobject/skillre/gunner/animation/uraniumbomb/biguraniumbomb/cloud_dodge.ani", 0, 1, 0, 0, size.tointeger(), 0, 1, 1.4, 0);
		locakonhit(obj, "passiveobject/skillre/gunner/animation/uraniumbomb/biguraniumbomb/middle_exp.ani", 0, 2, 0, 0, size.tointeger(), 0, 1, 1.0, 0);
		locakonhit(obj, "passiveobject/skillre/gunner/animation/uraniumbomb/floor_dodge.ani", 0, 0, 0, 0, size.tointeger(), 0, 2, 1.0, 0);
		locakonhit(obj, "passiveobject/skillre/gunner/animation/uraniumbomb/floor_normal.ani", 0, 0, 0, 0, size.tointeger(), 0, 2, 1.0, 0);
		sq_SetMyShake(obj, 5, 200);
	}
}

function onKeyFrameFlag_po_ATWindStrike(obj, flagIndex)
{
	if (!obj) return;
	local parentObj = obj.getTopCharacter();
	parentObj = sq_ObjectToSQRCharacter(parentObj);
	local state = obj.getVar("state").get_vector(0);
	if(state == 12)
	{
		obj.getVar("lockon").set_vector(0, 1);
		locakonhit(obj, "passiveobject/skillre/atgunner/animation/lockonsupport/lockonsupport_readyb_floor_eff02.ani", 0, -1, 0, 0, obj.getVar("size").get_vector(0), 1, 2, 1.0, 0);
		locakonhit(obj, "passiveobject/skillre/atgunner/animation/lockonsupport/lockonsupport_readyb_eff01.ani", 0, -1, 0, 0, obj.getVar("size").get_vector(0), 1, 2, 1.0, 0);
		locakonhit(obj, "passiveobject/skillre/atgunner/animation/lockonsupport/lockonsupport_readyb_back_eff01.ani", 0, -1, 0, 0, obj.getVar("size").get_vector(0), 1, 2, 1.0, 0);
	}
	return true;
}

function onEndCurrentAni_po_ATWindStrike(obj)
{
	if(!obj) return;
	local parentObj = obj.getTopCharacter();
	parentObj = sq_ObjectToSQRCharacter(parentObj);
	local type = obj.getVar("power").get_vector(0);
	local state = obj.getVar("state").get_vector(0);
	if(obj.isMyControlObject())
	{

		if(state == 100)
		{
			obj.sendStateOnlyPacket(101);
			obj.flushSetStatePacket();
		}
		if(state == 102)
		{
			sq_SendDestroyPacketPassiveObject(obj);
		}
		if(state == 46)
		{
			sq_SendDestroyPacketPassiveObject(obj);
		}
		if(state == 20)
		{
			obj.sendStateOnlyPacket(21);
			obj.flushSetStatePacket();
			local parentState = obj.sq_GetParentState();
			if(parentState != 0)
				parentObj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
		if(state == 22)
		{
			sq_SendDestroyPacketPassiveObject(obj);
		}
		if(state == 12 && obj.getVar("state").get_vector(1) == 0)
		{
			sq_SendDestroyPacketPassiveObject(obj);
		}
		if(type == -18)
		{
			sq_BinaryStartWrite();
			sq_BinaryWriteDword(0);
			sq_BinaryWriteDword(-16);
			sq_SendCreatePassiveObjectPacket(parentObj, 24201, 0, 200, 1, 0, obj.getDirection());
			sq_SendDestroyPacketPassiveObject(obj);
		}else
		if(state < 10)
			sq_SendDestroyPacketPassiveObject(obj);
	}
}


function LockOn(obj, obj1,aniFilename, disX, disY, disZ, imgangle, imgRate, Parent, layer, SpeedRate)
{
	local angle = imgangle;
	local ani = sq_CreateAnimation("", aniFilename);
	sq_SetfRotateAngle(ani, sq_ToRadian(-angle.tofloat()));
	local sizeRate = imgRate;
	local size = sizeRate.tofloat() / 100.0;
	ani.setImageRateFromOriginal(size, size);
	ani.setAutoLayerWorkAnimationAddSizeRate(size);
	ani.setSpeedRate(100.0 * SpeedRate);
	local pooledObj = sq_CreatePooledObject(ani, true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	if(Parent == 1)
	{
		sq_moveWithParent(obj, pooledObj);
	}
	sq_SetEnumDrawLayer(pooledObj, layer);
	sq_AddObject(obj, pooledObj, 2, false);
	obj.getVar("aniobj" + obj1.getVar("count").get_vector(1)).push_obj_vector(pooledObj);
}

function RemovelockonAni(obj, obj1)
{
	local AniObjVar  = obj.getVar("aniobj" + obj1.getVar("count").get_vector(1));
	local AniCount = AniObjVar.get_obj_vector_size();
	for(local i=0;i<AniCount;i++)
	{
		local aniobj = AniObjVar.get_obj_vector(i);
		if(aniobj)
			aniobj.setValid(false);
	}
	obj.getVar("aniobj" + obj1.getVar("count").get_vector(1)).clear_obj_vector();
}

function locakonhit(obj, aniFilename, disX, disY, disZ, imgangle, imgRate, Parent, layer, SpeedRate, Direction)
{
	local angle = imgangle;
	local ani = sq_CreateAnimation("", aniFilename);
	sq_SetfRotateAngle(ani, sq_ToRadian(-angle.tofloat()));
	local sizeRate = imgRate;
	local size = sizeRate.tofloat() / 100.0;
	ani.setImageRateFromOriginal(size, size);
	ani.setAutoLayerWorkAnimationAddSizeRate(size);
	ani.setSpeedRate(100.0 * SpeedRate);
	local pooledObj = sq_CreatePooledObject(ani, true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	if(Direction == 0)
		pooledObj.setCurrentDirection(obj.getDirection());
	if(Direction == 1)
		pooledObj.setCurrentDirection(sq_GetOppositeDirection(sq_GetDirection(obj)));
	if(Parent == 1)
	{
		sq_moveWithParent(obj, pooledObj);
	}
	sq_SetEnumDrawLayer(pooledObj, layer);
	sq_AddObject(obj, pooledObj, 2, false);
}

function icewaveEX(obj, aniFilename, disX, disY, disZ, imgangle, imgRate, Parent, layer, SpeedRate, var)
{
	local angle = imgangle;
	local ani = sq_CreateAnimation("", aniFilename);
	sq_SetfRotateAngle(ani, sq_ToRadian(-angle.tofloat()));
	local sizeRate = imgRate;
	local size = sizeRate.tofloat() / 100.0;
	ani.setImageRateFromOriginal(size, size);
	ani.setAutoLayerWorkAnimationAddSizeRate(size);
	ani.setSpeedRate(100.0 * SpeedRate);
	local pooledObj = sq_CreatePooledObject(ani, true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX, obj.getYPos() + disY, obj.getZPos() + disZ);
	if(Parent == 1)
	{
		sq_moveWithParent(obj, pooledObj);
	}
	sq_SetEnumDrawLayer(pooledObj, layer);
	sq_AddObject(obj, pooledObj, 2, false);
	obj.getVar(var).push_obj_vector(pooledObj);
}

function RemoveicewaveEX(obj, var)
{
	local AniObjVar  = obj.getVar(var);
	local AniCount = AniObjVar.get_obj_vector_size();
	for(local i=0;i<AniCount;i++)
	{
		local aniobj = AniObjVar.get_obj_vector(i);
		if(aniobj)
			aniobj.setValid(false);
	}
	obj.getVar(var).clear_obj_vector();
}
