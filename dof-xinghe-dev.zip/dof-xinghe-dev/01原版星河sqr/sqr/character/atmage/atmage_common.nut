
function procSkill_ATMage_erjuebeidong(obj)
{
	if (sq_getGrowType(obj) == 1) 	
	{
	    	local skill_level1 = sq_GetSkillLevel(obj, SKILL_DARKEYE);
		if(skill_level1 > 0)
		{
		        if (!CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atmage/darkeye/ap_darkeye.nut") )
		        {
		            local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, SKILL_DARKEYE, false, "character/atmage/darkeye/ap_darkeye.nut", true);
		
		            appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), SKILL_DARKEYE, skill_level1);
		            CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, SKILL_DARKEYE, true);
		        }
		        local count = obj.getMyPassiveObjectCount(24227);
			for(local i=0;i<count;++i)
			{
				local object = obj.getMyPassiveObject(24227, i);
				if(!object) continue;
				local fanwei = sq_GetIntData(obj, 18, 0);
				local skillLevel = sq_GetSkillLevel(obj, SKILL_DARKEYE);
				local dRange = sq_GetLevelData(obj, SKILL_DARKEYE, 2, skillLevel);
				local sizeRate = fanwei+dRange;
				sizeRate = sizeRate.tofloat()/100.0;
				local pAni = object.getCurrentAnimation();
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
				if(!object.getVar("isSetCharacterStand").getBool(0))
				{
					object.getVar("isSetCharacterStand").setBool(0,true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
			local count = obj.getMyPassiveObjectCount(30576);
			for(local i=0;i<count;++i)
			{
				local object = obj.getMyPassiveObject(30576, i);
				if(!object) continue;
				local fanwei = sq_GetIntData(obj, 18, 0);
				local skillLevel = sq_GetSkillLevel(obj, SKILL_DARKEYE);
				local dRange = sq_GetLevelData(obj, SKILL_DARKEYE, 2, skillLevel);
				local sizeRate = fanwei+dRange;
				sizeRate = sizeRate.tofloat()/100.0;
				local pAni = object.getCurrentAnimation();
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
				if(!object.getVar("isSetCharacterStand").getBool(0))
				{
					object.getVar("isSetCharacterStand").setBool(0,true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
			local count = obj.getMyPassiveObjectCount(24225);
			for(local i=0;i<count;++i)
			{
				local object = obj.getMyPassiveObject(24225, i);
				if(!object) continue;
				local fanwei = sq_GetIntData(obj, 14, 0);
				local skillLevel = sq_GetSkillLevel(obj, SKILL_DARKEYE);
				local dRange = sq_GetLevelData(obj, SKILL_DARKEYE, 2, skillLevel);
				local sizeRate = fanwei+dRange*3/2;
				sizeRate = sizeRate.tofloat()/100.0;
				local pAni = object.getCurrentAnimation();
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
				if(!object.getVar("isSetCharacterStand").getBool(0))
				{
					object.getVar("isSetCharacterStand").setBool(0,true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
			local count = obj.getMyPassiveObjectCount(24226);
			for(local i=0;i<count;++i)
			{
				local object = obj.getMyPassiveObject(24226, i);
				if(!object) continue;
				local skillLevel = sq_GetSkillLevel(obj, SKILL_DARKEYE);
				local dRange = sq_GetLevelData(obj, SKILL_DARKEYE, 2, skillLevel);
				local sizeRate = 100+dRange;
				sizeRate = sizeRate.tofloat()/100.0;
				local pAni = object.getCurrentAnimation();
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
				if(!object.getVar("isSetCharacterStand").getBool(0))
				{
					object.getVar("isSetCharacterStand").setBool(0,true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
			local count = obj.getMyPassiveObjectCount(24212);
			for(local i=0;i<count;++i)
			{
				local object = obj.getMyPassiveObject(24212, i);
				if(!object) continue;
				local fanwei = sq_GetIntData(obj, 6, 5);
				local skillLevel = sq_GetSkillLevel(obj, SKILL_DARKEYE);
				local dRange = sq_GetLevelData(obj, SKILL_DARKEYE, 2, skillLevel);
				local sizeRate = fanwei+dRange;
				sizeRate = sizeRate.tofloat()/100.0;
				local pAni = object.getCurrentAnimation();
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
				if(!object.getVar("isSetCharacterStand").getBool(0))
				{
					object.getVar("isSetCharacterStand").setBool(0,true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
			local count = obj.getMyPassiveObjectCount(24213);
			for(local i=0;i<count;++i)
			{
				local object = obj.getMyPassiveObject(24213, i);
				if(!object) continue;
				local fanwei = sq_GetIntData(obj, 6, 5);
				local skillLevel = sq_GetSkillLevel(obj, SKILL_DARKEYE);
				local dRange = sq_GetLevelData(obj, SKILL_DARKEYE, 2, skillLevel);
				local sizeRate = fanwei+dRange;
				sizeRate = sizeRate.tofloat()/100.0;
				local pAni = object.getCurrentAnimation();
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
				if(!object.getVar("isSetCharacterStand").getBool(0))
				{
					object.getVar("isSetCharacterStand").setBool(0,true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
			local count = obj.getMyPassiveObjectCount(24218);
			for(local i=0;i<count;++i)
			{
				local object = obj.getMyPassiveObject(24218, i);
				if(!object) continue;
				local fanwei = sq_GetIntData(obj, 29, 0);
				local skillLevel = sq_GetSkillLevel(obj, SKILL_DARKEYE);
				local dRange = sq_GetLevelData(obj, SKILL_DARKEYE, 2, skillLevel);
				local sizeRate = fanwei+dRange;
				sizeRate = sizeRate.tofloat()/100.0;
				local pAni = object.getCurrentAnimation();
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
				if(!object.getVar("isSetCharacterStand").getBool(0))
				{
					object.getVar("isSetCharacterStand").setBool(0,true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
		}
		local skill_level2 = sq_GetSkillLevel(obj, SKILL_ICECRAFT);
		if(skill_level2 > 0)
		{
		        if (!CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atmage/icecraft/ap_icecraft.nut") )
		        {
		            local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, SKILL_ICECRAFT, false, "character/atmage/icecraft/ap_icecraft.nut", true);
		
		            appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), SKILL_ICECRAFT, skill_level2);
		            CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, SKILL_ICECRAFT, true);
		        }
		}
	}
	if (sq_getGrowType(obj) == 2) 	
	{
		local count = obj.getMyPassiveObjectCount(24237);
		for(local i=0;i<count;++i)
		{
			local object = obj.getMyPassiveObject(24237, i);
			if(!object) continue;
			local skillLevel = sq_GetSkillLevel(obj, SKILL_ICECRAFT);
			local dRange = sq_GetLevelData(obj, SKILL_ICECRAFT, 1, skillLevel);
			local sizeRate = 100+dRange;
			sizeRate = sizeRate.tofloat()/100.0;
			local pAni = object.getCurrentAnimation();
			pAni.setImageRateFromOriginal(sizeRate, sizeRate);
			pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
			if(!object.getVar("isSetCharacterStand").getBool(0))
			{
				object.getVar("isSetCharacterStand").setBool(0,true);
				sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
			}
		}
		local count = obj.getMyPassiveObjectCount(24235);
		for(local i=0;i<count;++i)
		{
			local object = obj.getMyPassiveObject(24235, i);
			if(!object) continue;
			local skillLevel = sq_GetSkillLevel(obj, SKILL_ICECRAFT);
			local dRange = sq_GetLevelData(obj, SKILL_ICECRAFT, 1, skillLevel);
			local sizeRate = 100+dRange;
			sizeRate = sizeRate.tofloat()/100.0;
			local pAni = object.getCurrentAnimation();
			pAni.setImageRateFromOriginal(sizeRate, sizeRate);
			pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
			if(!object.getVar("isSetCharacterStand").getBool(0))
			{
				object.getVar("isSetCharacterStand").setBool(0,true);
				sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
			}
		}
		local count = obj.getMyPassiveObjectCount(24236);
		for(local i=0;i<count;++i)
		{
			local object = obj.getMyPassiveObject(24236, i);
			if(!object) continue;
			local skillLevel = sq_GetSkillLevel(obj, SKILL_ICECRAFT);
			local dRange = sq_GetLevelData(obj, SKILL_ICECRAFT, 1, skillLevel);
			local sizeRate = 100+dRange;
			sizeRate = sizeRate.tofloat()/100.0;
			local pAni = object.getCurrentAnimation();
			pAni.setImageRateFromOriginal(sizeRate, sizeRate);
			pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
			if(!object.getVar("isSetCharacterStand").getBool(0))
			{
				object.getVar("isSetCharacterStand").setBool(0,true);
				sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
			}
		}
		local count = obj.getMyPassiveObjectCount(24255);
		for(local i=0;i<count;++i)
		{
			local object = obj.getMyPassiveObject(24255, i);
			if(!object) continue;
			local skillLevel = sq_GetSkillLevel(obj, SKILL_ICECRAFT);
			local dRange = sq_GetLevelData(obj, SKILL_ICECRAFT, 1, skillLevel);
			local sizeRate = 100+dRange;
			sizeRate = sizeRate.tofloat()/100.0;
			local pAni = object.getCurrentAnimation();
			pAni.setImageRateFromOriginal(sizeRate, sizeRate);
			pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
			if(!object.getVar("isSetCharacterStand").getBool(0))
			{
				object.getVar("isSetCharacterStand").setBool(0,true);
				sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
			}
		}
		local count = obj.getMyPassiveObjectCount(24224);
		for(local i=0;i<count;++i)
		{
			local object = obj.getMyPassiveObject(24224, i);
			if(!object) continue;
			local skillLevel = sq_GetSkillLevel(obj, SKILL_ICECRAFT);
			local dRange = sq_GetLevelData(obj, SKILL_ICECRAFT, 1, skillLevel);
			local sizeRate = 100+dRange;
			sizeRate = sizeRate.tofloat()/100.0;
			local pAni = object.getCurrentAnimation();
			pAni.setImageRateFromOriginal(sizeRate, sizeRate);
			pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
			if(!object.getVar("isSetCharacterStand").getBool(0))
			{
				object.getVar("isSetCharacterStand").setBool(0,true);
				sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
			}
		}
		local count = obj.getMyPassiveObjectCount(24223);
		for(local i=0;i<count;++i)
		{
			local object = obj.getMyPassiveObject(24223, i);
			if(!object) continue;
			local skillLevel = sq_GetSkillLevel(obj, SKILL_ICECRAFT);
			local dRange = sq_GetLevelData(obj, SKILL_ICECRAFT, 1, skillLevel);
			local sizeRate = 100+dRange;
			sizeRate = sizeRate.tofloat()/100.0;
			local pAni = object.getCurrentAnimation();
			pAni.setImageRateFromOriginal(sizeRate, sizeRate);
			pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
			if(!object.getVar("isSetCharacterStand").getBool(0))
			{
				object.getVar("isSetCharacterStand").setBool(0,true);
				sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
			}
		}
	}
}

function destroyObject(obj)
{
	local objListSize = obj.getVar().get_obj_vector_size();
	for(local i =0;i<objListSize;++i)
	{
		local vObj = obj.getVar().get_obj_vector(i);
		if(vObj == null)
			continue;
			
		vObj.setValid(false);
	}
	
	obj.getVar().clear_obj_vector();
	
}

function destroyObjectByVar(obj, varStr)
{
	local objListSize = obj.getVar(varStr).get_obj_vector_size();
	for(local i =0;i<objListSize;++i)
	{
		local vObj = obj.getVar(varStr).get_obj_vector(i);
		if(vObj == null)
			continue;
			
		vObj.setValid(false);
	}
	
	obj.getVar(varStr).clear_obj_vector();
	
}


function getAngle(xPos1, yPos1, xPos2, yPos2)
{
	
	local xDistance = (xPos2 - xPos1);
	local yDistance = (yPos2 - yPos1);

	print(" xDistance:" + xDistance + " yDistance:" + yDistance);
	
	xDistance = sq_Abs(xDistance);
	yDistance = sq_Abs(yDistance);

	
	local radian = sq_Atan2(yDistance.tofloat(), xDistance.tofloat());
	
	
	local angle = sq_ToDegree(radian);
	
	
	
	print(" radian:" + radian + " angle:" + angle);
	return (angle + 360) % 360;
}

function getObjectAngle(orgObj, dstObj)
{
	if(!orgObj || !dstObj)
		return 9999.0;
		
	return getAngle(orgObj.getXPos(), orgObj.getYPos(), dstObj.getXPos(), dstObj.getYPos());
}



function isInFrontObject(orgObj, dstObj)
{ 
	if(orgObj.getDirection() == ENUM_DIRECTION_RIGHT)
	{
		if(orgObj.getXPos() < dstObj.getXPos())
			return true;
	}
	else
	{
		if(orgObj.getXPos() > dstObj.getXPos())
			return true;
	}
	
	return false;
}



function findAngleTarget(obj, distance, angle, targetMaxHeight)
{
	if(!obj)
		return null;
		
	local objectManager = obj.getObjectManager();
	

	if (objectManager == null)
		return null;

	local minDistance = 0;
	local target = null;
	

	for (local i = 0; i < objectManager.getCollisionObjectNumber(); i+=1)
	{
		local object = objectManager.getCollisionObject(i);
		if (object && obj.isEnemy(object) && object.isInDamagableState(obj) && object.isObjectType(OBJECTTYPE_ACTIVE) &&
			isInFrontObject(obj, object) && object.getZPos() <= targetMaxHeight)
		{
			local activeObj = sq_GetCNRDObjectToActiveObject(object);
			
			
			if(!activeObj.isDead())
			{
				
				
				print( " angle:" + getObjectAngle(obj, object));
				if(sq_GetDistanceObject(obj, object, false) < distance && getObjectAngle(obj, object) < angle)
				{
					if (target == null || sq_GetDistanceObject(obj, object, false) < minDistance)
					{
						target = activeObj;
						minDistance = sq_GetDistanceObject(obj, object, false);
					}
				}
			}
		}
	}

	return target;
}




function isSameObjectBySqVar(orgObj, sq_var)
{
	if(!orgObj || !sq_var)
		return false;
	
	local i;
	local object_num = sq_var.get_obj_vector_size();
	
	for(i = 0; i < object_num; i++)
	{ 
		local dstObj = sq_var.get_obj_vector(i);
		
		local isSame = isSameObject(orgObj, dstObj);
		
		if(isSame) 
			return true;
	}
	
	return false;
	
}

function getBossTarget(obj, firstTargetXStartRange, firstTargetXEndRange, firstTargetYRange, targetMaxHeight, exceptSqVar)
{
	if(!obj)
		return null;
		
	local objectManager = obj.getObjectManager();
	

	if (objectManager == null)
		return null;

	
	local target = null;
	

	for (local i = 0; i < objectManager.getCollisionObjectNumber(); i+=1)
	{
		local object = objectManager.getCollisionObject(i);
		if (object && obj.isEnemy(object) && object.isInDamagableState(obj) && object.isObjectType(OBJECTTYPE_ACTIVE) &&
			isInFrontObject(obj, object) && object.getZPos() <= targetMaxHeight )
		{
			if(sq_IsinMapArea(obj, object, firstTargetXStartRange, firstTargetXEndRange, firstTargetYRange))
			{
				local activeObj = sq_GetCNRDObjectToActiveObject(object);
				
				if(!activeObj.isDead())
				{ 
					if(activeObj.isBoss())
					{ 
						local isExist = isSameObjectBySqVar(object, exceptSqVar);
						
						if(!isExist || target == null)
						{
							target = activeObj;
						}
					}
				}
			}
		}
	}

	return target;

}

function getPriorityTarget(obj, firstTargetXStartRange, firstTargetXEndRange, firstTargetYRange, targetMaxHeight, exceptSqVar, isInFront)
{
	if(!obj)
		return null;
		
	local objectManager = obj.getObjectManager();
	

	if (objectManager == null)
		return null;

	
	local target = null;
	

	for (local i = 0; i < objectManager.getCollisionObjectNumber(); i+=1)
	{
		local object = objectManager.getCollisionObject(i);
		if (object && obj.isEnemy(object) && object.isInDamagableState(obj) && object.isObjectType(OBJECTTYPE_ACTIVE) &&
			object.getZPos() <= targetMaxHeight )
		{
			if(isInFront == true)
			{
				if(isInFrontObject(obj, object) == false)
				{
					continue;
				}
			}
			if(sq_IsinMapArea(obj, object, firstTargetXStartRange, firstTargetXEndRange, firstTargetYRange))
			{
				local activeObj = sq_GetCNRDObjectToActiveObject(object);
				
				if(!activeObj.isDead())
				{ 
					local isExist = isSameObjectBySqVar(object, exceptSqVar);
					
					if(activeObj.isBoss())
					{
						if(target == null)
						{
							target = activeObj;
							
							if(!isExist)
								return target;
						}
					}
					
					if(activeObj.isSuperChampion())
					{ 
						if(target == null || !isExist)
						{
							target = activeObj;
							
							if(!isExist)
								return target;
						}
					}
					
					if(activeObj.isCommonChampion())
					{
						if(target == null || !isExist)
						{
							target = activeObj;
							
							if(!isExist)
								return target;
						}
					}
					
					if(activeObj.isChampion())
					{
						if(target == null || !isExist)
						{
							target = activeObj;
							
							if(!isExist)
								return target;
						}
					}
					
					if(target == null || !isExist)
					{
						target = activeObj;
						
						if(!isExist)
							return target;
					}
				}
			}
		}
	}

	return target;

}



function createPaticleMap(obj, filename, x, y, z)
{
	local particleCreater = obj.getVar().GetparticleCreaterMap(filename, filename, obj);
		
	particleCreater.Restart(0);
	particleCreater.SetPos(x, y, z);
	sq_AddParticleObject(obj, particleCreater);
}

function initGetVarTimer(obj, maxTimerNum, eventTerm, eventMaxCount)
{
	if(maxTimerNum <= 0)
		return;
		
	local sq_var = obj.getVar();
	
	sq_var.clear_timer_vector();
	
	for (local i = 0;i < maxTimerNum; i+=1)
	{
		sq_var.push_timer_vector();
	}
	
	for (local i = 0;i < maxTimerNum; i+=1)
	{
		local t = sq_var.get_timer_vector(i);
		t.setParameter(eventTerm, eventMaxCount);
		t.resetInstant(i);
	}

}


function procParticleCreaterMap(obj, currentT, filename, x, y, z)
{
	local t = obj.getVar().get_timer_vector(0);
	
	if(!t)
		return;
	
	if(t.isOnEvent(currentT) == true)
	{
		local particleCreater = obj.getVar().GetparticleCreaterMap(filename, filename, obj);
			
		particleCreater.Restart(0);
		particleCreater.SetPos(x, y, z);
		
		sq_AddParticleObject(obj, particleCreater);
	}
}


function createAnimationPooledObject(obj, aniFilename, isAutoDestroy, x, y, z)
{
	local ani = sq_CreateAnimation("",aniFilename);
	local pooledObj = sq_CreatePooledObject(ani,isAutoDestroy);
	
	pooledObj.setCurrentPos(x,y,z);
	sq_SetCurrentDirection(pooledObj, obj.getDirection());
	
	sq_AddObject(obj, pooledObj, OBJECTTYPE_DRAWONLY, false);
	
	return pooledObj;
}

function createAnimationImageRatePooledObject(obj, aniFilename, isAutoDestroy, widthRate, heightRate, x, y, z)
{
	local ani = sq_CreateAnimation("",aniFilename);
	
	if(!ani)
		return null;
	
	ani.setImageRateFromOriginal(widthRate, heightRate);
	
	local pooledObj = sq_CreatePooledObject(ani,isAutoDestroy);
	
	pooledObj.setCurrentPos(x,y,z);
	sq_SetCurrentDirection(pooledObj, obj.getDirection());
	
	sq_AddObject(obj, pooledObj, OBJECTTYPE_DRAWONLY, false);
	
	return pooledObj;
}



function procSkill_IceRoad(obj)
{
	local appendage = obj.GetSquirrelAppendage("Character/ATMage/IceRoad/ap_ATMage_IceRoad.nut");
	
	if(appendage) {
		local isvalid = appendage.isValid();
		if(isvalid) {
			local currentT = appendage.getTimer().Get();
			local t = appendage.sq_var.get_timer_vector(0);
			local t2 = appendage.sq_var.get_timer_vector(1); 
			
			if (t2.isOnEvent(currentT) == true)
			{
				local skill = sq_GetSkill(obj, SKILL_ICEROAD);
				if(skill)
				{
					local skill_level = obj.sq_GetSkillLevel(SKILL_ICEROAD);
					local spendMp = obj.sq_GetLevelData(SKILL_ICEROAD, SKL_LV_0, skill_level); 
					if (spendMp > obj.getMp())
					{
						appendage.setValid(false);
						skill.setSealActiveFunction(true);
						return;
					}
					else
					{
						
						print( " spendMp:" + spendMp);
						obj.sendSetMpPacket(obj.getMp() - spendMp);
					}
				
				}
			}
			
			if (t.getEventTerm() == -1)
				return;
			
			if (t.isOnEvent(currentT) == true)
			{
				if(obj.isMyControlObject())
				{
					if(obj.getZPos() == 0)
					{
						local skill_level = sq_GetSkillLevel(obj, SKILL_ICEROAD);
						local change_time = sq_GetLevelData(obj, SKILL_ICEROAD, SKL_LV_1, skill_level); 
						local rate = sq_GetLevelData(obj, SKILL_ICEROAD, SKL_LV_3, skill_level); 
						local movSpd = sq_GetLevelData(obj, SKILL_ICEROAD, SKL_LV_2, skill_level); 
					
						sq_BinaryStartWrite();
						sq_BinaryWriteDword(change_time);	
						sq_BinaryWriteDword(rate);			
						sq_BinaryWriteDword(movSpd);		
						
						
						local skillLevel = sq_GetSkillLevel(obj, SKILL_ICEROAD_EX);
						sq_BinaryWriteWord(skillLevel);
						
						if (skillLevel > 0)
						{
							local prob = sq_GetLevelData(obj, SKILL_ICEROAD_EX, 4, skillLevel) / 10.0;
							local asLevel = sq_GetLevelData(obj, SKILL_ICEROAD_EX, 5, skillLevel);	
							local validTime = sq_GetLevelData(obj, SKILL_ICEROAD_EX, 6, skillLevel);	
							sq_BinaryWriteFloat(prob.tofloat());	
							sq_BinaryWriteWord(asLevel);			
							sq_BinaryWriteDword(validTime);			
						}
						
						sq_SendCreatePassiveObjectPacket(obj, 24243, 0, 0, 0, 0, obj.getDirection());
					}
				}
			}
		}
	}
}

function playMoveSound_ATMage(obj)
{
	
	
	if(!obj)
		return;
	
	local result = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "Character/ATMage/IceRoad/ap_ATMage_IceRoad.nut");

	if (result == true) 
	{
		obj.sq_PlaySound("R_ICE_WALK_LOOP", SOUND_ID_MOVE);
	}
	else 
	{
		obj.sq_PlayMoveSound();
	}
}

function procDash_ATMage(obj)
{
	if(!obj)
		return;
	
	local ani = sq_GetCurrentAnimation(obj);
	
	if(!ani)
		return;
		
	local isFlag = obj.sq_IsKeyFrameFlag(ani, 1);
	
	
	local result = CNSquirrelAppendage.sq_IsAppendAppendage(obj, "Character/ATMage/IceRoad/ap_ATMage_IceRoad.nut");

	if (result == true) 
	{
		
		if(isFlag)
		{
			obj.sq_PlaySound("R_ICE_WALK");
		}
		
		obj.sq_ClearKeyFrameFlag(ani);
	}
	else
	{
		
		
		if (isFlag)
		{
			local stage = sq_GetGlobaludpModuleStage();
			if(!stage)
				return;
			
			local dungeon = sq_GetDungeonByStage(stage);
			
			if(!dungeon)
				return;
				
			local dungeonIndex = sq_GetDuegonIndex(dungeon);
			local mapIndex = sq_GetMapIndex(stage);

			
			if (dungeonIndex == 40 || mapIndex == 50019)
			{
				obj.sq_PlaySound("R_RUN_SNOW");
			}
			else
			{
				local weight = sq_GetObjectWeight(obj);
				if (sq_GetShadowTypeByAnimation() != 0)
					obj.sq_PlaySound("R_RUN_FLOOR");
				else if (weight < LIGHT_OBJECT_MAX_WEIGHT)
					obj.sq_PlaySound("RUN_STONE");
				else if (weight < MIDDLE_OBJECT_MAX_WEIGHT)
					obj.sq_PlaySound("RUN_SOIL");
				else
					obj.sq_PlaySound("RUN_GRASS");
			}
		}
		obj.sq_ClearKeyFrameFlag(ani);
		
	}
}

function procSkill_MagicShield(obj)
{
}

function getImmuneTypeDamgeRate_ATMage(obj,damageRate, attacker)
{
	
	if(obj.getVar("firepillar").size_vector() > 0)
	{
		if(obj.getVar("firepillar").get_vector(VECTOR_FLAG_2))
		{
			if(attacker)
			{
				print( " damageRate:" + damageRate);
				local skillLevel = obj.sq_GetSkillLevel(SKILL_FIREPILLAR);
				local N = obj.sq_GetLevelData(SKILL_FIREPILLAR, 0, skillLevel); 
				
				damageRate = damageRate - N;
				
				print( " convert damageRate:" + damageRate);
			}
		}
	}

	
	if(CNSquirrelAppendage.sq_IsAppendAppendage(obj, "Character/ATMage/DieHard/ap_ATMage_DieHardSlowHeal.nut")) 
	{
		
		local increaseDamageRate = sq_GetIntData(obj, SKILL_DIEHARD, SKL_STATIC_INT_IDX_0); 
		
		
		damageRate = damageRate + increaseDamageRate;
	}
	
	return damageRate;
}

function getImmuneType_ATMage(obj,type, attacker)
{
	local immuneType = type;
	
	return immuneType;
}

function procSkill_ATMage(obj)
{
	procSkill_IceRoad(obj);
	procSkill_MagicShield(obj);
	procSkill_heteropupil(obj);
	procSkill_icecoagulation(obj);
	procSkill_ATMage_erjuebeidong(obj)
}



function useSkill_before_ATMage(obj, skillIndex, consumeMp, consumeItem, oldSkillMpRate)
{
	local bChangedMp = false;
	
	print(" consumpMp:" + consumeMp + " oldSkillMpRate:" + oldSkillMpRate);
	
	local appendage = obj.GetSquirrelAppendage("Character/ATMage/ManaBurst/ap_ATMage_ManaBurst.nut");
	
	if(appendage)
	{
		local isvalid = appendage.isValid();
		
		if(isvalid)
		{
			local skillLevel = obj.sq_GetSkillLevel(SKILL_MANABURST);
			local mpComsumeRate = sq_GetLevelData(obj, SKILL_MANABURST, SKL_LVL_COLUMN_IDX_0, skillLevel);
			local newMpRate = oldSkillMpRate.tofloat() * (100 + mpComsumeRate.tofloat()) / 100;
			
			print(" newMpRate:" + newMpRate);
			obj.setSkillMpRate(skillIndex, newMpRate.tofloat());
			bChangedMp = true;
		}
	}
	
	if(obj.sq_GetSkillLevel(SKILL_EXPRESSION) > 0)
	{
		local skillLevel = obj.sq_GetSkillLevel(SKILL_EXPRESSION);
		local skillMpRate = obj.getSkillMpRate(skillIndex);
		local mpComsumeRate = sq_GetLevelData(obj, SKILL_EXPRESSION, 0, skillLevel);
		local newMpRate = skillMpRate.tofloat() * (100 - mpComsumeRate.tofloat()) / 100;
		
		
		
		

		obj.setSkillMpRate(skillIndex, newMpRate.tofloat());
	}
	
	print(" now consumpMp:" + obj.getSkillMpRate(skillIndex));
	
	return true;
}

function useSkill_after_ATMage(obj, skillIndex, consumeMp, consumeItem, oldSkillMpRate)
{
	if(!obj)
		return false;
		
	obj.setSkillMpRate(skillIndex, oldSkillMpRate.tofloat());
	print(" after set consumpMp:" + oldSkillMpRate);
	
	return true;
}






function getAttackAni_ATMage(obj, index)
{
	if (!obj)
		return null;
	
	local animation = obj.sq_GetAttackAni(index);

	
	
	local skillLevel = obj.sq_GetSkillLevel(SKILL_ICE_ELEMENTAL_ATTACK);
	if (skillLevel > 0)
		animation = obj.sq_GetCustomAni(CUSTOM_ANI_ICE_ELEMENTAL_ATTACK1 + index);
	
	return animation;
}






function getDashAttackAni_ATMage(obj)
{
	if (!obj)
		return null;
	
	local animation = obj.sq_GetDashAttackAni();

	
	
	local skillLevel = obj.sq_GetSkillLevel(SKILL_ICE_ELEMENTAL_ATTACK);
	if (skillLevel > 0)
		animation = obj.sq_GetCustomAni(CUSTOM_ANI_ICE_ELEMENTAL_DASH_ATTACK);
	
	return animation;
}






function getJumpAttackAni_ATMage(obj)
{
	if (!obj)
		return null;
	
	local animation = obj.sq_GetJumpAttackAni();

	
	
	local skillLevel = obj.sq_GetSkillLevel(SKILL_ICE_ELEMENTAL_ATTACK);
	if (skillLevel > 0)
		animation = obj.sq_GetCustomAni(CUSTOM_ANI_ICE_ELEMENTAL_JUMP_ATTACK);
	
	return animation;
}



function getAttackCancelStartFrameSize_ATMage(obj)
{
	local maxAttackNumber = obj.sq_GetAttackCancelStartFrameSize();

	local skillLevel = obj.sq_GetSkillLevel(SKILL_ICE_ELEMENTAL_ATTACK);
	
	if (skillLevel > 0)
		maxAttackNumber = 2;

	return maxAttackNumber;
}

function setState_ATMage(obj, state, datas, isResetTimer)
{
	setState_dragonslayerlaser(obj, state, datas, isResetTimer);
	if(state == STATE_DIE)
		obj.sq_RemoveSkillLoad(SKILL_HOLONG_LIGHT);	
	return 0;
}

function getDefaultAttackInfo_ATMage(obj, index)
{
	if (!obj)
		return null;
	
	local attackInfo = obj.sq_GetDefaultAttackInfo(index);

	
	local skillLevel = obj.sq_GetSkillLevel(SKILL_ICE_ELEMENTAL_ATTACK);
	if (skillLevel > 0)
	{
		attackInfo = sq_GetCustomAttackInfo(obj, CUSTOM_ATTACK_INFO_ICE_ELEMENTAL_ATTACK1 + index);
	}
	
	return attackInfo;
}

function getDashAttackInfo_ATMage(obj)
{
	if (!obj)
		return null;
	
	local attackInfo = obj.sq_GetDashAttackInfo();

	
	local skillLevel = obj.sq_GetSkillLevel(SKILL_ICE_ELEMENTAL_ATTACK);
	if (skillLevel > 0)
		attackInfo = sq_GetCustomAttackInfo(obj, CUSTOM_ATTACK_INFO_ICE_ELEMENTAL_DASH_ATTACK);
	
	return attackInfo;
}


function getJumpAttackInfo_ATMage(obj)
{
	if (!obj)
		return null;
	
	local attackInfo = obj.sq_GetJumpAttackInfo();

	
	local skillLevel = obj.sq_GetSkillLevel(SKILL_ICE_ELEMENTAL_ATTACK);
	if (skillLevel > 0)
		attackInfo = sq_GetCustomAttackInfo(obj, CUSTOM_ATTACK_INFO_ICE_ELEMENTAL_JUMP_ATTACK);
	
	return attackInfo;
}




function setEnableCancelSkill_ATMage(obj, isEnable)
{
	if(!obj)
		return false;
	
	if(!obj.isMyControlObject())
		return false;


	if(!isEnable)
		return true;
		
	
	
	
	local GROW_TYPE_AT_MAGE = 0; 
	local GROW_TYPE_ELEMENTAL_BOMBER = 1; 
	local GROW_TYPE_GLACIALMASTER = 2; 
	
	
	
	
	
	
	
	{

		obj.setSkillCommandEnable(SKILL_WIND_STRIKE, isEnable);

		obj.setSkillCommandEnable(SKILL_PUSH_OUT, isEnable);

		obj.setSkillCommandEnable(SKILL_FALLENBLOSSOMS, isEnable);

		obj.setSkillCommandEnable(SKILL_TURNWINDMILL, isEnable);

		obj.setSkillCommandEnable(SKILL_BROKENARROW, isEnable);

		obj.setSkillCommandEnable(SKILL_ICE_CRASH, isEnable);

		obj.setSkillCommandEnable(SKILL_FROZENLAND, isEnable);

		obj.setSkillCommandEnable(SKILL_ICE_SWORD, isEnable);

		obj.setSkillCommandEnable(SKILL_MULTI_SHOT, isEnable);

		obj.setSkillCommandEnable(SKILL_FLAMECIRCLE, isEnable);

		
		


		obj.setSkillCommandEnable(SKILL_ICE_ORB_EX, isEnable);


		obj.setSkillCommandEnable(SKILL_CONCENTRATE_EX, isEnable);



		obj.setSkillCommandEnable(SKILL_ELEMENTAL_STRIKE_EX, isEnable);

		obj.setSkillCommandEnable(SKILL_ICE_FIELD_EX, isEnable);
		
		
		if(sq_getGrowType(obj) == GROW_TYPE_GLACIALMASTER)
		{
			obj.setSkillCommandEnable(SKILL_ICE_SWORD, isEnable);
		}
	}
	
	
	
	
	
	
	return true;
	
	local size = 10; 
	local cancel_skill_l =[];
	local skill_l =[];
	cancel_skill_l.resize(size);
	skill_l.resize(size);










	cancel_skill_l[0] = SKILL_CANCEL_WIND_STRIKE;
	cancel_skill_l[1] = SKILL_CANCEL_PUSH_OUT;
	cancel_skill_l[2] = SKILL_CANCEL_FALLENBLOSSOMS;
	cancel_skill_l[3] = SKILL_CANCEL_TURNWINDMILL;
	cancel_skill_l[4] = SKILL_CANCEL_BROKENARROW;
	cancel_skill_l[5] = SKILL_CANCEL_ICE_CRASH;
	cancel_skill_l[6] = SKILL_CANCEL_FROZENLAND;
	cancel_skill_l[7] = SKILL_CANCEL_ICE_SWORD;
	cancel_skill_l[8] = SKILL_CANCEL_FLAMECIRCLE;
	cancel_skill_l[9] = SKILL_CANCEL_MULTI_SHOT;

	skill_l[0] = SKILL_WIND_STRIKE;
	skill_l[1] = SKILL_PUSH_OUT;
	skill_l[2] = SKILL_FALLENBLOSSOMS;
	skill_l[3] = SKILL_TURNWINDMILL;
	skill_l[4] = SKILL_BROKENARROW;
	skill_l[5] = SKILL_ICE_CRASH;
	skill_l[6] = SKILL_FROZENLAND;
	skill_l[7] = SKILL_ICE_SWORD;
	skill_l[8] = SKILL_FLAMECIRCLE;
	skill_l[9] = SKILL_MULTI_SHOT;

	for(local i=0;i<size;i+=1)
	{
		
		local level = sq_GetSkillLevel(obj, cancel_skill_l[i]);
		local bRet = false;
		
		if(level > 0)
		{
			if(isEnable)
			{
				bRet = true;
			}
		}
		
		obj.setSkillCommandEnable(skill_l[i], bRet);
	}
	
	
	return true;
}



function sendSetHpPacket_ATMage(obj, hp, sendInstant)
{
	if(CNSquirrelAppendage.sq_IsAppendAppendage(obj, "Character/ATMage/DieHard/ap_ATMage_DieHardSlowHeal.nut")) 
	{
		if(obj.getHp() < hp)
		{
			
			return false;
		}
	}
	
	return true;
}

function sendSetMpPacket_ATMage(obj, mp, sendInstant)
{
	return true;
}





function isApplyConversionSkillPassiveObject_ATMage(passiveObjectIndex)
{
	if (passiveObjectIndex == 24201)
	{	
		return true;
	}
	else if (passiveObjectIndex == 24222)
	{	
		return true;
	}
	else if (passiveObjectIndex == 24217)
	{	
		return true;
	}
	else if (passiveObjectIndex == 24254)
	{	
		return true;
	}
	
	
	
	local idx = passiveObjectIndex;
	if (idx >= 24266 && idx <= 24283)
	{
		return true;
	}
	
	return false;
}



function resetDungeonStart_ATMage(obj, moduleType, resetReason, isDeadTower, isResetSkillUserCount)
{
	if(!obj) return -1;	

	local isReset = true; 
		
	if (sq_GetCurrentModuleType() == MODULE_TYPE_WARROOM || sq_GetCurrentModuleType() == MODULE_TYPE_DEAD_TOWER)
	{
		
		if (resetReason != REASON_DEATH)
		{
			isReset = false; 
		}
	}
	
	
	if(isReset)
	{ 
		local appendage = obj.GetSquirrelAppendage("Character/ATMage/IceRoad/ap_ATMage_IceRoad.nut");
		

		if(appendage)
		{
			local skill = sq_GetSkill(obj, SKILL_ICEROAD);
			local isvalid = appendage.isValid();
			
			if(skill)
			{
				print(" isSeal:" + skill.isSealActiveFunction());
				if(!skill.isSealActiveFunction())
				{
					skill.setSealActiveFunction(true);
				}
			}
			
			if(isvalid)
			{
				appendage.setValid(false);
			}
		}
		
		obj.sq_RemoveSkillLoad(SKILL_HOLONG_LIGHT);	
	}
	
	return 1;
	
}





function addElementalChain_ATMage(obj, element)
{
	if (!obj) return;
	if (element == ENUM_ELEMENT_MAX) return;
	local skillLevel = sq_GetSkillLevel(obj, SKILL_ELEMENTAL_CHAIN);
	if (skillLevel <= 0) return;
	
	local skill = sq_GetSkill(obj, SKILL_ELEMENTAL_CHAIN);
	if (!skill) return;
	local changeValue = obj.sq_GetLevelData(SKILL_ELEMENTAL_CHAIN, 0, skillLevel);
	local validTime = obj.sq_GetLevelData(SKILL_ELEMENTAL_CHAIN, 1, skillLevel);
	
	local apFire = null;
	local apWater = null;
	local apDark = null;
	local apLight = null;
	
	if (element == ENUM_ELEMENT_FIRE)
	{
		apWater = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_WATER, false, changeValue.tofloat(), validTime);
		apDark = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_DARK, false, changeValue.tofloat(), validTime);
		apLight = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_LIGHT, false, changeValue.tofloat(), validTime);
	}
	else if (element == ENUM_ELEMENT_WATER)
	{
		apFire = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_FIRE, false, changeValue.tofloat(), validTime);
		apDark = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_DARK, false, changeValue.tofloat(), validTime);
		apLight = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_LIGHT, false, changeValue.tofloat(), validTime);
	}
	else if (element == ENUM_ELEMENT_DARK)
	{
		apFire = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_FIRE, false, changeValue.tofloat(), validTime);
		apWater = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_WATER, false, changeValue.tofloat(), validTime);
		apLight = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_LIGHT, false, changeValue.tofloat(), validTime);
	}
	else if (element == ENUM_ELEMENT_LIGHT)
	{
		apFire = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_FIRE, false, changeValue.tofloat(), validTime);
		apWater = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_WATER, false, changeValue.tofloat(), validTime);
		apDark = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_DARK, false, changeValue.tofloat(), validTime);
	}
	else if (element == -1)
	{
		apFire = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_FIRE, false, changeValue.tofloat(), validTime);
		apWater = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_WATER, false, changeValue.tofloat(), validTime);
		apDark = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_DARK, false, changeValue.tofloat(), validTime);
		apLight = sq_CreateChangeStatus(CHANGE_STATUS_TYPE_ELEMENT_ATTACK_LIGHT, false, changeValue.tofloat(), validTime);
	}
	
	if (apFire != null)
		apFire.sq_Append(obj, obj, APID_SKILL_ELEMENTAL_CHAIN_FIRE);
	if (apWater != null)
		apWater.sq_Append(obj, obj, APID_SKILL_ELEMENTAL_CHAIN_WATER);
	if (apDark != null)
		apDark.sq_Append(obj, obj, APID_SKILL_ELEMENTAL_CHAIN_DARK);
	if (apLight != null)
		apLight.sq_Append(obj, obj, APID_SKILL_ELEMENTAL_CHAIN_LIGHT);
}

function onChangeSkillEffect_ATMage1(obj, skillIndex, reciveData)
{
	if(!obj)
		return;

	if(skillIndex == SKILL_ICEROAD)
	{
		local skill = sq_GetSkill(obj, SKILL_ICEROAD);
		skill.resetCurrentCoolTime();
		skill.setSealActiveFunction(true);	
		local skill_level = sq_GetSkillLevel(obj, SKILL_ICEROAD);
		obj.startSkillCoolTime(SKILL_ICEROAD, skill_level, -1);
		
		local appendage = obj.GetSquirrelAppendage("Character/ATMage/IceRoad/ap_ATMage_IceRoad.nut");
		appendage.setValid(false);
	}
	else if(skillIndex == SKILL_DIEHARD)
	{
		if(reciveData.getSize() > 0)
		{
			local hp = reciveData.readDword(); 
			
			if(hp > 0)
			{
				print(" onchange:" + hp);
				obj.setHp(hp, null, true);
			}
		}
	}
	else if (skillIndex == SKILL_ELEMENTAL_CHANGE)
	{
		if (reciveData.getSize() > 0)
		{
			local element = reciveData.readByte();
			obj.setThrowElement(element);
			
			
			local appendage = CNSquirrelAppendage.sq_GetAppendage(obj,"Character/ATMage/MagicShield/ap_MagicShield.nut");
			if(appendage)
				setMagicShieldType(appendage, obj, obj.getThrowElement());
		}
	}
	else if(skillIndex == SKILL_TUNDRASOUL)
	{
		if (reciveData.getSize() > 0)
		{
			local mode = reciveData.readDword();
			
			local auraAppendage = 0;
			local appendage = CNSquirrelAppendage.sq_GetAppendage(obj, "Character/ATMage/TundraSoul/ap_ATMage_TundraSoul.nut");
			
			if(appendage)
			{
				auraAppendage = appendage.sq_getSquirrelAuraMaster("AuraTundraSoul");
			
				if(mode == 1)
				{ 
					appendage.sq_DeleteAppendages();
				}
				else if(mode == 0)
				{ 
					local range = obj.sq_GetIntData(SKILL_TUNDRASOUL , 0);
					appendage.sq_AddSquirrelAuraMaster("AuraTundraSoul",obj, obj, range, 18, 5, 0);
				}
			}
		
		}
	}
}

function changeTrhowState_ATMage(obj, throwState)
{
	if (!obj) return false;
	
	printc("changeTrhowState_ATMage");
	if (throwState == 3 &&
		obj.getThrowIndex() == SKILL_ELEMENTAL_CHANGE)
	{
		
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(throwState);
		obj.sq_IntVectPush(-1);
		obj.sq_IntVectPush(obj.getThrowElement());
		obj.sq_AddSetStatePacket(STATE_THROW, STATE_PRIORITY_USER, true);
		return true;
	}

	return false;
}

function isCounterState_ATMage(obj, isCounter)
{
	if(obj.getVar("firepillar").size_vector() > 0)
	{
		if(obj.getVar("firepillar").get_vector(VECTOR_FLAG_2))
		{
			isCounter = false;
		}
	}
	
	return isCounter;
}


function AppendAppendageToSimple(obj, skillIndex, appendageFileName, validTime, isBuff)
{
	local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skillIndex, false, appendageFileName, false);
	
	appendage.sq_SetValidTime(validTime); 
	
	
	CNSquirrelAppendage.sq_Append(appendage, obj, obj, isBuff); 

}


function setActiveStatus_ATMage1(obj, activeStatus, power)
{
	if (!obj) return 0;
	
	local state = sq_GetState(obj);
	
	if (state == STATE_ELEMENTAL_BUSTER)
	{
		
		
		return 0;
	}
	
	return 1;
}



function reset_ATMage(obj)
{
	if(!obj)
		return;
	
}



function procSkill_heteropupil(obj)
{
    local skill_level = sq_GetSkillLevel(obj, SKILL_heteropupil);
	if(skill_level > 0)
	{
        if (!CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atmage/heteropupil/ap_heteropupil.nut") )
        {
            local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, SKILL_heteropupil, false, 
				"character/atmage/heteropupil/ap_heteropupil.nut", true);

            appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), SKILL_heteropupil, skill_level);
            CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, SKILL_heteropupil, true);

			local value0 = sq_GetLevelData(obj, SKILL_heteropupil, 0, skill_level); 
			local value1 = sq_GetLevelData(obj, SKILL_heteropupil, 1, skill_level); 
			local value2 = sq_GetLevelData(obj, SKILL_heteropupil, 2, skill_level); 
			local value3 = sq_GetLevelData(obj, SKILL_heteropupil, 3, skill_level); 
			local value4 = sq_GetLevelData(obj, SKILL_heteropupil, 4, skill_level); 
			local change_appendage = appendage.sq_getChangeStatus("heteropupil");

			if(!change_appendage)
            {
				change_appendage = appendage.sq_AddChangeStatusAppendageID(obj, obj, 0, 
				CHANGE_STATUS_TYPE_EQUIPMENT_PHYSICAL_ATTACK, 
				false, value0, APID_COMMON);
			}
            if (change_appendage){
				change_appendage.clearParameter();
				change_appendage.addParameter(CHANGE_STATUS_TYPE_EQUIPMENT_PHYSICAL_ATTACK, false, value0.tofloat());
				change_appendage.addParameter(CHANGE_STATUS_TYPE_EQUIPMENT_MAGICAL_ATTACK, false, value1.tofloat());
				change_appendage.addParameter(CHANGE_STATUS_TYPE_ADDITIONAL_PHYSICAL_GENUINE_ATTACK, false, value2.tofloat());
				change_appendage.addParameter(CHANGE_STATUS_TYPE_PHYSICAL_CRITICAL_DAMAGE_RATE, false, value3.tofloat());
				change_appendage.addParameter(CHANGE_STATUS_TYPE_MAGICAL_CRITICAL_DAMAGE_RATE, false, value4.tofloat());
			}

        }

    }

}

function procSkill_icecoagulation(obj)
{
    local skill_level = sq_GetSkillLevel(obj, SKILL_icecoagulation);
	if(skill_level > 0)
	{
        if (!CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atmage/icecoagulation/ap_icecoagulation.nut") )
        {
            local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, SKILL_icecoagulation, false, 
				"character/atmage/icecoagulation/ap_icecoagulation.nut", true);

            appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), SKILL_icecoagulation, skill_level);
            CNSquirrelAppendage.sq_AppendAppendageID(appendage, obj, obj, SKILL_icecoagulation, true);

			local value0 = sq_GetLevelData(obj, SKILL_icecoagulation, 0, skill_level); 
			local value1 = sq_GetLevelData(obj, SKILL_icecoagulation, 1, skill_level); 
			local value2 = sq_GetLevelData(obj, SKILL_icecoagulation, 2, skill_level); 
			local value3 = sq_GetLevelData(obj, SKILL_icecoagulation, 3, skill_level); 
			local value4 = sq_GetLevelData(obj, SKILL_icecoagulation, 4, skill_level); 
			local change_appendage = appendage.sq_getChangeStatus("icecoagulation");

			if(!change_appendage)
            {
				change_appendage = appendage.sq_AddChangeStatusAppendageID(obj, obj, 0, 
				CHANGE_STATUS_TYPE_EQUIPMENT_PHYSICAL_ATTACK, 
				false, value0, APID_COMMON);
			}
            if (change_appendage){
				change_appendage.clearParameter();
				change_appendage.addParameter(CHANGE_STATUS_TYPE_EQUIPMENT_PHYSICAL_ATTACK, false, value0.tofloat());
				change_appendage.addParameter(CHANGE_STATUS_TYPE_EQUIPMENT_MAGICAL_ATTACK, false, value1.tofloat());
				change_appendage.addParameter(CHANGE_STATUS_TYPE_ADDITIONAL_PHYSICAL_GENUINE_ATTACK, false, value2.tofloat());
				change_appendage.addParameter(CHANGE_STATUS_TYPE_PHYSICAL_CRITICAL_DAMAGE_RATE, false, value3.tofloat());
				change_appendage.addParameter(CHANGE_STATUS_TYPE_MAGICAL_CRITICAL_DAMAGE_RATE, false, value4.tofloat());
			}

        }

    }

}
