



function checkExecutableSkill_atfighter_spiralemperorslap(obj)
{
	if(!obj) return false;

	local isUse = obj.sq_IsUseSkill(SKILL_ATFIGHTER_SPIRALEMPERORSLAP);

	if(isUse)
	{
		if(sq_GetSkillLevel(obj, 237) > 0 && CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut") == true)
		{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(5); 
		obj.sq_AddSetStatePacket(STATE_ATFIGHTER_SPIRALEMPERORSLAP, STATE_PRIORITY_USER, true);
		return true;
		}
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0); 
		obj.sq_AddSetStatePacket(STATE_ATFIGHTER_SPIRALEMPERORSLAP, STATE_PRIORITY_USER, true);
		return true;
	}
	return false;
}


function checkCommandEnable_atfighter_spiralemperorslap(obj)
{
	if(!obj) return false;

	local state = obj.sq_GetState();

	if(state == STATE_STAND)
		return true;

	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(SKILL_ATFIGHTER_SPIRALEMPERORSLAP); 
	}


	return true;
}


function onSetState_atfighter_spiralemperorslap(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);

	switch(subState)
	{
		case 0:
			obj.sq_StopMove();

			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_SPIRALEMPERORSLAP_START_BODY);
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATFIGHTER_SPIRALEMPERORSLAPATTACKTRY);

			obj.getVar().clear_obj_vector();

			obj.sq_PlaySound("R_MF_SPIRAL_EMPEROSLAP_READY");
			break;
		case 1:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_SPIRALEMPERORSLAP_START_FAIL_BODY);

			if(obj.sq_IsMyControlObject())
				sq_flashScreen(obj, 0, 0, 160, 51, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			break;
		case 2:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_SPIRALEMPERORSLAP_START_SUCCESS_BODY);

			sq_SetMyShake(obj, 5, 500);
			if(obj.sq_IsMyControlObject())
				sq_flashScreen(obj, 0, 120, 240, 51, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_CLOSEBACK);
			break;
		case 3:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_SPIRALEMPERORSLAP_LOOP_BODY);

			local skill_level = sq_GetSkillLevel(obj, SKILL_ATFIGHTER_SPIRALEMPERORSLAP);
			
			local Time = obj.sq_GetLevelData(SKILL_ATFIGHTER_SPIRALEMPERORSLAP, 0, skill_level);

			obj.getVar().clear_vector();
			obj.getVar().push_vector(Time);
			obj.sq_PlaySound("SPIRAL_EMPEROSLAP_LOOP", SOUND_ID_ATFIGHTER_SPIRAL_EMPEROSLAP_LOOP);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_SPIRALEMPERORSLAP_END_BODY);

			break;

		case 5:
			obj.sq_StopMove();
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_SPIRALEMPERORSLAP_START_BODY);
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATFIGHTER_SPIRALEMPERORSLAPATTACKTRY);
			obj.sq_PlaySound("R_MF_SPIRAL_EMPEROSLAP_READY");
			break;
		case 6:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_SPIRALEMPERORSLAP_END_BODY);
			break;
	}

	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);

}


function onAttack_atfighter_spiralemperorslap(obj, damager, boundingBox, isStuck)
{
	if(!obj) return;

	local subState = obj.getSkillSubState();
	if(subState == 0)
	{
		if(obj.getVar().get_obj_vector_size() <= 0)
		{
			if(!damager.isObjectType(OBJECTTYPE_ACTIVE)) return;

			if(CNSquirrelAppendage.sq_IsAppendAppendage(damager, "character/atfighter/spiralemperorslap/ap_spiralemperorslap.nut"))
				CNSquirrelAppendage.sq_RemoveAppendage(damager, "character/atfighter/spiralemperorslap/ap_spiralemperorslap.nut");

			
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(damager, obj, SKILL_ATFIGHTER_SPIRALEMPERORSLAP, false, "character/atfighter/spiralemperorslap/ap_spiralemperorslap.nut", true);

			if(sq_IsHoldable(obj, damager))
				sq_HoldAndDelayDie(damager, obj, true, true, false, 0, 0, ENUM_DIRECTION_NEUTRAL, appendage);

			
			if(sq_IsGrabable(obj, damager) && !sq_IsFixture(damager))
				sq_MoveToAppendageForce(damager, obj, obj, 100, 0, 0, 0, true, appendage);

			obj.getVar().push_obj_vector(damager);
		}
	}
}


function onEndCurrentAni_atfighter_spiralemperorslap(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;

	local subState = obj.getSkillSubState();
	if(subState == 1 || subState == 4)
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	else
	{
		if(subState == 0)
		{
			if(obj.getVar().get_obj_vector_size() <= 0)
			{
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(1); 
				obj.sq_AddSetStatePacket(STATE_ATFIGHTER_SPIRALEMPERORSLAP, STATE_PRIORITY_USER, true);
			}
			else
			{
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2); 
				obj.sq_AddSetStatePacket(STATE_ATFIGHTER_SPIRALEMPERORSLAP, STATE_PRIORITY_USER, true);
			}
		}
		else if(subState == 2)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3); 
			obj.sq_AddSetStatePacket(STATE_ATFIGHTER_SPIRALEMPERORSLAP, STATE_PRIORITY_USER, true);
		}
		else if(subState == 5)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(6); 
			obj.sq_AddSetStatePacket(STATE_ATFIGHTER_SPIRALEMPERORSLAP, STATE_PRIORITY_USER, true);
		}
		else if(subState == 6)
		{
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_USER, true);
		}
	}
}


function onProcCon_atfighter_spiralemperorslap(obj)
{
	if(!obj) return;

	local subState = obj.getSkillSubState();
	if(subState == 3)
	{
		local time = obj.getVar().get_vector(0);
		local currentT = sq_GetCurrentTime(obj.sq_GetCurrentAni());
		if(currentT >= time)
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(subState + 1); 
			obj.sq_AddSetStatePacket(STATE_ATFIGHTER_SPIRALEMPERORSLAP, STATE_PRIORITY_USER, true);
		}
	}
}


function onKeyFrameFlag_atfighter_spiralemperorslap(obj, flagIndex)
{
	if(!obj) return false;

	local subState = obj.getSkillSubState();
	if(subState == 4 && flagIndex == 1)
	{
		deleteAllApVarObj_atfighter_spiralemperorslap(obj);

		obj.stopSound(SOUND_ID_ATFIGHTER_SPIRAL_EMPEROSLAP_LOOP);

		if(obj.sq_IsMyControlObject())
		{
			sq_flashScreen(obj, 80, 80, 0, 102, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_CLOSEBACK);

			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATFIGHTER_SPIRALEMPERORSLAP, STATE_ATFIGHTER_SPIRALEMPERORSLAP, 1, 1.0);

			obj.sq_StartWrite();
			obj.sq_WriteDword(SKILL_ATFIGHTER_SPIRALEMPERORSLAP);	
			obj.sq_WriteDword(attackBonusRate);	
			obj.sq_SendCreatePassiveObjectPacket(24375, 0, 100, 1, 65);
		}
	}
	else if(subState == 6 && flagIndex == 1)
	{
		if(obj.sq_IsMyControlObject())
		{
			sq_flashScreen(obj, 80, 80, 0, 102, sq_RGB(0, 0, 0), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_CLOSEBACK);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATFIGHTER_SPIRALEMPERORSLAP, STATE_ATFIGHTER_SPIRALEMPERORSLAP, 1, 2.0);
			obj.sq_StartWrite();
			obj.sq_WriteDword(SKILL_ATFIGHTER_SPIRALEMPERORSLAP);	
			obj.sq_WriteDword(attackBonusRate);	
			obj.sq_SendCreatePassiveObjectPacket(24375, 0, 100, 1, 65);
		}
	}
	else if(subState == 3 && flagIndex == 1)
		sq_SetMyShake(obj, 1, 400);

	return true;
}


function onEndState_atfighter_spiralemperorslap(obj, new_state)
{
	if(!obj) return;

	if(new_state != STATE_ATFIGHTER_SPIRALEMPERORSLAP)
		obj.stopSound(SOUND_ID_ATFIGHTER_SPIRAL_EMPEROSLAP_LOOP);
}


function deleteAllApVarObj_atfighter_spiralemperorslap(obj)
{
	local count = obj.getVar().get_obj_vector_size();
	for(local i = 0; i < count; i++)
	{
		local object = obj.getVar().get_obj_vector(i);
		if(object)
		{
			if(CNSquirrelAppendage.sq_IsAppendAppendage(object, "character/atfighter/spiralemperorslap/ap_spiralemperorslap.nut"))
				CNSquirrelAppendage.sq_RemoveAppendage(object, "character/atfighter/spiralemperorslap/ap_spiralemperorslap.nut");
		}
	}
	obj.getVar().clear_obj_vector();
}

