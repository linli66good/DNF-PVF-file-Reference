
function checkExecutableSkill_thundersuplex(obj)
{
	if (!obj) return false;
	
	local isUse = obj.sq_IsUseSkill(250);

	if (isUse)
	{
		
		local pIntVec = sq_GetGlobalIntVector();
		sq_IntVectorClear(pIntVec);
		sq_IntVectorPush(pIntVec, 0);
		obj.addSetStatePacket(250 , pIntVec, STATE_PRIORITY_FORCE, false, "");
}
}

function checkCommandEnable_thundersuplex(obj)
{
	if(!obj)
		return false;

	return true;
}


function onSetState_thundersuplex(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	obj.sq_StopMove();
	local state = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(state);
	switch(state)
	{
	case 0:
    obj.sq_SetCurrentAnimation(221);
	break;
    }
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
		SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}

function onEndCurrentAni_thundersuplex(obj)
{
	if(!obj) return;
	local state = obj.getSkillSubState(); 
	local id = sq_GetObjectId(obj);	
	switch(state)
	{
	case 0:
        obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	break;
    }
}


function onKeyFrameFlag_thundersuplex(obj,flagIndex)
{
	if(!obj)
		return false;
	local state = obj.getSkillSubState(); 
	local id = sq_GetObjectId(obj);	
	switch(state)
	{
	case 0:	
    if (flagIndex == 1)
    {
	sq_SetMyShake(obj,3,180);
	
    }else if (flagIndex == 2)
    {
	obj.sq_StartWrite();
	obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(250 , -1, 0, 1.0));
	obj.sq_WriteDword(21);
	obj.sq_WriteDword(sq_GetIntData(obj, 250, 2));
	obj.sq_WriteDword(sq_GetLevelData(obj, 250, 1, sq_GetSkillLevel(obj, 250) ));
	obj.sq_WriteDword(sq_GetLevelData(obj, 250, 2, sq_GetSkillLevel(obj, 250) ));
	obj.sq_WriteDword(sq_GetLevelData(obj, 250, 3, sq_GetSkillLevel(obj, 250) ));
	obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(250 , -1, 4, 1.0));
	obj.sq_SendCreatePassiveObjectPacket(24395, 0, 0, 0, 0 );
    }else if (flagIndex == 3)
    {
    sq_flashScreen(obj, 1, 7, 18, 63, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
    }
	break;
    }
return true;
}

function crethunderkickfloor_light(obj, disX, disY, disZ, size)
{

	local ani = sq_CreateAnimation("","passiveobject/zrr_skill/atfighter/animation/atthunderkick/thunderkickfloor_light.ani");

    local sizeRate = size.tofloat()/100.0;
    ani.setImageRateFromOriginal(sizeRate, sizeRate);
    ani.setAutoLayerWorkAnimationAddSizeRate(sizeRate);
	
	local pooledObj = sq_CreatePooledObject(ani,true);
	local posX = sq_GetDistancePos(obj.getXPos(), obj.getDirection(), disX);
	pooledObj.setCurrentPos(posX,obj.getYPos() + disY,obj.getZPos() + disZ);
	pooledObj.setCurrentDirection(obj.getDirection());
	pooledObj = sq_SetEnumDrawLayer(pooledObj, ENUM_DRAWLAYER_BOTTOM);		
	sq_AddObject(obj,pooledObj,2,false);	
}
