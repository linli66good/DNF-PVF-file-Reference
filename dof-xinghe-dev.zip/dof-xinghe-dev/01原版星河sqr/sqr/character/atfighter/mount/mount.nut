function onAfterSetState_Mount(obj, state, datas, isResetTimer)
{
	if (!obj) return;
	local level = sq_GetSkillLevel(obj, 233);
	if(level > 0)
	{
		sq_IntVectorClear(sq_GetGlobalIntVector());
		sq_IntVectorPush(sq_GetGlobalIntVector(), 5);
		sq_AddSetStatePacketActiveObject(obj, 120, sq_GetGlobalIntVector(), STATE_PRIORITY_FORCE);
	}
}

function onSetState_atskill_new(obj, state, datas, isResetTimer)
{
	if (!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	local pAni = obj.sq_GetCurrentAni();
	obj.setSkillSubState(substate);
	switch (substate)
	{
		case 5:
			obj.getVar("flag").clear_vector();
			obj.getVar("flag").push_vector(0);
			obj.sq_SetCurrentAnimation(37);
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ndelay = ani.getDelaySum(false);
			local speed = delay.tofloat() / ndelay.tofloat();
			locakonhit(obj, "passiveobject/skillre/fighter/animation/mount/110lvepicweaponb/110lvepicmodify/firebombstart_00.ani", 0, 0, 0, 0, 100, 0, 1, speed, 0);
		break;
	}
}

function onProcCon_atskill_new(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local ani = obj.getCurrentAnimation();
	local frameIndex = sq_GetAnimationFrameIndex(ani);
	switch (substate)
	{
		case 5:
			if(frameIndex >= 9 && obj.getVar("flag").get_vector(0) <= 0)
			{
				obj.sq_StartWrite();
				obj.sq_WriteDword(1);
				obj.sq_SendCreatePassiveObjectPacket(24333, 0, 60, 0, 0);
				sq_SetMyShake(obj, 8, 300);
				obj.getVar("flag").set_vector(0, 1);
			}
		break;
	}
}

function onEndCurrentAni_atskill_new(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	switch (substate)
	{
		case 5:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		break;
	}
}
