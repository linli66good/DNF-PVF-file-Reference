

function onSetState_atrandomkick(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();

	if(substate == 0)
	{
			obj.sq_SetCurrentAnimation(64);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(obj.getXPos());
	}
}

function onEndCurrentAni_atrandomkick(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_IntVectPush(0);
			obj.sq_IntVectPush(0);
			obj.sq_AddSetStatePacket(STATE_JUMP, STATE_PRIORITY_USER, true);
	}
}



function onKeyFrameFlag_atrandomkick(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		if (flagIndex == 10001)
		{
			obj.sq_StartWrite();
			obj.sq_WriteDword(601);
			obj.sq_SendCreatePassiveObjectPacket(24333, 0, 85, 0, 59);
		}
	}
	return true;
}

function onProc_atrandomkick(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local Ani = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(Ani);
	local frameindex = sq_GetCurrentFrameIndex(obj);
	if (substate == 0)
	{
			local ani = obj.getCurrentAnimation();
			local currentT = sq_GetCurrentTime(ani);
			local fireT = ani.getDelaySum(false);
			local objVar = obj.getVar();
			local startX = objVar.get_vector(0);
			if(startX != 0)
			{
				local dstX = sq_GetDistancePos(startX, obj.getDirection(), sq_GetUniformVelocity(0, 300, currentT, fireT/2));
				if(obj.isMovablePos(dstX, obj.getYPos()))
					sq_setCurrentAxisPos(obj, 0, dstX);
				
				else
					objVar.set_vector(0,0);
			}
			sq_setCurrentAxisPos(obj, 2, 30);
	}

}


