

function onSetState_atrisingupper(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();

	if(substate == 0)
	{
			obj.sq_SetCurrentAnimation(224);
			obj.sq_SetCurrentAttackInfo(31);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(83 , 155, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local atkCount = obj.sq_GetIntData(83, 2);
			obj.getVar().clear_vector();
			local objVar = obj.getVar();
			objVar.push_vector(atkCount);
	}
	if(substate == 1)
	{
			obj.sq_SetCurrentAnimation(225);
			obj.sq_SetCurrentAttackInfo(31);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(83 , 155, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			obj.getVar().set_vector(0, obj.getVar().get_vector(0) - 1);
	}
	if(substate == 2)
	{
			obj.sq_SetCurrentAnimation(226);
			obj.sq_SetCurrentAttackInfo(31);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(83 , 155, 0, 2.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
	}
}



function onEndCurrentAni_atrisingupper(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject())return;

	local SubState = obj.getSkillSubState();

	switch(SubState)
	{
		case 0:
			break;
		case 2:
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
			return;
		default:
			local atkCount = obj.getVar().get_vector(0);
			if(atkCount > 0)
			{
				if(SubState == 1)
				{
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(1);
					obj.sq_AddSetStatePacket(155, STATE_PRIORITY_USER, true);
				}
				else
					break;
			}
			else
			{
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2);
				obj.sq_AddSetStatePacket(155, STATE_PRIORITY_USER, true);
			}
			return;
	}
	obj.sq_IntVectClear();
	obj.sq_IntVectPush(SubState + 1);
	obj.sq_AddSetStatePacket(155, STATE_PRIORITY_USER, true);
}


