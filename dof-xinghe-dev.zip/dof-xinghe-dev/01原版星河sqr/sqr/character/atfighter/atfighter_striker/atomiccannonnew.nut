

function onSetState_atomiccannonnew(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();

	if(substate == 0)
	{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATOMICCANNON_BODY_READY);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
	}
	if(substate == 1)
	{
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATOMICCANNON_BODY_CHARGE_END);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
	}
	if(substate == 2)
	{
			obj.sq_SetCurrentAnimation(227);
			local ani = obj.getCurrentAnimation();
			local delay = ani.getDelaySum(false);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			local ndelay = ani.getDelaySum(false);
			local speed = delay.tofloat() / ndelay.tofloat();
			locakonhit(obj, "character/fighter/effect/animation/atatomiccannon/talisman/dash_05.ani", 0, 0, 0, 0, 150, 1, 0, speed, 0);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(obj.getXPos());
	}
	if(substate == 3)
	{
			obj.sq_SetCurrentAnimation(228);
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATFIGHTER_ATOMICCANNONPUNCH);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATFIGHTER_ATOMICCANNON, 159, 0, 2.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);
			obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
				SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
			locakonhit(obj, "character/fighter/effect/animation/atatomiccannon/talisman/flamelegsexp/atomiccannontalisman_skillhit02.ani", 0, 0, 0, 0, 150, 0, 0, 1.5, 0);
			sq_SetMyShake(obj, 8, 500);
	}
}

function onEndCurrentAni_atomiccannonnew(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_AddSetStatePacket(159, STATE_PRIORITY_USER, true);
	}
	if(substate == 1)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(2);
		obj.sq_AddSetStatePacket(159, STATE_PRIORITY_USER, true);
	}
	if(substate == 2)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(3);
		obj.sq_AddSetStatePacket(159, STATE_PRIORITY_USER, true);
	}
	if(substate == 3)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


function onProc_atomiccannonnew(obj)
{
	if(!obj) return;
	local substate = obj.getSkillSubState();
	local Ani = obj.sq_GetCurrentAni();
	local currentT = sq_GetCurrentTime(Ani);
	local frameindex = sq_GetCurrentFrameIndex(obj);
	if (substate == 2)
	{
			local ani = obj.getCurrentAnimation();
			local currentT = sq_GetCurrentTime(ani);
			local fireT = ani.getDelaySum(false);
			local objVar = obj.getVar();
			local startX = objVar.get_vector(0);
			if(startX != 0)
			{
				local dstX = sq_GetDistancePos(startX, obj.getDirection(), sq_GetUniformVelocity(0, 300, currentT*5, fireT));
				if(obj.isMovablePos(dstX, obj.getYPos()))
					sq_setCurrentAxisPos(obj, 0, dstX);
				
				else
					objVar.set_vector(0,0);
			}
	}
}


