



function checkExecutableSkill_atfighter_dropfire(obj)
{
	if(!obj) return false;

	local isUse = obj.sq_IsUseSkill(SKILL_ATFIGHTER_DROPFIRE);

	if(isUse)
	{
		local subState = (obj.getState()==6)?1:0;
		if(sq_GetSkillLevel(obj, 234) > 0)
		{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(2); 
		obj.sq_AddSetStatePacket(STATE_ATFIGHTER_DROPFIRE, STATE_PRIORITY_USER, true);
		return true;
		}
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(subState); 
		obj.sq_AddSetStatePacket(STATE_ATFIGHTER_DROPFIRE, STATE_PRIORITY_USER, true);
		return true;
	}

	return false;
}


function checkCommandEnable_atfighter_dropfire(obj)
{
	if(!obj) return false;

	local state = obj.sq_GetState();

	if(state == STATE_STAND)
		return true;

	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(SKILL_ATFIGHTER_DROPFIRE); 
	}


	return true;
}


function onSetState_atfighter_dropfire(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	obj.sq_StopMove();
	obj.sq_ZStop();

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);

	switch(subState)
	{
		case 0:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATDROPFIRE_BODY_JUMP);

			local moveX = 80;
			local moveZ = 60;
			local moveTime = 150;
			obj.getVar().clear_vector();
			obj.getVar().push_vector(moveTime);
			obj.getVar().push_vector(obj.getXPos());
			obj.getVar().push_vector(obj.getZPos());
			obj.getVar().push_vector(moveX);
			obj.getVar().push_vector(moveZ);

			
			if(CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/dropfire/ap_dropfire.nut"))
				CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/atfighter/dropfire/ap_dropfire.nut");

			
			CNSquirrelAppendage.sq_AppendAppendage(obj, obj, SKILL_ATFIGHTER_DROPFIRE, false, "character/atfighter/dropfire/ap_dropfire.nut", true);
			break;
		case 1:
			
			if(CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/dropfire/ap_dropfire.nut"))
				CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/atfighter/dropfire/ap_dropfire.nut");

			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATDROPFIRE_BODY);

			local moveX = 75;
			obj.getVar().clear_vector();
			obj.getVar().push_vector(obj.getXPos());
			obj.getVar().push_vector(obj.getZPos());
			obj.getVar().push_vector(moveX);

			obj.getVar().setBool(0, false);

			obj.sq_PlaySound("MF_DROP_FIRE");
			break;
		case 2:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATDROPFIRE_BODY);
			obj.sq_PlaySound("MF_DROP_FIRE");
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onProc_atfighter_dropfire(obj)
{
	if(!obj) return;

	local subState = obj.getSkillSubState();
	if(subState == 0)
	{
		local currentT = obj.sq_GetStateTimer();
		local fireT = obj.getVar().get_vector(0);

		local moveX = obj.getVar().get_vector(3);
		local dstX = sq_GetDistancePos(obj.getVar().get_vector(1),
									   obj.getDirection(),
									   sq_GetUniformVelocity(0, moveX, currentT, fireT));

		if(obj.isMovablePos(dstX, obj.getYPos()))
			sq_setCurrentAxisPos(obj, 0, dstX);
		else
		{
			local offset = sq_Abs(dstX - obj.getXPos());
			if(offset != 0)
				obj.getVar().set_vector(3, (moveX > 0) ? moveX - offset : moveX + offset);
		}
		
		local dstZ = obj.getVar().get_vector(2) + obj.getVar().get_vector(4) * sq_SinTable(sq_GetUniformVelocity(0, 90, currentT, fireT));
		sq_setCurrentAxisPos(obj, 2, dstZ.tointeger());

		if(currentT >= fireT && obj.sq_IsMyControlObject())
		{
			
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1); 
			obj.sq_AddSetStatePacket(STATE_ATFIGHTER_DROPFIRE, STATE_PRIORITY_USER, true);
		}
	}
	else if(subState == 1)
	{
		local pAni = obj.getCurrentAnimation();
		local currentT = obj.sq_GetStateTimer();
		local fireT = pAni.getDelaySum(0, 1);

		local moveX = obj.getVar().get_vector(2);

		if(obj.getZPos() != 0)
		{
			local dstX = sq_GetDistancePos(obj.getVar().get_vector(0),
										   obj.getDirection(),
										   sq_GetUniformVelocity(0, moveX, currentT, fireT));

			if(obj.isMovablePos(dstX, obj.getYPos()))
				sq_setCurrentAxisPos(obj, 0, dstX);
			else
			{
				local offset = sq_Abs(dstX - obj.getXPos());
				if(offset != 0)
					obj.getVar().set_vector(2, (moveX > 0) ? moveX - offset : moveX + offset);
			}

			local dstZ = obj.getVar().get_vector(1) * sq_SinTable(sq_GetUniformVelocity(90, 180, currentT, fireT));
			sq_setCurrentAxisPos(obj, 2, dstZ.tointeger());
		}
		else if(obj.getVar().getBool(0) == false)
		{
			obj.getVar().setBool(0, true);

			if(obj.sq_IsMyControlObject())
			{
				local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATFIGHTER_DROPFIRE, STATE_ATFIGHTER_DROPFIRE, 0, 1.0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(SKILL_ATFIGHTER_DROPFIRE);	
				obj.sq_WriteDword(attackBonusRate);	
				obj.sq_SendCreatePassiveObjectPacket(24375, 0, 55, 0, 0);
			}
		}
	}
}

function onKeyFrameFlag_atfighter_dropfire(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 2)
	{
		if (flagIndex == 10001)
		{
				local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATFIGHTER_DROPFIRE, STATE_ATFIGHTER_DROPFIRE, 0, 2.0);
				obj.sq_StartWrite();
				obj.sq_WriteDword(SKILL_ATFIGHTER_DROPFIRE);	
				obj.sq_WriteDword(attackBonusRate);	
				obj.sq_SendCreatePassiveObjectPacket(24375, 0, 55, 0, 0);
				obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
	}
	return true;
}



function onEndCurrentAni_atfighter_dropfire(obj)
{
	if(!obj) return;

	local subState = obj.getSkillSubState();
	if(subState == 1 && obj.sq_IsMyControlObject())
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
}


function onEndState_atfighter_dropfire(obj, new_state)
{
	if(!obj) return;

	if(new_state != STATE_ATFIGHTER_DROPFIRE)
	{
		
		if(CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/dropfire/ap_dropfire.nut"))
			CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/atfighter/dropfire/ap_dropfire.nut");
	}
}

