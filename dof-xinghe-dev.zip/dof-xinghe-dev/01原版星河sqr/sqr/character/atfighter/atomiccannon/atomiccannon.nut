



function checkExecutableSkill_atfighter_atomiccannon(obj)
{
	if(!obj) return false;

	local isUse = obj.sq_IsUseSkill(SKILL_ATFIGHTER_ATOMICCANNON);

	if(isUse)
	{
		obj.sq_IsEnterSkillLastKeyUnits(SKILL_ATFIGHTER_ATOMICCANNON);

		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0); 
		obj.sq_AddSetStatePacket(STATE_ATFIGHTER_ATOMICCANNON, STATE_PRIORITY_USER, true);
		return true;
	}

	return false;
}


function checkCommandEnable_atfighter_atomiccannon(obj)
{
	if(!obj) return false;

	local state = obj.sq_GetState();

	if(state == STATE_STAND)
		return true;

	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(SKILL_ATFIGHTER_ATOMICCANNON); 
	}


	return true;
}


function onSetState_atfighter_atomiccannon(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	obj.sq_StopMove();

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);

	obj.getVar().setBool(0, false);

	switch(subState)
	{
		case 0:
			obj.getVar().clear_vector();
			obj.getVar().clear_timer_vector();
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATOMICCANNON_BODY_READY);

			break;
		case 1:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATOMICCANNON_BODY_CHARGE);

			break;
		case 2:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATOMICCANNON_BODY_CHARGE_END);

			break;
		case 3:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATOMICCANNON_BODY_RUSH);
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATFIGHTER_ATOMICCANNONRUSH);

			local moveX = obj.sq_GetVectorData(datas, 1);
			local endMoveX = obj.sq_GetVectorData(datas, 2);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(obj.getXPos());
			obj.getVar().push_vector(moveX);
			obj.getVar().push_vector(endMoveX);

			obj.getVar().clear_timer_vector();
			obj.getVar().push_timer_vector();
			local t = obj.getVar().get_timer_vector(0);
			t.setParameter(50, -1);
			t.resetInstant(0);

			sq_CreateDrawOnlyObject(obj, "character/fighter/effect/animation/atatomiccannon/atomiccannon_01dash_dust.ani", ENUM_DRAWLAYER_NORMAL, true);
			break;
		case 4:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_ATOMICCANNON_BODY_PUNCH);
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATFIGHTER_ATOMICCANNONPUNCH);
			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATFIGHTER_ATOMICCANNON, state, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);


			local moveX = obj.sq_GetVectorData(datas, 1);
			obj.getVar().clear_vector();
			obj.getVar().push_vector(obj.getXPos());
			obj.getVar().push_vector(moveX);

			obj.sq_PlaySound("MF_ATOMIC_CANNON_02");

			if(obj.sq_IsMyControlObject())
				sq_flashScreen(obj, 0, 60, 0, 255, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
			
			break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}

function onProcCon_atfighter_atomiccannon(obj)
{
	if(!obj) return;

	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 1:
			local currentT = obj.sq_GetStateTimer();
			local fireT = 2000;
			if(!obj.isDownSkillLastKey() || currentT >= fireT)
			{
				
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(2); 
				obj.sq_AddSetStatePacket(STATE_ATFIGHTER_ATOMICCANNON, STATE_PRIORITY_USER, true);
			}
			break;
	}
}

function onProc_atfighter_atomiccannon(obj)
{
	if(!obj) return;

	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 3:
			local currentT = obj.sq_GetStateTimer();
			local fireT = 150;

			if(obj.getVar().size_vector() >0)
			{
				local moveX = obj.getVar().get_vector(1);

				local dstX = sq_GetDistancePos(obj.getVar().get_vector(0), 
											   obj.getDirection(),
											   sq_GetUniformVelocity(0, moveX, currentT, fireT));

				if(obj.isMovablePos(dstX, obj.getYPos()))
					sq_setCurrentAxisPos(obj, 0, dstX);
				else
				{
					local offset = sq_Abs(dstX - obj.getXPos());
					if(offset != 0)
						obj.getVar().set_vector(1, (moveX > 0) ? moveX - offset : moveX + offset);
				}

				if(currentT >= fireT)
				{
					
					obj.sq_IntVectClear();
					obj.sq_IntVectPush(4); 
					obj.sq_IntVectPush(obj.getVar().get_vector(2)); 
					obj.sq_AddSetStatePacket(STATE_ATFIGHTER_ATOMICCANNON, STATE_PRIORITY_USER, true);
					return;
				}
			}

			local t = obj.getVar().get_timer_vector(0);
			if(t)
			{
				if(t.isOnEvent(currentT) == true)
					if(obj.getVar().getBool(0) == true)
						obj.getVar().setBool(0, false);
			}
			break;
		case 4:
			if(obj.getVar().size_vector() > 0)
			{
				local pAni = obj.getCurrentAnimation();
				local currentT = sq_GetCurrentTime(pAni);
				local fireT = pAni.getDelaySum(0, 6);

				local moveX = obj.getVar().get_vector(1);

				local dstX = sq_GetDistancePos(obj.getVar().get_vector(0),
											   obj.getDirection(),
											   sq_GetUniformVelocity(0, moveX, currentT, fireT));

				if(obj.isMovablePos(dstX, obj.getYPos()))
					sq_setCurrentAxisPos(obj, 0, dstX);
				else
				{
					local offset = sq_Abs(dstX - obj.getXPos());
					if(offset != 0)
						obj.getVar().set_vector(1, (moveX > 0) ? moveX - offset : moveX + offset);
				}
			}
			break;
	}
}


function onEndCurrentAni_atfighter_atomiccannon(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;

	local subState = obj.getSkillSubState();
	if(subState != 4)
	{
		if(subState == 2)
		{
			local direction = obj.getDirection();
			local moveX = 160;
			local endMoveX = 85;
			if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && direction == ENUM_DIRECTION_RIGHT
			   || sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && direction == ENUM_DIRECTION_LEFT)
			{
				obj.sq_IntVectClear();
				obj.sq_IntVectPush(4); 
				obj.sq_IntVectPush(150); 
				obj.sq_AddSetStatePacket(STATE_ATFIGHTER_ATOMICCANNON, STATE_PRIORITY_USER, true);
				return;
			}
			else if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && direction == ENUM_DIRECTION_LEFT
					|| sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && direction == ENUM_DIRECTION_RIGHT)
			{
				moveX = 285;
				endMoveX = 150;
			}
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3); 
			obj.sq_IntVectPush(moveX); 
			obj.sq_IntVectPush(endMoveX); 
			obj.sq_AddSetStatePacket(STATE_ATFIGHTER_ATOMICCANNON, STATE_PRIORITY_USER, true);
			return;
		}

		obj.sq_IntVectClear();
		obj.sq_IntVectPush(subState + 1); 
		obj.sq_AddSetStatePacket(STATE_ATFIGHTER_ATOMICCANNON, STATE_PRIORITY_USER, true);
	}
	else
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
}


function onAttack_atfighter_atomiccannon(obj, damager, boundingBox, isStuck)
{
	if(!obj) return;

	if(isStuck || !damager.isObjectType(OBJECTTYPE_ACTIVE)) return;

	local substate = obj.getSkillSubState();
	switch(substate)
	{
		case 3:
			if(obj.getVar().getBool(0) == false)
			{
				obj.getVar().setBool(0, true);

				local pooledObj = sq_AddDrawOnlyAniFromParent(obj, "character/fighter/effect/animation/atatomiccannon/atomiccannon_05dust.ani", 80, 0, 65);
				sq_SetCurrentDirection(pooledObj, sq_GetOppositeDirection(obj.getDirection()));
			}
			break;
		case 4:
			if(obj.getVar().getBool(0) == false)
			{
				obj.getVar().setBool(0, true);

				sq_SetMyShake(obj, 3, 250);
				sq_CreateDrawOnlyObject(obj, "character/fighter/effect/animation/atatomiccannon/atomiccannon_03finish_hit.ani", ENUM_DRAWLAYER_NORMAL, true);
			}
			break;
	}
}


