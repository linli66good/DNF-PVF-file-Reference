
function checkExecutableSkill_thundercannon(obj)
{
	if (!obj) return false;
	
	local isUse = obj.sq_IsUseSkill(249);

	if (isUse)
	{
		
		local pIntVec = sq_GetGlobalIntVector();
		sq_IntVectorClear(pIntVec);
		sq_IntVectorPush(pIntVec, 0);
		obj.addSetStatePacket(249 , pIntVec, STATE_PRIORITY_FORCE, false, "");
}
}

function checkCommandEnable_thundercannon(obj)
{
	if(!obj)
		return false;

	return true;
}


function onSetState_thundercannon(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	obj.sq_StopMove();
	local state = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(state);
	switch(state)
	{
	case 0:
    obj.sq_SetCurrentAnimation(219);
	break;
	case 1:
    obj.sq_SetCurrentAnimation(220);
	obj.sq_SetCurrentAttackInfo(107);
	obj.getVar("pos").clear_vector();
	obj.getVar("pos").push_vector( obj.getXPos() );
	obj.getVar("pos").push_vector( 70 );
	break;
    }
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
		SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onProc_thundercannon(obj)
{
	if(!obj) return;
	local state = obj.getSkillSubState(); 
	local id = sq_GetObjectId(obj);	
	switch(state)
	{
	case 1:
		local pAni = obj.sq_GetCurrentAni();
		local frmIndex = obj.sq_GetCurrentFrameIndex(pAni);


		local startFrameIndex = 0;
		local endFrameIndex = 1;

		local currentT = sq_GetCurrentTime(pAni);

		if (frmIndex < startFrameIndex)
		{
			obj.setCurrentPos(obj.getVar("pos").get_vector(0),obj.getYPos(),obj.getZPos() );

		}else if (frmIndex > startFrameIndex && frmIndex <= endFrameIndex)
		{
			local startX = obj.getVar("pos").get_vector(0);
			local maxD = obj.getVar("pos").get_vector(1);

			currentT = currentT - pAni.getDelaySum(0,startFrameIndex);
			local maxT = pAni.getDelaySum(startFrameIndex,endFrameIndex);
			if (currentT < maxT)
			{
				local v = sq_GetAccel(0, maxD, currentT,maxT, true);
				local dstX = sq_GetDistancePos(startX, obj.getDirection(), v);

				if( obj.isMovablePos(dstX, obj.getYPos() ))
				{
					sq_setCurrentAxisPos(obj, 0, dstX);
				}

			}
		}
	break;
	}
}

function onEndCurrentAni_thundercannon(obj)
{
	if(!obj) return;
	local state = obj.getSkillSubState(); 
	local id = sq_GetObjectId(obj);	
	switch(state)
	{
	case 0:
		local pIntVec = sq_GetGlobalIntVector();
		sq_IntVectorClear(pIntVec);
		sq_IntVectorPush(pIntVec, 1);
		
		obj.addSetStatePacket(249 , pIntVec, STATE_PRIORITY_FORCE, false, "");		
	break;
	case 1:
        obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	break;
    }
}


function onKeyFrameFlag_thundercannon(obj,flagIndex)
{
	if(!obj)
		return false;
	local state = obj.getSkillSubState(); 
	local id = sq_GetObjectId(obj);	
	switch(state)
	{
	case 1:	
    if (flagIndex == 0)
    {
	obj.sq_PlaySound("MF_PNENTAN");
    }else if (flagIndex == 1)
    {
    sq_flashScreen(obj, 20, 160, 250, 20, sq_RGB(255,255,255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
    sq_SetMyShake(obj,5,100);
	local sizemove= sq_GetIntData(obj, 249, 0)-100;
	obj.sq_StartWrite();
	obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(249 , -1, 0, 1.0));
	obj.sq_WriteDword(20);
	obj.sq_WriteDword(sq_GetIntData(obj, 249, 0));
	obj.sq_WriteDword(sq_GetLevelData(obj, 249, 1, sq_GetSkillLevel(obj, 249) ));
	obj.sq_WriteDword(sq_GetLevelData(obj, 249, 3, sq_GetSkillLevel(obj, 249) ));
	obj.sq_WriteDword(sq_GetLevelData(obj, 249, 2, sq_GetSkillLevel(obj, 249) ));
	obj.sq_WriteDword(obj.sq_GetBonusRateWithPassive(249 , -1, 4, 1.0));
	obj.sq_SendCreatePassiveObjectPacket(24395, 0, 50, 0, 0-sizemove/2);
	
    }else if (flagIndex == 2)
    {
    sq_SetMyShake(obj,1,330);
    }
	break;
    }
        return true;	
}
