

function checkCommandEnable_flyingchainkick(obj)
{
	return true;
}



function checkExecutableSkill_flyingchainkick(obj)
{
	if(!obj) return false;

	local isUse = obj.sq_IsUseSkill(SKILL_FLYINGCHAINKICK);
	if(isUse)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(STATE_FLYINGCHAINKICK, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}



function onSetState_flyingchainkick(obj, state, datas, isResetTimer)
{	
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);
	obj.sq_StopMove();

	switch(subState)
	{
		case 0:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_FLYINGCHAINKICK1);
		break;
		case 1:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_FLYINGCHAINKICK2);
			if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == ENUM_DIRECTION_RIGHT || sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == ENUM_DIRECTION_LEFT)
			{
				obj.sq_SetStaticMoveInfo(0, 600, 600, false);
				obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			}
			obj.sq_SetCurrentAttackInfo(0);
			local damage = obj.sq_GetBonusRateWithPassive(SKILL_FLYINGCHAINKICK, -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(damage);

			local appendage = sq_AttractToMe(obj, sq_GetIntData(obj, SKILL_FLYINGCHAINKICK, 0), 80, sq_GetIntData(obj, SKILL_FLYINGCHAINKICK, 1));
			obj.getVar().setAppendage(101, appendage);
		break;
		case 2:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_FLYINGCHAINKICK1);
		break;
		case 3:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_FLYINGCHAINKICK2);
			if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_RIGHT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == ENUM_DIRECTION_RIGHT || sq_IsKeyDown(OPTION_HOTKEY_MOVE_LEFT, ENUM_SUBKEY_TYPE_ALL) && obj.getDirection() == ENUM_DIRECTION_LEFT)
			{
				obj.sq_SetStaticMoveInfo(0, 600, 600, false);
				obj.sq_SetMoveDirection(obj.getDirection(), ENUM_DIRECTION_NEUTRAL);
			}
			obj.sq_SetCurrentAttackInfo(0);
			local damage = obj.sq_GetBonusRateWithPassive(SKILL_FLYINGCHAINKICK, -1, 0, 1.0);
			obj.sq_SetCurrentAttackBonusRate(damage);

			local appendage = sq_AttractToMe(obj, sq_GetIntData(obj, SKILL_FLYINGCHAINKICK, 0), 80, sq_GetIntData(obj, SKILL_FLYINGCHAINKICK, 1));
			obj.getVar().setAppendage(101, appendage);
		break;
		case 4:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_FLYINGCHAINKICK3);
			obj.sq_SetCurrentAttackInfo(1);
			local damage = obj.sq_GetBonusRateWithPassive(SKILL_FLYINGCHAINKICK, -1, 1, 1.0);
			obj.sq_SetCurrentAttackBonusRate(damage);

			local pAttack = sq_GetCurrentAttackInfo(obj);
			sq_SetCurrentAttacknBackForce(pAttack, sq_GetIntData(obj, SKILL_FLYINGCHAINKICK, 3));
			sq_SetCurrentAttacknUpForce(pAttack, sq_GetIntData(obj, SKILL_FLYINGCHAINKICK, 4));
			sq_SetCurrentAttackDirection(pAttack, ATTACK_DIRECTION_UP);

			local pAni = obj.getCurrentAnimation();
			local size = 1.0;
			local sizeRate = sq_GetIntData(obj, SKILL_FLYINGCHAINKICK, 2);
			sizeRate = sizeRate.tofloat() / 100.0;
			sq_SetAttackBoundingBoxSizeRate(pAni, size * sizeRate, size * sizeRate, size * sizeRate);
		break;
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}



function onEndCurrentAni_flyingchainkick(obj)
{
	if(!obj) return;

	if(!obj.isMyControlObject())
	{
		return;
	}

	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 0:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(1);
			obj.sq_AddSetStatePacket(STATE_FLYINGCHAINKICK, STATE_PRIORITY_IGNORE_FORCE, true);
		break;
		case 1:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(2);
			obj.sq_AddSetStatePacket(STATE_FLYINGCHAINKICK, STATE_PRIORITY_IGNORE_FORCE, true);
		break;
		case 2:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(3);
			obj.sq_AddSetStatePacket(STATE_FLYINGCHAINKICK, STATE_PRIORITY_IGNORE_FORCE, true);
		break;
		case 3:
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(4);
			obj.sq_AddSetStatePacket(STATE_FLYINGCHAINKICK, STATE_PRIORITY_IGNORE_FORCE, true);
		break;
		case 4:
			obj.sq_IntVectClear();
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_IGNORE_FORCE, true);
		break;
	}
}


function onEndState_flyingchainkick(obj, new_state)
{

	if(!obj) return;

	local appendage = obj.getVar().getAppendage(101);
	if(appendage)
		appendage.setValid(false);

}

function onKeyFrameFlag_flyingchainkick(obj, flagIndex)
{
	if(!obj) return false;

	local subState = obj.getSkillSubState();
	switch(subState)
	{
		case 4:
			switch(flagIndex)
			{
				case 10001:
					if(obj.isMyControlObject())
					{
						sq_SetMyShake(obj, 10, 300);
						sq_flashScreen(obj, 70, 140, 70, 160, sq_RGB(255, 255, 255), GRAPHICEFFECT_NONE, ENUM_DRAWLAYER_BOTTOM);
					}
					local ani = sq_CreateAnimation("", "character/fighter/effect/animation/atflyingchainkick/atflyingchainkicknormalattackexp.ani");
					local size = 1.0;
					local sizeRate = sq_GetIntData(obj, SKILL_FLYINGCHAINKICK, 2);
					sizeRate = sizeRate.tofloat() / 100.0;
					ani.setImageRateFromOriginal(size * sizeRate, size * sizeRate);
					ani.setAutoLayerWorkAnimationAddSizeRate(size * sizeRate);
					local pooledObj = sq_CreatePooledObject(ani, true);
					pooledObj.setCurrentPos(sq_GetDistancePos(obj.getXPos(), obj.getDirection(), 0), obj.getYPos(), obj.getZPos());
					pooledObj.setCurrentDirection(obj.getDirection());
					sq_AddObject(obj, pooledObj, 2, false);
				break;
			}
		break;
	}
	return true;
}



function onProc_flyingchainkick(obj)
{
	if(!obj) return;

	local subState = obj.getSkillSubState();
	local pAni = sq_GetCurrentAnimation(obj);
	switch(subState)
	{
		case 0:
			if(obj.sq_IsKeyFrameFlag(pAni, 10001))
			{
				sq_SetZVelocity(obj, 100, 100);
			}
		break;
		case 1:
			if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL))
			{
				sq_SetVelocity(obj, 1, -300.0);
			}
			else if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL))
			{
				sq_SetVelocity(obj, 1, 300.0);
			}
		break;
		case 2:
			if(obj.sq_IsKeyFrameFlag(pAni, 10001))
			{
				sq_SetZVelocity(obj, 100, 100);
			}
		break;
		case 3:
			if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_UP, ENUM_SUBKEY_TYPE_ALL))
			{
				sq_SetVelocity(obj, 1, -300.0);
			}
			else if(sq_IsKeyDown(OPTION_HOTKEY_MOVE_DOWN, ENUM_SUBKEY_TYPE_ALL))
			{
				sq_SetVelocity(obj, 1, 300.0);
			}
		break;
	}
	return true;
}

