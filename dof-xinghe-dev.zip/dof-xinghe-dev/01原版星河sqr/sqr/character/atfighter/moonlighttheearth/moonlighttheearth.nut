




function checkExecutableSkill_atfighter_moonlighttheearth(obj)
{
	if(!obj) return false;

	local isUse = obj.sq_IsUseSkill(SKILL_ATFIGHTER_MOONLIGHTTHEEARTH);

	if(isUse)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0); 
		obj.sq_AddSetStatePacket(STATE_ATFIGHTER_MOONLIGHTTHEEARTH, STATE_PRIORITY_USER, true);
		return true;
	}

	return false;
}


function checkCommandEnable_atfighter_moonlighttheearth(obj)
{
	if(!obj) return false;

	local state = obj.sq_GetState();

	if(state == STATE_STAND)
		return true;

	if(state == STATE_ATTACK)
	{
		return obj.sq_IsCommandEnable(SKILL_ATFIGHTER_MOONLIGHTTHEEARTH); 
	}


	return true;
}


function onSetState_atfighter_moonlighttheearth(obj, state, datas, isResetTimer)
{
	if(!obj) return;

	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);

	switch(subState)
	{
		case 0:
			obj.sq_StopMove();

			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_MOONLIGHTTHEEARTH_BODY_START);

			obj.sq_PlaySound("MF_MOONLIGHT_EARTH");
			break;
		case 1:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_MOONLIGHTTHEEARTH_BODY_LOOP);
			obj.sq_SetCurrentAttackInfo(CUSTOM_ATTACK_ATFIGHTER_MOONLIGHTTHEEARTH);

			local attackBonusRate = obj.sq_GetBonusRateWithPassive(SKILL_ATFIGHTER_MOONLIGHTTHEEARTH, state, 2, 1.0);
			obj.sq_SetCurrentAttackBonusRate(attackBonusRate);

			local skill_level = sq_GetSkillLevel(obj, SKILL_ATFIGHTER_MOONLIGHTTHEEARTH);
			local time = obj.sq_GetLevelData(SKILL_ATFIGHTER_MOONLIGHTTHEEARTH, 0, skill_level);
			local atkCount = obj.sq_GetLevelData(SKILL_ATFIGHTER_MOONLIGHTTHEEARTH, 1, skill_level);

			obj.getVar().clear_timer_vector();
			obj.getVar().push_timer_vector();
			local t = obj.getVar().get_timer_vector(0);
			t.setParameter(time / atkCount, atkCount);
			t.setEventOnStart(true);
			t.resetInstant(0);

			break;
		case 2:
			obj.sq_SetCurrentAnimation(CUSTOM_ANI_ATFIGHTER_MOONLIGHTTHEEARTH_BODY_END);
			if(sq_GetSkillLevel(obj, 237) > 0 && CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut") == true)
			{
			obj.sq_StartWrite();
			obj.sq_WriteDword(515);
			obj.sq_SendCreatePassiveObjectPacket(24333, 0, 0, 0, 50);
			}
			break;
	}

	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_CAST_SPEED, SPEED_TYPE_CAST_SPEED, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_atfighter_moonlighttheearth(obj)
{
	if(!obj) return;
	if(!obj.sq_IsMyControlObject()) return;

	local subState = obj.getSkillSubState();
	if(subState != 2)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(subState + 1); 
		obj.sq_AddSetStatePacket(STATE_ATFIGHTER_MOONLIGHTTHEEARTH, STATE_PRIORITY_USER, true);
	}
	else
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
}


function onProcCon_atfighter_moonlighttheearth(obj)
{
	if(!obj) return;

	local subState = obj.getSkillSubState();
	if(subState == 1)
	{
		local t = obj.getVar().get_timer_vector(0);
		if(!t) return;

		if(t.isOnEvent(obj.sq_GetStateTimer()) == true)
		{
			local xPos = obj.getXPos();
			local yPos = obj.getYPos();
			local zPos = obj.getZPos();
			local xDistance = 300;
			local yDistance = 130;
			local zDistance = 300;
			local objectManager = obj.getObjectManager();
			local objectcount = objectManager.getCollisionObjectNumber();

			for(local i = 0; i < objectcount; i++)
			{
				local object = objectManager.getCollisionObject(i);
				if(!obj.isEnemy(object) || !object || !object.isInDamagableState(obj)) continue;

				if(sq_Abs(xPos - sq_GetXPos(object)) > xDistance
				   || sq_Abs(yPos - sq_GetYPos(object)) > yDistance
				   || sq_Abs(zPos - sq_GetZPos(object)) > zDistance) continue;

				local activeObj = sq_GetCNRDObjectToActiveObject(object);
				if(activeObj)
				{
					if(!activeObj.isDead())
						sq_SendHitObjectPacket(obj, object, 0, 0, sq_GetHeightObject(object) / 2);
				}
				else if(object.isObjectType(OBJECTTYPE_PASSIVE))
					sq_SendHitObjectPacket(obj, object, 0, 0, sq_GetHeightObject(object) / 2);
			}
			sq_SetMyShake(obj, 3, t.getEventTerm());
		}

		if(t.isEnd())
		{
			obj.sq_IntVectClear();
			obj.sq_IntVectPush(subState + 1); 
			obj.sq_AddSetStatePacket(STATE_ATFIGHTER_MOONLIGHTTHEEARTH, STATE_PRIORITY_USER, true);
		}
	}
}


