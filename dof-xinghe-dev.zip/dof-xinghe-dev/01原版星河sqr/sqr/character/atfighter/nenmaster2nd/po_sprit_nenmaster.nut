
function setCustomData_po_sprit_nenmaster(obj, receiveData)
{

	local atkRate = receiveData.readDword();
	local id = receiveData.readDword();
	
	if (id == 20)
    {
		local size = receiveData.readDword();	
		local bloodProc = receiveData.readDword();
		local bloodleve = receiveData.readDword();
		local bloodTime = receiveData.readDword();
		local bloodRate = receiveData.readDword();
		
        local ani = obj.getVar().GetAnimationMap("20", 
        "passiveobject/zrr_skill/atfighter/animation/atthundercannon/atthundercannon_front20.ani"); 
        obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);

		local attackInfo = sq_GetCustomAttackInfo(obj, 25);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, atkRate);	
		
        sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,
		ACTIVESTATUS_LIGHTNING, bloodProc, bloodleve, bloodTime,bloodRate);
		
		local imageRate = size.tofloat() / 100.0;
		ani.setImageRateFromOriginal(imageRate, imageRate);
		ani.setAutoLayerWorkAnimationAddSizeRate(imageRate);
		sq_SetAttackBoundingBoxSizeRate(ani, imageRate, imageRate, imageRate);
		
		local parentChr = obj.getTopCharacter();
		parentChr = sq_GetCNRDObjectToSQRCharacter(parentChr);

		local pAni = obj.getCurrentAnimation();
		local delay = pAni.getDelaySum(false);
		local initDelay = 0;
		local hitCnt = 	sq_GetIntData(parentChr, 249, 1)+3;
		local term = delay / hitCnt;
		parentChr.sq_timer_.setParameter(term, hitCnt);
		parentChr.sq_timer_.resetInstant(initDelay);
	}
	else if (id == 21)
    {
		local size = receiveData.readDword();	
		local bloodProc = receiveData.readDword();
		local bloodleve = receiveData.readDword();
		local bloodTime = receiveData.readDword();
		local bloodRate = receiveData.readDword();
		
        local ani = obj.getVar().GetAnimationMap("21", 
        "passiveobject/zrr_skill/atfighter/animation/atthunderkick/thunderkickhit_lighting.ani"); 
        obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);

		local attackInfo = sq_GetCustomAttackInfo(obj, 26);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, atkRate);	
		
        sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,
		ACTIVESTATUS_LIGHTNING, bloodProc, bloodleve, bloodTime,bloodRate);
		
		local imageRate = size.tofloat() / 100.0;
		ani.setImageRateFromOriginal(imageRate, imageRate);
		ani.setAutoLayerWorkAnimationAddSizeRate(imageRate);
		sq_SetAttackBoundingBoxSizeRate(ani, imageRate, imageRate, imageRate);
		
		crethunderkickfloor_light(obj, 0, 0, 0, size)	
	}
	else if (id == 22)
    {
		local size = receiveData.readDword();	
		local bloodProc = receiveData.readDword();
		local bloodleve = receiveData.readDword();
		local bloodTime = receiveData.readDword();
		local bloodRate = receiveData.readDword();
		crethundertigerattback_00(obj, 0, 0, 0, size)
        local ani = obj.getVar().GetAnimationMap("22", 
        "passiveobject/zrr_skill/atfighter/animation/atthundertiger/thundertigerattfront_00.ani"); 
        obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);
		sq_SetMyShake(obj, 8, 300);
		local attackInfo = sq_GetCustomAttackInfo(obj, 28);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, atkRate);	
		
        sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,
		ACTIVESTATUS_LIGHTNING, bloodProc, bloodleve, bloodTime,bloodRate);
		
		local imageRate = size.tofloat() / 100.0;
		ani.setImageRateFromOriginal(imageRate, imageRate);
		ani.setAutoLayerWorkAnimationAddSizeRate(imageRate);
		sq_SetAttackBoundingBoxSizeRate(ani, imageRate, imageRate, imageRate);
		crethundertigerattbottom_00(obj, 0, 0, 0, size)
	}
	else if (id == 23)
    {
		local size = receiveData.readDword();	
		local bloodProc = receiveData.readDword();
		local bloodleve = receiveData.readDword();
		local bloodTime = receiveData.readDword();
		local bloodRate = receiveData.readDword();
		
        local ani = obj.getVar().GetAnimationMap("23", 
        "passiveobject/zrr_skill/atfighter/animation/atthundertiger/thundertigerbottomloop_00.ani"); 
        obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_BOTTOM);

		local attackInfo = sq_GetCustomAttackInfo(obj, 29);
		sq_SetCurrentAttackInfo(obj, attackInfo);
		local attackInfo = sq_GetCurrentAttackInfo(obj);
		sq_SetCurrentAttackBonusRate(attackInfo, atkRate);	
		
        sq_SetChangeStatusIntoAttackInfo(attackInfo, 0,
		ACTIVESTATUS_LIGHTNING, bloodProc, bloodleve, bloodTime,bloodRate);
		
		local imageRate = size.tofloat() / 100.0;
		ani.setImageRateFromOriginal(imageRate, imageRate);
		ani.setAutoLayerWorkAnimationAddSizeRate(imageRate);
		sq_SetAttackBoundingBoxSizeRate(ani, imageRate, imageRate, imageRate);

		local parentChr = obj.getTopCharacter();
		parentChr = sq_GetCNRDObjectToSQRCharacter(parentChr);		

		local initDelay = 0;
		local hitCnt = 	sq_GetIntData(parentChr, 251, 1);
		local term = sq_GetIntData(parentChr, 251, 2);
		parentChr.sq_timer_.setParameter(term, hitCnt);
		parentChr.sq_timer_.resetInstant(initDelay);

	}
	else if (id == 24)
    {
		local size = receiveData.readDword();	
		
        local ani = obj.getVar().GetAnimationMap("24", 
        "character/fighter/effect/animation/atthundertiger/thundertigerfrontloop_00.ani"); 
        obj.setCurrentAnimation(ani);
		sq_ChangeDrawLayer(obj, ENUM_DRAWLAYER_NORMAL);
		
		local imageRate = size.tofloat() / 100.0;
		ani.setImageRateFromOriginal(imageRate, imageRate);
		ani.setAutoLayerWorkAnimationAddSizeRate(imageRate);
		sq_SetAttackBoundingBoxSizeRate(ani, imageRate, imageRate, imageRate);
	
		local parentChr = obj.getTopCharacter();
		parentChr = sq_GetCNRDObjectToSQRCharacter(parentChr);	
		
		local initDelay = 0;
		local hitCnt = 	sq_GetIntData(parentChr, 251, 1);
		local term = sq_GetIntData(parentChr, 251, 2);
		parentChr.sq_timer_.setParameter(term, hitCnt);
		parentChr.sq_timer_.resetInstant(initDelay);
	}
    obj.getVar("id").clear_vector();
    obj.getVar("id").push_vector(id);
    obj.getVar("atk").clear_vector();
    obj.getVar("atk").push_vector(atkRate);
}




function procAppend_po_sprit_nenmaster(obj)
{
    local id = obj.getVar("id").get_vector(0);
    if (id == 20)
    {
	
	local pAni = obj.getCurrentAnimation();
	local currentT = sq_GetCurrentTime(pAni);
		local parentChr = obj.getTopCharacter();
		parentChr = sq_GetCNRDObjectToSQRCharacter(parentChr);
	if (parentChr.sq_timer_.isOnEvent(currentT) == true)
	{
	obj.resetHitObjectList();
	}
    }else if (id == 23)
    {
	local pAni = obj.getCurrentAnimation();
	local currentT = sq_GetCurrentTime(pAni);
	local parentChr = obj.getTopCharacter();
	parentChr = sq_GetCNRDObjectToSQRCharacter(parentChr);
	if (parentChr.sq_timer_.isOnEvent(currentT) == true)
	{
	obj.resetHitObjectList();
	}
	if (parentChr.sq_timer_.isEnd())
	{
	crethundertigerbottomend_00(obj, 0, 0, 0, sq_GetIntData(parentChr, 251, 0))
	sq_SendDestroyPacketPassiveObject(obj);	

	}
    }else if (id == 24)
    {
	local pAni = obj.getCurrentAnimation();
	local currentT = sq_GetCurrentTime(pAni);
	local parentChr = obj.getTopCharacter();
	parentChr = sq_GetCNRDObjectToSQRCharacter(parentChr);
	if (parentChr.sq_timer_.isEnd())
	{
		crethundertigerfrontend_00(obj, 0, 0, 0, sq_GetIntData(parentChr, 251, 0))
		sq_SendDestroyPacketPassiveObject(obj);	

	}
	}
	
}

	
function onEndCurrentAni_po_sprit_nenmaster(obj)
{
    local id = obj.getVar("id").get_vector(0);

    if (id == 20)
    {

		sq_SendDestroyPacketPassiveObject(obj);	
    }else if (id == 21)
    {

		sq_SendDestroyPacketPassiveObject(obj);	
    }else if (id == 22)
    {

		sq_SendDestroyPacketPassiveObject(obj);	
    }
}










