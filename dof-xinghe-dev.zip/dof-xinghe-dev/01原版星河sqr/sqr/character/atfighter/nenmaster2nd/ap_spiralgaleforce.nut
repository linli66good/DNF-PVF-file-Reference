
function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("proc", "proc_appendage_SpiralGaleForce");
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_SpiralGaleForce");
	appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_SpiralGaleForce");
	appendage.sq_AddFunctionName("onStartMap", "onStartMap_appendage_SpiralGaleForce");
	appendage.sq_AddFunctionName("onEnd", "onEnd_appendage_SpiralGaleForce");
}


function onEnd_appendage_SpiralGaleForce(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	destroyObjectByVar(appendage, "SpiralGaleForcePool");
	return;
}



function onStartMap_appendage_SpiralGaleForce(appendage) {
	if (!appendage) return;

	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	local aniPath = "character/fighter/effect/animation/atspiralgaleforce/buff_01.ani";
	local pooledObj = createAnimationPooledEx(parentObj, aniPath, 2, true, parentObj.getXPos(), parentObj.getYPos() - 1, parentObj.getZPos(), false);
	destroyObjectByVar(appendage, "SpiralGaleForcePool");
	appendage.getVar("SpiralGaleForcePool").clear_obj_vector();
	appendage.getVar("SpiralGaleForcePool").push_obj_vector(pooledObj);
}


function onStart_appendage_SpiralGaleForce(appendage) {
	if (!appendage) {
		return;
	}
	local parentObj = appendage.getParent();
}


function proc_appendage_SpiralGaleForce(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}

	if (parentObj.isDead()) {
		parentObj.getVar("SpiralInhaleEnergy").clear_vector();
		parentObj.getVar("SpiralInhaleEnergy").push_vector(0);
		destroyObjectByVar(parentObj, "SpiralGaleForcePool");
		appendage.setValid(false);
		return;
	}
	local SpiralInhaleEnergy_int = parentObj.getVar("SpiralInhaleEnergy").get_vector(0);
	if (SpiralInhaleEnergy_int == 0) appendage.setValid(false);
}


function onAttackParent_appendage_SpiralGaleForce(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
}

