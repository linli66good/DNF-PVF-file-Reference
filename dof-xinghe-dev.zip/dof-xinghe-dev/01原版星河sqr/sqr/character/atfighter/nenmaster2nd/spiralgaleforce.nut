
function checkExecutableSkill_SpiralGaleForce(obj) {
	if (!obj) return false;
	local isUse = obj.sq_IsUseSkill(237);

	if (isUse) {
		local apPath = "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut";
		local apPath1 = "character/atfighter/nenmaster2nd/ap_spiralnen.nut";
		if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath)) {
			destroyObjectByVar(obj, "SpiralGaleForcePool");
			CNSquirrelAppendage.sq_RemoveAppendage(obj, apPath);
			if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath1)) CNSquirrelAppendage.sq_RemoveAppendage(obj, apPath1);
			return;
		}
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(0);
		obj.sq_AddSetStatePacket(237, STATE_PRIORITY_IGNORE_FORCE, true);
		return true;
	}
	return false;
}


function checkCommandEnable_SpiralGaleForce(obj) {
	if (!obj) return false;
	local apPath = "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut";
	local isSpecificAp = CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath);
	if (isSpecificAp)
		return true;
	else {
		if (obj.getVar("SpiralInhaleEnergy").size_vector() > 0 && obj.getVar("SpiralInhaleEnergy").get_vector(0) >= 1000) return true;
	}

	return false;
}


function onSetState_SpiralGaleForce(obj, state, datas, isResetTimer) {
	if (!obj) return;
	local subState = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(subState);

	switch (subState) {
		case 0:
			obj.sq_StopMove();
			obj.sq_PlaySound("MF_SPIRAL_GALEFORCE");
			obj.sq_SetCurrentAnimation(199);

			break;
		case 1:
			obj.sq_SetCurrentAnimation(200);
			break;
	}
	obj.sq_SetStaticSpeedInfo(4, 4, SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}


function onEndCurrentAni_SpiralGaleForce(obj) {
	if (!obj) return;
	local subState = obj.getSkillSubState();
	switch (subState) {
		case 0:
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, false);
			break;
		case 1:
			obj.sq_AddSetStatePacket(0, STATE_PRIORITY_IGNORE_FORCE, false);
			break;
	}
}


function onKeyFrameFlag_SpiralGaleForce(obj, flagIndex) {
	if (!obj) return false;
	switch (flagIndex) {
		case 1:
			if (obj.isMyControlObject()) sq_SetMyShake(obj, 1, 150);

			local aniPath = "passiveobject/chang_qing_skill/atfighter/animation/atspiralgaleforce/cast2_effect_01.ani";
			createAnimationPooledEx(obj, aniPath, 1, true, obj.getXPos(), obj.getYPos(), obj.getZPos() + 50, false);

			local apPath = "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut";
			local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, apPath, false);
			if (appendage != null) {
				appendage.sq_SetValidTime(0);
				appendage.setAppendCauseSkill(BUFF_CAUSE_SKILL, sq_getJob(obj), 237, sq_GetSkillLevel(obj, 237));
				appendage.setEnableIsBuff(true);
				CNSquirrelAppendage.sq_Append(appendage, obj, obj, true);
			}

			local aniPath1 = "character/fighter/effect/animation/atspiralgaleforce/buff_01.ani";
			local pooledObj = createAnimationPooledEx(obj, aniPath1, 2, true, obj.getXPos(), obj.getYPos() - 1, obj.getZPos(), false);
			destroyObjectByVar(appendage, "SpiralGaleForcePool");
			appendage.getVar("SpiralGaleForcePool").clear_obj_vector();
			appendage.getVar("SpiralGaleForcePool").push_obj_vector(pooledObj);

			break;
	}
	return true;
}

function createAnimationPooledEx(obj, aniPath, layer, moveWithParent, xPos, yPos, zPos, aniEx) {
	local ani = sq_CreateAnimation("", aniPath);
	if (aniEx != false) {
		ani.setImageRateFromOriginal(aniEx, aniEx);
		ani.setAutoLayerWorkAnimationAddSizeRate(aniEx);
	}

	local pooledObj = sq_CreatePooledObject(ani, true);

	pooledObj.setCurrentPos(xPos, yPos, zPos);
	if (moveWithParent) sq_moveWithParent(obj, pooledObj);

	sq_SetEnumDrawLayer(pooledObj, layer);
	sq_SetCurrentDirection(pooledObj, obj.getDirection());

	sq_AddObject(obj, pooledObj, OBJECTTYPE_DRAWONLY, false);

	return pooledObj;
}







