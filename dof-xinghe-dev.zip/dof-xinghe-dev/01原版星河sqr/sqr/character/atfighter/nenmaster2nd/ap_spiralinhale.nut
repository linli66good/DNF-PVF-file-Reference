
function sq_AddFunctionName(appendage) {
	appendage.sq_AddFunctionName("proc", "proc_appendage_SpiralInhale");
	appendage.sq_AddFunctionName("onStart", "onStart_appendage_SpiralInhale");
	appendage.sq_AddFunctionName("onAttackParent", "onAttackParent_appendage_SpiralInhale");
}


function onStart_appendage_SpiralInhale(appendage) {
	if (!appendage) {
		return;
	}
	local parentObj = appendage.getParent();
	local parentObj = sq_GetCNRDObjectToCharacter(parentObj);
	parentObj.getVar("SpiralInhaleEnergy").clear_vector();
	parentObj.getVar("SpiralInhaleEnergy").push_vector(0);
}


function proc_appendage_SpiralInhale(appendage) {
	if (!appendage) return;
	local parentObj = appendage.getParent();
	if (!parentObj) {
		appendage.setValid(false);
		return;
	}
}


function onAttackParent_appendage_SpiralInhale(appendage, realAttacker, damager, boundingBox, isStuck) {
	if (!appendage || !appendage.isValid()) return;
	local parentObj = appendage.getParent();
	local parentObj = sq_GetCNRDObjectToCharacter(parentObj);

	if (realAttacker.isObjectType(OBJECTTYPE_PASSIVE)) {
		realAttacker = sq_GetCNRDObjectToCollisionObject(realAttacker);
		local colObjId = realAttacker.getCollisionObjectIndex();

		local SpiralInhaleEnergy_int = parentObj.getVar("SpiralInhaleEnergy").get_vector(0);
		local apPath = "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut";
		local isSpecificAp = CNSquirrelAppendage.sq_IsAppendAppendage(parentObj, apPath);
		if (colObjId == 46004 || colObjId == 21054 || colObjId == 21055 || colObjId == 21056 || colObjId == 21079 || colObjId == 21067 || colObjId == 21062 || colObjId == 24395 || colObjId == 24375) {
			if (!realAttacker.getVar("SpiralInhaleIs").getBool(0) && !isSpecificAp) {
				parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 150);
				realAttacker.getVar("SpiralInhaleIs").setBool(0, true);
			}
		} else if (colObjId == 21085 && !isSpecificAp) {
			if (!parentObj.getVar("SpiralInha	leIs").getBool(0)) {
				parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 150);
				parentObj.getVar("SpiralInhaleIs").setBool(0, true);
			}
		} else if (colObjId == 21053) {
			if (!realAttacker.getVar("SpiralInhaleIs").getBool(0)) {
				parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 150);
				realAttacker.getVar("SpiralInhaleIs").setBool(0, true);
			}
		}
	} else if (realAttacker.isObjectType(OBJECTTYPE_CHARACTER)) {
		local SpiralInhaleEnergy_int = parentObj.getVar("SpiralInhaleEnergy").get_vector(0);
		local skillIndex = parentObj.getCurrentSkillIndex();
		if (parentObj.isCurrentCutomAniIndex(52))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 30);
		else if (parentObj.isCurrentCutomAniIndex(53))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 30);
		else if (parentObj.isCurrentCutomAniIndex(54))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 30);
		else if (parentObj.isCurrentCutomAniIndex(55))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 30);
		else if (parentObj.isCurrentCutomAniIndex(57))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 30);
		else if (parentObj.isCurrentCutomAniIndex(58))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 30);
		else if (parentObj.isCurrentCutomAniIndex(143))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 30);
		else if (parentObj.isCurrentCutomAniIndex(215))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 300);
		else if (parentObj.isCurrentCutomAniIndex(153))
			parentObj.getVar("SpiralInhaleEnergy").set_vector(0, SpiralInhaleEnergy_int + 1000);
	}

	if (parentObj.getVar("SpiralInhaleEnergy").get_vector(0) > 1000) parentObj.getVar("SpiralInhaleEnergy").set_vector(0, 1000);
}

