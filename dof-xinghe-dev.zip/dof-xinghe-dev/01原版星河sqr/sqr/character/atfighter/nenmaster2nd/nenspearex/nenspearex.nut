function onSetState_nenspearex(obj, state, datas, isResetTimer)
{
	if(!obj) return;
	local substate = obj.sq_GetVectorData(datas, 0);
	obj.setSkillSubState(substate);
	obj.sq_StopMove();
	if(substate == 0)
	{
			obj.sq_SetCurrentAnimation(125);

	}
	if(substate == 1)
	{
			obj.sq_SetCurrentAnimation(126);
			obj.sq_StartWrite();
			obj.sq_WriteDword(503);
			obj.sq_SendCreatePassiveObjectPacket(24333, 0, 85, 0, 85);
			obj.sq_StartWrite();
			obj.sq_WriteDword(504);
			obj.sq_SendCreatePassiveObjectPacket(24333, 0, 85, 0, 85);
	}
	obj.sq_SetStaticSpeedInfo(SPEED_TYPE_ATTACK_SPEED, SPEED_TYPE_ATTACK_SPEED,
	SPEED_VALUE_DEFAULT, SPEED_VALUE_DEFAULT, 1.0, 1.0);
}

function onEndCurrentAni_nenspearex(obj)
{
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		obj.sq_IntVectClear();
		obj.sq_IntVectPush(1);
		obj.sq_AddSetStatePacket(150, STATE_PRIORITY_IGNORE_FORCE, true);
	}
	if(substate == 1)
	{
		obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
	}
}


function onKeyFrameFlag_nenspearex(obj,flagIndex)
{
	if(!obj)
		return false;
	local substate = obj.getSkillSubState();
	if(substate == 0)
	{
		if (flagIndex == 1)
		{

		}
	}
	return true;
}
