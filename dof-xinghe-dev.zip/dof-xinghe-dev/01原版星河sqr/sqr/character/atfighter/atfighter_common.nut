
function setState_ATFighter(obj, state, datas, isResetTimer) {
	if (!obj) return;
	
	
	setState_dragonslayerlaser(obj, state, datas, isResetTimer);  
	return;
}

function ATfighter_Nenmaster_addSetStatePacket(obj, state, datas)
{
	if(sq_GetSkillLevel(obj, 237)<1) return;
		local SubState = obj.sq_GetVectorData(datas, 0);
	if(CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut") == true)
	{
		switch(state)
		{
			case 66:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(150, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
			case 70:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(151, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
			case 56:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(152, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
		}
	}
	return;
}


function ATfighter_Striker_addSetStatePacket(obj, state, datas)
{
	if(sq_GetSkillLevel(obj, 234)<1) return;
		local SubState = obj.sq_GetVectorData(datas, 0);
		switch(state)
		{
			case 21:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(153, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
			case 43:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(154, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
			case 50:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(155, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
			case 38:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(156, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
			case 49:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(157, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
			case 67:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(158, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
			case 224:
					obj.sq_IntVectClear()
					obj.sq_IntVectPush(0)
					obj.sq_AddSetStatePacket(159, STATE_PRIORITY_IGNORE_FORCE, true)
			break;
		}
	return;
}


function addSetStatePacket_ATFighter(obj, state, datas) {
	if(!obj) return;
	ATfighter_Nenmaster_addSetStatePacket(obj, state, datas);
	ATfighter_Striker_addSetStatePacket(obj, state, datas);
	if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/appendage/ap_flamelegs.nut")) {
		if (state == 62 && obj.sq_GetVectorData(datas, 0) == -1)
			return -1;
		else {
			local appendage = CNSquirrelAppendage.sq_GetAppendage(obj, "character/atfighter/appendage/ap_flamelegs.nut");
			if (!appendage || appendage.getVar().getBool(1) != true) return 1;

			switch (state) {
				case 0:
				case 8:
				case 14:
					if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/appendage/ap_flamelegs_add.nut")) return 1;
					local appendage1 = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, -1, false, "character/atfighter/appendage/ap_flamelegs_add.nut", true);
					
					local skillLevel = sq_GetSkillLevel(obj, 41);
					appendage1.setAppendCauseSkill(BUFF_CAUSE_SKILL, ENUM_CHARACTERJOB_AT_FIGHTER, 41, skillLevel);
					CNSquirrelAppendage.sq_AppendAppendageID(appendage1, obj, obj, 41, true);
					local levelData = obj.sq_GetLevelData(41, 9, skillLevel);
					local change_appendage = appendage1.sq_getChangeStatus("changeStatus");
					if (!change_appendage) change_appendage = appendage1.sq_AddChangeStatusAppendageID(obj, obj, 0, CHANGE_STATUS_TYPE_MAGICAL_ATTACK_BONUS, true, levelData, APID_COMMON);
					if (change_appendage) {
						change_appendage.clearParameter();
						change_appendage.addParameter(CHANGE_STATUS_TYPE_MAGICAL_ATTACK_BONUS, true, levelData.tofloat());
						change_appendage.addParameter(CHANGE_STATUS_TYPE_PHYSICAL_ATTACK_BONUS, true, levelData.tofloat());
					}
					break;
			}
		}
	}
	return 1;
}

 
function setEnableCancelSkill_ATFighter(obj, isEnable) {
	if (!obj) return false;

	if (!obj.isMyControlObject()) return false;
	if (!isEnable) return true;
	obj.setSkillCommandEnable(220, isEnable);
	obj.setSkillCommandEnable(221, isEnable);
	obj.setSkillCommandEnable(222, isEnable);
	obj.setSkillCommandEnable(223, isEnable);
	obj.setSkillCommandEnable(224, isEnable);
	obj.setSkillCommandEnable(225, isEnable);
	obj.setSkillCommandEnable(226, isEnable);
	obj.setSkillCommandEnable(227, isEnable);
	obj.setSkillCommandEnable(228, isEnable);
	obj.setSkillCommandEnable(229, isEnable);
	obj.setSkillCommandEnable(230, isEnable);

	return true;
}



function onChangeSkillEffect_ATFighter111(obj, skillIndex, reciveData) {
	if (!obj) return;
	switch (skillIndex) {
		case 50:
			local readData = reciveData.readWord();
			switch (readData) {
				case 1:

					if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/appendage/ap_definitegrab.nut"))
						CNSquirrelAppendage.sq_RemoveAppendage(obj, "character/atfighter/appendage/ap_definitegrab.nut");
					local levelData = obj.sq_GetLevelData(skillIndex, 0, sq_GetSkillLevel(obj, skillIndex));
					local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skillIndex, false, "character/atfighter/appendage/ap_definitegrab.nut", false);
					appendage.sq_SetValidTime(levelData);
					CNSquirrelAppendage.sq_Append(appendage, obj, obj, false);
					break;
			}
			break;
	}
}


function drawCustomUI_SpiralInhale_by_ChangQing751675335(obj) {
	local skillLevel = sq_GetSkillLevel(obj, 238);
	if (skillLevel < 1) return;

	local aniPath = "character/fighter/effect/animation/atspiralinhale/spiralinhale_bodyshadow.ani";
	local aniPath1 = "character/fighter/effect/animation/atspiralinhale/spiralinhale_body.ani";
	local aniPath2 = "character/fighter/effect/animation/atspiralinhale/spiralinhale_gaugeline.ani";

	sq_drawBack_ChangQing751675335(obj, aniPath, 150, 474);
	sq_drawBack_ChangQing751675335(obj, aniPath1, 150, 474);
	sq_drawBack_ChangQing751675335(obj, aniPath2, 150, 474);

	if (obj.getVar("SpiralInhaleEnergy").size_vector() == 0) obj.getVar("SpiralInhaleEnergy").push_vector(0);
	local SpiralInhaleEnergy_int = obj.getVar("SpiralInhaleEnergy").get_vector(0);
	sq_drawPercentLine_ChangQing751675335(obj, SpiralInhaleEnergy_int, 1000, 150, 474);

	local apPath = "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut";
	if (!CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath)) destroyObjectByVar(obj, "SpiralGaleForcePool");
	return;
}


function sq_draw_ChangQing751675335(obj, index, xPos, yPos) {
	if (!obj) return;
	index = index.tostring();
	local filePath = "character/fighter/effect/animation/atspiralinhale/numbers/";
	local customData = {["0"] = "0.ani", ["1"] = "1.ani", ["2"] = "2.ani", ["3"] = "3.ani", ["4"] = "4.ani", ["5"] = "5.ani", ["6"] = "6.ani", ["7"] = "7.ani", ["8"] = "8.ani", ["9"] = "9.ani"}

	local customData1 = 5;
	local customData2 = index.len();

	for (local customData3 = 0; customData3 < customData2; ++customData3) {
		local customData4 = index.slice(customData3, customData3 + 1);

		if (customData.rawin(customData4)) {
			local filePath1 = "SpiralInhaleAniName" + customData4;
			local customData5 = filePath + customData[customData4];
			local sq_var = obj.getVar();
			local ani = sq_var.GetAnimationMap(filePath1, customData5);

			sq_AnimationProc(ani);
			sq_drawCurrentFrame(ani, xPos + customData3 * customData1, yPos, false);
		}
	}
}


function sq_drawBack_ChangQing751675335(obj, aniMapName, xPos, yPos) {
	local customData = aniMapName;
	local sq_var = obj.getVar();
	local ani = sq_var.GetAnimationMap(customData, aniMapName);

	sq_AnimationProc(ani);
	sq_drawCurrentFrame(ani, xPos, yPos, false);
}


function sq_drawPercentLine_ChangQing751675335(obj, index, specificIndex, xPos, yPos) {
	local aniPath = "character/fighter/effect/animation/atspiralinhale/spiralinhale_caugebarblue.ani";
	local aniPath1 = "character/fighter/effect/animation/atspiralinhale/spiralinhale_gaugebarwhite.ani";
	local aniPath2 = "character/fighter/effect/animation/atspiralinhale/spiralinhale_gaugebaryellow.ani";
	local aniPath3 = "character/fighter/effect/animation/atspiralinhale/fullgaugeeffect.ani";
	local aniPath4 = "character/fighter/effect/animation/atspiralinhale/numbers/none.ani";
	local aniPath5 = "character/fighter/effect/animation/atspiralinhale/numbers/max.ani";
	local aniPath6 = "character/fighter/effect/animation/atspiralinhale/chargegaugeeffect.ani";

	local sq_var = obj.getVar();
	if (index == specificIndex) {
		local ani = sq_var.GetAnimationMap(aniPath1, aniPath1);
		ani.setImageRate(1.0, 0.5);
		sq_AnimationProc(ani);
		sq_drawCurrentFrame(ani, xPos + 31, yPos + 11, false);
		local ani1 = sq_var.GetAnimationMap(aniPath2, aniPath2);
		ani1.setImageRate(1.0, 0.5);
		sq_AnimationProc(ani1);
		sq_drawCurrentFrame(ani1, xPos + 31, yPos + 11, false);

		local ani2 = sq_var.GetAnimationMap(aniPath5, aniPath5);
		sq_AnimationProc(ani2);
		sq_drawCurrentFrame(ani2, xPos - 70, yPos - 4, false);
	} else {
		if (index < 1) {
			local ani3 = sq_var.GetAnimationMap(aniPath4, aniPath4);
			sq_AnimationProc(ani3);
			sq_drawCurrentFrame(ani3, xPos - 65, yPos - 4, false);
		} else {
			local floatData = index / specificIndex.tofloat();
			local ani4 = sq_var.GetAnimationMap(aniPath, aniPath);
			ani4.setImageRate(1.0, 0.5);
			local customData = 138 * floatData;
			setClip(xPos - 55, yPos - 4, xPos - 55 + customData.tointeger(), yPos + 2);
			sq_AnimationProc(ani4);
			sq_drawCurrentFrame(ani4, xPos + 31, yPos + 11, false);
			releaseClip();

			sq_draw_ChangQing751675335(obj, index, xPos - 70, yPos - 4);

			local ani5 = sq_var.GetAnimationMap(aniPath6, aniPath6);
			sq_AnimationProc(ani5);
			sq_drawCurrentFrame(ani5, xPos - 55 + customData.tointeger(), yPos + 2, false);
		}
	}

	local apPath = "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut";
	if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath)) {
		local ani6 = sq_var.GetAnimationMap(aniPath3, aniPath3);
		sq_AnimationProc(ani6);
		sq_drawCurrentFrame(ani6, xPos, yPos, false);
	}
}


function IsInterval_Default(obj, ddlTime, arrName) {
	if (!obj) return false;

	local sq_var = obj.getVar(arrName).get_ct_vector(0);

	if (!sq_var) {
		obj.getVar(arrName).clear_ct_vector();
		obj.getVar(arrName).push_ct_vector();
		sq_var = obj.getVar(arrName).get_ct_vector(0);
		sq_var.Reset();
		sq_var.Start(10000, 0);
		return true;
	}

	local customData = sq_var.Get();
	if (customData > ddlTime) {
		sq_var.Reset();
		sq_var.Start(10000, 0);
		return true;
	}
	return false;
}


function createAnimationPooledForceEx(obj, aniPath, moveWithParent, xPos, yPos, zPos, aniSize) {
	local ani = sq_CreateAnimation("", aniPath);
	ani.setLoop(true);
	if (aniSize != false) {
		ani.setImageRateFromOriginal(aniSize, aniSize);
		ani.setAutoLayerWorkAnimationAddSizeRate(aniSize);
	}

	local pooledObj = sq_CreatePooledObject(ani, true);

	pooledObj.setCurrentPos(xPos, yPos, zPos);
	if (moveWithParent) sq_moveWithParent(obj, pooledObj);

	sq_SetCurrentDirection(pooledObj, obj.getDirection());

	sq_AddObject(obj, pooledObj, OBJECTTYPE_DRAWONLY, false);

	return pooledObj;
}







function procSkill_ATFighter(obj) {
	procSkill_nianqihuanrao(obj);  
	procSkill_nianzhizhanmao(obj);
	procSkill_chongyunnianqichang(obj);
}



function procSkill_nianzhizhanmao(obj) {
	if (sq_getGrowType(obj) == 1) {
		local skillLevel = sq_GetSkillLevel(obj, 40);
		if (skillLevel > 0) {
			local count = obj.getMyPassiveObjectCount(21079);
			for (local i = 0; i < count; ++i) {
				local object = obj.getMyPassiveObject(21079, i);
				if (!object) continue;
				local fanwei = obj.sq_GetIntData(117, 2);
				local sizeRate = fanwei;					
				sizeRate = sizeRate.tofloat() / 100.0;		
				local pAni = object.getCurrentAnimation();	
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);  
				if (!object.getVar("isSetCharacterStand").getBool(0)) {
					object.getVar("isSetCharacterStand").setBool(0, true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
		}
	}
}


function procSkill_chongyunnianqichang(obj) {
	if (sq_getGrowType(obj) == 1) {
		local skillLevel = sq_GetSkillLevel(obj, 40);
		if (skillLevel > 0) {
			local count = obj.getMyPassiveObjectCount(21067);
			for (local i = 0; i < count; ++i) {
				local object = obj.getMyPassiveObject(21067, i);
				if (!object) continue;
				local fanwei = obj.sq_GetIntData(120, 4);
				local sizeRate = fanwei;					
				sizeRate = sizeRate.tofloat() / 100.0;		
				local pAni = object.getCurrentAnimation();	
				pAni.setImageRateFromOriginal(sizeRate, sizeRate);
				pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);  
				if (!object.getVar("isSetCharacterStand").getBool(0)) {
					object.getVar("isSetCharacterStand").setBool(0, true);
					sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
				}
			}
		}
	}
}



function procSkill_nianqihuanrao(obj)  
{
	if (sq_getGrowType(obj) == 1) {
		local skillLevel = sq_GetSkillLevel(obj, 40);
		if (skillLevel > 0) {
			if (CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut") == true) {
				local count = obj.getMyPassiveObjectCount(21085);
				for (local i = 0; i < count; ++i) {
					local object = obj.getMyPassiveObject(21085, i);
					if (!object) continue;
					local sizeRate = 100 + 50;
					sizeRate = sizeRate.tofloat() / 100.0;
					local pAni = object.getCurrentAnimation();	
					pAni.setImageRateFromOriginal(sizeRate, sizeRate);
					pAni.setAutoLayerWorkAnimationAddSizeRate(sizeRate);  
					if (!object.getVar("isSetCharacterStand").getBool(0)) {
						object.getVar("isSetCharacterStand").setBool(0, true);
						sq_SetAttackBoundingBoxSizeRate(pAni, sizeRate, sizeRate, sizeRate);
					}
				}
			}
		}
	}
}



