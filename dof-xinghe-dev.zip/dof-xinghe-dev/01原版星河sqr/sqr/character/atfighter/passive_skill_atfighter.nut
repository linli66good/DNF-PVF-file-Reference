function ProcPassiveSkill_ATFighter(obj, skill_index, skill_level)
{
	if(skill_index == 238 && skill_level > 0)
	{
		local path = "character/atfighter/nenmaster2nd/ap_spiralinhale.nut";
		local Appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skill_index, false, path, true);
	}
 switch(skill_index)
 {

case 174:
	if(skill_level > 0)
	{
		if(!obj || sq_isPVPMode()) return;
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skill_index, false, "character/atfighter/appendage/ap_atfighter_comminterrupt.nut", true);
	}
 break;
case 254:
	if(skill_level > 0)
	{
		local appendage = CNSquirrelAppendage.sq_AppendAppendage(obj, obj, skill_index, false, "character/gunner/latentability/ap_latentability.nut", true);
	}
 break;
 }
 return true;
};

