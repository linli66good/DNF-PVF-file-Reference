

function onKeyFrameFlag_NenFlower(obj, flagIndex) {
	if (!obj) return false;
	local apPath = "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut";
	local isSpecificAp = CNSquirrelAppendage.sq_IsAppendAppendage(obj, apPath);
	if (!isSpecificAp) return;
	if (flagIndex == 1) {
		local skillLevel = sq_GetSkillLevel(obj, 237);
		local levelData = obj.sq_GetLevelData(237, 1, skillLevel) / 1000.0;
		local attackRate = obj.sq_GetBonusRateWithPassive(67, -1, 0, levelData);
		local attackRate1 = obj.sq_GetBonusRateWithPassive(67, -1, 1, levelData);
		local attackRate2 = obj.sq_GetBonusRateWithPassive(67, -1, 3, levelData);
		local levelData1 = obj.sq_GetLevelData(67, 7, sq_GetSkillLevel(obj, 67));
		obj.sq_StartWrite();
		obj.sq_WriteDword(67);
		obj.sq_WriteDword(attackRate);
		obj.sq_WriteDword(attackRate1);
		obj.sq_WriteDword(attackRate2);
		obj.sq_WriteDword(levelData1);
		obj.sq_SendCreatePassiveObjectPacket(24375, 0, 0, 1, 100);
	}
	return true;
}


function onCreateObject_atfighter_Throw(obj, createObject)
{
	if(!obj) return;
	local object = sq_GetCNRDObjectToCollisionObject(createObject);
	if(!object) return;
	if(sq_GetSkillLevel(obj, 237) > 0 && obj.getCurrentSkillIndex() == 16 && CNSquirrelAppendage.sq_IsAppendAppendage(obj, "character/atfighter/nenmaster2nd/ap_spiralgaleforce.nut") == true)
	{
		local objectindex = object.getCollisionObjectIndex();
		if(object && objectindex == 21055)
		{
			obj.sq_StartWrite();
			obj.sq_WriteDword(500);
			obj.sq_SendCreatePassiveObjectPacket(24333, 0, 85, 0, 85);
			obj.sq_StartWrite();
			obj.sq_WriteDword(501);
			obj.sq_SendCreatePassiveObjectPacket(24333, 0, 85, 0, 85);
			object.sendDestroyPacket(true);
			obj.sq_AddSetStatePacket(STATE_STAND, STATE_PRIORITY_USER, false);
		}
	}
}

