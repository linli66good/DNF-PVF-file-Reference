 
IRDSQRCharacter.pushPassiveObj("character/atgunner_3rd/po_new_atgunner.nut", 24360);

 
IRDSQRCharacter.pushScriptFiles("character/atgunner_3rd/atgunner_header.nut");


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "Character/Atgunner_3rd/crimsongarden/crimsongarden.nut", "CrimsonGarden", 112, 119);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "Character/Atgunner_3rd/ruinationarea/ruinationarea.nut", "RuinationArea", 111, 111);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner_3rd/hyperflare/hyperflare.nut", "HyperFlare", 113, 113);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner_3rd/gxstardust/gxstardust.nut", "GXStardust", 114, 114);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner_3rd/phlegethon/phlegethon.nut", "Phlegethon", 115, 115);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner_3rd/decisivebattle/decisivebattle.nut", "DecisiveBattle", 116, 116);

IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner_3rd/definitesolution/definitesolution.nut", "DefiniteSolution", 118, 118);
