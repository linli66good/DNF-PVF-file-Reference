



IRDSQRCharacter.pushPassiveObj("js60_qq506807329/share_obj/share_po_atgunner_24376.nut", 24376);
sq_RunScript("js60_qq506807329/share_obj/atgunner/setcustomdata.nut");
sq_RunScript("js60_qq506807329/share_obj/atgunner/setstate.nut");
sq_RunScript("js60_qq506807329/share_obj/atgunner/procappend.nut");
sq_RunScript("js60_qq506807329/share_obj/atgunner/onendcurrentani.nut");
sq_RunScript("js60_qq506807329/share_obj/atgunner/else.nut");

 

IRDSQRCharacter.pushScriptFiles("character/atgunner/atgunner_header.nut");  
IRDSQRCharacter.pushScriptFiles("character/atgunner/atgunner_common.nut");  
IRDSQRCharacter.pushScriptFiles("Character/atgunner/passive_skill_atgunner.nut"); 

 
 
 

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/plasmaboost/plasmaboost.nut", "atgunner_plasmaboost", 232, 232);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/fsc_7/fsc_7.nut", "atgunner_fsc_7", 233, 233);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/pt_15/pt_15.nut", "atgunner_pt_15", 234, 234);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/operationraze/operationraze.nut", "atgunner_operationraze", 235, 235);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/suppressingfire/suppressingfire.nut", "atgunner_suppressingfire", 236, 236);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/killpoint/killpoint.nut", "atgunner_killpoint", 237, 237);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/chaindevider/chaindevider.nut", "atgunner_chaindevider", 238, 238);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/bloodnchain/bloodnchain.nut", "atgunner_bloodnchain", 239, 239);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/gravitygrenade/gravitygrenade.nut", "atgunner_gravitygrenade", 240, 240);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/pistolcarbine/pistolcarbine.nut", "atgunner_pistolcarbine", 241, 241);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/openfire/openfire.nut", "atgunner_openfire", 242, 242);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/g96thermobaricgranade/g96thermobaricgranade.nut", "atgunner_g96thermobaricgranade", 243, 243);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/dday/dday.nut", "atgunner_dday", 244, 244);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/hs12/hs12.nut", "atgunner_hs12", 245, 245);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/g4/g4.nut", "atgunner_g4", 246, 246);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/gspfalcon/gspfalcon.nut", "atgunner_gspfalcon", 247, 247);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/magneticfield/magneticfield.nut", "atgunner_magneticfield", 248, 248);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/mecabolt/mecabolt.nut", "atgunner_mecabolt", 249, 249);


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "Character/atgunner/atgunner_throw.nut", "atgunner_throw", 13, -1);







IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/ATwalkshoot/ATwalkshoot.nut", "ATWalkShoot", 27, 15);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/RandomShoot/RandomShoot.nut", "NewRandomShoot", STATE_RandomShoot, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/RandomShoot/RandomShoot.nut", "RandomShoot", 24, -1);
IRDSQRCharacter.pushPassiveObj("character/atgunner/passiveobj/po_gunner_skill.nut", 24391);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/newtwingunblade/newtwingunblade.nut", "newtwingunblade", 250, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/newtwingunblade/newtwingunblade.nut", "TwinGunblade", 55, 100); 
IRDSQRCharacter.pushScriptFiles("character/atgunner/doublegunhawk/doublegunhawk.nut");
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/airraid/airraid.nut", "airraid", 152, -1); 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/chainsnatch/chainsnatch.nut", "chainsnatch", 153, 24); 


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/alphasupport/alphasupport.nut", "athouzuoli", 30, -1); 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/FlameThrower/FlameThrower.nut", "FlameThrower", 122, 13);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/FlameThrower/FlameThrower.nut", "FlameThrowerBoost", 123, 36);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/atgunner_launcher/atstingerex.nut", "atstingerex", 26, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/atgunner_launcher/atextruder.nut", "atextruder", 150, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/atgunner_launcher/pt15new.nut", "pt15new", 151, -1);


 sq_RunScript("character/atgunner/nitromotor/nitromotor.nut");
IRDSQRCharacter.pushPassiveObj("unclebang_shared_passive_object/atgunner/po_atgunner_shared.nut", 24331);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/nitromotor/nitromotor.nut", "sky_crossshoot", STATE_SKY_CROSSSHOOT, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/nitromotor/nitromotor.nut", "sky_chargebuster", STATE_SKY_CHARGEBUSTER, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/nitromotor/nitromotor.nut", "sky_napalmbomb", STATE_SKY_NAPALMBOMB, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/nitromotor/nitromotor.nut", "sky_nielsniping", STATE_SKY_NIELSNIPING, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/nitromotor/nitromotor.nut", "sky_empstorm", STATE_SKY_EMPSTORM, -1);
IRDSQRCharacter.pushPassiveObj("character/atgunner/passiveobject/po_nmy_skill.nut", 24350);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/atgunner_throw.nut", "grenade", 42, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/atchelli/atchelli.nut", "atchelli", 251, 251);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/photobilizer/photobilizer.nut", "photobilizer", STATE_photobilizer, SKILL_photobilizer);


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/overcharge/overcharge.nut", "atovercharge", 252, 252);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/overcharge/overcharge.nut", "atgunner_charge", 32, -1);


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/ATlockonsupport/ATlockonsupport.nut", "ATLockOnSupport", STATE_ATLockOnSupport, SKILL_ATLockOnSupport);


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/skill_new/atgunner_skill_new.nut", "atgunner_skill_new", 120, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/GMagnetic/GMagnetic.nut", "GMagnetic", -1, SKILL_GMagnetic);


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/MultiHeadShot/ATMultiHeadShot.nut", "ATMultiHeadShot", 37, 72);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_GUNNER, "character/atgunner/MultiHeadShot/ATMultiHeadShot.nut", "NewATMultiHeadShot", 101, 72);
