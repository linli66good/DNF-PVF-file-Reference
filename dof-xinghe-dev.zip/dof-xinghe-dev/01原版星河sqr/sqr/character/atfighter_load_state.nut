



 
IRDSQRCharacter.pushPassiveObj("js60_qq506807329/share_obj/share_po_atfighter_24375.nut", 24375);
sq_RunScript("js60_qq506807329/share_obj/atfighter/setcustomdata.nut");
sq_RunScript("js60_qq506807329/share_obj/atfighter/setstate.nut");
sq_RunScript("js60_qq506807329/share_obj/atfighter/procappend.nut");
sq_RunScript("js60_qq506807329/share_obj/atfighter/onendcurrentani.nut");
sq_RunScript("js60_qq506807329/share_obj/atfighter/else.nut");

 
 
 
IRDSQRCharacter.pushScriptFiles("character/atfighter/atfighter_header.nut");  
IRDSQRCharacter.pushScriptFiles("character/atfighter/atfighter_common.nut");  
IRDSQRCharacter.pushScriptFiles("Character/atfighter/passive_skill_atfighter.nut"); 


 
 
 

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/spiralemperorslap/spiralemperorslap.nut", "atfighter_spiralemperorslap", 220, 220);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/moonlighttheearth/moonlighttheearth.nut", "atfighter_moonlighttheearth", 221, 221);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/glancethehost/glancethehost.nut", "atfighter_glancethehost", 222, 222);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/dropfire/dropfire.nut", "atfighter_dropfire", 223, 223);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/atomiccannon/atomiccannon.nut", "atfighter_atomiccannon", 224, 224);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/emperorcombination/emperorcombination.nut", "atfighter_emperorcombination", 225, 225);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/chaindrive/chaindrive.nut", "atfighter_chaindrive", 226, 226);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/ruinrain/ruinrain.nut", "atfighter_ruinrain", 227, 227);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/fireworks/fireworks.nut", "atfighter_fireworks", 228, 228);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/cyclonecrash/cyclonecrash.nut", "atfighter_cyclonecrash", 229, 229);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/chainbrake/chainbrake.nut", "atfighter_chainbrake", 230, 230);

 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/finalextremestrike/finalextremestrike.nut", "atfighter_finalextremestrike", 231, 231);



 
 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "Character/atfighter/atfighter_buff.nut", "atfighter_buff", 17, -1);
 
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "Character/atfighter/flamelegs/flamelegs.nut", "atfighter_flamelegs", 62, -1);


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/mount/mount.nut", "Mount", 26, 14);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/mount/mount.nut", "atskill_new", 120, -1);


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "Character/atfighter/atfighter_buff.nut", "atfighter_Throw", 13, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "Character/atfighter/atfighter_buff.nut", "NenFlower", 45, 67);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/nenmaster2nd/spiralgaleforce.nut", "SpiralGaleForce", 237, 237);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/nenmaster2nd/nenspearex/nenspearex.nut", "nenspearex", 150, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/nenmaster2nd/spiralcolumnex/spiralcolumnex.nut", "SpiralColumnEx", 151, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/nenmaster2nd/lightningdragon/lightningdragon.nut", "lightningdragon", 152, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "Character/atfighter/thundercannon/thundercannon.nut", "thundercannon", 249, 249);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "Character/atfighter/thundersuplex/thundersuplex.nut", "thundersuplex", 250, 250);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "Character/atfighter/thundertiger/thundertiger.nut", "thundertiger", 251, 251);
IRDSQRCharacter.pushPassiveObj("character/atfighter/nenmaster2nd/po_sprit_nenmaster.nut", 24395);


IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/atfighter_striker/atcrashlowkick.nut", "atcrashlowkick", 153, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/atfighter_striker/atshouldercharge.nut", "atshouldercharge", 154, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/atfighter_striker/atrisingupper.nut", "atrisingupper", 155, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/atfighter_striker/atlightningdance.nut", "atlightningdance", 156, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/atfighter_striker/atrandomkick.nut", "atrandomkick", 157, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/atfighter_striker/athurricanespear.nut", "athurricanespear", 158, -1);
IRDSQRCharacter.pushState(ENUM_CHARACTERJOB_AT_FIGHTER, "character/atfighter/atfighter_striker/atomiccannonnew.nut", "atomiccannonnew", 159, -1);
